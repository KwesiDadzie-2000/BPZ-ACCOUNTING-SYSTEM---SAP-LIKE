import {
  pgTable, serial, text, varchar, numeric, timestamp, integer, bigint,
  boolean, primaryKey, index, date, jsonb,
} from "drizzle-orm/pg-core";

const money = (n: string) => numeric(n, { precision: 20, scale: 4 });
const cid = () => varchar("client_id", { length: 32 }).notNull();

/* ===================== TENANTS, USERS, SECURITY ===================== */
export const clients = pgTable("clients", {
  id: varchar("id", { length: 32 }).primaryKey(),
  name: text("name").notNull(),
  shortName: varchar("short_name", { length: 32 }).notNull().default(""),
  sector: varchar("sector", { length: 48 }).notNull().default("GENERAL"),
  isFirm: boolean("is_firm").notNull().default(false),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  tin: varchar("tin", { length: 32 }).notNull().default(""),
  vatRegistered: boolean("vat_registered").notNull().default(true),
  serviceLines: jsonb("service_lines").$type<string[]>().notNull().default([]),
  fyStartMonth: integer("fy_start_month").notNull().default(1),
  // Global reach: a workspace is not forced onto Ghanaian statutory payroll.
  country: varchar("country", { length: 2 }).notNull().default("GH"),
  payrollTaxMode: varchar("payroll_tax_mode", { length: 16 }).notNull().default("GH_PAYE"), // GH_PAYE | FLAT_RATE | NONE
  payrollFlatRatePct: numeric("payroll_flat_rate_pct", { precision: 7, scale: 3 }).notNull().default("0"),
  statutoryLabel: varchar("statutory_label", { length: 64 }).notNull().default("SSNIT"),
  active: boolean("active").notNull().default(true),
  createdBy: varchar("created_by", { length: 64 }).notNull().default("owner"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 160 }).notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 24 }).notNull().default("CLIENT_USER"),
  clientId: varchar("client_id", { length: 32 }),
  isFirmStaff: boolean("is_firm_staff").notNull().default(false),
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  tempPassword: varchar("temp_password", { length: 64 }).notNull().default(""),
  phone: varchar("phone", { length: 32 }).notNull().default(""),
  jobTitle: varchar("job_title", { length: 64 }).notNull().default(""),
  permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
  approvalLimit: money("approval_limit").notNull().default("0"),
  active: boolean("active").notNull().default(true),
  lastLoginAt: timestamp("last_login_at"),
  // Brute-force protection: failed attempts are counted and the account is
  // temporarily locked, mirroring the lockout policy of mainstream SaaS
  // accounting platforms.
  failedLogins: integer("failed_logins").notNull().default(0),
  lockedUntil: timestamp("locked_until"),
  // Self-service password reset: a hashed, time-boxed, single-use token.
  resetTokenHash: varchar("reset_token_hash", { length: 128 }).notNull().default(""),
  resetTokenExpires: timestamp("reset_token_expires"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  clientId: varchar("client_id", { length: 32 }).notNull().default(""),
  userEmail: varchar("user_email", { length: 160 }).notNull(),
  role: varchar("role", { length: 24 }).notNull(),
  action: varchar("action", { length: 64 }).notNull(),
  detail: text("detail").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [index("act_client_idx").on(t.clientId)]);

/* ===================== FISCAL CALENDAR ===================== */
export const fiscalPeriods = pgTable("fiscal_periods", {
  clientId: cid(),
  code: varchar("code", { length: 16 }).notNull(), // 2026-01
  year: integer("year").notNull(),
  period: integer("period").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  status: varchar("status", { length: 16 }).notNull().default("OPEN"), // OPEN|CLOSED|LOCKED
  closedBy: varchar("closed_by", { length: 64 }).notNull().default(""),
  closedAt: timestamp("closed_at"),
}, (t) => [primaryKey({ columns: [t.clientId, t.code] })]);

/* ===================== MASTER DATA ===================== */
export const accounts = pgTable("accounts", {
  clientId: cid(),
  accountNo: varchar("account_no", { length: 24 }).notNull(),
  description: text("description").notNull(),
  type: varchar("type", { length: 16 }).notNull(), // Asset|Liability|Equity|Revenue|Expense
  subType: varchar("sub_type", { length: 48 }).notNull().default(""),
  ifrsLine: varchar("ifrs_line", { length: 64 }).notNull().default(""),
  cashflowClass: varchar("cashflow_class", { length: 24 }).notNull().default("NONE"),
  currency: varchar("currency", { length: 8 }).notNull().default(""),
  isBank: boolean("is_bank").notNull().default(false),
  isControl: boolean("is_control").notNull().default(false),
  sector: varchar("sector", { length: 48 }).notNull().default("GENERAL"),
  active: boolean("active").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.clientId, t.accountNo] })]);

export const partners = pgTable("partners", {
  clientId: cid(),
  bpNo: varchar("bp_no", { length: 24 }).notNull(),
  name: text("name").notNull(),
  type: varchar("type", { length: 16 }).notNull(), // Vendor|Customer|Employee
  tin: varchar("tin", { length: 32 }).notNull().default(""),
  isResident: boolean("is_resident").notNull().default(true),
  whtCode: varchar("wht_code", { length: 24 }).notNull().default(""),
  vatRegistered: boolean("vat_registered").notNull().default(false),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  creditDays: integer("credit_days").notNull().default(30),
  email: varchar("email", { length: 160 }).notNull().default(""),
  phone: varchar("phone", { length: 32 }).notNull().default(""),
  active: boolean("active").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.clientId, t.bpNo] })]);

export const costCenters = pgTable("cost_centers", {
  clientId: cid(),
  ccCode: varchar("cc_code", { length: 24 }).notNull(),
  ccName: text("cc_name").notNull(),
  ccType: varchar("cc_type", { length: 24 }).notNull().default("DEPT"),
}, (t) => [primaryKey({ columns: [t.clientId, t.ccCode] })]);

export const materials = pgTable("materials", {
  clientId: cid(),
  materialNo: varchar("material_no", { length: 24 }).notNull(),
  description: text("description").notNull(),
  type: varchar("type", { length: 32 }).notNull(),
  uom: varchar("uom", { length: 12 }).notNull().default("EA"),
  valuationMethod: varchar("valuation_method", { length: 12 }).notNull().default("WAVG"),
  stdPrice: money("std_price").notNull().default("0"),
  salesPrice: money("sales_price").notNull().default("0"),
  qtyOnHand: money("qty_on_hand").notNull().default("0"),
  valueOnHand: money("value_on_hand").notNull().default("0"),
  nrv: money("nrv").notNull().default("0"),
  reorderLevel: money("reorder_level").notNull().default("0"),
  active: boolean("active").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.clientId, t.materialNo] })]);

export const stockMoves = pgTable("stock_moves", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  materialNo: varchar("material_no", { length: 24 }).notNull(),
  moveDate: date("move_date").notNull(),
  moveType: varchar("move_type", { length: 24 }).notNull(),
  qty: money("qty").notNull(),
  unitCost: money("unit_cost").notNull(),
  value: money("value").notNull(),
  balQty: money("bal_qty").notNull(),
  balValue: money("bal_value").notNull(),
  docNo: varchar("doc_no", { length: 24 }).notNull().default(""),
  reference: varchar("reference", { length: 64 }).notNull().default(""),
}, (t) => [index("sm_client_idx").on(t.clientId, t.materialNo)]);

/* ===================== CURRENCY ===================== */
export const fxRates = pgTable("fx_rates", {
  id: serial("id").primaryKey(),
  rateDate: date("rate_date").notNull(),
  currency: varchar("currency", { length: 8 }).notNull(),
  midRate: money("mid_rate").notNull(),
  buyRate: money("buy_rate").notNull().default("0"),
  sellRate: money("sell_rate").notNull().default("0"),
  source: varchar("source", { length: 32 }).notNull().default("BOG"),
  fetchedAt: timestamp("fetched_at").notNull().defaultNow(),
}, (t) => [index("fx_idx").on(t.rateDate, t.currency)]);

/* ===================== UNIVERSAL JOURNAL (ACDOCA) ===================== */
export const journalLines = pgTable("journal_lines", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  docNo: varchar("doc_no", { length: 24 }).notNull(),
  lineNo: integer("line_no").notNull(),
  postDate: date("post_date").notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  module: varchar("module", { length: 16 }).notNull(),
  docType: varchar("doc_type", { length: 12 }).notNull(),
  account: varchar("account", { length: 24 }).notNull(),
  bp: varchar("bp", { length: 24 }).notNull().default(""),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default(""),
  project: varchar("project", { length: 24 }).notNull().default(""),
  material: varchar("material", { length: 24 }).notNull().default(""),
  description: text("description").notNull().default(""),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  fxRate: money("fx_rate").notNull().default("1"),
  debitFc: money("debit_fc").notNull().default("0"),
  creditFc: money("credit_fc").notNull().default("0"),
  debit: money("debit").notNull().default("0"),
  credit: money("credit").notNull().default("0"),
  taxCode: varchar("tax_code", { length: 24 }).notNull().default(""),
  reversed: boolean("reversed").notNull().default(false),
  reversalOf: varchar("reversal_of", { length: 24 }).notNull().default(""),
  reason: text("reason").notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default("SYSTEM"),
  reference: varchar("reference", { length: 96 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("jl_client_idx").on(t.clientId, t.periodCode),
  index("jl_acct_idx").on(t.clientId, t.account),
  index("jl_doc_idx").on(t.clientId, t.docNo),
]);

/* ===================== SALES & PURCHASE DOCUMENTS ===================== */
export const tradeDocs = pgTable("trade_docs", {
  clientId: cid(),
  docNo: varchar("doc_no", { length: 24 }).notNull(),
  docKind: varchar("doc_kind", { length: 24 }).notNull(), // QUOTE|SO|SINV|SCN|SDN|PO|PINV|PCN|PDN
  side: varchar("side", { length: 8 }).notNull(), // AR|AP
  bp: varchar("bp", { length: 24 }).notNull(),
  docDate: date("doc_date").notNull(),
  dueDate: date("due_date").notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull().default(""),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  fxRate: money("fx_rate").notNull().default("1"),
  netAmount: money("net_amount").notNull().default("0"),
  vatAmount: money("vat_amount").notNull().default("0"),
  levyAmount: money("levy_amount").notNull().default("0"),
  grossAmount: money("gross_amount").notNull().default("0"),
  whtAmount: money("wht_amount").notNull().default("0"),
  settled: money("settled").notNull().default("0"),
  baseGross: money("base_gross").notNull().default("0"),
  status: varchar("status", { length: 24 }).notNull().default("DRAFT"),
  glDoc: varchar("gl_doc", { length: 24 }).notNull().default(""),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default(""),
  project: varchar("project", { length: 24 }).notNull().default(""),
  narrative: text("narrative").notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.clientId, t.docNo] })]);

export const tradeLines = pgTable("trade_lines", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  docNo: varchar("doc_no", { length: 24 }).notNull(),
  lineNo: integer("line_no").notNull(),
  materialNo: varchar("material_no", { length: 24 }).notNull().default(""),
  description: text("description").notNull().default(""),
  account: varchar("account", { length: 24 }).notNull().default(""),
  qty: money("qty").notNull().default("1"),
  unitPrice: money("unit_price").notNull().default("0"),
  discount: money("discount").notNull().default("0"),
  taxCode: varchar("tax_code", { length: 24 }).notNull().default("STD"),
  net: money("net").notNull().default("0"),
  vat: money("vat").notNull().default("0"),
  levy: money("levy").notNull().default("0"),
  total: money("total").notNull().default("0"),
}, (t) => [index("tl_idx").on(t.clientId, t.docNo)]);

/* ===================== PAYMENT DESK ===================== */
export const payments = pgTable("payments", {
  clientId: cid(),
  payNo: varchar("pay_no", { length: 24 }).notNull(),
  payDate: date("pay_date").notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull().default(""),
  direction: varchar("direction", { length: 8 }).notNull(), // OUT|IN
  // TRADE = settles an AR/AP invoice through the normal procurement/sales
  // cycle. DIRECT = a statutory remittance or direct expense (utilities,
  // PAYE/VAT/WHT/SSNIT remittance, insurance premiums, regulatory fees,
  // penalties and fines) that correctly bypasses procurement entirely.
  category: varchar("category", { length: 12 }).notNull().default("TRADE"),
  directCategory: varchar("direct_category", { length: 32 }).notNull().default(""),
  glAccount: varchar("gl_account", { length: 24 }).notNull().default(""),
  payeeName: varchar("payee_name", { length: 160 }).notNull().default(""),
  bp: varchar("bp", { length: 24 }).notNull(),
  bankAccount: varchar("bank_account", { length: 24 }).notNull(),
  method: varchar("method", { length: 24 }).notNull().default("BANK"),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  fxRate: money("fx_rate").notNull().default("1"),
  grossAmount: money("gross_amount").notNull().default("0"),
  whtCode: varchar("wht_code", { length: 24 }).notNull().default(""),
  whtRate: money("wht_rate").notNull().default("0"),
  whtAmount: money("wht_amount").notNull().default("0"),
  whtBase: money("wht_base").notNull().default("0"),
  netPaid: money("net_paid").notNull().default("0"),
  status: varchar("status", { length: 24 }).notNull().default("DRAFT"),
  approvedBy: varchar("approved_by", { length: 64 }).notNull().default(""),
  glDoc: varchar("gl_doc", { length: 24 }).notNull().default(""),
  // The realised FX gain/loss on a foreign-currency settlement is posted as a
  // SEPARATE document from the main payment (see createPayment). Without
  // tracking it here, reversing the payment left this second document
  // uncorrected in the ledger forever — a real, now-fixed gap.
  fxDoc: varchar("fx_doc", { length: 24 }).notNull().default(""),
  narrative: text("narrative").notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.clientId, t.payNo] })]);

export const paymentAllocations = pgTable("payment_allocations", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  payNo: varchar("pay_no", { length: 24 }).notNull(),
  docNo: varchar("doc_no", { length: 24 }).notNull(),
  amount: money("amount").notNull().default("0"),
}, (t) => [index("pa_idx").on(t.clientId, t.payNo)]);

/* ===================== BANKING & RECONCILIATION ===================== */
export const bankAccounts = pgTable("bank_accounts", {
  clientId: cid(),
  bankCode: varchar("bank_code", { length: 24 }).notNull(),
  bankName: text("bank_name").notNull(),
  accountNo: varchar("account_no", { length: 48 }).notNull().default(""),
  glAccount: varchar("gl_account", { length: 24 }).notNull(),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  openingBalance: money("opening_balance").notNull().default("0"),
  active: boolean("active").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.clientId, t.bankCode] })]);

export const bankStatementLines = pgTable("bank_statement_lines", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  bankCode: varchar("bank_code", { length: 24 }).notNull(),
  stmtDate: date("stmt_date").notNull(),
  narrative: text("narrative").notNull().default(""),
  reference: varchar("reference", { length: 96 }).notNull().default(""),
  debit: money("debit").notNull().default("0"),
  credit: money("credit").notNull().default("0"),
  balance: money("balance").notNull().default("0"),
  status: varchar("status", { length: 24 }).notNull().default("UNMATCHED"),
  matchedJournalId: integer("matched_journal_id"),
  suggestedAccount: varchar("suggested_account", { length: 24 }).notNull().default(""),
  postedDoc: varchar("posted_doc", { length: 24 }).notNull().default(""),
  importBatch: varchar("import_batch", { length: 32 }).notNull().default(""),
}, (t) => [index("bsl_idx").on(t.clientId, t.bankCode, t.status)]);

export const bankRecs = pgTable("bank_recs", {
  clientId: cid(),
  recNo: varchar("rec_no", { length: 24 }).notNull(),
  bankCode: varchar("bank_code", { length: 24 }).notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull(),
  statementBalance: money("statement_balance").notNull().default("0"),
  ledgerBalance: money("ledger_balance").notNull().default("0"),
  unpresentedChq: money("unpresented_chq").notNull().default("0"),
  uncreditedLodg: money("uncredited_lodg").notNull().default("0"),
  difference: money("difference").notNull().default("0"),
  status: varchar("status", { length: 16 }).notNull().default("DRAFT"),
  notes: text("notes").notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.clientId, t.recNo] })]);

/* ===================== FIXED ASSETS ===================== */
export const assets = pgTable("assets", {
  clientId: cid(),
  assetNo: varchar("asset_no", { length: 24 }).notNull(),
  description: text("description").notNull(),
  assetClass: varchar("asset_class", { length: 32 }).notNull(),
  sector: varchar("sector", { length: 48 }).notNull().default("GENERAL"),
  acquisitionDate: date("acquisition_date").notNull(),
  cost: money("cost").notNull().default("0"),
  residual: money("residual").notNull().default("0"),
  usefulLife: integer("useful_life").notNull().default(5),
  method: varchar("method", { length: 24 }).notNull().default("SL"), // SL|RB|UOP
  rbRate: money("rb_rate").notNull().default("0"),
  unitsTotal: money("units_total").notNull().default("0"),
  unitsUsed: money("units_used").notNull().default("0"),
  accumDep: money("accum_dep").notNull().default("0"),
  nbv: money("nbv").notNull().default("0"),
  revalReserve: money("reval_reserve").notNull().default("0"),
  impairment: money("impairment").notNull().default("0"),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default(""),
  capitalAllowanceClass: varchar("ca_class", { length: 16 }).notNull().default("CLASS3"),
  status: varchar("status", { length: 16 }).notNull().default("ACTIVE"),
  disposalDate: date("disposal_date"),
  disposalProceeds: money("disposal_proceeds").notNull().default("0"),
  lastDepPeriod: varchar("last_dep_period", { length: 16 }).notNull().default(""),
}, (t) => [primaryKey({ columns: [t.clientId, t.assetNo] })]);

export const depreciationRuns = pgTable("depreciation_runs", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  periodCode: varchar("period_code", { length: 16 }).notNull(),
  assetNo: varchar("asset_no", { length: 24 }).notNull(),
  amount: money("amount").notNull().default("0"),
  glDoc: varchar("gl_doc", { length: 24 }).notNull().default(""),
  runAt: timestamp("run_at").notNull().defaultNow(),
}, (t) => [index("dr_idx").on(t.clientId, t.periodCode)]);

/* ===================== PREPAYMENTS / ACCRUALS ===================== */
export const prepayments = pgTable("prepayments", {
  clientId: cid(),
  prepayNo: varchar("prepay_no", { length: 24 }).notNull(),
  kind: varchar("kind", { length: 16 }).notNull().default("PREPAY"), // PREPAY|ACCRUAL|DEFERRED
  description: text("description").notNull(),
  bp: varchar("bp", { length: 24 }).notNull().default(""),
  totalAmount: money("total_amount").notNull().default("0"),
  amortised: money("amortised").notNull().default("0"),
  balanceAccount: varchar("balance_account", { length: 24 }).notNull(),
  expenseAccount: varchar("expense_account", { length: 24 }).notNull(),
  startPeriod: varchar("start_period", { length: 16 }).notNull(),
  periods: integer("periods").notNull().default(12),
  perPeriod: money("per_period").notNull().default("0"),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default(""),
  status: varchar("status", { length: 16 }).notNull().default("ACTIVE"),
  lastRunPeriod: varchar("last_run_period", { length: 16 }).notNull().default(""),
}, (t) => [primaryKey({ columns: [t.clientId, t.prepayNo] })]);

/* ===================== PAYROLL ===================== */
export const employees = pgTable("employees", {
  clientId: cid(),
  empNo: varchar("emp_no", { length: 24 }).notNull(),
  name: text("name").notNull(),
  email: varchar("email", { length: 160 }).notNull().default(""),
  phone: varchar("phone", { length: 32 }).notNull().default(""),
  ssnit: varchar("ssnit", { length: 32 }).notNull().default(""),
  tin: varchar("tin", { length: 32 }).notNull().default(""),
  jobTitle: varchar("job_title", { length: 64 }).notNull().default(""),
  department: varchar("department", { length: 64 }).notNull().default(""),
  employmentType: varchar("employment_type", { length: 24 }).notNull().default("PERMANENT"),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default("CC-ADM"),
  basicSalary: money("basic_salary").notNull().default("0"),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  isResident: boolean("is_resident").notNull().default(true),
  ssnitApplicable: boolean("ssnit_applicable").notNull().default(true),
  tier3Employee: money("tier3_employee").notNull().default("0"),
  tier3Employer: money("tier3_employer").notNull().default("0"),
  bankCode: varchar("bank_code", { length: 24 }).notNull().default(""),
  bankAccount: varchar("bank_account", { length: 48 }).notNull().default(""),
  startDate: date("start_date"),
  terminationDate: date("termination_date"),
  active: boolean("active").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.clientId, t.empNo] })]);

/** Recurring or one-off components; basis drives how reliefs/deductions apply. */
export const payComponents = pgTable("pay_components", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  empNo: varchar("emp_no", { length: 24 }).notNull().default("*"),
  code: varchar("code", { length: 24 }).notNull(),
  name: text("name").notNull(),
  kind: varchar("kind", { length: 24 }).notNull(), // ALLOWANCE|DEDUCTION|RELIEF|EMPLOYER
  basis: varchar("basis", { length: 16 }).notNull().default("FIXED"), // FIXED|PCT_BASIC|PCT_GROSS|PCT_NET
  rate: money("rate").notNull().default("0"),
  amount: money("amount").notNull().default("0"),
  taxable: boolean("taxable").notNull().default(true),
  cashable: boolean("cashable").notNull().default(true),
  periodCode: varchar("period_code", { length: 16 }).notNull().default("*"),
  active: boolean("active").notNull().default(true),
}, (t) => [index("pc_idx").on(t.clientId, t.empNo)]);

export const payrollRuns = pgTable("payroll_runs", {
  clientId: cid(),
  runNo: varchar("run_no", { length: 24 }).notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("DRAFT"),
  grossTotal: money("gross_total").notNull().default("0"),
  payeTotal: money("paye_total").notNull().default("0"),
  ssnitEeTotal: money("ssnit_ee_total").notNull().default("0"),
  ssnitErTotal: money("ssnit_er_total").notNull().default("0"),
  netTotal: money("net_total").notNull().default("0"),
  glDoc: varchar("gl_doc", { length: 24 }).notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.clientId, t.runNo] })]);

export const payslips = pgTable("payslips", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  runNo: varchar("run_no", { length: 24 }).notNull(),
  empNo: varchar("emp_no", { length: 24 }).notNull(),
  basic: money("basic").notNull().default("0"),
  allowances: money("allowances").notNull().default("0"),
  gross: money("gross").notNull().default("0"),
  ssnitEe: money("ssnit_ee").notNull().default("0"),
  ssnitEr: money("ssnit_er").notNull().default("0"),
  tier3Ee: money("tier3_ee").notNull().default("0"),
  reliefs: money("reliefs").notNull().default("0"),
  taxable: money("taxable").notNull().default("0"),
  paye: money("paye").notNull().default("0"),
  otherDeductions: money("other_deductions").notNull().default("0"),
  net: money("net").notNull().default("0"),
  detail: jsonb("detail").$type<Record<string, number>>().notNull().default({}),
}, (t) => [index("ps_idx").on(t.clientId, t.runNo)]);

/* ===================== TAX CONFIGURATION ===================== */
export const taxRates = pgTable("tax_rates", {
  id: serial("id").primaryKey(),
  scope: varchar("scope", { length: 24 }).notNull(), // PAYE|VAT|WHT|LEVY|CIT
  code: varchar("code", { length: 32 }).notNull(),
  name: text("name").notNull(),
  rate: money("rate").notNull().default("0"),
  bandFrom: money("band_from").notNull().default("0"),
  bandTo: money("band_to").notNull().default("0"),
  residency: varchar("residency", { length: 16 }).notNull().default("ANY"),
  sector: varchar("sector", { length: 48 }).notNull().default("ALL"),
  basis: varchar("basis", { length: 24 }).notNull().default(""),
  effectiveFrom: date("effective_from").notNull(),
  effectiveTo: date("effective_to"),
  note: text("note").notNull().default(""),
  seq: integer("seq").notNull().default(0),
}, (t) => [index("tax_idx").on(t.scope, t.code)]);

/* ===================== BUDGET / FORECAST / SCENARIO ===================== */
export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  scenario: varchar("scenario", { length: 32 }).notNull().default("BASE"),
  fiscalYear: integer("fiscal_year").notNull(),
  periodCode: varchar("period_code", { length: 16 }).notNull(),
  account: varchar("account", { length: 24 }).notNull(),
  costCenter: varchar("cost_center", { length: 24 }).notNull().default(""),
  amount: money("amount").notNull().default("0"),
  note: text("note").notNull().default(""),
}, (t) => [index("bud_idx").on(t.clientId, t.scenario, t.fiscalYear)]);

/* ===================== PROJECTS (construction / O&G / mining) ===================== */
export const projects = pgTable("projects", {
  clientId: cid(),
  projectNo: varchar("project_no", { length: 24 }).notNull(),
  name: text("name").notNull(),
  sector: varchar("sector", { length: 48 }).notNull().default("GENERAL"),
  kind: varchar("kind", { length: 32 }).notNull().default("CONTRACT"),
  customer: varchar("customer", { length: 24 }).notNull().default(""),
  contractValue: money("contract_value").notNull().default("0"),
  budgetCost: money("budget_cost").notNull().default("0"),
  costToDate: money("cost_to_date").notNull().default("0"),
  billedToDate: money("billed_to_date").notNull().default("0"),
  pctComplete: money("pct_complete").notNull().default("0"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  status: varchar("status", { length: 16 }).notNull().default("ACTIVE"),
  meta: jsonb("meta").$type<Record<string, string | number>>().notNull().default({}),
}, (t) => [primaryKey({ columns: [t.clientId, t.projectNo] })]);

/* ===================== PRACTICE MANAGEMENT (BPZ service delivery) ===================== */
export const engagements = pgTable("engagements", {
  clientId: cid(),
  engNo: varchar("eng_no", { length: 24 }).notNull(),
  serviceLine: varchar("service_line", { length: 48 }).notNull(),
  title: text("title").notNull(),
  templateKey: varchar("template_key", { length: 48 }).notNull().default(""),
  periodCode: varchar("period_code", { length: 16 }).notNull().default(""),
  assignedTo: varchar("assigned_to", { length: 160 }).notNull().default(""),
  status: varchar("status", { length: 24 }).notNull().default("PLANNED"),
  feeAmount: money("fee_amount").notNull().default("0"),
  currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
  chargeTo: varchar("charge_to", { length: 16 }).notNull().default("CLIENT"),
  dueDate: date("due_date"),
  quantitative: jsonb("quantitative").$type<Record<string, number>>().notNull().default({}),
  qualitative: jsonb("qualitative").$type<Record<string, string>>().notNull().default({}),
  checklist: jsonb("checklist").$type<{ item: string; done: boolean; note: string }[]>().notNull().default([]),
  conclusion: text("conclusion").notNull().default(""),
  createdBy: varchar("created_by", { length: 64 }).notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [primaryKey({ columns: [t.clientId, t.engNo] })]);

export const timesheets = pgTable("timesheets", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  engNo: varchar("eng_no", { length: 24 }).notNull().default(""),
  staffEmail: varchar("staff_email", { length: 160 }).notNull(),
  workDate: date("work_date").notNull(),
  hours: money("hours").notNull().default("0"),
  chargeRate: money("charge_rate").notNull().default("0"),
  billable: boolean("billable").notNull().default(true),
  narrative: text("narrative").notNull().default(""),
  billedDoc: varchar("billed_doc", { length: 24 }).notNull().default(""),
}, (t) => [index("ts_idx").on(t.clientId, t.staffEmail)]);

/* ===================== APPROVALS ===================== */
export const approvals = pgTable("approvals", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  refType: varchar("ref_type", { length: 24 }).notNull(),
  refNo: varchar("ref_no", { length: 24 }).notNull(),
  amount: money("amount").notNull().default("0"),
  requestedBy: varchar("requested_by", { length: 160 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("PENDING"),
  decidedBy: varchar("decided_by", { length: 160 }).notNull().default(""),
  decidedAt: timestamp("decided_at"),
  note: text("note").notNull().default(""),
  // Maker-checker: the original request is held here, unexecuted, until a
  // user holding PAY_APPROVE (with sufficient approvalLimit) approves it.
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [index("appr_idx").on(t.clientId, t.status)]);

/* ===================== ATTACHMENTS ===================== */
/**
 * Supporting documents (receipts, signed contracts, delivery notes) attached
 * to any transaction. Stored as base64 text directly in Postgres — no
 * external object storage is configured for this deployment, so this is the
 * honest, portable way to give users real attachment capability today. A
 * 4 MB per-file cap keeps rows small; swapping to S3/Blob storage later only
 * requires changing how `data` is populated, not the schema shape consumers read.
 */
export const attachments = pgTable("attachments", {
  id: serial("id").primaryKey(),
  clientId: cid(),
  refType: varchar("ref_type", { length: 24 }).notNull(), // TRADE_DOC | JOURNAL | PAYMENT | ASSET | ENGAGEMENT
  refNo: varchar("ref_no", { length: 32 }).notNull(),
  fileName: varchar("file_name", { length: 200 }).notNull(),
  mimeType: varchar("mime_type", { length: 100 }).notNull().default("application/octet-stream"),
  sizeBytes: integer("size_bytes").notNull().default(0),
  data: text("data").notNull(), // base64
  note: text("note").notNull().default(""),
  uploadedBy: varchar("uploaded_by", { length: 160 }).notNull().default(""),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
}, (t) => [index("attach_idx").on(t.clientId, t.refType, t.refNo)]);

/* ===================== NUMBER RANGES ===================== */
export const numberRanges = pgTable("number_ranges", {
  clientId: cid(),
  rangeKey: varchar("range_key", { length: 24 }).notNull(),
  current: bigint("current", { mode: "number" }).notNull(),
}, (t) => [primaryKey({ columns: [t.clientId, t.rangeKey] })]);
