import { db } from "@/db";
import { taxRates } from "@/db/schema";
import { and, asc, eq, lte, or, isNull, gte } from "drizzle-orm";

export type Band = { from: number; to: number; rate: number };

/* =======================================================================
   PAYE — Income Tax (Amendment) Act, 2026 (Act 1178), effective 1 Sep 2026.
   Monthly resident graduated bands. Annual = monthly x 12 (reconciles to
   GHS 600,000 top threshold).
   ======================================================================= */
export const PAYE_BANDS_2026_09: { width: number; rate: number; label: string }[] = [
  { width: 588, rate: 0, label: "First 588" },
  { width: 80, rate: 5, label: "Next 80" },
  { width: 100, rate: 10, label: "Next 100" },
  { width: 2900, rate: 17.5, label: "Next 2,900" },
  { width: 16000, rate: 25, label: "Next 16,000" },
  { width: 30332, rate: 30, label: "Next 30,332" },
  { width: Number.MAX_SAFE_INTEGER, rate: 35, label: "Exceeding 50,000" },
];

/** Superseded schedule kept so prior periods still compute correctly. */
export const PAYE_BANDS_2025: { width: number; rate: number; label: string }[] = [
  { width: 490, rate: 0, label: "First 490" },
  { width: 110, rate: 5, label: "Next 110" },
  { width: 130, rate: 10, label: "Next 130" },
  { width: 3166.67, rate: 17.5, label: "Next 3,166.67" },
  { width: 16000, rate: 25, label: "Next 16,000" },
  { width: 30520, rate: 30, label: "Next 30,520" },
  { width: Number.MAX_SAFE_INTEGER, rate: 35, label: "Exceeding 50,416.67" },
];

export const NON_RESIDENT_EMPLOYMENT_RATE = 25;

export const SSNIT = { employee: 5.5, employerTier1: 13, tier1Share: 13.5, tier2Share: 5, tier3CapPct: 16.5 };

/** Statutory personal reliefs (annual GHS) — editable in the Tax Centre. */
export const PERSONAL_RELIEFS = [
  { code: "MARRIAGE", name: "Marriage / Responsibility Relief", annual: 1200, basis: "FIXED" },
  { code: "CHILD_EDU", name: "Child Education Relief (per child, max 3)", annual: 600, basis: "FIXED" },
  { code: "OLD_AGE", name: "Old Age Relief (60+)", annual: 1500, basis: "FIXED" },
  { code: "AGED_DEPENDANT", name: "Aged Dependant Relief (max 2)", annual: 1000, basis: "FIXED" },
  { code: "TRAINING", name: "Professional / Technical Training Relief", annual: 2000, basis: "FIXED" },
  { code: "DISABILITY", name: "Disability Relief (25% of assessable income)", annual: 0, basis: "PCT_ASSESSABLE" },
];

/* ===================== VAT & LEVIES ===================== */
export const VAT_CODES = [
  { code: "STD", name: "Standard rated VAT (non-cascading)", rate: 20, levy: 0, recoverable: true },
  { code: "ZERO", name: "Zero rated (exports)", rate: 0, levy: 0, recoverable: true },
  { code: "EXEMPT", name: "Exempt supply", rate: 0, levy: 0, recoverable: false },
  { code: "OUT", name: "Outside the scope of VAT", rate: 0, levy: 0, recoverable: false },
  { code: "RC", name: "Reverse charge (imported services)", rate: 20, levy: 0, recoverable: true },
  { code: "FLAT", name: "VAT Flat Rate Scheme (retail)", rate: 3, levy: 0, recoverable: false },
  { code: "TOURISM", name: "Standard VAT + Tourism Levy 1%", rate: 20, levy: 1, recoverable: true },
  { code: "CST", name: "Standard VAT + Communication Service Tax 5%", rate: 20, levy: 5, recoverable: true },
];

/* ===================== WITHHOLDING TAX — comprehensive ===================== */
export type WhtDef = {
  code: string; name: string; rate: number; residency: "RESIDENT" | "NON_RESIDENT";
  category: string; note: string;
};

export const WHT_RATES: WhtDef[] = [
  // ---- Resident ----
  { code: "R_GOODS", name: "Supply of goods (contract > GHS 2,000)", rate: 3, residency: "RESIDENT", category: "Supply", note: "s.116 Act 896" },
  { code: "R_WORKS", name: "Supply of works", rate: 5, residency: "RESIDENT", category: "Supply", note: "Construction & civil works" },
  { code: "R_SERVICES", name: "Supply of services / general services fee", rate: 7.5, residency: "RESIDENT", category: "Supply", note: "Professional & technical services" },
  { code: "R_DIVIDEND", name: "Dividend to resident", rate: 8, residency: "RESIDENT", category: "Investment", note: "Final tax" },
  { code: "R_INTEREST", name: "Interest to resident individual", rate: 8, residency: "RESIDENT", category: "Investment", note: "Final tax for individuals" },
  { code: "R_RENT_RES", name: "Rent — residential property (investment)", rate: 8, residency: "RESIDENT", category: "Rent", note: "Final tax" },
  { code: "R_RENT_COM", name: "Rent — commercial property (investment)", rate: 15, residency: "RESIDENT", category: "Rent", note: "Final tax" },
  { code: "R_ROYALTY", name: "Royalties to resident", rate: 15, residency: "RESIDENT", category: "Investment", note: "" },
  { code: "R_NATRES", name: "Natural resource payment", rate: 15, residency: "RESIDENT", category: "Extractives", note: "" },
  { code: "R_DIRECTOR", name: "Director's fees / board allowance (resident individual)", rate: 20, residency: "RESIDENT", category: "Fees", note: "Non-executive directors" },
  { code: "R_COMM_INS", name: "Commission to insurance agents & sales persons", rate: 10, residency: "RESIDENT", category: "Commission", note: "" },
  { code: "R_COMM_LOTTO", name: "Commission to lotto receivers & agents", rate: 10, residency: "RESIDENT", category: "Commission", note: "" },
  { code: "R_ENDORSE", name: "Endorsement / promotion fees (resident)", rate: 10, residency: "RESIDENT", category: "Fees", note: "" },
  { code: "R_LOTTERY", name: "Lottery / gaming winnings", rate: 10, residency: "RESIDENT", category: "Other", note: "Final tax" },
  { code: "R_PETRO_SUB", name: "Petroleum subcontractor (resident)", rate: 7.5, residency: "RESIDENT", category: "Extractives", note: "Ring-fenced, final" },
  { code: "R_MINERAL", name: "Unprocessed precious minerals purchase", rate: 1.5, residency: "RESIDENT", category: "Extractives", note: "Licensed buyers / small-scale gold" },
  { code: "R_FEES_PART", name: "Fees / allowances to part-time teachers, examiners, invigilators", rate: 10, residency: "RESIDENT", category: "Fees", note: "Final tax" },
  { code: "R_TRANSPORT", name: "Carriage & haulage of goods (resident)", rate: 3, residency: "RESIDENT", category: "Supply", note: "Treated as supply of goods/works" },
  { code: "R_RENT_BUS", name: "Rent as business income (resident)", rate: 15, residency: "RESIDENT", category: "Rent", note: "On account, not final" },
  { code: "R_INSURANCE", name: "Insurance premium to resident insurer", rate: 0, residency: "RESIDENT", category: "Insurance", note: "Not subject to WHT" },
  { code: "R_EXEMPT", name: "Exempt / WHT exemption certificate holder", rate: 0, residency: "RESIDENT", category: "Exempt", note: "Valid GRA exemption required" },
  // ---- Non-resident ----
  { code: "NR_DIVIDEND", name: "Dividend to non-resident", rate: 8, residency: "NON_RESIDENT", category: "Investment", note: "Subject to DTA" },
  { code: "NR_INTEREST", name: "Interest to non-resident", rate: 8, residency: "NON_RESIDENT", category: "Investment", note: "Subject to DTA" },
  { code: "NR_ROYALTY", name: "Royalties to non-resident", rate: 15, residency: "NON_RESIDENT", category: "Investment", note: "Subject to DTA" },
  { code: "NR_NATRES", name: "Natural resource payment to non-resident", rate: 15, residency: "NON_RESIDENT", category: "Extractives", note: "" },
  { code: "NR_MGMT", name: "Management & technical service fees (non-resident)", rate: 20, residency: "NON_RESIDENT", category: "Fees", note: "Subject to DTA" },
  { code: "NR_SERVICES", name: "General services by non-resident", rate: 20, residency: "NON_RESIDENT", category: "Supply", note: "" },
  { code: "NR_GOODS", name: "Supply of goods by non-resident", rate: 20, residency: "NON_RESIDENT", category: "Supply", note: "" },
  { code: "NR_WORKS", name: "Supply of works by non-resident", rate: 20, residency: "NON_RESIDENT", category: "Supply", note: "" },
  { code: "NR_ENDORSE", name: "Endorsement fees to non-resident", rate: 20, residency: "NON_RESIDENT", category: "Fees", note: "" },
  { code: "NR_ENTERTAIN", name: "Non-resident entertainers & sportspersons", rate: 20, residency: "NON_RESIDENT", category: "Fees", note: "Final tax" },
  { code: "NR_INSURANCE", name: "Short-term insurance premium to non-resident", rate: 5, residency: "NON_RESIDENT", category: "Insurance", note: "Final tax" },
  { code: "NR_SHIPPING", name: "Non-resident shipping / sea transport income", rate: 15, residency: "NON_RESIDENT", category: "Transport", note: "Final tax" },
  { code: "NR_AIR", name: "Non-resident air transport income", rate: 15, residency: "NON_RESIDENT", category: "Transport", note: "Final tax" },
  { code: "NR_TELECOM", name: "Non-resident telecom / transport of messages out of Ghana", rate: 15, residency: "NON_RESIDENT", category: "Transport", note: "Final tax" },
  { code: "NR_BRANCH", name: "Repatriated branch after-tax profits", rate: 8, residency: "NON_RESIDENT", category: "Investment", note: "s.60 Act 896" },
  { code: "NR_PETRO_SUB", name: "Petroleum subcontractor (non-resident)", rate: 15, residency: "NON_RESIDENT", category: "Extractives", note: "Final, ring-fenced" },
  { code: "NR_MINING_SUB", name: "Mining subcontractor (non-resident)", rate: 15, residency: "NON_RESIDENT", category: "Extractives", note: "Final" },
  { code: "NR_RENT", name: "Rent to non-resident", rate: 15, residency: "NON_RESIDENT", category: "Rent", note: "Final tax" },
  { code: "NR_DTA", name: "Reduced rate under Double Taxation Agreement", rate: 0, residency: "NON_RESIDENT", category: "Treaty", note: "Enter the treaty rate manually" },
];

/* ===================== CORPORATE / SECTOR TAX ===================== */
export const CIT_RATES = [
  { code: "CIT_STD", name: "Standard corporate income tax", rate: 25, sector: "ALL" },
  { code: "CIT_MINING", name: "Mining companies", rate: 35, sector: "MINING" },
  { code: "CIT_PETROLEUM", name: "Petroleum (upstream) operations", rate: 35, sector: "OIL_GAS_UPSTREAM" },
  { code: "CIT_FINANCIAL", name: "Financial institutions (banks)", rate: 25, sector: "BANKING" },
  { code: "CIT_FZ_EXPORT", name: "Free Zone — export sales after concession", rate: 15, sector: "FREE_ZONE" },
  { code: "CIT_FZ_LOCAL", name: "Free Zone — domestic market sales", rate: 25, sector: "FREE_ZONE" },
  { code: "CIT_HOTEL", name: "Hotels and hospitality", rate: 22, sector: "HOSPITALITY" },
  { code: "CIT_AGRO", name: "Agro-processing (after concession)", rate: 25, sector: "AGRO_PROCESSING" },
  { code: "CIT_NONTRAD_EXPORT", name: "Non-traditional exports", rate: 8, sector: "ALL" },
  { code: "GSL_MINING", name: "Growth & Sustainability Levy — mining/upstream", rate: 1, sector: "MINING" },
  { code: "GSL_BANKS", name: "Growth & Sustainability Levy — banks & specified", rate: 5, sector: "BANKING" },
  { code: "GSL_OTHER", name: "Growth & Sustainability Levy — all other entities", rate: 2.5, sector: "ALL" },
  { code: "ROYALTY_MINERAL", name: "Mineral royalty on gross revenue", rate: 5, sector: "MINING" },
  { code: "ROYALTY_PETRO", name: "Petroleum royalty on gross production", rate: 5, sector: "OIL_GAS_UPSTREAM" },
];

/* ===================== COMPUTATION ===================== */
const r2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function payeBandsFor(periodStart: string) {
  return periodStart >= "2026-09-01" ? PAYE_BANDS_2026_09 : PAYE_BANDS_2025;
}

/** Progressive PAYE on monthly chargeable income. Returns tax + band trace. */
export function computePaye(chargeable: number, periodStart: string, isResident = true) {
  if (chargeable <= 0) return { tax: 0, trace: [] as { label: string; amount: number; rate: number; tax: number }[] };
  if (!isResident) {
    const tax = r2((chargeable * NON_RESIDENT_EMPLOYMENT_RATE) / 100);
    return { tax, trace: [{ label: "Non-resident flat", amount: chargeable, rate: NON_RESIDENT_EMPLOYMENT_RATE, tax }] };
  }
  const bands = payeBandsFor(periodStart);
  let remaining = chargeable;
  let tax = 0;
  const trace: { label: string; amount: number; rate: number; tax: number }[] = [];
  for (const b of bands) {
    if (remaining <= 0) break;
    const slice = Math.min(remaining, b.width);
    const t = r2((slice * b.rate) / 100);
    tax += t;
    trace.push({ label: b.label, amount: r2(slice), rate: b.rate, tax: t });
    remaining -= slice;
  }
  return { tax: r2(tax), trace };
}

/** VAT at 20% with NO cascading: levies are computed on the net, not on VAT. */
export function computeVat(net: number, code: string) {
  const def = VAT_CODES.find((v) => v.code === code) ?? VAT_CODES[0];
  const vat = r2((net * def.rate) / 100);
  const levy = r2((net * def.levy) / 100);
  return { vat, levy, total: r2(net + vat + levy), rate: def.rate, levyRate: def.levy, recoverable: def.recoverable };
}

export function whtFor(code: string) {
  return WHT_RATES.find((w) => w.code === code);
}

export function computeWht(base: number, code: string, overrideRate?: number) {
  const def = whtFor(code);
  const rate = overrideRate ?? def?.rate ?? 0;
  return { rate, amount: r2((base * rate) / 100) };
}

/* ===================== DB-BACKED OVERRIDES (owner editable) ===================== */
export async function seedTaxRates() {
  const existing = await db.select({ id: taxRates.id }).from(taxRates).limit(1);
  if (existing.length) return;
  const rows: (typeof taxRates.$inferInsert)[] = [];
  let cum = 0;
  PAYE_BANDS_2026_09.forEach((b, i) => {
    const from = cum;
    const to = b.width === Number.MAX_SAFE_INTEGER ? 0 : cum + b.width;
    cum = to || cum;
    rows.push({
      scope: "PAYE", code: `BAND_${i + 1}`, name: b.label, rate: String(b.rate),
      bandFrom: String(from), bandTo: String(to), residency: "RESIDENT",
      basis: "MONTHLY_CHARGEABLE", effectiveFrom: "2026-09-01", seq: i + 1,
      note: "Income Tax (Amendment) Act, 2026 (Act 1178)",
    });
  });
  let cum5 = 0;
  PAYE_BANDS_2025.forEach((b, i) => {
    const from = cum5;
    const to = b.width === Number.MAX_SAFE_INTEGER ? 0 : cum5 + b.width;
    cum5 = to || cum5;
    rows.push({
      scope: "PAYE", code: `BAND_${i + 1}`, name: b.label, rate: String(b.rate),
      bandFrom: String(from), bandTo: String(to), residency: "RESIDENT",
      basis: "MONTHLY_CHARGEABLE", effectiveFrom: "2025-01-01", effectiveTo: "2026-08-31",
      seq: i + 1, note: "Superseded schedule",
    });
  });
  rows.push({
    scope: "PAYE", code: "NON_RESIDENT", name: "Non-resident employment income (flat)",
    rate: String(NON_RESIDENT_EMPLOYMENT_RATE), residency: "NON_RESIDENT",
    basis: "MONTHLY_CHARGEABLE", effectiveFrom: "2015-01-01", seq: 99, note: "s.115 Act 896",
  });
  for (const v of VAT_CODES) {
    rows.push({
      scope: "VAT", code: v.code, name: v.name, rate: String(v.rate),
      basis: v.levy ? `LEVY_${v.levy}` : "", effectiveFrom: "2026-01-01",
      note: "VAT 20% — non-cascading; levies computed on the net value",
    });
  }
  for (const w of WHT_RATES) {
    rows.push({
      scope: "WHT", code: w.code, name: w.name, rate: String(w.rate),
      residency: w.residency, basis: w.category, effectiveFrom: "2015-01-01", note: w.note,
    });
  }
  for (const c of CIT_RATES) {
    rows.push({
      scope: "CIT", code: c.code, name: c.name, rate: String(c.rate),
      sector: c.sector, effectiveFrom: "2015-01-01", note: "",
    });
  }
  for (const rlf of PERSONAL_RELIEFS) {
    rows.push({
      scope: "PAYE", code: `RELIEF_${rlf.code}`, name: rlf.name, rate: "0",
      bandFrom: String(rlf.annual), basis: rlf.basis, residency: "RESIDENT",
      effectiveFrom: "2015-01-01", note: "Annual relief amount (GHS)", seq: 200,
    });
  }
  await db.insert(taxRates).values(rows);
}

/** Effective rate lookup honouring effectiveFrom/To, so historic periods stay correct. */
export async function effectiveRate(scope: string, code: string, onDate: string) {
  const rows = await db
    .select()
    .from(taxRates)
    .where(and(
      eq(taxRates.scope, scope),
      eq(taxRates.code, code),
      lte(taxRates.effectiveFrom, onDate),
      or(isNull(taxRates.effectiveTo), gte(taxRates.effectiveTo, onDate)),
    ))
    .orderBy(asc(taxRates.seq));
  return rows;
}
