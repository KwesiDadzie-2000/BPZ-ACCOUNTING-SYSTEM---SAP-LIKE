/* ============ SECTORS (full coverage of the Ghanaian economy) ============ */
export type SectorDef = {
  key: string;
  name: string;
  group: string;
  regulator: string;
  notes: string;
  specialTax: string[];
};

export const SECTORS: SectorDef[] = [
  { key: "GENERAL", name: "General / Diversified", group: "Cross-sector", regulator: "GRA / RGD", notes: "Default template for mixed operations.", specialTax: ["CIT 25%"] },
  { key: "MANUFACTURING", name: "Manufacturing", group: "Industry", regulator: "GRA, GSA, EPA", notes: "BOM, WIP, absorption costing, variance analysis (IAS 2).", specialTax: ["CIT 25%", "Excise (selected)", "Import duty"] },
  { key: "AGRO_PROCESSING", name: "Agro-Processing", group: "Industry", regulator: "GRA, FDA, GSA", notes: "Temporary concession rates; biological to inventory transfer.", specialTax: ["CIT concession", "IAS 41 → IAS 2"] },
  { key: "PHARMA", name: "Pharmaceuticals", group: "Industry", regulator: "FDA, GRA", notes: "Batch traceability, expiry provisioning, NRV testing.", specialTax: ["CIT 25%", "VAT exempt (selected drugs)"] },
  { key: "TEXTILES", name: "Textiles & Apparel", group: "Industry", regulator: "GRA, GSA", notes: "Conversion costing, seasonal stock obsolescence.", specialTax: ["CIT 25%"] },
  { key: "PRINTING", name: "Printing & Packaging", group: "Industry", regulator: "GRA", notes: "Job costing per print order.", specialTax: ["CIT 25%"] },
  { key: "AUTOMOTIVE", name: "Automotive Assembly & Trade", group: "Industry", regulator: "GRA, DVLA", notes: "GAMDP incentives, CKD/SKD duty treatment.", specialTax: ["CIT concession", "Import duty"] },
  { key: "CONSTRUCTION", name: "Construction & Civil Works", group: "Projects", regulator: "GRA, MWH", notes: "IFRS 15 over-time revenue, retentions, IPCs, variations, WIP.", specialTax: ["WHT 5% works", "VAT 20%"] },
  { key: "REAL_ESTATE", name: "Real Estate & Property", group: "Projects", regulator: "GRA, Lands Commission", notes: "IAS 40 investment property, IFRS 15 unit sales, rent WHT.", specialTax: ["Rent WHT 8%/15%", "CGT on realisation"] },
  { key: "OIL_GAS_UPSTREAM", name: "Oil & Gas — Upstream", group: "Extractives", regulator: "PC, GRA, GNPC, PIAC", notes: "Ring-fenced per contract area; IFRS 6 E&E; cost oil / profit oil; decommissioning (IAS 37).", specialTax: ["Petroleum CIT 35%", "Royalty 5%", "AOE / carried interest", "Branch profit 8%", "Subcontractor WHT 15% NR / 7.5% R"] },
  { key: "OIL_GAS_MIDSTREAM", name: "Oil & Gas — Midstream", group: "Extractives", regulator: "NPA, PC, GRA", notes: "Throughput tariffs, pipeline capacity, take-or-pay.", specialTax: ["CIT 25%", "NPA levies"] },
  { key: "OIL_GAS_DOWNSTREAM", name: "Petroleum Downstream / OMC", group: "Extractives", regulator: "NPA, GRA", notes: "UPPF, price build-up, bulk stock, specific excise per litre.", specialTax: ["Energy levies", "ESLA", "Excise per litre", "CIT 25%"] },
  { key: "MINING", name: "Mining & Quarrying", group: "Extractives", regulator: "Minerals Commission, GRA, EPA", notes: "IFRS 6, stripping cost (IFRIC 20), UOP depreciation, rehabilitation provision.", specialTax: ["Mineral royalty 5%", "Mining CIT 35%", "Capital allowance 20% SL", "GRIF"] },
  { key: "ENERGY_POWER", name: "Energy & Power Generation", group: "Utilities", regulator: "PURC, Energy Commission", notes: "PPA accounting, IFRIC 12 service concession, capacity vs energy charge.", specialTax: ["CIT 25%", "VAT on commercial supply"] },
  { key: "WATER_UTILITY", name: "Water & Sanitation Utility", group: "Utilities", regulator: "PURC, GWCL", notes: "Tariff regulation, unbilled revenue accrual.", specialTax: ["CIT 25%"] },
  { key: "WASTE_ENV", name: "Waste Management & Environment", group: "Utilities", regulator: "EPA, MMDAs", notes: "Landfill restoration provisions.", specialTax: ["CIT 25%"] },
  { key: "BANKING", name: "Banking & Finance", group: "Financial", regulator: "Bank of Ghana", notes: "IFRS 9 ECL staging, BoG prudential returns, capital adequacy.", specialTax: ["CIT 25%", "Financial sector levy", "NFSL 5%"] },
  { key: "INSURANCE", name: "Insurance", group: "Financial", regulator: "NIC", notes: "IFRS 17 contract groups, UPR, IBNR, claims reserving.", specialTax: ["CIT 25%", "NR premium WHT 5%"] },
  { key: "MICROFINANCE", name: "Microfinance / Savings & Loans", group: "Financial", regulator: "Bank of Ghana", notes: "Loan book staging, portfolio at risk.", specialTax: ["CIT 25%"] },
  { key: "CAPITAL_MARKETS", name: "Capital Markets & Fund Management", group: "Financial", regulator: "SEC Ghana, GSE", notes: "IFRS 9 FVTPL, NAV per unit, client asset segregation.", specialTax: ["CIT 25%", "Interest WHT 8%"] },
  { key: "FINTECH", name: "Fintech & Mobile Money", group: "Financial", regulator: "BoG (PSP licence)", notes: "E-money float trust accounting, settlement reconciliation.", specialTax: ["CIT 25%", "VAT on fees"] },
  { key: "TELECOM", name: "Telecommunications", group: "Services", regulator: "NCA, GRA", notes: "IFRS 15 bundles, deferred airtime, tower sharing, spectrum intangibles.", specialTax: ["CST 5%", "VAT 20%", "NCA levy"] },
  { key: "ICT_SOFTWARE", name: "ICT & Software", group: "Services", regulator: "NITA, GRA", notes: "SaaS deferred revenue, IAS 38 development cost capitalisation.", specialTax: ["CIT 25%", "NR service WHT 20%"] },
  { key: "MEDIA", name: "Media, Advertising & Creative", group: "Services", regulator: "NMC, NCA", notes: "Airtime inventory, production WIP, endorsement WHT.", specialTax: ["Endorsement WHT 10%/20%"] },
  { key: "PROFESSIONAL_SERVICES", name: "Professional & Consulting Services", group: "Services", regulator: "GRA, professional bodies", notes: "WIP on time, engagement profitability, recoverability.", specialTax: ["Service WHT 7.5%", "VAT 20%"] },
  { key: "LEGAL", name: "Legal Practice", group: "Services", regulator: "General Legal Council", notes: "Client trust accounts strictly segregated from office account.", specialTax: ["Service WHT 7.5%"] },
  { key: "HEALTHCARE", name: "Healthcare & Hospitals", group: "Services", regulator: "MOH, HeFRA, NHIA", notes: "NHIS claims receivable and rejection provisioning.", specialTax: ["VAT exempt (medical)", "CIT 25%"] },
  { key: "EDUCATION", name: "Education & Training", group: "Services", regulator: "GES, GTEC", notes: "Deferred tuition over terms, scholarship contra revenue.", specialTax: ["VAT exempt (approved)", "CIT 25%"] },
  { key: "HOSPITALITY", name: "Hospitality, Hotels & Restaurants", group: "Services", regulator: "GTA, GRA", notes: "RevPAR, F&B costing, tourism levy.", specialTax: ["Tourism levy 1%", "VAT 20%"] },
  { key: "TOURISM", name: "Tourism & Travel", group: "Services", regulator: "Ghana Tourism Authority", notes: "Agency vs principal (IFRS 15) for ticketing.", specialTax: ["Tourism levy 1%"] },
  { key: "TRANSPORT_LOGISTICS", name: "Transport & Logistics", group: "Trade & Logistics", regulator: "GRA, DVLA", notes: "Fleet costing per vehicle, fuel control, haulage margin.", specialTax: ["CIT 25%", "Carriage WHT"] },
  { key: "SHIPPING_PORTS", name: "Shipping, Ports & Freight", group: "Trade & Logistics", regulator: "GPHA, GMA", notes: "Voyage accounting, demurrage, non-resident carrier tax.", specialTax: ["NR sea/air transport 15%"] },
  { key: "AVIATION", name: "Aviation", group: "Trade & Logistics", regulator: "GCAA", notes: "Aircraft leases (IFRS 16), maintenance reserves.", specialTax: ["NR air transport 15%"] },
  { key: "RETAIL_WHOLESALE", name: "Retail & Wholesale Trade", group: "Trade & Logistics", regulator: "GRA, RGD", notes: "POS integration, shrinkage, margin by SKU.", specialTax: ["VAT 20%", "Goods WHT 3%"] },
  { key: "FREE_ZONE", name: "Free Zone Enterprise", group: "Trade & Logistics", regulator: "GFZA, GRA", notes: "Export vs local sales split drives the tax rate.", specialTax: ["0% first 10 yrs", "15% thereafter", "Local sales 25%"] },
  { key: "AGRIC", name: "Agriculture & Crop Production", group: "Primary", regulator: "MoFA, GRA", notes: "IAS 41 biological assets at fair value less cost to sell.", specialTax: ["Farming concessions", "CIT exemption window"] },
  { key: "COCOA", name: "Cocoa & Commodity Trading", group: "Primary", regulator: "COCOBOD, GRA", notes: "Licensed buying company margins, evacuation costing.", specialTax: ["Concessionary CIT"] },
  { key: "FISHERIES", name: "Fisheries & Aquaculture", group: "Primary", regulator: "Fisheries Commission", notes: "Vessel costing, catch valuation.", specialTax: ["Farming concessions"] },
  { key: "LIVESTOCK", name: "Livestock & Poultry", group: "Primary", regulator: "MoFA, Vet Services", notes: "Biological asset growth (IAS 41), feed conversion.", specialTax: ["Farming concessions"] },
  { key: "FORESTRY", name: "Forestry & Timber", group: "Primary", regulator: "Forestry Commission", notes: "Concession rights amortisation, reforestation provision.", specialTax: ["Timber royalty", "Export levy"] },
  { key: "NGO_NPO", name: "NGO / Not-for-Profit", group: "Public & Social", regulator: "RGD, Dept. of Social Welfare", notes: "Fund accounting, donor restriction tracking, grant compliance.", specialTax: ["Exempt (approved)", "PAYE/WHT still apply"] },
  { key: "PUBLIC_SECTOR", name: "Public Sector / MDA / MMDA", group: "Public & Social", regulator: "CAGD, Audit Service", notes: "IPSAS-aligned classification, GIFMIS-style votes, commitment control.", specialTax: ["Withholding agent obligations"] },
  { key: "RELIGIOUS", name: "Religious & Faith-Based", group: "Public & Social", regulator: "RGD", notes: "Offering/tithe income streams, project funds.", specialTax: ["Exempt on non-business", "PAYE on staff"] },
  { key: "COOPERATIVE", name: "Cooperatives & Associations", group: "Public & Social", regulator: "Dept. of Cooperatives", notes: "Member equity, patronage refunds.", specialTax: ["Concessionary"] },
  { key: "SPORTS", name: "Sports & Entertainment", group: "Public & Social", regulator: "NSA, GRA", notes: "Player registration intangibles, gate receipts.", specialTax: ["NR entertainer 20%"] },
  { key: "SECURITY", name: "Security Services", group: "Services", regulator: "Ministry of Interior", notes: "Guard deployment costing per site.", specialTax: ["Service WHT 7.5%"] },
  { key: "MINING_SUPPORT", name: "Mining & Petroleum Support Services", group: "Extractives", regulator: "Minerals Commission, PC", notes: "Subcontractor registration and ring-fenced WHT.", specialTax: ["Subcontractor WHT 7.5% R / 15% NR"] },
];

export const SECTOR_KEYS = SECTORS.map((s) => s.key);
export const sectorName = (k: string) => SECTORS.find((s) => s.key === k)?.name ?? k;

/* ============ BPZ SERVICE LINES ============ */
export const SERVICE_LINES = [
  { key: "BOOKKEEPING", name: "Accounting & Bookkeeping", color: "emerald" },
  { key: "PAYROLL", name: "Payroll Services", color: "sky" },
  { key: "TAX", name: "Tax Planning & Preparation", color: "amber" },
  { key: "ADVISORY", name: "Business Advisory", color: "violet" },
  { key: "AUDIT_SUPPORT", name: "Audit Support & Readiness", color: "rose" },
  { key: "CFO", name: "Virtual CFO / Management Accounts", color: "indigo" },
  { key: "COMPLIANCE", name: "Statutory & Regulatory Compliance", color: "teal" },
  { key: "VALUATION", name: "Valuation & Transaction Support", color: "orange" },
  { key: "RISK", name: "Risk, Internal Control & Governance", color: "slate" },
  { key: "TRAINING", name: "Training & Capacity Building", color: "cyan" },
];

/* ============ ROLES & PERMISSIONS ============ */
export const PERMISSIONS = [
  "GL_POST", "GL_REVERSE", "AR_MANAGE", "AP_MANAGE", "PAY_CREATE", "PAY_APPROVE",
  "BANK_MANAGE", "BANK_RECONCILE", "ASSET_MANAGE", "INVENTORY_MANAGE",
  "PAYROLL_MANAGE", "TAX_MANAGE", "BUDGET_MANAGE", "PERIOD_CLOSE",
  "ADVISORY_MANAGE", "REPORT_VIEW", "MASTER_MANAGE", "USER_MANAGE", "SYSTEM_ADMIN",
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export const ROLES: Record<string, { name: string; perms: Permission[] }> = {
  OWNER: { name: "Firm Owner / Managing Partner", perms: [...PERMISSIONS] },
  FIRM_MANAGER: {
    name: "Firm Manager",
    perms: ["GL_POST", "GL_REVERSE", "AR_MANAGE", "AP_MANAGE", "PAY_CREATE", "PAY_APPROVE", "BANK_MANAGE", "BANK_RECONCILE", "ASSET_MANAGE", "INVENTORY_MANAGE", "PAYROLL_MANAGE", "TAX_MANAGE", "BUDGET_MANAGE", "PERIOD_CLOSE", "ADVISORY_MANAGE", "REPORT_VIEW", "MASTER_MANAGE"],
  },
  FIRM_STAFF: {
    name: "Firm Staff / Associate",
    perms: ["GL_POST", "AR_MANAGE", "AP_MANAGE", "PAY_CREATE", "BANK_MANAGE", "BANK_RECONCILE", "ASSET_MANAGE", "INVENTORY_MANAGE", "PAYROLL_MANAGE", "ADVISORY_MANAGE", "REPORT_VIEW"],
  },
  CLIENT_ADMIN: {
    name: "Client Administrator",
    perms: ["GL_POST", "AR_MANAGE", "AP_MANAGE", "PAY_CREATE", "PAY_APPROVE", "BANK_MANAGE", "BANK_RECONCILE", "ASSET_MANAGE", "INVENTORY_MANAGE", "PAYROLL_MANAGE", "BUDGET_MANAGE", "REPORT_VIEW", "MASTER_MANAGE", "USER_MANAGE"],
  },
  CLIENT_USER: {
    name: "Client User",
    perms: ["GL_POST", "AR_MANAGE", "AP_MANAGE", "PAY_CREATE", "REPORT_VIEW"],
  },
  CLIENT_VIEWER: { name: "Client Viewer (read-only)", perms: ["REPORT_VIEW"] },
};

/* ============ FIXED ASSET CLASSES ============ */
export type AssetClassDef = {
  key: string; name: string; life: number; method: "SL" | "RB" | "UOP";
  rate: number; caClass: string; sectors: string[];
};

export const ASSET_CLASSES: AssetClassDef[] = [
  // --- General (all sectors) ---
  { key: "LAND", name: "Land (not depreciated)", life: 0, method: "SL", rate: 0, caClass: "NONE", sectors: ["*"] },
  { key: "BUILDING", name: "Buildings & Structures", life: 50, method: "SL", rate: 2, caClass: "CLASS5", sectors: ["*"] },
  { key: "LEASEHOLD", name: "Leasehold Improvements", life: 10, method: "SL", rate: 10, caClass: "CLASS5", sectors: ["*"] },
  { key: "PLANT", name: "Plant & Machinery", life: 10, method: "SL", rate: 10, caClass: "CLASS2", sectors: ["*"] },
  { key: "MOTOR", name: "Motor Vehicles", life: 5, method: "SL", rate: 20, caClass: "CLASS2", sectors: ["*"] },
  { key: "FURNITURE", name: "Furniture & Fittings", life: 8, method: "SL", rate: 12.5, caClass: "CLASS3", sectors: ["*"] },
  { key: "OFFICE_EQUIP", name: "Office Equipment", life: 5, method: "SL", rate: 20, caClass: "CLASS3", sectors: ["*"] },
  { key: "COMPUTER", name: "Computers & Hardware", life: 3, method: "SL", rate: 33.33, caClass: "CLASS1", sectors: ["*"] },
  { key: "SOFTWARE", name: "Software & Intangibles", life: 4, method: "SL", rate: 25, caClass: "CLASS4", sectors: ["*"] },
  { key: "ROU_ASSET", name: "Right-of-Use Asset (IFRS 16)", life: 5, method: "SL", rate: 20, caClass: "NONE", sectors: ["*"] },
  // --- Manufacturing / industry ---
  { key: "PROD_LINE", name: "Production Line & Tooling", life: 12, method: "UOP", rate: 0, caClass: "CLASS2", sectors: ["MANUFACTURING", "AGRO_PROCESSING", "PHARMA", "TEXTILES", "PRINTING", "AUTOMOTIVE"] },
  { key: "MOULDS", name: "Moulds, Dies & Jigs", life: 4, method: "UOP", rate: 0, caClass: "CLASS2", sectors: ["MANUFACTURING", "AUTOMOTIVE", "PRINTING"] },
  { key: "COLD_CHAIN", name: "Cold Chain & Refrigeration", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["PHARMA", "AGRO_PROCESSING", "FISHERIES", "HOSPITALITY"] },
  // --- Construction ---
  { key: "HEAVY_EQUIP", name: "Heavy Construction Equipment", life: 8, method: "RB", rate: 20, caClass: "CLASS2", sectors: ["CONSTRUCTION", "MINING"] },
  { key: "SCAFFOLD", name: "Scaffolding & Formwork", life: 5, method: "SL", rate: 20, caClass: "CLASS3", sectors: ["CONSTRUCTION"] },
  { key: "SITE_CABIN", name: "Site Cabins & Temporary Works", life: 4, method: "SL", rate: 25, caClass: "CLASS3", sectors: ["CONSTRUCTION", "MINING", "OIL_GAS_UPSTREAM"] },
  // --- Oil & gas ---
  { key: "EE_ASSET", name: "Exploration & Evaluation Asset (IFRS 6)", life: 0, method: "UOP", rate: 0, caClass: "PETROLEUM", sectors: ["OIL_GAS_UPSTREAM", "MINING"] },
  { key: "DEV_WELL", name: "Development Wells & Completions", life: 0, method: "UOP", rate: 0, caClass: "PETROLEUM", sectors: ["OIL_GAS_UPSTREAM"] },
  { key: "FPSO", name: "FPSO / Production Facility", life: 20, method: "UOP", rate: 0, caClass: "PETROLEUM", sectors: ["OIL_GAS_UPSTREAM"] },
  { key: "PIPELINE", name: "Pipelines & Flowlines", life: 25, method: "SL", rate: 4, caClass: "PETROLEUM", sectors: ["OIL_GAS_UPSTREAM", "OIL_GAS_MIDSTREAM", "ENERGY_POWER"] },
  { key: "DECOMM_ASSET", name: "Decommissioning Asset (IAS 37)", life: 20, method: "SL", rate: 5, caClass: "NONE", sectors: ["OIL_GAS_UPSTREAM", "MINING"] },
  { key: "FUEL_STATION", name: "Retail Fuel Station & Dispensers", life: 15, method: "SL", rate: 6.67, caClass: "CLASS2", sectors: ["OIL_GAS_DOWNSTREAM"] },
  { key: "BULK_TANK", name: "Bulk Storage Tanks & Depots", life: 25, method: "SL", rate: 4, caClass: "CLASS2", sectors: ["OIL_GAS_DOWNSTREAM", "OIL_GAS_MIDSTREAM"] },
  // --- Mining ---
  { key: "MINE_DEV", name: "Mine Development & Shafts", life: 0, method: "UOP", rate: 0, caClass: "MINERAL", sectors: ["MINING"] },
  { key: "STRIPPING", name: "Deferred Stripping Asset (IFRIC 20)", life: 0, method: "UOP", rate: 0, caClass: "MINERAL", sectors: ["MINING"] },
  { key: "PROCESS_PLANT", name: "Ore Processing & CIL Plant", life: 15, method: "UOP", rate: 0, caClass: "MINERAL", sectors: ["MINING"] },
  { key: "TAILINGS", name: "Tailings Storage Facility", life: 15, method: "UOP", rate: 0, caClass: "MINERAL", sectors: ["MINING"] },
  { key: "REHAB_ASSET", name: "Mine Rehabilitation Asset", life: 15, method: "SL", rate: 6.67, caClass: "NONE", sectors: ["MINING"] },
  // --- Energy / utilities ---
  { key: "GENERATION", name: "Generation Plant & Turbines", life: 25, method: "SL", rate: 4, caClass: "CLASS2", sectors: ["ENERGY_POWER"] },
  { key: "SOLAR", name: "Solar / Renewable Installation", life: 20, method: "SL", rate: 5, caClass: "CLASS2", sectors: ["ENERGY_POWER", "AGRIC"] },
  { key: "TRANSMISSION", name: "Transmission & Distribution Network", life: 30, method: "SL", rate: 3.33, caClass: "CLASS2", sectors: ["ENERGY_POWER", "WATER_UTILITY"] },
  { key: "METERS", name: "Meters & Metering Infrastructure", life: 10, method: "SL", rate: 10, caClass: "CLASS3", sectors: ["ENERGY_POWER", "WATER_UTILITY"] },
  // --- Telecom / ICT ---
  { key: "NETWORK", name: "Network & Transmission Equipment", life: 8, method: "SL", rate: 12.5, caClass: "CLASS1", sectors: ["TELECOM", "ICT_SOFTWARE"] },
  { key: "TOWER", name: "Towers & Masts", life: 15, method: "SL", rate: 6.67, caClass: "CLASS2", sectors: ["TELECOM"] },
  { key: "SPECTRUM", name: "Spectrum Licence (intangible)", life: 15, method: "SL", rate: 6.67, caClass: "CLASS4", sectors: ["TELECOM"] },
  { key: "DATACENTRE", name: "Data Centre Infrastructure", life: 10, method: "SL", rate: 10, caClass: "CLASS1", sectors: ["ICT_SOFTWARE", "BANKING", "TELECOM"] },
  // --- Transport / logistics ---
  { key: "TRUCK_FLEET", name: "Heavy Trucks & Trailers", life: 8, method: "UOP", rate: 0, caClass: "CLASS2", sectors: ["TRANSPORT_LOGISTICS", "MINING", "OIL_GAS_DOWNSTREAM"] },
  { key: "VESSEL", name: "Marine Vessels & Barges", life: 25, method: "SL", rate: 4, caClass: "CLASS2", sectors: ["SHIPPING_PORTS", "FISHERIES", "OIL_GAS_UPSTREAM"] },
  { key: "AIRCRAFT", name: "Aircraft & Engines", life: 20, method: "UOP", rate: 0, caClass: "CLASS2", sectors: ["AVIATION"] },
  { key: "HANDLING", name: "Port / Cargo Handling Equipment", life: 12, method: "SL", rate: 8.33, caClass: "CLASS2", sectors: ["SHIPPING_PORTS", "AVIATION"] },
  // --- Agriculture ---
  { key: "BEARER_PLANT", name: "Bearer Plants (IAS 16)", life: 25, method: "SL", rate: 4, caClass: "CLASS5", sectors: ["AGRIC", "COCOA", "FORESTRY"] },
  { key: "FARM_EQUIP", name: "Tractors & Farm Machinery", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["AGRIC", "COCOA", "LIVESTOCK"] },
  { key: "IRRIGATION", name: "Irrigation Infrastructure", life: 15, method: "SL", rate: 6.67, caClass: "CLASS2", sectors: ["AGRIC"] },
  { key: "LIVESTOCK_PROD", name: "Productive Livestock (breeding)", life: 6, method: "SL", rate: 16.67, caClass: "CLASS2", sectors: ["LIVESTOCK", "AGRIC"] },
  // --- Health / education / hospitality ---
  { key: "MEDICAL_EQUIP", name: "Medical & Diagnostic Equipment", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["HEALTHCARE"] },
  { key: "LAB", name: "Laboratory Equipment", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["HEALTHCARE", "PHARMA", "MINING", "EDUCATION"] },
  { key: "SCHOOL_BUS", name: "School Buses & Student Transport", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["EDUCATION"] },
  { key: "HOTEL_FF", name: "Hotel Furniture, Fittings & Equipment", life: 7, method: "SL", rate: 14.29, caClass: "CLASS3", sectors: ["HOSPITALITY", "TOURISM"] },
  { key: "KITCHEN", name: "Commercial Kitchen Equipment", life: 8, method: "SL", rate: 12.5, caClass: "CLASS2", sectors: ["HOSPITALITY"] },
  // --- Financial ---
  { key: "ATM", name: "ATMs & Self-Service Terminals", life: 7, method: "SL", rate: 14.29, caClass: "CLASS1", sectors: ["BANKING", "MICROFINANCE", "FINTECH"] },
  { key: "SECURITY_SYS", name: "Security & Surveillance Systems", life: 6, method: "SL", rate: 16.67, caClass: "CLASS3", sectors: ["BANKING", "SECURITY", "RETAIL_WHOLESALE", "*"] },
];

export const CA_CLASSES: Record<string, { name: string; rate: number; method: string }> = {
  CLASS1: { name: "Class 1 — Computers & data handling", rate: 40, method: "Reducing balance" },
  CLASS2: { name: "Class 2 — Plant, machinery, vehicles", rate: 30, method: "Reducing balance" },
  CLASS3: { name: "Class 3 — Furniture, fixtures, general", rate: 20, method: "Reducing balance" },
  CLASS4: { name: "Class 4 — Intangibles / intellectual property", rate: 0, method: "Straight line over useful life" },
  CLASS5: { name: "Class 5 — Buildings & structures", rate: 10, method: "Straight line" },
  MINERAL: { name: "Mineral & petroleum rights", rate: 20, method: "Straight line (5 yrs)" },
  PETROLEUM: { name: "Petroleum capital expenditure", rate: 20, method: "Straight line (5 yrs)" },
  NONE: { name: "Not eligible for capital allowance", rate: 0, method: "—" },
};

export const CURRENCIES = ["GHS", "USD", "GBP", "EUR", "NGN", "ZAR", "CNY", "JPY", "CAD", "AUD", "CHF", "XOF", "KES"];

/* ============ GLOBAL REACH — countries & payroll tax regimes ============
   Ghana runs the full statutory PAYE/SSNIT engine. Every other country runs
   a configurable flat-rate or no-withholding scheme so the platform can
   onboard a client anywhere without silently mis-applying Ghanaian law. */
export type CountryDef = { code: string; name: string; currency: string; defaultFlatRate: number; statutoryLabel: string };

export const COUNTRIES: CountryDef[] = [
  { code: "GH", name: "Ghana", currency: "GHS", defaultFlatRate: 0, statutoryLabel: "SSNIT" },
  { code: "NG", name: "Nigeria", currency: "NGN", defaultFlatRate: 10, statutoryLabel: "Pension (PenCom)" },
  { code: "ZA", name: "South Africa", currency: "ZAR", defaultFlatRate: 18, statutoryLabel: "UIF" },
  { code: "KE", name: "Kenya", currency: "KES", defaultFlatRate: 15, statutoryLabel: "NSSF" },
  { code: "US", name: "United States", currency: "USD", defaultFlatRate: 12, statutoryLabel: "Social Security / FICA" },
  { code: "GB", name: "United Kingdom", currency: "GBP", defaultFlatRate: 20, statutoryLabel: "National Insurance" },
  { code: "CA", name: "Canada", currency: "CAD", defaultFlatRate: 15, statutoryLabel: "CPP / EI" },
  { code: "AE", name: "United Arab Emirates", currency: "USD", defaultFlatRate: 0, statutoryLabel: "GPSSA (nationals only)" },
  { code: "IN", name: "India", currency: "USD", defaultFlatRate: 10, statutoryLabel: "Provident Fund (EPFO)" },
  { code: "DE", name: "Germany", currency: "EUR", defaultFlatRate: 25, statutoryLabel: "Sozialversicherung" },
  { code: "FR", name: "France", currency: "EUR", defaultFlatRate: 22, statutoryLabel: "Sécurité sociale" },
  { code: "CI", name: "Côte d'Ivoire", currency: "XOF", defaultFlatRate: 15, statutoryLabel: "CNPS" },
  { code: "TG", name: "Togo", currency: "XOF", defaultFlatRate: 15, statutoryLabel: "CNSS" },
  { code: "ZZ", name: "Other / Global (generic)", currency: "USD", defaultFlatRate: 0, statutoryLabel: "Social Security" },
];

export const PAYROLL_TAX_MODES = [
  { key: "GH_PAYE", name: "Ghana statutory PAYE + SSNIT (Act 1178)" },
  { key: "FLAT_RATE", name: "Configurable flat-rate withholding" },
  { key: "NONE", name: "No payroll tax withholding (gross-to-net only)" },
];

export const EMPLOYMENT_TYPES = ["PERMANENT", "CONTRACT", "TEMPORARY", "INTERN", "PART_TIME", "CONSULTANT"];

/* ============ DIRECT / STATUTORY PAYMENTS ============
   Not every outgoing payment represents a purchase of goods or services from
   a supplier. Utilities, every category of tax and statutory remittance,
   pension and provident fund contributions, insurance premiums, other
   regulatory payments, and penalties/fines are paid directly — there is no
   purchase order, no goods receipt and often no "vendor invoice" to raise.
   Forcing these through the procurement (AP) cycle would be both incorrect
   accounting practice and needless clerical work, so they get their own
   lightweight direct-posting path straight to the correct G/L account. */
export type DirectPaymentCategory = {
  key: string; label: string; group: string; account: string; direction: "OUT" | "IN";
  hint: string; suggestedBp?: string;
  /**
   * True when this category can also be raised as a Direct/Statutory Invoice
   * first (recognising the liability when the bill/assessment is received)
   * and settled later — in full or in part — through the Payment Desk, the
   * same way a supplier invoice works. False for items that are entirely
   * self-assessed from figures already in the ledger (PAYE, VAT, WHT, CIT
   * instalments, SSNIT, Tier 3) — there is no external invoice to record for
   * these; the liability already exists the moment payroll is posted or VAT
   * is settled, so only a direct payment is needed to clear it.
   */
  invoiceable: boolean;
};

export const DIRECT_PAYMENT_CATEGORIES: DirectPaymentCategory[] = [
  // ---- Statutory tax & levy remittances (self-assessed; no invoice step) ----
  { key: "PAYE_REMIT", label: "PAYE remittance to GRA", group: "Taxes & Statutory Remittances", account: "420300", direction: "OUT", hint: "Clears the PAYE payable created automatically when payroll is posted. Due by the 15th of the following month.", suggestedBp: "GRA", invoiceable: false },
  { key: "VAT_REMIT", label: "VAT remittance to GRA", group: "Taxes & Statutory Remittances", account: "420200", direction: "OUT", hint: "Settles the net VAT control balance. Due by the last working day of the following month.", suggestedBp: "GRA", invoiceable: false },
  { key: "WHT_REMIT", label: "Withholding tax remittance to GRA", group: "Taxes & Statutory Remittances", account: "420400", direction: "OUT", hint: "Remits tax withheld from suppliers and employees. Due by the 15th of the following month.", suggestedBp: "GRA", invoiceable: false },
  { key: "CIT_REMIT", label: "Corporate income tax / instalment to GRA", group: "Taxes & Statutory Remittances", account: "420500", direction: "OUT", hint: "Quarterly self-assessment instalments or the final annual settlement.", suggestedBp: "GRA", invoiceable: false },
  { key: "OTHER_LEVY", label: "Other statutory levy (GETFund, NHIL, COVID levy, etc.)", group: "Taxes & Statutory Remittances", account: "421000", direction: "OUT", hint: "Any other levy collected alongside VAT or billed separately by GRA.", suggestedBp: "GRA", invoiceable: true },
  // ---- Pension & provident fund (self-assessed from payroll; no invoice step) ----
  { key: "SSNIT_T1", label: "SSNIT Tier 1 remittance", group: "Pension & Provident Fund", account: "420600", direction: "OUT", hint: "The mandatory basic national pension scheme — employee 5.5% plus employer's 13.5% share. Due by the 14th of the following month.", suggestedBp: "SSNIT", invoiceable: false },
  { key: "SSNIT_T2", label: "SSNIT Tier 2 remittance", group: "Pension & Provident Fund", account: "420700", direction: "OUT", hint: "The mandatory occupational pension scheme, usually remitted to a licensed trustee.", suggestedBp: "SSNIT", invoiceable: false },
  { key: "PROVIDENT_T3", label: "Tier 3 provident fund remittance", group: "Pension & Provident Fund", account: "420800", direction: "OUT", hint: "The voluntary third-tier provident fund, remitted to the chosen fund manager.", invoiceable: false },
  // ---- Insurance — a real premium invoice arrives; recognise it, pay later ----
  { key: "INSURANCE_PREMIUM", label: "Insurance premium payment", group: "Insurance", account: "710400", direction: "OUT", hint: "Property, motor, liability or other insurance premiums paid directly to the insurer.", invoiceable: true },
  // ---- Utilities & regulatory — a bill or assessment arrives first ----
  { key: "UTILITIES", label: "Utility bill (electricity, water)", group: "Utilities & Regulatory", account: "710200", direction: "OUT", hint: "ECG, GWCL or similar utility bills paid directly, without a supplier invoice in the system.", invoiceable: true },
  { key: "REGULATORY_FEE", label: "Regulatory fee, permit or licence", group: "Utilities & Regulatory", account: "721700", direction: "OUT", hint: "Business operating permits, sector regulator fees, inspection charges and similar statutory payments.", invoiceable: true },
  { key: "BANK_CHARGE", label: "Bank charges & commissions", group: "Utilities & Regulatory", account: "720800", direction: "OUT", hint: "Ledger fees, commission on turnover, SMS alerts and other bank-deducted charges. Usually discovered when the bank statement is imported.", invoiceable: false },
  // ---- Penalties & fines — a formal demand or assessment arrives first ----
  { key: "PENALTY_FINE", label: "Penalty, fine or interest on late payment", group: "Penalties & Fines", account: "760300", direction: "OUT", hint: "Non-deductible for tax purposes. Always keep the regulator's assessment or demand notice as support.", invoiceable: true },
  // ---- Catch-all ----
  { key: "OTHER_DIRECT", label: "Other direct payment", group: "Other", account: "", direction: "OUT", hint: "Any other payment that does not relate to a purchase order or supplier invoice — choose the G/L account manually.", invoiceable: true },
];
