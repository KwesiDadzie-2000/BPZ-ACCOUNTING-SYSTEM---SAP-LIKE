import ExcelJS from "exceljs";
import { db } from "@/db";
import { accounts, clients, partners, payments, tradeDocs } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  ageing, assetRegister, balanceSheet, budgetVsActual, cashFlow, changesInEquity,
  incomeStatement, inventoryValuation, journal, kpis, payrollRegister, trialBalance, vatSchedule,
  whtSchedule, type Filter,
} from "./reports";

const BRAND = "FF0B3B5C";
const ACCENT = "FFC9A227";

type Col = { header: string; key: string; width?: number; money?: boolean };

/**
 * Neutralises CSV/Excel formula injection (OWASP). Any string value beginning
 * with =, +, -, @, tab or carriage return is prefixed with a leading
 * apostrophe so spreadsheet applications render it as literal text instead
 * of evaluating it as a formula when a user opens the export.
 */
function sanitiseCell(v: string): string {
  return /^[=+\-@\t\r]/.test(v) ? `'${v}` : v;
}

/** Builds the full multi-sheet workbook. Returns a real .xlsx buffer. */
export async function buildWorkbook(clientId: string, f: Filter = {}) {
  const [client] = await db.select().from(clients).where(eq(clients.id, clientId));
  const wb = new ExcelJS.Workbook();
  wb.creator = "BPZ Enterprise Platform";
  wb.created = new Date();

  const sheet = (name: string, cols: Col[], rows: Record<string, unknown>[], title?: string) => {
    const ws = wb.addWorksheet(name.slice(0, 31), { views: [{ state: "frozen", ySplit: title ? 4 : 1 }] });
    let r = 1;
    if (title) {
      ws.mergeCells(1, 1, 1, Math.max(cols.length, 1));
      const c = ws.getCell(1, 1);
      c.value = `${client?.name ?? clientId} — ${title}`;
      c.font = { bold: true, size: 13, color: { argb: "FFFFFFFF" } };
      c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: BRAND } };
      c.alignment = { vertical: "middle" };
      ws.getRow(1).height = 24;
      ws.mergeCells(2, 1, 2, Math.max(cols.length, 1));
      const s = ws.getCell(2, 1);
      s.value = `Period ${f.from ?? "opening"} to ${f.to ?? "latest"}  ·  Currency ${client?.currency ?? "GHS"}  ·  Generated ${new Date().toLocaleString()}  ·  Prepared under IFRS`;
      s.font = { italic: true, size: 9, color: { argb: "FF555555" } };
      r = 4;
    }
    const head = ws.getRow(r);
    cols.forEach((col, i) => {
      const cell = head.getCell(i + 1);
      cell.value = col.header;
      cell.font = { bold: true, size: 10, color: { argb: "FFFFFFFF" } };
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: BRAND } };
      cell.border = { bottom: { style: "thin", color: { argb: ACCENT } } };
      ws.getColumn(i + 1).width = col.width ?? 18;
    });
    head.commit();
    rows.forEach((row, ri) => {
      const xr = ws.getRow(r + 1 + ri);
      cols.forEach((col, i) => {
        const cell = xr.getCell(i + 1);
        const v = row[col.key];
        cell.value = (v === undefined || v === null)
          ? ""
          : typeof v === "string" ? sanitiseCell(v) : (v as number);
        if (col.money) { cell.numFmt = "#,##0.00;(#,##0.00)"; cell.alignment = { horizontal: "right" }; }
        if (row.__bold) cell.font = { bold: true };
        if (row.__header) {
          cell.font = { bold: true, color: { argb: BRAND } };
          cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF2F4F8" } };
        }
      });
      xr.commit();
    });
    if (rows.length && cols.length) {
      ws.autoFilter = { from: { row: r, column: 1 }, to: { row: r, column: cols.length } };
    }
    return ws;
  };

  const M = (h: string, k: string, w = 16) => ({ header: h, key: k, width: w, money: true });

  // 1 — Cover
  const cover = wb.addWorksheet("Cover");
  cover.getColumn(1).width = 34; cover.getColumn(2).width = 60;
  cover.mergeCells(1, 1, 1, 2);
  const title = cover.getCell(1, 1);
  title.value = "BPZ ENTERPRISE FINANCIAL PLATFORM";
  title.font = { bold: true, size: 18, color: { argb: "FFFFFFFF" } };
  title.fill = { type: "pattern", pattern: "solid", fgColor: { argb: BRAND } };
  cover.getRow(1).height = 34;
  [
    ["Entity", client?.name ?? clientId],
    ["Workspace ID", clientId],
    ["Sector", client?.sector ?? ""],
    ["Reporting currency", client?.currency ?? "GHS"],
    ["TIN", client?.tin || "Not recorded"],
    ["Period from", f.from ?? "Opening"],
    ["Period to", f.to ?? "Latest"],
    ["Framework", "IFRS / IAS as adopted in Ghana"],
    ["Tax basis", "Income Tax Act 2015 (Act 896) as amended; VAT 20% non-cascading"],
    ["Generated", new Date().toLocaleString()],
  ].forEach(([k, v], i) => {
    const row = cover.getRow(i + 3);
    row.getCell(1).value = k; row.getCell(1).font = { bold: true };
    row.getCell(2).value = v;
  });

  const [tb, is, bs, cf, soc, k] = await Promise.all([
    trialBalance(clientId, f), incomeStatement(clientId, f), balanceSheet(clientId, f),
    cashFlow(clientId, f), changesInEquity(clientId, f), kpis(clientId, f),
  ]);

  sheet("KPI Dashboard",
    [{ header: "Measure", key: "m", width: 36 }, M("Value", "v", 20)],
    Object.entries(k).filter(([, v]) => typeof v === "number").map(([m, v]) => ({ m, v })),
    "Key Performance Indicators");

  sheet("Income Statement",
    [{ header: "Line", key: "label", width: 52 }, M("Amount", "amount", 20)],
    is.lines.map((l) => ({ label: l.label, amount: l.amount, __bold: l.bold })),
    "Statement of Profit or Loss and Other Comprehensive Income");

  sheet("Balance Sheet",
    [{ header: "Account", key: "a", width: 14 }, { header: "Description", key: "d", width: 46 },
     { header: "IFRS line", key: "i", width: 34 }, M("Amount", "v", 18)],
    [
      { a: "", d: "NON-CURRENT ASSETS", i: "", v: "", __header: true },
      ...bs.nonCurrentAssets.map((r) => ({ a: r.accountNo, d: r.description, i: r.ifrsLine, v: r.closing })),
      { a: "", d: "Total non-current assets", i: "", v: bs.totals.totalNCA, __bold: true },
      { a: "", d: "CURRENT ASSETS", i: "", v: "", __header: true },
      ...bs.currentAssets.map((r) => ({ a: r.accountNo, d: r.description, i: r.ifrsLine, v: r.closing })),
      { a: "", d: "Total current assets", i: "", v: bs.totals.totalCA, __bold: true },
      { a: "", d: "TOTAL ASSETS", i: "", v: bs.totals.totalAssets, __bold: true },
      { a: "", d: "EQUITY", i: "", v: "", __header: true },
      ...bs.equity.map((r) => ({ a: r.accountNo, d: r.description, i: r.ifrsLine, v: -r.closing })),
      { a: "", d: "Profit for the period", i: "Retained earnings", v: bs.totals.retainedProfit },
      { a: "", d: "Total equity", i: "", v: bs.totals.totalEquity, __bold: true },
      { a: "", d: "NON-CURRENT LIABILITIES", i: "", v: "", __header: true },
      ...bs.nonCurrentLiabilities.map((r) => ({ a: r.accountNo, d: r.description, i: r.ifrsLine, v: -r.closing })),
      { a: "", d: "CURRENT LIABILITIES", i: "", v: "", __header: true },
      ...bs.currentLiabilities.map((r) => ({ a: r.accountNo, d: r.description, i: r.ifrsLine, v: -r.closing })),
      { a: "", d: "Total liabilities", i: "", v: bs.totals.totalLiabilities, __bold: true },
      { a: "", d: "TOTAL EQUITY AND LIABILITIES", i: "", v: bs.totals.equityAndLiabilities, __bold: true },
    ],
    "Statement of Financial Position");

  sheet("Cash Flow",
    [{ header: "Line", key: "label", width: 58 }, M("Amount", "amount", 20)],
    cf.lines.map((l) => ({ label: l.label, amount: "amount" in l ? l.amount : "", __bold: l.bold, __header: l.header })),
    "Statement of Cash Flows (indirect method, IAS 7)");

  sheet("Changes in Equity",
    [{ header: "", key: "label", width: 50 }, M("Stated capital", "capital"), M("Retained earnings", "retained"),
     M("OCI reserves", "oci"), M("Other reserves", "other"), M("Total", "total")],
    soc.rows.map((r) => ({ ...r, __bold: r.bold })),
    "Statement of Changes in Equity (IAS 1)");

  sheet("Trial Balance",
    [{ header: "Account", key: "accountNo", width: 14 }, { header: "Description", key: "description", width: 44 },
     { header: "Type", key: "type", width: 12 }, { header: "IFRS line", key: "ifrsLine", width: 32 },
     M("Opening Dr", "openingDr"), M("Opening Cr", "openingCr"), M("Period Dr", "periodDr"),
     M("Period Cr", "periodCr"), M("Closing", "closing")],
    tb, "Trial Balance");

  const [arAge, apAge, reg, invv, pay, jrn] = await Promise.all([
    ageing(clientId, "AR"), ageing(clientId, "AP"), assetRegister(clientId),
    inventoryValuation(clientId), payrollRegister(clientId), journal(clientId, f, 20000),
  ]);

  const ageCols = [{ header: "Partner", key: "bp", width: 14 }, { header: "Name", key: "name", width: 38 },
    M("Current", "current"), M("1-30 days", "d30"), M("31-60 days", "d60"),
    M("61-90 days", "d90"), M("90+ days", "d120"), M("Total", "total")];
  sheet("AR Ageing", ageCols, [...arAge.rows, { bp: "", name: "TOTAL", ...arAge.totals, __bold: true }], "Accounts Receivable Ageing");
  sheet("AP Ageing", ageCols, [...apAge.rows, { bp: "", name: "TOTAL", ...apAge.totals, __bold: true }], "Accounts Payable Ageing");

  sheet("Fixed Asset Register",
    [{ header: "Asset", key: "assetNo", width: 14 }, { header: "Description", key: "description", width: 38 },
     { header: "Class", key: "assetClass", width: 16 }, { header: "Acquired", key: "acquisitionDate", width: 13 },
     { header: "Method", key: "method", width: 9 }, { header: "Life (yrs)", key: "usefulLife", width: 10 },
     M("Cost", "cost"), M("Accum. dep.", "accumDep"), M("Impairment", "impairment"), M("NBV", "nbv"),
     { header: "CA class", key: "capitalAllowanceClass", width: 12 }, { header: "Status", key: "status", width: 12 }],
    reg, "Fixed Asset Register");

  sheet("Inventory Valuation",
    [{ header: "Item", key: "materialNo", width: 14 }, { header: "Description", key: "description", width: 38 },
     { header: "UoM", key: "uom", width: 8 }, M("Qty", "qty"), M("Unit cost", "unitCost"),
     M("Cost value", "cost"), M("NRV value", "nrvTotal"), M("Carrying", "carrying"), M("Write-down", "writedown")],
    invv, "Inventory Valuation (IAS 2 — lower of cost and NRV)");

  sheet("Payroll Register",
    [{ header: "Run", key: "runNo", width: 14 }, { header: "Employee", key: "empNo", width: 14 },
     M("Basic", "basic"), M("Allowances", "allowances"), M("Gross", "gross"),
     M("SSNIT (EE)", "ssnitEe"), M("SSNIT (ER)", "ssnitEr"), M("Reliefs", "reliefs"),
     M("Chargeable", "taxable"), M("PAYE", "paye"), M("Other ded.", "otherDeductions"), M("Net pay", "net")],
    pay, "Payroll Register");

  sheet("Universal Journal",
    [{ header: "Doc", key: "docNo", width: 12 }, { header: "Ln", key: "lineNo", width: 5 },
     { header: "Date", key: "postDate", width: 12 }, { header: "Period", key: "periodCode", width: 10 },
     { header: "Module", key: "module", width: 9 }, { header: "Type", key: "docType", width: 8 },
     { header: "Account", key: "account", width: 12 }, { header: "Partner", key: "bp", width: 12 },
     { header: "Cost ctr", key: "costCenter", width: 12 }, { header: "Project", key: "project", width: 12 },
     { header: "Description", key: "description", width: 46 }, { header: "Ccy", key: "currency", width: 7 },
     M("Debit", "debit"), M("Credit", "credit"), { header: "User", key: "createdBy", width: 26 },
     { header: "Reference", key: "reference", width: 20 }],
    jrn, "Universal Journal (ACDOCA)");

  const coa = await db.select().from(accounts).where(eq(accounts.clientId, clientId));
  sheet("Chart of Accounts",
    [{ header: "Account", key: "accountNo", width: 14 }, { header: "Description", key: "description", width: 48 },
     { header: "Type", key: "type", width: 12 }, { header: "Sub-type", key: "subType", width: 22 },
     { header: "IFRS line", key: "ifrsLine", width: 36 }, { header: "Cash flow", key: "cashflowClass", width: 14 }],
    coa, "Chart of Accounts");

  const bps = await db.select().from(partners).where(eq(partners.clientId, clientId));
  sheet("Business Partners",
    [{ header: "Code", key: "bpNo", width: 12 }, { header: "Name", key: "name", width: 40 },
     { header: "Type", key: "type", width: 12 }, { header: "TIN", key: "tin", width: 16 },
     { header: "Resident", key: "isResident", width: 10 }, { header: "WHT code", key: "whtCode", width: 16 },
     { header: "Currency", key: "currency", width: 10 }, { header: "Credit days", key: "creditDays", width: 12 }],
    bps, "Business Partner Master");

  const docs = await db.select().from(tradeDocs).where(eq(tradeDocs.clientId, clientId));
  sheet("Sales & Purchases",
    [{ header: "Document", key: "docNo", width: 14 }, { header: "Kind", key: "docKind", width: 10 },
     { header: "Side", key: "side", width: 7 }, { header: "Partner", key: "bp", width: 12 },
     { header: "Date", key: "docDate", width: 12 }, { header: "Due", key: "dueDate", width: 12 },
     { header: "Ccy", key: "currency", width: 7 }, M("Net", "netAmount"), M("VAT", "vatAmount"),
     M("Gross", "grossAmount"), M("Settled", "settled"), { header: "Status", key: "status", width: 14 }],
    docs.map((d) => ({ ...d, netAmount: Number(d.netAmount), vatAmount: Number(d.vatAmount), grossAmount: Number(d.grossAmount), settled: Number(d.settled) })),
    "Sales and Purchase Documents");

  const pays = await db.select().from(payments).where(eq(payments.clientId, clientId));
  sheet("Payments & WHT",
    [{ header: "Payment", key: "payNo", width: 14 }, { header: "Date", key: "payDate", width: 12 },
     { header: "Dir", key: "direction", width: 7 }, { header: "Partner", key: "bp", width: 12 },
     { header: "Bank", key: "bankAccount", width: 12 }, M("Gross", "grossAmount"),
     { header: "WHT code", key: "whtCode", width: 16 }, M("WHT rate %", "whtRate"),
     M("WHT amount", "whtAmount"), M("Net paid", "netPaid"), { header: "GL doc", key: "glDoc", width: 12 }],
    pays.map((p) => ({ ...p, grossAmount: Number(p.grossAmount), whtRate: Number(p.whtRate), whtAmount: Number(p.whtAmount), netPaid: Number(p.netPaid) })),
    "Payment Desk and Withholding Tax Schedule");

  const vat = await vatSchedule(clientId, f);
  sheet("VAT Filing Schedule",
    [{ header: "Tax code", key: "code", width: 12 }, { header: "Description", key: "name", width: 34 },
     M("Rate %", "rate", 10), M("Levy %", "levyRate", 10), { header: "Documents", key: "docCount", width: 11 },
     M("Net", "net"), M("VAT", "vat"), M("Levy", "levy"), M("Gross", "gross")],
    [
      { code: "", name: "OUTPUT VAT — SALES", __header: true },
      ...vat.sales.map((r) => ({ ...r })),
      { code: "", name: "Total sales", net: vat.totals.salesNet, vat: vat.totals.outputVat, __bold: true },
      { code: "", name: "INPUT VAT — PURCHASES", __header: true },
      ...vat.purchases.map((r) => ({ ...r })),
      { code: "", name: "Total purchases", net: vat.totals.purchasesNet, vat: vat.totals.inputVat, __bold: true },
      { code: "", name: "NET VAT PAYABLE / (RECOVERABLE)", vat: vat.totals.netPayable, __bold: true },
    ],
    `VAT Filing Schedule (standard rate 20%, non-cascading) — ${vat.periodFrom} to ${vat.periodTo}`);

  const wht = await whtSchedule(clientId, f);
  sheet("WHT Filing Schedule",
    [{ header: "Code", key: "code", width: 14 }, { header: "Description", key: "name", width: 40 },
     { header: "Residency", key: "residency", width: 13 }, { header: "Category", key: "category", width: 14 },
     M("Rate %", "rate", 10), { header: "Payments", key: "count", width: 10 }, M("Taxable base", "base"), M("WHT withheld", "amount")],
    [...wht.rows, { code: "", name: "TOTAL", residency: "", category: "", rate: "", count: "", base: wht.totals.base, amount: wht.totals.amount, __bold: true }],
    `Withholding Tax Filing Schedule — ${wht.periodFrom} to ${wht.periodTo}`);

  try {
    const bva = await budgetVsActual(clientId, "BASE", new Date().getUTCFullYear(), f);
    sheet("Budget vs Actual",
      [{ header: "Account", key: "account", width: 14 }, { header: "Description", key: "description", width: 44 },
       M("Budget", "budget"), M("Actual", "actual"), M("Variance", "variance"), M("Variance %", "variancePct")],
      [...bva.rows, { account: "", description: "TOTAL", ...bva.totals, __bold: true }],
      "Budget versus Actual");
  } catch { /* budgets optional */ }

  return wb.xlsx.writeBuffer();
}
