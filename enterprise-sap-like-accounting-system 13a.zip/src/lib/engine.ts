import { db } from "@/db";
import { journalLines, numberRanges } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { assertPostable } from "./periods";
import { getRate } from "./fx";

export type JournalLineInput = {
  account: string; bp?: string; cc?: string; project?: string; material?: string;
  desc?: string; dr?: number; cr?: number; taxCode?: string;
};

export type PostInput = {
  clientId: string;
  postDate?: string;
  module: string;
  docType: string;
  lines: JournalLineInput[];
  createdBy?: string;
  reference?: string;
  currency?: string;
  fxRate?: number;
  reason?: string;
};

export const RANGE_START: Record<string, number> = {
  DOC: 1000000, QUOTE: 3100000, SO: 3200000, SINV: 3300000, SCN: 3400000, SDN: 3500000,
  PO: 4100000, PINV: 4200000, PCN: 4300000, PDN: 4400000, DINV: 4500000,
  PAY: 5100000, REC: 5200000, ASSET: 6100000, PREPAY: 6200000,
  PRUN: 7100000, ENG: 8100000, EMP: 9100000, BATCH: 9900000,
};

export const today = () => new Date().toISOString().slice(0, 10);
export const r2 = (n: number) => Math.round(((Number(n) || 0) + Number.EPSILON) * 100) / 100;
export const r4 = (n: number) => Math.round(((Number(n) || 0) + Number.EPSILON) * 10000) / 10000;
export const num = (v: unknown) => Number(v ?? 0);

export class PostingError extends Error {}

/**
 * Serialises a period-scoped batch operation (depreciation, amortisation,
 * payroll posting, VAT settlement, year-end close) per client and period so
 * that a double-click, a retried request, or two colleagues triggering the
 * same run at the same moment can never both "win" and double-post.
 *
 * Uses a Postgres transaction-scoped advisory lock: a second caller for the
 * same (clientId, periodCode, operation) blocks until the first transaction
 * commits, at which point it sees the already-updated state (e.g.
 * `lastDepPeriod`) and correctly does nothing — closing the exact class of
 * race condition that a plain "check, then later write" sequence is exposed
 * to under real concurrent use.
 */
export async function withPeriodLock<T>(
  clientId: string, periodCode: string, operation: string,
  fn: () => Promise<T>,
): Promise<T> {
  return db.transaction(async (tx) => {
    const key = `${clientId}:${periodCode}:${operation}`;
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${key}))`);
    return fn();
  });
}

/** Per-client atomic document numbering. */
export async function nextNumber(clientId: string, key: string, prefix = "") {
  const start = RANGE_START[key] ?? 1000000;
  const rows = await db.execute<{ current: string }>(sql`
    INSERT INTO number_ranges (client_id, range_key, current)
    VALUES (${clientId}, ${key}, ${start + 1})
    ON CONFLICT (client_id, range_key)
    DO UPDATE SET current = number_ranges.current + 1
    RETURNING current
  `);
  const n = String(rows.rows?.[0]?.current ?? start + 1);
  return prefix ? `${prefix}${n}` : n;
}

/**
 * THE UNIVERSAL JOURNAL POSTING GATE.
 * Enforces: balanced document, valid open fiscal period, FX translation to the
 * reporting currency, and a complete audit stamp. Every module posts here.
 */
export async function postDocument(input: PostInput) {
  const lines = (input.lines ?? []).filter((l) => l.account && ((l.dr ?? 0) !== 0 || (l.cr ?? 0) !== 0));
  if (lines.length < 2) throw new PostingError("A document needs at least two non-zero line items.");

  const postDate = input.postDate || today();
  const period = await assertPostable(input.clientId, postDate);

  const ccy = input.currency || "GHS";
  const rate = ccy === "GHS" ? 1 : (input.fxRate && input.fxRate > 0 ? input.fxRate : await getRate(ccy, postDate));

  const totalDrFc = r2(lines.reduce((s, l) => s + (Number(l.dr) || 0), 0));
  const totalCrFc = r2(lines.reduce((s, l) => s + (Number(l.cr) || 0), 0));
  if (totalDrFc !== totalCrFc) {
    throw new PostingError(
      `Document is not balanced. Debits ${totalDrFc.toFixed(2)} vs Credits ${totalCrFc.toFixed(2)} (difference ${(totalDrFc - totalCrFc).toFixed(2)}).`,
    );
  }
  if (totalDrFc === 0) throw new PostingError("Document has zero value.");

  const docNo = await nextNumber(input.clientId, "DOC");

  // Base-currency rounding is forced onto the final line so the GL always ties.
  const baseRows = lines.map((l) => ({
    dr: r2((Number(l.dr) || 0) * rate),
    cr: r2((Number(l.cr) || 0) * rate),
  }));
  const baseDr = r2(baseRows.reduce((s, b) => s + b.dr, 0));
  const baseCr = r2(baseRows.reduce((s, b) => s + b.cr, 0));
  const drift = r2(baseDr - baseCr);
  if (drift !== 0) {
    for (let i = baseRows.length - 1; i >= 0; i--) {
      if (baseRows[i].cr > 0) { baseRows[i].cr = r2(baseRows[i].cr + drift); break; }
      if (baseRows[i].dr > 0) { baseRows[i].dr = r2(baseRows[i].dr - drift); break; }
    }
  }

  await db.insert(journalLines).values(
    lines.map((l, i) => ({
      clientId: input.clientId,
      docNo,
      lineNo: i + 1,
      postDate,
      periodCode: period.code,
      fiscalYear: period.year,
      module: input.module,
      docType: input.docType,
      account: l.account,
      bp: l.bp ?? "",
      costCenter: l.cc ?? "",
      project: l.project ?? "",
      material: l.material ?? "",
      description: l.desc ?? "",
      currency: ccy,
      fxRate: String(r4(rate)),
      debitFc: String(r2(Number(l.dr) || 0)),
      creditFc: String(r2(Number(l.cr) || 0)),
      debit: String(baseRows[i].dr),
      credit: String(baseRows[i].cr),
      taxCode: l.taxCode ?? "",
      reason: input.reason ?? "",
      createdBy: input.createdBy || "SYSTEM",
      reference: input.reference ?? "",
    })),
  );

  return { docNo, amount: totalDrFc, baseAmount: r2(baseDr), postDate, period: period.code, currency: ccy, fxRate: r4(rate) };
}

/**
 * Reverses a document by posting a mirror-image entry (never deletes).
 * A reason is mandatory — this is the audit-defensible pattern.
 */
export async function reverseDocument(
  clientId: string, docNo: string, by: string, reason: string, reversalDate?: string,
) {
  if (!reason || reason.trim().length < 5) {
    throw new PostingError("A reversal reason of at least 5 characters is required.");
  }
  const orig = await db.select().from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));
  if (!orig.length) throw new PostingError(`Document ${docNo} was not found.`);
  if (orig[0].reversed) throw new PostingError(`Document ${docNo} has already been reversed.`);
  if (orig[0].reversalOf) throw new PostingError(`Document ${docNo} is itself a reversal and cannot be reversed.`);

  const date = reversalDate || today();
  const period = await assertPostable(clientId, date);
  const revNo = await nextNumber(clientId, "DOC");

  await db.insert(journalLines).values(
    orig.map((l, i) => ({
      clientId, docNo: revNo, lineNo: i + 1, postDate: date,
      periodCode: period.code, fiscalYear: period.year,
      module: l.module, docType: "REV", account: l.account, bp: l.bp,
      costCenter: l.costCenter, project: l.project, material: l.material,
      description: `REVERSAL of ${docNo} — ${l.description}`.slice(0, 500),
      currency: l.currency, fxRate: l.fxRate,
      debitFc: l.creditFc, creditFc: l.debitFc,
      debit: l.credit, credit: l.debit,
      taxCode: l.taxCode, reversalOf: docNo, reason,
      createdBy: by, reference: l.reference,
    })),
  );
  await db.update(journalLines).set({ reversed: true })
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.docNo, docNo)));

  return { docNo: revNo, reversalOf: docNo, period: period.code, message: `Document ${docNo} reversed by ${revNo}` };
}

/** Balance of a GL account up to (and including) a period. */
export async function accountBalance(clientId: string, account: string, uptoPeriod?: string) {
  const conds = [eq(journalLines.clientId, clientId), eq(journalLines.account, account)];
  if (uptoPeriod) conds.push(sql`${journalLines.periodCode} <= ${uptoPeriod}` as never);
  const [row] = await db
    .select({
      dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
      cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
    })
    .from(journalLines)
    .where(and(...conds));
  return r2(num(row?.dr) - num(row?.cr));
}

export async function resetNumberRanges(clientId: string) {
  await db.delete(numberRanges).where(eq(numberRanges.clientId, clientId));
}
