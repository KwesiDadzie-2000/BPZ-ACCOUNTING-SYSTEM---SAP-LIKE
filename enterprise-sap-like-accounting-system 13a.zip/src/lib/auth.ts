import crypto from "crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { activityLog, clients, users } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { ROLES, type Permission } from "./constants";

export const SESSION_COOKIE = "bpz_session";
export const ACTIVE_CLIENT_COOKIE = "bpz_ws";
export const FIRM_ID = "BPZ-FIRM";

/**
 * Shared cookie options for every auth cookie in the app.
 *
 * CRITICAL: this platform's preview is commonly rendered inside an iframe on
 * a different top-level origin than the app itself. With `sameSite: "lax"`
 * (the previous setting), browsers treat every fetch made from inside that
 * iframe as cross-site and silently refuse to attach the cookie — so a login
 * POST succeeds, but the very next GET request looks logged out. This is the
 * most common cause of "login doesn't work" reports for apps previewed this
 * way. `sameSite: "none"` (which requires `secure: true`, satisfied here
 * because the preview is always served over HTTPS) allows the cookie to
 * travel with same-origin requests regardless of how the page is framed.
 */
export function authCookieOptions(maxAgeSeconds: number) {
  return {
    httpOnly: true,
    sameSite: "none" as const,
    secure: true,
    path: "/",
    maxAge: maxAgeSeconds,
  };
}
export const SEVEN_DAYS = 7 * 86400;

const SECRET = process.env.AUTH_SECRET || process.env.DATABASE_URL || "bpz-dev-secret";
export const OWNER_EMAIL = (process.env.OWNER_EMAIL || "owner@bpz.com.gh").toLowerCase();
export const OWNER_PASSWORD = process.env.OWNER_PASSWORD || "Bpz@Owner2026";
export const OWNER_NAME = process.env.OWNER_NAME || "BPZ Managing Partner";

export function hashPassword(pw: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  return `scrypt:${salt}:${crypto.scryptSync(pw, salt, 64).toString("hex")}`;
}
export function verifyPassword(pw: string, stored: string) {
  const [s, salt, hash] = (stored || "").split(":");
  if (s !== "scrypt" || !salt || !hash) return false;
  const a = crypto.scryptSync(pw, salt, 64);
  const b = Buffer.from(hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
export function tempPassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 4; i++) out += chars[crypto.randomInt(chars.length)];
  return `BPZ-${out}-${crypto.randomInt(1000, 9999)}`;
}

/* ===================== SELF-SERVICE PASSWORD RESET ===================== */
const hashToken = (t: string) => crypto.createHash("sha256").update(t).digest("hex");

/**
 * Issues a one-hour, single-use reset token. Returns both the raw token
 * (shown to the user / sent by email if SMTP is configured) and its hash
 * (the only thing persisted) so a leaked database never exposes usable
 * tokens — the same principle used for password storage.
 */
export async function issueResetToken(email: string): Promise<{ token: string; userId: number } | null> {
  const normalised = email.trim().toLowerCase();
  const [u] = await db.select().from(users).where(eq(users.email, normalised)).limit(1);
  if (!u || !u.active) return null;
  const token = crypto.randomBytes(24).toString("base64url");
  await db.update(users).set({
    resetTokenHash: hashToken(token),
    resetTokenExpires: new Date(Date.now() + 60 * 60_000),
  }).where(eq(users.id, u.id));
  return { token, userId: u.id };
}

export async function redeemResetToken(token: string, newPassword: string): Promise<{ email: string }> {
  if (!token) throw new AuthError("Reset link is invalid.", 400);
  const hash = hashToken(token);
  const [u] = await db.select().from(users).where(eq(users.resetTokenHash, hash)).limit(1);
  if (!u || !u.resetTokenExpires || u.resetTokenExpires.getTime() < Date.now()) {
    throw new AuthError("This reset link is invalid or has expired. Request a new one.", 400);
  }
  if (newPassword.length < 8 || !/[A-Za-z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
    throw new AuthError("The new password must be at least 8 characters and include a letter and a number.", 400);
  }
  await db.update(users).set({
    passwordHash: hashPassword(newPassword), mustChangePassword: false, tempPassword: "",
    resetTokenHash: "", resetTokenExpires: null, failedLogins: 0, lockedUntil: null,
  }).where(eq(users.id, u.id));
  return { email: u.email };
}

/**
 * Delivers the reset link. If an SMTP/email provider is configured via env
 * vars this is the single place to wire it in; without one configured, the
 * link is returned to the caller so the UI can display it directly — never
 * silently dropped.
 */
export async function deliverResetLink(email: string, link: string): Promise<{ emailed: boolean }> {
  const smtpConfigured = !!(process.env.SMTP_HOST || process.env.RESEND_API_KEY || process.env.SENDGRID_API_KEY);
  if (!smtpConfigured) return { emailed: false };
  try {
    // Placeholder for a real provider integration (Resend/SendGrid/SMTP).
    // Intentionally not fabricated — wire up the provider's SDK here when
    // credentials are added to the environment.
    return { emailed: false };
  } catch {
    return { emailed: false };
  }
}

const sign = (p: string) => crypto.createHmac("sha256", SECRET).update(p).digest("base64url");
export function createToken(uid: number, days = 7) {
  const body = Buffer.from(JSON.stringify({ uid, exp: Date.now() + days * 86400000 })).toString("base64url");
  return `${body}.${sign(body)}`;
}
export function readToken(token?: string): number | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const exp = sign(body);
  if (sig.length !== exp.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp))) return null;
  try {
    const d = JSON.parse(Buffer.from(body, "base64url").toString()) as { uid: number; exp: number };
    return d.exp > Date.now() ? d.uid : null;
  } catch { return null; }
}

export type SessionUser = {
  id: number; email: string; name: string; role: string; clientId: string | null;
  isFirmStaff: boolean; permissions: Permission[]; mustChangePassword: boolean;
  approvalLimit: number; jobTitle: string;
};

export class AuthError extends Error {
  status: number;
  constructor(m: string, s = 401) { super(m); this.status = s; }
}

export function permsFor(role: string, extra: string[] = []): Permission[] {
  const base = ROLES[role]?.perms ?? [];
  return Array.from(new Set([...base, ...extra])) as Permission[];
}

/** Creates the BPZ firm workspace + the owner login on first boot. */
export async function ensureOwner() {
  const [firm] = await db.select().from(clients).where(eq(clients.id, FIRM_ID)).limit(1);
  if (!firm) {
    await db.insert(clients).values({
      id: FIRM_ID, name: "BPZ Chartered Accountants & Advisors", shortName: "BPZ",
      sector: "PROFESSIONAL_SERVICES", isFirm: true, currency: "GHS",
      serviceLines: ["BOOKKEEPING", "PAYROLL", "TAX", "ADVISORY", "AUDIT_SUPPORT", "CFO", "COMPLIANCE", "VALUATION", "RISK", "TRAINING"],
      createdBy: "system",
    }).onConflictDoNothing();
  }
  const [owner] = await db.select().from(users).where(eq(users.role, "OWNER")).limit(1);
  if (owner) return owner;
  const [created] = await db.insert(users).values({
    email: OWNER_EMAIL, name: OWNER_NAME, passwordHash: hashPassword(OWNER_PASSWORD),
    role: "OWNER", clientId: null, isFirmStaff: true, jobTitle: "Managing Partner",
    approvalLimit: "999999999", mustChangePassword: false,
  }).onConflictDoNothing().returning();
  return created;
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const uid = readToken(jar.get(SESSION_COOKIE)?.value);
  if (!uid) return null;
  const [u] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
  if (!u || !u.active) return null;
  return {
    id: u.id, email: u.email, name: u.name, role: u.role, clientId: u.clientId,
    isFirmStaff: u.isFirmStaff, permissions: permsFor(u.role, u.permissions),
    mustChangePassword: u.mustChangePassword, approvalLimit: Number(u.approvalLimit),
    jobTitle: u.jobTitle,
  };
}

export async function requireUser(): Promise<SessionUser> {
  const u = await getSessionUser();
  if (!u) throw new AuthError("Your session has expired. Please sign in again.", 401);
  return u;
}

export async function requireOwner(): Promise<SessionUser> {
  const u = await requireUser();
  if (u.role !== "OWNER") throw new AuthError("This action is restricted to the firm owner.", 403);
  return u;
}

export function can(u: SessionUser, p: Permission) {
  return u.role === "OWNER" || u.permissions.includes(p);
}
export function requirePerm(u: SessionUser, p: Permission) {
  if (!can(u, p)) throw new AuthError(`You do not have the '${p}' permission.`, 403);
}

/**
 * Resolves the active workspace. Client users are HARD-LOCKED to their own
 * company — they can never read or write another workspace, including the firm.
 */
export async function requireWorkspace(): Promise<{ user: SessionUser; clientId: string; isFirmWs: boolean }> {
  const user = await requireUser();
  if (user.mustChangePassword) {
    throw new AuthError("You must change your temporary password before continuing.", 428);
  }
  if (!user.isFirmStaff) {
    if (!user.clientId) throw new AuthError("No workspace is assigned to your login.", 403);
    const [c] = await db.select().from(clients).where(eq(clients.id, user.clientId)).limit(1);
    if (!c) throw new AuthError("Your workspace no longer exists.", 403);
    if (!c.active) throw new AuthError("Your workspace has been suspended. Contact BPZ.", 403);
    return { user, clientId: c.id, isFirmWs: false };
  }
  const jar = await cookies();
  const active = jar.get(ACTIVE_CLIENT_COOKIE)?.value;
  if (active) {
    const [c] = await db.select().from(clients).where(eq(clients.id, active)).limit(1);
    if (c) return { user, clientId: c.id, isFirmWs: c.isFirm };
  }
  return { user, clientId: FIRM_ID, isFirmWs: true };
}

/** Owner/firm staff may address any workspace; clients only their own. */
export async function resolveTargetClient(user: SessionUser, requested?: string) {
  if (!user.isFirmStaff) {
    if (requested && requested !== user.clientId) {
      throw new AuthError("You may only operate within your own workspace.", 403);
    }
    return user.clientId!;
  }
  if (!requested) return (await requireWorkspace()).clientId;
  const [c] = await db.select().from(clients).where(eq(clients.id, requested)).limit(1);
  if (!c) throw new AuthError("Workspace not found.", 404);
  return c.id;
}

export async function logActivity(clientId: string, user: SessionUser, action: string, detail = "") {
  await db.insert(activityLog).values({
    clientId, userEmail: user.email, role: user.role, action, detail: detail.slice(0, 900),
  });
}

export function slugId(name: string) {
  const base = name.toUpperCase().replace(/[^A-Z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 18);
  return `${base || "CLIENT"}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
}

export async function listAllClients() {
  return db.select().from(clients).orderBy(asc(clients.name));
}
