import { db } from "@/db";
import { fxRates } from "@/db/schema";
import { and, desc, eq, lte } from "drizzle-orm";
import { CURRENCIES } from "./constants";

export const BASE_CCY = "GHS";
const r4 = (n: number) => Math.round((n + Number.EPSILON) * 10000) / 10000;
const todayStr = () => new Date().toISOString().slice(0, 10);

/** Indicative fallback mid-rates (GHS per 1 unit) if no live feed is reachable. */
const FALLBACK: Record<string, number> = {
  GHS: 1, USD: 12.65, GBP: 16.1, EUR: 13.75, NGN: 0.0082,
  ZAR: 0.69, CNY: 1.75, JPY: 0.083, CAD: 9.2, AUD: 8.3, CHF: 14.3, XOF: 0.021, KES: 0.098,
};

type Fetched = { currency: string; mid: number; source: string };

/**
 * Live rate acquisition. Tries the Bank of Ghana daily interbank page first
 * (the official mid rate), then falls back to an open FX API, then to the
 * indicative table. Rates are cached per day in `fx_rates`.
 */
async function fetchBoG(): Promise<Fetched[]> {
  const out: Fetched[] = [];
  try {
    const res = await fetch("https://www.bog.gov.gh/treasury-and-the-markets/daily-interbank-fx-rates/", {
      headers: { "User-Agent": "Mozilla/5.0 BPZ-ERP" },
      signal: AbortSignal.timeout(8000),
    });
    if (res.ok) {
      const html = await res.text();
      // BoG publishes a table of CURRENCY | BUYING | SELLING | MID
      const re = /(USD|GBP|EUR|NGN|ZAR|CNY|JPY|CAD|AUD|CHF|XOF)[^0-9]{0,80}?([0-9]+\.[0-9]{2,6})[^0-9]{1,40}([0-9]+\.[0-9]{2,6})[^0-9]{1,40}([0-9]+\.[0-9]{2,6})/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(html))) {
        const mid = Number(m[4]) || (Number(m[2]) + Number(m[3])) / 2;
        if (mid > 0 && !out.find((o) => o.currency === m![1])) {
          out.push({ currency: m[1], mid, source: "BOG" });
        }
      }
    }
  } catch { /* fall through */ }
  return out;
}

async function fetchOpenApi(): Promise<Fetched[]> {
  try {
    const res = await fetch("https://open.er-api.com/v6/latest/GHS", { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return [];
    const data = (await res.json()) as { rates?: Record<string, number> };
    if (!data.rates) return [];
    return CURRENCIES.filter((c) => c !== BASE_CCY && data.rates![c])
      .map((c) => ({ currency: c, mid: 1 / Number(data.rates![c]), source: "ER-API" }));
  } catch {
    return [];
  }
}

/** Refreshes today's rates. Safe to call repeatedly — it upserts per day. */
export async function refreshRates(force = false) {
  const day = todayStr();
  if (!force) {
    const have = await db.select({ id: fxRates.id }).from(fxRates).where(eq(fxRates.rateDate, day)).limit(1);
    if (have.length) return { cached: true, day, count: 0, source: "cache" };
  }
  let rows = await fetchBoG();
  let source = "BOG";
  if (rows.length < 3) {
    const alt = await fetchOpenApi();
    if (alt.length >= rows.length) { rows = alt; source = "ER-API"; }
  }
  if (rows.length === 0) {
    rows = CURRENCIES.filter((c) => c !== BASE_CCY).map((c) => ({ currency: c, mid: FALLBACK[c] ?? 1, source: "FALLBACK" }));
    source = "FALLBACK";
  }
  rows.push({ currency: BASE_CCY, mid: 1, source });

  await db.delete(fxRates).where(eq(fxRates.rateDate, day));
  await db.insert(fxRates).values(
    rows.map((r) => ({
      rateDate: day, currency: r.currency, midRate: String(r4(r.mid)),
      buyRate: String(r4(r.mid * 0.995)), sellRate: String(r4(r.mid * 1.005)), source: r.source,
    })),
  );
  return { cached: false, day, count: rows.length, source };
}

/** Mid rate for a currency on (or before) a date. Never throws. */
export async function getRate(currency: string, onDate?: string): Promise<number> {
  if (!currency || currency === BASE_CCY) return 1;
  const day = onDate || todayStr();
  const [row] = await db
    .select()
    .from(fxRates)
    .where(and(eq(fxRates.currency, currency), lte(fxRates.rateDate, day)))
    .orderBy(desc(fxRates.rateDate))
    .limit(1);
  if (row) return Number(row.midRate);
  await refreshRates();
  const [again] = await db
    .select()
    .from(fxRates)
    .where(eq(fxRates.currency, currency))
    .orderBy(desc(fxRates.rateDate))
    .limit(1);
  return again ? Number(again.midRate) : (FALLBACK[currency] ?? 1);
}

export async function latestRates() {
  await refreshRates();
  const day = todayStr();
  const rows = await db.select().from(fxRates).where(eq(fxRates.rateDate, day));
  if (rows.length) return rows.map((r) => ({ ...r, midRate: Number(r.midRate) }));
  const fallback = await db.select().from(fxRates).orderBy(desc(fxRates.rateDate)).limit(CURRENCIES.length);
  return fallback.map((r) => ({ ...r, midRate: Number(r.midRate) }));
}

export const toBase = (amountFc: number, rate: number) => r4(amountFc * rate);
