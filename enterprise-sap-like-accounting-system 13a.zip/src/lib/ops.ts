import { db } from "@/db";
import {
  accounts, approvals, assets, bankAccounts, bankRecs, bankStatementLines, clients, depreciationRuns,
  employees, fiscalPeriods, journalLines, materials, partners, payComponents, paymentAllocations,
  payments, payrollRuns, payslips, prepayments, stockMoves, tradeDocs, tradeLines,
} from "@/db/schema";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { JournalLineInput, nextNumber, num, postDocument, r2, reverseDocument as reverseJournalDocument, today, withPeriodLock } from "./engine";
import { assertPostable, periodForDate } from "./periods";
import { computeVat, computeWht, computePaye, SSNIT, whtFor } from "./tax";
import { getRate } from "./fx";
import { ASSET_CLASSES, DIRECT_PAYMENT_CATEGORIES } from "./constants";

export type Ctx = { clientId: string; user: string; approvalLimit?: number; canApprove?: boolean; role?: string };
export class OpsError extends Error {}
export class ApprovalRequiredError extends Error {
  approvalId: number;
  constructor(approvalId: number, message: string) { super(message); this.approvalId = approvalId; }
}

const firstOf = (code: string) => `${code}-01`;

/* ================================================================
   1. TRADE DOCUMENTS — quotes, orders, invoices, credit/debit notes
   ================================================================ */
export type TradeLineIn = {
  materialNo?: string; description: string; account?: string;
  qty: number; unitPrice: number; discount?: number; taxCode?: string;
};

const KIND_META: Record<string, { side: "AR" | "AP"; range: string; prefix: string; posts: boolean; sign: 1 | -1; label: string }> = {
  QUOTE: { side: "AR", range: "QUOTE", prefix: "QT-", posts: false, sign: 1, label: "Quotation / Estimate" },
  SO: { side: "AR", range: "SO", prefix: "SO-", posts: false, sign: 1, label: "Sales Order" },
  SINV: { side: "AR", range: "SINV", prefix: "SI-", posts: true, sign: 1, label: "Sales Invoice" },
  SCN: { side: "AR", range: "SCN", prefix: "SC-", posts: true, sign: -1, label: "Sales Credit Note" },
  SDN: { side: "AR", range: "SDN", prefix: "SD-", posts: true, sign: 1, label: "Sales Debit Note" },
  PO: { side: "AP", range: "PO", prefix: "PO-", posts: false, sign: 1, label: "Purchase Order" },
  PINV: { side: "AP", range: "PINV", prefix: "PI-", posts: true, sign: 1, label: "Purchase Invoice" },
  PCN: { side: "AP", range: "PCN", prefix: "PC-", posts: true, sign: -1, label: "Purchase Credit Note" },
  PDN: { side: "AP", range: "PDN", prefix: "PD-", posts: true, sign: 1, label: "Purchase Debit Note" },
  // A statutory/direct invoice — utilities, insurance, regulatory fees,
  // penalties and similar bills that never pass through procurement. It
  // still creates a genuine payable so it can be settled in full or in part
  // through the normal Payment Desk, exactly like a supplier invoice — the
  // only difference is there is no purchase order behind it and it clears to
  // "Other Payables & Accruals" rather than "Trade Payables" (see the
  // `control` account logic in postTradeDoc below).
  DINV: { side: "AP", range: "DINV", prefix: "DI-", posts: true, sign: 1, label: "Direct / Statutory Invoice" },
};

export async function createTradeDoc(ctx: Ctx, p: {
  docKind: string; bp: string; docDate?: string; dueDate?: string; currency?: string;
  lines: TradeLineIn[]; costCenter?: string; project?: string; narrative?: string;
  autoPost?: boolean;
}) {
  const meta = KIND_META[p.docKind];
  if (!meta) throw new OpsError(`Unknown document type ${p.docKind}`);
  if (!p.bp) throw new OpsError("A business partner is required.");
  if (!p.lines?.length) throw new OpsError("At least one line is required.");

  // AUDIT FIX 1 — reject negative quantities and prices. A reduction must be
  // raised as a credit note (SCN/PCN) so the document trail stays auditable.
  p.lines.forEach((l, i) => {
    if ((Number(l.qty) || 0) < 0) {
      throw new OpsError(`Line ${i + 1}: quantity cannot be negative. Raise a credit note instead.`);
    }
    if ((Number(l.unitPrice) || 0) < 0) {
      throw new OpsError(`Line ${i + 1}: unit price cannot be negative. Raise a credit note instead.`);
    }
    if ((Number(l.discount) || 0) < 0) {
      throw new OpsError(`Line ${i + 1}: discount cannot be negative.`);
    }
    const lineNet = (Number(l.qty) || 0) * (Number(l.unitPrice) || 0) - (Number(l.discount) || 0);
    if (lineNet < 0) {
      throw new OpsError(`Line ${i + 1}: the discount exceeds the line value.`);
    }
  });

  const docDate = p.docDate || today();
  const [bp] = await db.select().from(partners)
    .where(and(eq(partners.clientId, ctx.clientId), eq(partners.bpNo, p.bp)));
  if (!bp) throw new OpsError(`Business partner ${p.bp} not found.`);

  const ccy = p.currency || bp.currency || "GHS";
  const rate = await getRate(ccy, docDate);
  const period = await periodForDate(ctx.clientId, docDate);
  const dueDate = p.dueDate || new Date(Date.parse(docDate) + (bp.creditDays || 30) * 86400000).toISOString().slice(0, 10);

  let net = 0, vat = 0, levy = 0;
  const computed = p.lines.map((l, i) => {
    const gross = r2((Number(l.qty) || 0) * (Number(l.unitPrice) || 0));
    const lineNet = r2(gross - (Number(l.discount) || 0));
    const t = computeVat(lineNet, l.taxCode || "STD");
    net = r2(net + lineNet); vat = r2(vat + t.vat); levy = r2(levy + t.levy);
    return { ...l, lineNo: i + 1, net: lineNet, vat: t.vat, levy: t.levy, total: r2(lineNet + t.vat + t.levy) };
  });
  const grossTotal = r2(net + vat + levy);
  // AUDIT FIX 2 — refuse a zero-value document up front rather than creating a
  // header that can never be posted (previously left orphaned records behind).
  if (grossTotal <= 0) {
    throw new OpsError("The document has no value. Enter at least one line with a quantity and a price.");
  }

  // AUDIT FIX 4 — duplicate supplier invoice control. Catching a repeated
  // supplier reference is the standard AP defence against paying twice.
  if (meta.side === "AP" && (p.narrative ?? "").trim()) {
    const dup = await db.select({ docNo: tradeDocs.docNo }).from(tradeDocs).where(and(
      eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.bp, p.bp),
      eq(tradeDocs.narrative, p.narrative!.trim()),
      eq(tradeDocs.grossAmount, String(grossTotal)),
    )).limit(1);
    if (dup.length) {
      throw new OpsError(
        `Possible duplicate: ${dup[0].docNo} already records "${p.narrative}" for ${p.bp} at ${grossTotal.toFixed(2)}. Change the reference if this is a genuinely separate invoice.`,
      );
    }
  }

  const docNo = await nextNumber(ctx.clientId, meta.range, meta.prefix);

  await db.insert(tradeDocs).values({
    clientId: ctx.clientId, docNo, docKind: p.docKind, side: meta.side, bp: p.bp,
    docDate, dueDate, periodCode: period?.code ?? "", currency: ccy, fxRate: String(rate),
    netAmount: String(net), vatAmount: String(vat), levyAmount: String(levy),
    grossAmount: String(grossTotal), baseGross: String(r2(grossTotal * rate)),
    status: meta.posts ? "OPEN" : "DRAFT",
    costCenter: p.costCenter || "", project: p.project || "",
    narrative: p.narrative || "", createdBy: ctx.user,
  });
  await db.insert(tradeLines).values(computed.map((l) => ({
    clientId: ctx.clientId, docNo, lineNo: l.lineNo, materialNo: l.materialNo || "",
    description: l.description, account: l.account || "", qty: String(l.qty),
    unitPrice: String(l.unitPrice), discount: String(l.discount || 0),
    taxCode: l.taxCode || "STD", net: String(l.net), vat: String(l.vat),
    levy: String(l.levy), total: String(l.total),
  })));

  let glDoc = "";
  if (meta.posts && p.autoPost !== false) {
    try {
      glDoc = (await postTradeDoc(ctx, docNo)).docNo;
    } catch (err) {
      // AUDIT FIX 2b — if the ledger rejects the document (closed period, etc.)
      // roll the header and lines back so no orphan record survives.
      await db.delete(tradeLines).where(and(eq(tradeLines.clientId, ctx.clientId), eq(tradeLines.docNo, docNo)));
      await db.delete(tradeDocs).where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));
      throw err;
    }
  }
  return { docNo, glDoc, net, vat, levy, gross: grossTotal, currency: ccy, fxRate: rate, message: `${meta.label} ${docNo} created` };
}

/** Posts an AR/AP document to the Universal Journal with full VAT treatment. */
export async function postTradeDoc(ctx: Ctx, docNo: string) {
  const [doc] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));
  if (!doc) throw new OpsError(`Document ${docNo} not found.`);
  if (doc.glDoc) throw new OpsError(`Document ${docNo} is already posted (GL ${doc.glDoc}).`);
  const meta = KIND_META[doc.docKind];
  if (!meta?.posts) throw new OpsError(`${doc.docKind} documents are not posted to the ledger.`);

  const lines = await db.select().from(tradeLines)
    .where(and(eq(tradeLines.clientId, ctx.clientId), eq(tradeLines.docNo, docNo)))
    .orderBy(asc(tradeLines.lineNo));
  const gl: JournalLineInput[] = [];
  const gross = num(doc.grossAmount), vat = num(doc.vatAmount), levy = num(doc.levyAmount);
  const isAR = doc.side === "AR";
  const reverse = meta.sign === -1;

  // A direct/statutory invoice clears to "Other Payables & Accruals"
  // (410300), not "Trade Payables" (410100) — it was never a trade purchase.
  const control = doc.docKind === "DINV" ? "410300" : isAR ? "130100" : "410100";
  const vatAcct = isAR ? "420100" : "131000";
  const levyAcct = isAR ? "421000" : "760100";

  const put = (account: string, amount: number, debit: boolean, desc: string, extra: Partial<JournalLineInput> = {}) => {
    if (r2(amount) === 0) return;
    const flip = reverse ? !debit : debit;
    gl.push({ account, [flip ? "dr" : "cr"]: r2(Math.abs(amount)), desc, ...extra } as JournalLineInput);
  };

  put(control, gross, isAR, `${isAR ? "Receivable" : "Payable"} — ${doc.bp}`, { bp: doc.bp });
  for (const l of lines) {
    const acct = l.account || (isAR ? "500100" : "720500");
    put(acct, num(l.net), !isAR, l.description || doc.docKind, {
      cc: doc.costCenter, project: doc.project, material: l.materialNo, taxCode: l.taxCode,
    });
  }
  put(vatAcct, vat, !isAR, isAR ? "Output VAT (20%)" : "Input VAT recoverable (20%)", { taxCode: "VAT" });
  put(levyAcct, levy, !isAR, "Statutory levies", { taxCode: "LEVY" });

  const res = await postDocument({
    clientId: ctx.clientId, postDate: doc.docDate, module: isAR ? "AR" : "AP",
    docType: doc.docKind, lines: gl, createdBy: ctx.user, reference: docNo,
    currency: doc.currency, fxRate: num(doc.fxRate),
  });
  await db.update(tradeDocs).set({ glDoc: res.docNo, status: "OPEN", periodCode: res.period })
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));

  // Inventory movement for stocked sales lines
  if (isAR && !reverse) {
    for (const l of lines) {
      if (l.materialNo) await issueStock(ctx, l.materialNo, num(l.qty), docNo, doc.docDate).catch(() => undefined);
    }
  }
  if (!isAR && !reverse) {
    for (const l of lines) {
      if (l.materialNo) await receiveStock(ctx, l.materialNo, num(l.qty), num(l.net) / Math.max(num(l.qty), 1), docNo, doc.docDate).catch(() => undefined);
    }
  }
  return res;
}

/** Converts a quotation or order into the next document in the chain. */
export async function convertTradeDoc(ctx: Ctx, docNo: string, toKind: string) {
  const [doc] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));
  if (!doc) throw new OpsError(`Document ${docNo} not found.`);
  const lines = await db.select().from(tradeLines)
    .where(and(eq(tradeLines.clientId, ctx.clientId), eq(tradeLines.docNo, docNo)));
  const res = await createTradeDoc(ctx, {
    docKind: toKind, bp: doc.bp, currency: doc.currency, costCenter: doc.costCenter,
    project: doc.project, narrative: `Converted from ${docNo}`,
    lines: lines.map((l) => ({
      materialNo: l.materialNo, description: l.description, account: l.account,
      qty: num(l.qty), unitPrice: num(l.unitPrice), discount: num(l.discount), taxCode: l.taxCode,
    })),
  });
  await db.update(tradeDocs).set({ status: `CONVERTED → ${res.docNo}` })
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));
  return res;
}

/* ================================================================
   2. PAYMENT DESK — partial/full settlement with withholding tax
   ================================================================ */
export type PaymentInput = {
  direction: "IN" | "OUT"; bp: string; bankCode: string; payDate?: string;
  allocations: { docNo: string; amount: number }[]; whtCode?: string; whtRateOverride?: number;
  method?: string; narrative?: string; currency?: string;
  /** Advance / deposit / retainer with no invoice yet — posts to a control account. */
  onAccountAmount?: number;
  /** Set internally when an approver executes a previously queued request. */
  _skipApproval?: boolean;
};

/**
 * Payment Desk — settles invoices in full or in part, supports advance
 * receipts/payments with no invoice ("on account"), applies withholding tax,
 * recognises REALISED foreign-exchange gain or loss at settlement (IAS 21),
 * and enforces maker-checker approval above a user's approval limit.
 */
export async function createPayment(ctx: Ctx, p: PaymentInput) {
  const onAccount = r2(p.onAccountAmount ?? 0);
  if (!p.allocations?.length && onAccount <= 0) {
    throw new OpsError("Allocate the payment to at least one invoice, or enter an on-account amount.");
  }
  const payDate = p.payDate || today();
  await assertPostable(ctx.clientId, payDate);

  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, p.bankCode)));
  if (!bank) throw new OpsError(`Bank account ${p.bankCode} not found.`);
  const [bp] = await db.select().from(partners)
    .where(and(eq(partners.clientId, ctx.clientId), eq(partners.bpNo, p.bp)));
  if (!bp) throw new OpsError(`Business partner ${p.bp} not found.`);

  const docNos = (p.allocations ?? []).map((a) => a.docNo);
  const docs = docNos.length ? await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), inArray(tradeDocs.docNo, docNos))) : [];

  let gross = 0;
  let realisedFx = 0; // + gain, - loss, always from the entity's perspective
  for (const a of p.allocations ?? []) {
    const d = docs.find((x) => x.docNo === a.docNo);
    if (!d) throw new OpsError(`Invoice ${a.docNo} not found.`);
    if (d.bp !== p.bp) throw new OpsError(`Invoice ${a.docNo} does not belong to ${p.bp}.`);
    const outstanding = r2(num(d.grossAmount) - num(d.settled));
    if (r2(a.amount) <= 0) throw new OpsError(`Allocation for ${a.docNo} must be positive.`);
    if (r2(a.amount) > outstanding + 0.01) {
      throw new OpsError(`Allocation ${a.amount.toFixed(2)} exceeds the ${outstanding.toFixed(2)} outstanding on ${a.docNo}.`);
    }
    gross = r2(gross + a.amount);

    // Realised FX (IAS 21.28): the invoice was booked at its own-date rate
    // (baseGross / fxRate); if settlement happens at a different rate, the
    // difference on the settled portion is a realised gain or loss today —
    // not left as a balance-sheet residual for period-end revaluation.
    if (d.currency !== "GHS" && num(d.fxRate) > 0) {
      const settleRate = await getRate(d.currency, payDate);
      const originalBaseForPortion = r2(a.amount * num(d.fxRate));
      const settleBaseForPortion = r2(a.amount * settleRate);
      const diff = r2(settleBaseForPortion - originalBaseForPortion);
      // AR (asset): base value rising when FC strengthens is a gain; AP (liability) is the reverse.
      realisedFx = r2(realisedFx + (d.side === "AR" ? diff : -diff));
    }
  }
  gross = r2(gross + onAccount);

  // Withholding tax applies to outgoing payments, on the VAT-exclusive value.
  const whtCode = p.direction === "OUT" ? (p.whtCode || bp.whtCode || "") : "";
  let whtAmount = 0, whtRate = 0, whtBase = 0;
  if (whtCode) {
    for (const a of p.allocations ?? []) {
      const d = docs.find((x) => x.docNo === a.docNo)!;
      const ratio = num(d.grossAmount) > 0 ? a.amount / num(d.grossAmount) : 0;
      whtBase = r2(whtBase + num(d.netAmount) * ratio);
    }
    const w = computeWht(whtBase, whtCode, p.whtRateOverride);
    whtRate = w.rate; whtAmount = w.amount;
  }
  const netPaid = r2(gross - whtAmount);

  // Maker-checker: anything exceeding the requester's approval limit is
  // queued instead of posted. Users with a zero limit (the default) can only
  // post up to the owner-set threshold explicitly granted to them.
  if (!p._skipApproval && !ctx.canApprove) {
    const limit = ctx.approvalLimit ?? 0;
    if (gross > limit + 0.01) {
      const [row] = await db.insert(approvals).values({
        clientId: ctx.clientId, refType: "PAYMENT", refNo: `PENDING-${Date.now().toString(36).toUpperCase()}`,
        amount: String(gross), requestedBy: ctx.user, status: "PENDING",
        note: p.narrative || "", payload: { ...p, _skipApproval: true } as Record<string, unknown>,
      }).returning();
      throw new ApprovalRequiredError(
        row.id,
        `This ${p.direction === "OUT" ? "payment" : "receipt"} of ${gross.toFixed(2)} exceeds your approval limit of ${limit.toFixed(2)} and has been queued for approval (request #${row.id}).`,
      );
    }
  }

  const ccy = p.currency || bank.currency || "GHS";
  const rate = await getRate(ccy, payDate);
  const payNo = await nextNumber(ctx.clientId, p.direction === "OUT" ? "PAY" : "REC", p.direction === "OUT" ? "PV-" : "RC-");
  const controlAcct = p.direction === "OUT" ? "410100" : "130100";
  const onAccountAcct = p.direction === "OUT" ? "130600" : "410600"; // advance to vendor / customer deposit

  // Document 1 — the cash settlement itself, in the invoice/bank currency,
  // clearing the control account at today's rate.
  const gl: JournalLineInput[] = [];
  if (p.direction === "OUT") {
    if (gross - onAccount > 0) gl.push({ account: controlAcct, bp: p.bp, dr: r2(gross - onAccount), desc: `Settlement to ${bp.name}` });
    if (onAccount > 0) gl.push({ account: onAccountAcct, bp: p.bp, dr: onAccount, desc: `Advance to ${bp.name} (on account)` });
    if (whtAmount > 0) gl.push({ account: "420400", bp: p.bp, cr: whtAmount, desc: `WHT ${whtCode} @ ${whtRate}%`, taxCode: whtCode });
    gl.push({ account: bank.glAccount, cr: netPaid, desc: `Bank payment ${payNo}` });
  } else {
    gl.push({ account: bank.glAccount, dr: netPaid, desc: `Bank receipt ${payNo}` });
    if (whtAmount > 0) gl.push({ account: "131100", bp: p.bp, dr: whtAmount, desc: `WHT credit withheld by ${bp.name}` });
    if (gross - onAccount > 0) gl.push({ account: controlAcct, bp: p.bp, cr: r2(gross - onAccount), desc: `Receipt from ${bp.name}` });
    if (onAccount > 0) gl.push({ account: onAccountAcct, bp: p.bp, cr: onAccount, desc: `Deposit from ${bp.name} (on account)` });
  }

  const res = await postDocument({
    clientId: ctx.clientId, postDate: payDate, module: "PAY",
    docType: p.direction === "OUT" ? "KZ" : "DZ", lines: gl,
    createdBy: ctx.user, reference: payNo, currency: ccy, fxRate: rate,
  });

  // Document 2 — realised FX gain/loss (IAS 21.28). Clearing the control
  // account at today's rate (above) leaves a base-currency residual equal to
  // the FX movement since the invoice date; this document sweeps that
  // residual straight to profit or loss instead of leaving it stranded on
  // the control account. Posted in GHS (rate 1) since this is a pure
  // base-currency remeasurement, not a foreign-currency transaction itself.
  let fxDoc = "";
  if (Math.abs(realisedFx) >= 0.01 && (p.allocations?.length ?? 0) > 0) {
    // Verified by direct trace for both directions: clearing the control
    // account at today's rate leaves a residual that is cancelled by debiting
    // the control account on a gain and crediting it on a loss, with the P&L
    // leg always on the opposite side.
    const isGain = realisedFx > 0;
    const amt = Math.abs(realisedFx);
    const fxLines: JournalLineInput[] = [
      { account: controlAcct, bp: p.bp, [isGain ? "dr" : "cr"]: amt, desc: `FX remeasurement on settlement ${payNo}` } as JournalLineInput,
      { account: isGain ? "510500" : "750300", [isGain ? "cr" : "dr"]: amt, desc: `Realised FX ${isGain ? "gain" : "loss"} on settlement ${payNo}` } as JournalLineInput,
    ];
    const fxRes = await postDocument({
      clientId: ctx.clientId, postDate: payDate, module: "PAY", docType: "FXRLZ",
      lines: fxLines, createdBy: ctx.user, reference: payNo, currency: "GHS",
    });
    fxDoc = fxRes.docNo;
  }

  await db.insert(payments).values({
    clientId: ctx.clientId, payNo, payDate, periodCode: res.period, direction: p.direction,
    bp: p.bp, bankAccount: p.bankCode, method: p.method || "BANK", currency: ccy,
    fxRate: String(rate), grossAmount: String(gross), whtCode, whtRate: String(whtRate),
    whtAmount: String(whtAmount), whtBase: String(whtBase), netPaid: String(netPaid), status: "POSTED",
    glDoc: res.docNo, fxDoc, narrative: p.narrative || "", createdBy: ctx.user,
  });
  if (p.allocations?.length) {
    await db.insert(paymentAllocations).values(p.allocations.map((a) => ({
      clientId: ctx.clientId, payNo, docNo: a.docNo, amount: String(r2(a.amount)),
    })));
  }

  for (const a of p.allocations ?? []) {
    const d = docs.find((x) => x.docNo === a.docNo)!;
    const settled = r2(num(d.settled) + a.amount);
    const fully = settled >= r2(num(d.grossAmount)) - 0.01;
    await db.update(tradeDocs)
      .set({ settled: String(settled), status: fully ? "PAID" : "PART-PAID" })
      .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, a.docNo)));
  }

  const fxNote = realisedFx !== 0 ? `, realised FX ${realisedFx > 0 ? "gain" : "loss"} ${Math.abs(realisedFx).toFixed(2)}` : "";
  return {
    payNo, glDoc: res.docNo, fxDoc, gross, whtAmount, whtRate, netPaid, realisedFx, onAccount,
    message: `${p.direction === "OUT" ? "Payment" : "Receipt"} ${payNo} posted — gross ${gross.toFixed(2)}, WHT ${whtAmount.toFixed(2)}, net ${netPaid.toFixed(2)}${fxNote}${onAccount > 0 ? `, ${onAccount.toFixed(2)} on account` : ""}`,
  };
}

export type DirectPaymentInput = {
  direction: "IN" | "OUT"; categoryKey: string; account: string; bankCode: string;
  payDate?: string; amount: number; bp?: string; payeeName?: string;
  narrative?: string; currency?: string; _skipApproval?: boolean;
};

/**
 * Posts a payment that does NOT belong to the procurement/sales cycle:
 * utility bills, every category of tax and statutory remittance (PAYE, VAT,
 * WHT, CIT), pension and provident fund contributions (SSNIT, Tier 3),
 * insurance premiums, other regulatory fees, and penalties or fines. None of
 * these has a purchase order or a supplier invoice behind it — this posts
 * straight to the correct G/L account (clearing a statutory payable, or
 * hitting an expense account directly) against the bank, exactly as a real
 * accounting department would raise a payment voucher, with no procurement
 * step in between. Withholding tax is never applied here, since none of
 * these payment types is a withholdable supplier payment.
 */
export async function directPayment(ctx: Ctx, p: DirectPaymentInput) {
  if (!(p.amount > 0)) throw new OpsError("Enter an amount greater than zero.");
  if (!p.account) throw new OpsError("Select the account this payment affects.");
  const payDate = p.payDate || today();
  await assertPostable(ctx.clientId, payDate);

  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, p.bankCode)));
  if (!bank) throw new OpsError(`Bank account ${p.bankCode} not found.`);
  const [acct] = await db.select().from(accounts)
    .where(and(eq(accounts.clientId, ctx.clientId), eq(accounts.accountNo, p.account)));
  if (!acct) throw new OpsError(`Account ${p.account} does not exist in the chart of accounts.`);

  let bpName = p.payeeName || "";
  if (p.bp) {
    const [bpRow] = await db.select().from(partners)
      .where(and(eq(partners.clientId, ctx.clientId), eq(partners.bpNo, p.bp)));
    if (bpRow) bpName = bpRow.name;
  }

  const amount = r2(p.amount);

  // Maker-checker applies here exactly as it does on trade payments — a
  // large tax remittance or penalty needs the same second pair of eyes as a
  // large supplier payment.
  if (!p._skipApproval && !ctx.canApprove) {
    const limit = ctx.approvalLimit ?? 0;
    if (amount > limit + 0.01) {
      const [row] = await db.insert(approvals).values({
        clientId: ctx.clientId, refType: "DIRECT_PAYMENT", refNo: `PENDING-${Date.now().toString(36).toUpperCase()}`,
        amount: String(amount), requestedBy: ctx.user, status: "PENDING",
        note: p.narrative || "", payload: { ...p, _skipApproval: true } as Record<string, unknown>,
      }).returning();
      throw new ApprovalRequiredError(
        row.id,
        `This payment of ${amount.toFixed(2)} exceeds your approval limit of ${limit.toFixed(2)} and has been queued for approval (request #${row.id}).`,
      );
    }
  }

  const ccy = p.currency || bank.currency || "GHS";
  const rate = await getRate(ccy, payDate);
  const payNo = await nextNumber(ctx.clientId, p.direction === "OUT" ? "PAY" : "REC", p.direction === "OUT" ? "DP-" : "DR-");
  const def = DIRECT_PAYMENT_CATEGORIES.find((c) => c.key === p.categoryKey);
  const label = def?.label || "Direct payment";
  const desc = `${label}${bpName ? ` — ${bpName}` : ""}`;

  const gl: JournalLineInput[] = p.direction === "OUT"
    ? [
        { account: p.account, bp: p.bp, dr: amount, desc },
        { account: bank.glAccount, cr: amount, desc: `Bank payment ${payNo} — ${label}` },
      ]
    : [
        { account: bank.glAccount, dr: amount, desc: `Bank receipt ${payNo} — ${label}` },
        { account: p.account, bp: p.bp, cr: amount, desc },
      ];

  const res = await postDocument({
    clientId: ctx.clientId, postDate: payDate, module: "FI",
    docType: p.direction === "OUT" ? "DP" : "DR", lines: gl,
    createdBy: ctx.user, reference: payNo, currency: ccy, fxRate: rate,
  });

  await db.insert(payments).values({
    clientId: ctx.clientId, payNo, payDate, periodCode: res.period, direction: p.direction,
    category: "DIRECT", directCategory: p.categoryKey, glAccount: p.account,
    payeeName: p.payeeName || "", bp: p.bp || "", bankAccount: p.bankCode, method: "BANK",
    currency: ccy, fxRate: String(rate), grossAmount: String(amount), netPaid: String(amount),
    status: "POSTED", glDoc: res.docNo, narrative: p.narrative || label, createdBy: ctx.user,
  });

  return {
    payNo, glDoc: res.docNo, amount,
    message: `${label} of ${amount.toFixed(2)} posted as ${payNo} — no procurement document required.`,
  };
}

/**
 * BUG FIX — reversing a document previously only reversed the raw journal
 * lines. Every screen in the application (Payment Desk open items, AR/AP
 * ageing, the payment history table, bank reconciliation) reads from the
 * `payments`, `tradeDocs` and `bankStatementLines` tables, NOT from the
 * journal's `reversed` flag — so a "successful" reversal was completely
 * invisible everywhere except the raw Universal Journal: an invoice stayed
 * marked PAID forever, the cash could never be re-collected through the
 * application, and ageing/open-items were silently wrong from that point on.
 *
 * This function cascades a reversal into every table that actually drives
 * the screens a user looks at:
 *   - Reversing a PAYMENT reopens the invoice(s) it was allocated to (settled
 *     is reduced, status recalculated back to OPEN/PART-PAID) and marks the
 *     payment itself REVERSED so it can never be "un-reversed" twice.
 *   - Reversing an unpaid INVOICE (no settlement yet) marks it VOID so it
 *     correctly disappears from open items and ageing.
 *   - Reversing a bank-posted statement line resets it to UNMATCHED so it can
 *     be reclassified and re-posted correctly.
 *   - Batch system postings with their own multi-row subsidiary state
 *     (depreciation runs, payroll runs, amortisation runs, inventory
 *     write-downs, single-asset capitalisation/disposal) are explicitly
 *     BLOCKED with a clear explanation rather than silently leaving a
 *     different part of the system inconsistent — the same mistake this fix
 *     corrects should not be repeated in a new area.
 */
export async function reverseTransaction(ctx: Ctx, docNo: string, reason: string, reversalDate?: string) {
  // ERGONOMICS FIX — a user naturally types the number they can actually see
  // on screen (a payment number like "PV-5100001", or an invoice number like
  // "SI-3300004"), not the internal numeric General Ledger document id. The
  // old form only accepted the raw GL id, so entering the payment/invoice
  // number a user could see either found nothing or, if it happened to
  // collide with something else, appeared to "do nothing" — this is very
  // likely what was actually experienced. Both forms are now accepted.
  const [paymentByPayNo] = await db.select().from(payments)
    .where(and(eq(payments.clientId, ctx.clientId), eq(payments.payNo, docNo)));
  const [docByDocNo] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, docNo)));
  const resolvedGlDoc = paymentByPayNo?.glDoc || docByDocNo?.glDoc || docNo;

  const [payment] = await db.select().from(payments)
    .where(and(eq(payments.clientId, ctx.clientId), eq(payments.glDoc, resolvedGlDoc)));
  if (payment) return reversePaymentCascade(ctx, payment, reason, reversalDate);

  const [doc] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.glDoc, resolvedGlDoc)));
  if (doc) return reverseTradeDocCascade(ctx, doc, reason, reversalDate);

  const [stmtLine] = await db.select().from(bankStatementLines)
    .where(and(eq(bankStatementLines.clientId, ctx.clientId), eq(bankStatementLines.postedDoc, resolvedGlDoc)));
  if (stmtLine) return reverseBankLineCascade(ctx, stmtLine, reason, reversalDate);

  // A user who reverses the realised-FX companion document directly (rather
  // than the payment it belongs to) would otherwise undo only the exchange
  // adjustment while leaving the underlying settlement intact — not a valid
  // accounting correction, since the FX movement only exists because of that
  // settlement. Redirect them to reverse the payment itself instead.
  const [fxOwner] = await db.select({ payNo: payments.payNo }).from(payments)
    .where(and(eq(payments.clientId, ctx.clientId), eq(payments.fxDoc, resolvedGlDoc))).limit(1);
  if (fxOwner) {
    throw new OpsError(
      `This is the foreign exchange adjustment for payment ${fxOwner.payNo} and cannot be reversed on its own. ` +
      `Reverse payment ${fxOwner.payNo} instead — the FX adjustment will be reversed with it automatically.`,
    );
  }

  docNo = resolvedGlDoc;

  const [depRun] = await db.select({ id: depreciationRuns.id }).from(depreciationRuns)
    .where(and(eq(depreciationRuns.clientId, ctx.clientId), eq(depreciationRuns.glDoc, docNo))).limit(1);
  if (depRun) {
    throw new OpsError(
      "This is a batch depreciation posting covering multiple assets and cannot be reversed directly. " +
      "Re-open the fiscal period, correct the individual asset records if needed, and post a manual adjusting journal instead.",
    );
  }

  const [payRun] = await db.select({ runNo: payrollRuns.runNo }).from(payrollRuns)
    .where(and(eq(payrollRuns.clientId, ctx.clientId), eq(payrollRuns.glDoc, docNo))).limit(1);
  if (payRun) {
    throw new OpsError(
      `This is the payroll posting for run ${payRun.runNo}, covering every employee paid in that run, and cannot be reversed directly. ` +
      "Post a manual correcting journal for the specific adjustment needed instead.",
    );
  }

  const [orig] = await db.select({ module: journalLines.module, docType: journalLines.docType })
    .from(journalLines)
    .where(and(eq(journalLines.clientId, ctx.clientId), eq(journalLines.docNo, docNo))).limit(1);
  if (!orig) throw new OpsError(`Document ${docNo} was not found.`);

  const blockedBatchTypes: Record<string, string> = {
    AMORT: "a batch prepayment/accrual amortisation run covering multiple schedules",
    NRV: "a batch inventory net-realisable-value write-down covering multiple stock items",
    GI: "an automatic cost-of-sales posting linked to a stock issue",
    AA: "a fixed asset capitalisation",
    REVAL: "a fixed asset revaluation",
    IMPAIR: "a fixed asset impairment",
    AD: "a fixed asset disposal",
  };
  if (blockedBatchTypes[orig.docType]) {
    throw new OpsError(
      `This document is ${blockedBatchTypes[orig.docType]} and carries its own subsidiary records that a plain reversal would not correct. ` +
      "Make the correction through the originating module (Fixed Assets, Prepayments or Inventory) or post a manual adjusting journal instead.",
    );
  }

  // Plain manual journals, opening balances, VAT control settlement, year-end
  // close and FX revaluation touch only the General Ledger with no
  // dependent subsidiary table — a straightforward reversal is fully correct.
  const res = await reverseJournalDocument(ctx.clientId, docNo, ctx.user, reason, reversalDate);
  return { ...res, message: `Document ${docNo} reversed by ${res.docNo}.` };
}

async function reversePaymentCascade(
  ctx: Ctx, payment: typeof payments.$inferSelect, reason: string, reversalDate?: string,
) {
  if (payment.status === "REVERSED") throw new OpsError(`Payment ${payment.payNo} has already been reversed.`);

  const allocations = await db.select().from(paymentAllocations)
    .where(and(eq(paymentAllocations.clientId, ctx.clientId), eq(paymentAllocations.payNo, payment.payNo)));

  const reopened: string[] = [];
  for (const a of allocations) {
    const [doc] = await db.select().from(tradeDocs)
      .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, a.docNo)));
    if (!doc) continue; // defensive — the invoice may have been removed separately
    const newSettled = Math.max(0, r2(num(doc.settled) - num(a.amount)));
    const gross = num(doc.grossAmount);
    const newStatus = newSettled <= 0.01 ? "OPEN" : newSettled < gross - 0.01 ? "PART-PAID" : "PAID";
    await db.update(tradeDocs).set({ settled: String(newSettled), status: newStatus })
      .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, a.docNo)));
    reopened.push(a.docNo);
  }

  const res = await reverseJournalDocument(ctx.clientId, payment.glDoc, ctx.user, reason, reversalDate);

  // BUG FIX — a foreign-currency settlement posts a SECOND document for the
  // realised FX gain/loss (see createPayment). This was never reversed
  // alongside the payment, leaving a stray, now-incorrect FX entry in the
  // ledger forever. It is now reversed in the same operation.
  let fxReversalDoc = "";
  if (payment.fxDoc) {
    try {
      const fxRes = await reverseJournalDocument(ctx.clientId, payment.fxDoc, ctx.user, `FX adjustment for reversed payment ${payment.payNo}: ${reason}`, reversalDate);
      fxReversalDoc = fxRes.docNo;
    } catch { /* already reversed independently — do not block the main reversal */ }
  }

  // BUG FIX — if this payment's bank leg had already been matched or posted
  // during bank reconciliation, the statement line kept pointing at a journal
  // entry that no longer represents real, unreversed activity. Returning it
  // to UNMATCHED keeps the reconciliation honest instead of silently treating
  // a reversed payment as still cleared.
  const relatedStatementLines = await db.select({ id: bankStatementLines.id }).from(bankStatementLines)
    .where(and(eq(bankStatementLines.clientId, ctx.clientId), eq(bankStatementLines.postedDoc, payment.glDoc)));
  for (const line of relatedStatementLines) {
    await db.update(bankStatementLines).set({ status: "UNMATCHED", postedDoc: "", matchedJournalId: null })
      .where(eq(bankStatementLines.id, line.id));
  }

  await db.update(payments).set({ status: "REVERSED" })
    .where(and(eq(payments.clientId, ctx.clientId), eq(payments.payNo, payment.payNo)));

  const reopenedNote = reopened.length
    ? ` ${reopened.join(", ")} ${reopened.length === 1 ? "is" : "are"} now reopened in the Payment Desk and can be re-collected.`
    : "";
  const fxNote = fxReversalDoc ? ` The associated foreign exchange adjustment was also reversed (${fxReversalDoc}).` : "";
  const bankNote = relatedStatementLines.length ? " Its bank statement line was returned to Unmatched." : "";
  return {
    ...res, payNo: payment.payNo,
    message: `Payment ${payment.payNo} reversed by ${res.docNo}.${reopenedNote}${fxNote}${bankNote}`,
  };
}

async function reverseTradeDocCascade(
  ctx: Ctx, doc: typeof tradeDocs.$inferSelect, reason: string, reversalDate?: string,
) {
  if (doc.status === "VOID") throw new OpsError(`${doc.docNo} has already been voided.`);
  if (num(doc.settled) > 0.01) {
    throw new OpsError(
      `${doc.docNo} has ${num(doc.settled).toFixed(2)} already allocated against it. ` +
      "Reverse the payment(s) settling it first, then void the invoice.",
    );
  }
  const res = await reverseJournalDocument(ctx.clientId, doc.glDoc, ctx.user, reason, reversalDate);
  await db.update(tradeDocs).set({ status: "VOID" })
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, doc.docNo)));
  return { ...res, docNo: doc.docNo, message: `${doc.docNo} voided and reversed by ${res.docNo}.` };
}

async function reverseBankLineCascade(
  ctx: Ctx, line: typeof bankStatementLines.$inferSelect, reason: string, reversalDate?: string,
) {
  const res = await reverseJournalDocument(ctx.clientId, line.postedDoc, ctx.user, reason, reversalDate);
  await db.update(bankStatementLines).set({ status: "UNMATCHED", postedDoc: "" })
    .where(eq(bankStatementLines.id, line.id));
  return { ...res, message: `Statement line reversed by ${res.docNo} and returned to Unmatched for reclassification.` };
}

/** Lists payments awaiting a checker's decision. */
export async function listApprovals(clientId: string, status = "PENDING") {
  const rows = await db.select().from(approvals)
    .where(and(eq(approvals.clientId, clientId), eq(approvals.status, status)))
    .orderBy(desc(approvals.createdAt));
  return rows.map((r) => ({ ...r, amount: num(r.amount) }));
}

/** Approves a queued payment and posts it; or rejects it, releasing the request. */
export async function decideApproval(ctx: Ctx, id: number, decision: "APPROVED" | "REJECTED", note = "") {
  const [row] = await db.select().from(approvals).where(and(eq(approvals.id, id), eq(approvals.clientId, ctx.clientId)));
  if (!row) throw new OpsError("Approval request not found.");
  if (row.status !== "PENDING") throw new OpsError(`This request has already been ${row.status.toLowerCase()}.`);

  if (decision === "REJECTED") {
    await db.update(approvals).set({ status: "REJECTED", decidedBy: ctx.user, decidedAt: new Date(), note })
      .where(eq(approvals.id, id));
    return { message: `Request #${id} rejected.` };
  }

  if (num(row.amount) > (ctx.approvalLimit ?? 0) + 0.01) {
    throw new OpsError(`Your approval limit of ${(ctx.approvalLimit ?? 0).toFixed(2)} is below the requested ${num(row.amount).toFixed(2)}.`);
  }
  const result = row.refType === "DIRECT_PAYMENT"
    ? await directPayment(ctx, { ...(row.payload as DirectPaymentInput), _skipApproval: true })
    : await createPayment(ctx, { ...(row.payload as PaymentInput), _skipApproval: true });
  await db.update(approvals).set({ status: "APPROVED", decidedBy: ctx.user, decidedAt: new Date(), note, refNo: result.payNo })
    .where(eq(approvals.id, id));
  return { ...result, message: `Request #${id} approved and posted as ${result.payNo}.` };
}

// Documents that represent a genuine cash-collectible/payable balance.
// Credit notes (SCN/PCN) are deliberately excluded — they reduce what a
// partner owes rather than adding to it, so they cannot be "paid"; they are
// resolved through applyCreditNote() instead. See AUDIT FIX 6.
const CASH_SETTLEABLE_KINDS = ["SINV", "SDN", "PINV", "PDN", "DINV"];
const CREDIT_NOTE_KINDS = ["SCN", "PCN"];

/** Open items for a partner, used to drive the payment allocation grid (invoices and debit notes only). */
export async function openItems(clientId: string, bp?: string, side?: "AR" | "AP") {
  const conds = [
    eq(tradeDocs.clientId, clientId),
    inArray(tradeDocs.status, ["OPEN", "PART-PAID"]),
    inArray(tradeDocs.docKind, CASH_SETTLEABLE_KINDS),
  ];
  if (bp) conds.push(eq(tradeDocs.bp, bp));
  if (side) conds.push(eq(tradeDocs.side, side));
  const rows = await db.select().from(tradeDocs).where(and(...conds)).orderBy(asc(tradeDocs.dueDate));
  return rows.map((d) => ({
    docNo: d.docNo, docKind: d.docKind, side: d.side, bp: d.bp, docDate: d.docDate,
    dueDate: d.dueDate, currency: d.currency, gross: num(d.grossAmount),
    settled: num(d.settled), outstanding: r2(num(d.grossAmount) - num(d.settled)), status: d.status,
  }));
}

/** Credit notes with a balance still available to apply against an invoice. */
export async function availableCredits(clientId: string, bp?: string, side?: "AR" | "AP") {
  const conds = [
    eq(tradeDocs.clientId, clientId),
    inArray(tradeDocs.status, ["OPEN", "PART-PAID"]),
    inArray(tradeDocs.docKind, CREDIT_NOTE_KINDS),
  ];
  if (bp) conds.push(eq(tradeDocs.bp, bp));
  if (side) conds.push(eq(tradeDocs.side, side));
  const rows = await db.select().from(tradeDocs).where(and(...conds)).orderBy(asc(tradeDocs.docDate));
  return rows.map((d) => ({
    docNo: d.docNo, docKind: d.docKind, side: d.side, bp: d.bp, docDate: d.docDate,
    currency: d.currency, gross: num(d.grossAmount), settled: num(d.settled),
    available: r2(num(d.grossAmount) - num(d.settled)), status: d.status,
  }));
}

/**
 * Applies a credit note against an outstanding invoice/debit note — a
 * non-cash settlement. No new GL postings are required: the credit note
 * already credited the AR/AP control account when it was raised, and the
 * invoice already debited the same control account, so the ledger already
 * nets correctly. This only reconciles the open-item sub-ledger so both
 * documents show their true remaining balance instead of sitting open forever.
 */
export async function applyCreditNote(ctx: Ctx, p: { creditDocNo: string; invoiceDocNo: string; amount: number }) {
  const [credit] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, p.creditDocNo)));
  if (!credit) throw new OpsError(`Document ${p.creditDocNo} not found.`);
  if (!CREDIT_NOTE_KINDS.includes(credit.docKind)) throw new OpsError(`${p.creditDocNo} is not a credit note.`);

  const [invoice] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, p.invoiceDocNo)));
  if (!invoice) throw new OpsError(`Document ${p.invoiceDocNo} not found.`);
  if (!CASH_SETTLEABLE_KINDS.includes(invoice.docKind)) throw new OpsError(`${p.invoiceDocNo} must be an invoice or debit note.`);
  if (invoice.bp !== credit.bp) throw new OpsError("The credit note and the invoice must belong to the same business partner.");
  if (invoice.side !== credit.side) throw new OpsError("The credit note and the invoice must be on the same side (both receivable or both payable).");

  const amount = r2(p.amount);
  if (amount <= 0) throw new OpsError("Enter an amount greater than zero to apply.");
  const creditAvailable = r2(num(credit.grossAmount) - num(credit.settled));
  const invoiceOutstanding = r2(num(invoice.grossAmount) - num(invoice.settled));
  if (amount > creditAvailable + 0.01) throw new OpsError(`Only ${creditAvailable.toFixed(2)} is available on credit note ${p.creditDocNo}.`);
  if (amount > invoiceOutstanding + 0.01) throw new OpsError(`Only ${invoiceOutstanding.toFixed(2)} is outstanding on ${p.invoiceDocNo}.`);

  const newCreditSettled = r2(num(credit.settled) + amount);
  const newInvoiceSettled = r2(num(invoice.settled) + amount);
  await db.update(tradeDocs).set({
    settled: String(newCreditSettled),
    status: newCreditSettled >= r2(num(credit.grossAmount)) - 0.01 ? "APPLIED" : "PART-PAID",
  }).where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, p.creditDocNo)));
  await db.update(tradeDocs).set({
    settled: String(newInvoiceSettled),
    status: newInvoiceSettled >= r2(num(invoice.grossAmount)) - 0.01 ? "PAID" : "PART-PAID",
  }).where(and(eq(tradeDocs.clientId, ctx.clientId), eq(tradeDocs.docNo, p.invoiceDocNo)));

  return {
    amount,
    message: `${amount.toFixed(2)} from credit note ${p.creditDocNo} applied against ${p.invoiceDocNo}`,
  };
}

/* ================================================================
   3. BANKING — statement import, auto-matching, reconciliation
   ================================================================ */
const RULES: { re: RegExp; account: string; label: string }[] = [
  { re: /salar|payroll|wages/i, account: "430100", label: "Payroll settlement" },
  { re: /\bssnit\b|social security/i, account: "420600", label: "SSNIT remittance" },
  { re: /\bpaye\b/i, account: "420300", label: "PAYE remittance" },
  { re: /\bvat\b/i, account: "420200", label: "VAT remittance" },
  { re: /withhold|\bwht\b/i, account: "420400", label: "WHT remittance" },
  { re: /bank charge|commission|\bcoT\b|ledger fee|sms alert/i, account: "720800", label: "Bank charges" },
  { re: /interest (received|credit)|credit interest/i, account: "510200", label: "Interest income" },
  { re: /interest (paid|charge)|loan interest/i, account: "750100", label: "Interest expense" },
  { re: /electricity|ecg|water|gwcl|utilit/i, account: "710200", label: "Utilities" },
  { re: /rent/i, account: "710100", label: "Rent" },
  { re: /fuel|petrol|diesel|shell|goil|total/i, account: "720100", label: "Vehicle running" },
  { re: /internet|data|vodafone|mtn|airteltigo|telecel/i, account: "720300", label: "Telephone & internet" },
  { re: /insurance|premium/i, account: "710400", label: "Insurance" },
  { re: /transfer|trf|deposit|lodg/i, account: "130100", label: "Customer receipt (likely)" },
];

function suggestAccount(narrative: string, isCredit: boolean) {
  for (const r of RULES) if (r.re.test(narrative)) return r.account;
  return isCredit ? "149000" : "990100";
}

/** Imports a statement from CSV text. Columns: date, narrative, debit, credit[, balance, reference] */
export async function importStatement(ctx: Ctx, bankCode: string, csv: string) {
  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, bankCode)));
  if (!bank) throw new OpsError(`Bank account ${bankCode} not found.`);

  const rows = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (rows.length < 2) throw new OpsError("The statement needs a header row and at least one transaction.");
  const header = rows[0].toLowerCase().split(",").map((h) => h.trim());
  const idx = (names: string[]) => header.findIndex((h) => names.some((n) => h.includes(n)));
  const iDate = idx(["date"]), iNarr = idx(["narrat", "descr", "details", "particular"]);
  const iDr = idx(["debit", "withdraw", "outflow"]), iCr = idx(["credit", "deposit", "inflow"]);
  const iBal = idx(["balance"]), iRef = idx(["ref", "cheque"]);
  if (iDate < 0 || iNarr < 0) throw new OpsError("The statement must contain at least 'Date' and 'Narrative' columns.");

  const batch = `IMP-${Date.now().toString(36).toUpperCase()}`;
  const parsed: (typeof bankStatementLines.$inferInsert)[] = [];
  const errors: string[] = [];

  for (let i = 1; i < rows.length; i++) {
    const cells = rows[i].split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
    const raw = cells[iDate];
    const d = new Date(raw);
    if (!raw || Number.isNaN(d.getTime())) { errors.push(`Row ${i + 1}: unreadable date "${raw}"`); continue; }
    const clean = (s?: string) => Math.abs(Number((s || "0").replace(/[^0-9.-]/g, ""))) || 0;
    const dr = iDr >= 0 ? clean(cells[iDr]) : 0;
    const cr = iCr >= 0 ? clean(cells[iCr]) : 0;
    if (dr === 0 && cr === 0) { errors.push(`Row ${i + 1}: both debit and credit are zero`); continue; }
    const narrative = cells[iNarr] || "";
    parsed.push({
      clientId: ctx.clientId, bankCode, stmtDate: d.toISOString().slice(0, 10), narrative,
      reference: iRef >= 0 ? cells[iRef] || "" : "", debit: String(dr), credit: String(cr),
      balance: String(iBal >= 0 ? clean(cells[iBal]) : 0), status: "UNMATCHED",
      suggestedAccount: suggestAccount(narrative, cr > 0), importBatch: batch,
    });
  }
  if (!parsed.length) throw new OpsError(`No usable rows. ${errors.slice(0, 3).join("; ")}`);

  // AUDIT FIX 3 — duplicate statement detection. Re-importing the same period
  // previously doubled the statement and silently broke the reconciliation.
  const existing = await db.select().from(bankStatementLines)
    .where(and(eq(bankStatementLines.clientId, ctx.clientId), eq(bankStatementLines.bankCode, bankCode)));
  const key = (d: string, n: string, dr: string, cr: string) =>
    `${d}|${n.trim().toLowerCase()}|${Number(dr).toFixed(2)}|${Number(cr).toFixed(2)}`;
  const seen = new Set(existing.map((e) => key(e.stmtDate, e.narrative, e.debit, e.credit)));
  const fresh = parsed.filter((p) => !seen.has(key(String(p.stmtDate), String(p.narrative ?? ""), String(p.debit), String(p.credit))));
  const duplicates = parsed.length - fresh.length;
  if (!fresh.length) {
    throw new OpsError(`All ${parsed.length} rows are already on file for ${bankCode} — this statement has been imported before.`);
  }
  await db.insert(bankStatementLines).values(fresh);
  const matched = await autoMatch(ctx, bankCode);
  return {
    batch, imported: fresh.length, duplicates, skipped: errors.length,
    errors: errors.slice(0, 10), autoMatched: matched,
    message: `Imported ${fresh.length} line(s)${duplicates ? `, ${duplicates} duplicate(s) ignored` : ""}${errors.length ? `, ${errors.length} unreadable row(s) skipped` : ""}. ${matched} matched automatically.`,
  };
}

/** Matches statement lines to existing GL postings on the bank account. */
export async function autoMatch(ctx: Ctx, bankCode: string) {
  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, bankCode)));
  if (!bank) return 0;
  const open = await db.select().from(bankStatementLines)
    .where(and(eq(bankStatementLines.clientId, ctx.clientId), eq(bankStatementLines.bankCode, bankCode), eq(bankStatementLines.status, "UNMATCHED")));
  const gl = await db.select().from(journalLines)
    .where(and(eq(journalLines.clientId, ctx.clientId), eq(journalLines.account, bank.glAccount)));
  const used = new Set<number>();
  let count = 0;
  for (const s of open) {
    const sDr = num(s.debit), sCr = num(s.credit);
    // Bank statement debit = money out = GL credit on the bank account.
    const hit = gl.find((g) => !used.has(g.id)
      && Math.abs(num(g.credit) - sDr) < 0.01 && Math.abs(num(g.debit) - sCr) < 0.01
      && Math.abs(Date.parse(g.postDate) - Date.parse(s.stmtDate)) <= 5 * 86400000);
    if (hit) {
      used.add(hit.id);
      await db.update(bankStatementLines)
        .set({ status: "MATCHED", matchedJournalId: hit.id, postedDoc: hit.docNo })
        .where(eq(bankStatementLines.id, s.id));
      count++;
    }
  }
  return count;
}

/** Posts an unmatched statement line to a chosen GL account. */
export async function postStatementLine(ctx: Ctx, lineId: number, account: string, bp?: string, ccode?: string) {
  const [s] = await db.select().from(bankStatementLines).where(eq(bankStatementLines.id, lineId));
  if (!s || s.clientId !== ctx.clientId) throw new OpsError("Statement line not found.");
  if (s.status === "POSTED" || s.status === "MATCHED") throw new OpsError("This line is already cleared.");
  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, s.bankCode)));
  if (!bank) throw new OpsError("Bank account not found.");

  const dr = num(s.debit), cr = num(s.credit);
  const gl: JournalLineInput[] = cr > 0
    ? [{ account: bank.glAccount, dr: cr, desc: s.narrative }, { account, cr, bp, cc: ccode, desc: s.narrative }]
    : [{ account, dr, bp, cc: ccode, desc: s.narrative }, { account: bank.glAccount, cr: dr, desc: s.narrative }];

  const res = await postDocument({
    clientId: ctx.clientId, postDate: s.stmtDate, module: "BANK", docType: "BS",
    lines: gl, createdBy: ctx.user, reference: s.reference || `STMT-${s.id}`,
    currency: bank.currency,
  });
  await db.update(bankStatementLines).set({ status: "POSTED", postedDoc: res.docNo })
    .where(eq(bankStatementLines.id, lineId));
  return { ...res, message: `Statement line posted as ${res.docNo}` };
}

export async function buildReconciliation(ctx: Ctx, bankCode: string, periodCode: string) {
  const [bank] = await db.select().from(bankAccounts)
    .where(and(eq(bankAccounts.clientId, ctx.clientId), eq(bankAccounts.bankCode, bankCode)));
  if (!bank) throw new OpsError("Bank account not found.");

  const [glRow] = await db.select({
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines).where(and(
    eq(journalLines.clientId, ctx.clientId), eq(journalLines.account, bank.glAccount),
    sql`${journalLines.periodCode} <= ${periodCode}`,
  ));
  const ledgerBalance = r2(num(bank.openingBalance) + num(glRow?.dr) - num(glRow?.cr));

  const stmt = await db.select().from(bankStatementLines)
    .where(and(eq(bankStatementLines.clientId, ctx.clientId), eq(bankStatementLines.bankCode, bankCode)))
    .orderBy(desc(bankStatementLines.stmtDate));
  const last = stmt[0];
  const statementBalance = last ? num(last.balance) : ledgerBalance;

  const unmatched = stmt.filter((s) => s.status === "UNMATCHED");
  const unpresented = r2(unmatched.reduce((t, s) => t + num(s.debit), 0));
  const uncredited = r2(unmatched.reduce((t, s) => t + num(s.credit), 0));
  const difference = r2(statementBalance - unpresented + uncredited - ledgerBalance);
  const status = Math.abs(difference) < 0.01 ? "BALANCED" : "DRAFT";

  // AUDIT FIX 12 — re-running the reconciliation for the same bank/period
  // previously inserted a brand-new record every time, leaving a pile of
  // stale drafts. An unreviewed draft for the same bank + period is now
  // refreshed in place instead; a reconciliation already marked REVIEWED or
  // APPROVED is left untouched and a fresh one is prepared alongside it.
  const [existingDraft] = await db.select().from(bankRecs).where(and(
    eq(bankRecs.clientId, ctx.clientId), eq(bankRecs.bankCode, bankCode),
    eq(bankRecs.periodCode, periodCode), inArray(bankRecs.status, ["DRAFT", "BALANCED"]),
  ));

  const recNo = existingDraft?.recNo ?? (await nextNumber(ctx.clientId, "REC", "BR-"));
  const values = {
    statementBalance: String(statementBalance), ledgerBalance: String(ledgerBalance),
    unpresentedChq: String(unpresented), uncreditedLodg: String(uncredited),
    difference: String(difference), status, createdBy: ctx.user,
  };
  if (existingDraft) {
    await db.update(bankRecs).set(values)
      .where(and(eq(bankRecs.clientId, ctx.clientId), eq(bankRecs.recNo, recNo)));
  } else {
    await db.insert(bankRecs).values({ clientId: ctx.clientId, recNo, bankCode, periodCode, ...values });
  }
  return {
    recNo, statementBalance, ledgerBalance, unpresented, uncredited, difference,
    balanced: Math.abs(difference) < 0.01, unmatchedCount: unmatched.length,
    message: `Reconciliation ${recNo} ${existingDraft ? "refreshed" : "prepared"} — difference ${difference.toFixed(2)}`,
  };
}

export async function updateReconciliation(ctx: Ctx, recNo: string, patch: { statementBalance?: number; notes?: string; status?: string }) {
  const set: Record<string, string> = {};
  if (patch.statementBalance !== undefined) set.statementBalance = String(r2(patch.statementBalance));
  if (patch.notes !== undefined) set.notes = patch.notes;
  if (patch.status) set.status = patch.status;
  await db.update(bankRecs).set(set)
    .where(and(eq(bankRecs.clientId, ctx.clientId), eq(bankRecs.recNo, recNo)));
  return { message: `Reconciliation ${recNo} updated` };
}

/* ================================================================
   4. FIXED ASSETS — register, depreciation, revaluation, disposal
   ================================================================ */
export async function createAsset(ctx: Ctx, p: {
  description: string; assetClass: string; cost: number; acquisitionDate?: string;
  residual?: number; usefulLife?: number; method?: string; costCenter?: string;
  unitsTotal?: number; bankAccount?: string; capitalise?: boolean;
}) {
  const cls = ASSET_CLASSES.find((c) => c.key === p.assetClass);
  if (!cls) throw new OpsError(`Unknown asset class ${p.assetClass}`);
  // AUDIT FIX 8 — a negative cost would capitalise a "negative asset",
  // silently crediting instead of debiting the balance sheet.
  if (!(p.cost > 0)) throw new OpsError("Acquisition cost must be greater than zero.");
  if (p.residual !== undefined && p.residual < 0) throw new OpsError("Residual value cannot be negative.");
  if (p.residual !== undefined && p.residual > p.cost) throw new OpsError("Residual value cannot exceed the acquisition cost.");
  const date = p.acquisitionDate || today();
  const assetNo = await nextNumber(ctx.clientId, "ASSET", "FA-");
  const life = p.usefulLife ?? cls.life;
  const method = (p.method ?? cls.method) as string;

  await db.insert(assets).values({
    clientId: ctx.clientId, assetNo, description: p.description, assetClass: p.assetClass,
    acquisitionDate: date, cost: String(r2(p.cost)), residual: String(r2(p.residual ?? 0)),
    usefulLife: life, method, rbRate: String(cls.rate), unitsTotal: String(p.unitsTotal ?? 0),
    nbv: String(r2(p.cost)), costCenter: p.costCenter || "CC-ADM",
    capitalAllowanceClass: cls.caClass,
  });

  let glDoc = "";
  if (p.capitalise !== false) {
    const acct = p.assetClass === "LAND" ? "110100"
      : p.assetClass === "BUILDING" ? "110200"
      : ["MOTOR", "TRUCK_FLEET"].includes(p.assetClass) ? "110400"
      : ["COMPUTER", "DATACENTRE"].includes(p.assetClass) ? "110600"
      : ["SOFTWARE", "SPECTRUM"].includes(p.assetClass) ? "112000"
      : ["FURNITURE", "OFFICE_EQUIP", "HOTEL_FF"].includes(p.assetClass) ? "110500"
      : p.assetClass === "ROU_ASSET" ? "110800" : "110300";
    const res = await postDocument({
      clientId: ctx.clientId, postDate: date, module: "FA", docType: "AA",
      lines: [
        { account: acct, dr: r2(p.cost), cc: p.costCenter, desc: `Capitalise ${p.description}` },
        { account: p.bankAccount || "141000", cr: r2(p.cost), desc: `Acquisition of ${assetNo}` },
      ],
      createdBy: ctx.user, reference: assetNo,
    });
    glDoc = res.docNo;
  }
  return { assetNo, glDoc, message: `Asset ${assetNo} added to the register` };
}

/** Runs depreciation for every eligible asset in a period (idempotent). */
export async function runDepreciation(ctx: Ctx, periodCode: string) {
  // Concurrency guard — see withPeriodLock. Two simultaneous "Run
  // depreciation" requests for the same period can no longer both decide to
  // charge the same assets.
  return withPeriodLock(ctx.clientId, periodCode, "depreciation", () => runDepreciationInner(ctx, periodCode));
}

async function runDepreciationInner(ctx: Ctx, periodCode: string) {
  const [period] = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
  if (!period) throw new OpsError(`Period ${periodCode} does not exist.`);
  if (period.status !== "OPEN") throw new OpsError(`Period ${periodCode} is ${period.status}.`);

  const list = await db.select().from(assets)
    .where(and(eq(assets.clientId, ctx.clientId), eq(assets.status, "ACTIVE")));
  const lines: JournalLineInput[] = [];
  const detail: { assetNo: string; amount: number }[] = [];
  let total = 0;

  for (const a of list) {
    if (a.lastDepPeriod >= periodCode) continue;
    if (a.assetClass === "LAND") continue;
    if (a.acquisitionDate > period.endDate) continue;
    const cost = num(a.cost), residual = num(a.residual), accum = num(a.accumDep);
    const depreciable = r2(cost - residual - accum);
    if (depreciable <= 0) continue;

    let amount = 0;
    if (a.method === "RB") amount = r2(((cost - accum) * num(a.rbRate)) / 100 / 12);
    else if (a.method === "UOP" && num(a.unitsTotal) > 0) {
      amount = r2(((cost - residual) / num(a.unitsTotal)) * (num(a.unitsTotal) / Math.max(a.usefulLife, 1) / 12));
    } else amount = r2((cost - residual) / Math.max(a.usefulLife, 1) / 12);
    amount = Math.min(amount, depreciable);
    if (amount <= 0) continue;

    const expense = a.assetClass === "ROU_ASSET" ? "730300"
      : ["SOFTWARE", "SPECTRUM"].includes(a.assetClass) ? "730200" : "730100";
    lines.push({ account: expense, dr: amount, cc: a.costCenter, desc: `Depreciation ${a.assetNo} — ${a.description}` });
    lines.push({ account: "111500", cr: amount, desc: `Accumulated depreciation ${a.assetNo}` });

    await db.update(assets).set({
      accumDep: String(r2(accum + amount)), nbv: String(r2(cost - accum - amount)), lastDepPeriod: periodCode,
    }).where(and(eq(assets.clientId, ctx.clientId), eq(assets.assetNo, a.assetNo)));
    detail.push({ assetNo: a.assetNo, amount });
    total = r2(total + amount);
  }

  if (!lines.length) return { posted: 0, total: 0, message: `No depreciation due for ${periodCode}.` };
  const res = await postDocument({
    clientId: ctx.clientId, postDate: period.endDate, module: "FA", docType: "AF",
    lines, createdBy: ctx.user, reference: `DEP-${periodCode}`,
  });
  await db.insert(depreciationRuns).values(detail.map((d) => ({
    clientId: ctx.clientId, periodCode, assetNo: d.assetNo, amount: String(d.amount), glDoc: res.docNo,
  })));
  return { posted: detail.length, total, docNo: res.docNo, message: `Depreciation for ${periodCode}: ${detail.length} assets, ${total.toFixed(2)}` };
}

export async function revalueAsset(ctx: Ctx, assetNo: string, newValue: number, date: string, reason: string) {
  const [a] = await db.select().from(assets)
    .where(and(eq(assets.clientId, ctx.clientId), eq(assets.assetNo, assetNo)));
  if (!a) throw new OpsError("Asset not found.");
  const nbv = r2(num(a.cost) - num(a.accumDep) - num(a.impairment));
  const delta = r2(newValue - nbv);
  if (delta === 0) return { message: "No revaluation difference." };
  const up = delta > 0;
  const res = await postDocument({
    clientId: ctx.clientId, postDate: date, module: "FA", docType: up ? "REVAL" : "IMPAIR",
    reason,
    lines: up
      ? [{ account: "110300", dr: delta, desc: `Revaluation uplift ${assetNo}` }, { account: "320100", cr: delta, desc: "Revaluation surplus (OCI)" }]
      : [{ account: "730400", dr: Math.abs(delta), cc: a.costCenter, desc: `Impairment ${assetNo}` }, { account: "111600", cr: Math.abs(delta), desc: `Accumulated impairment ${assetNo}` }],
    createdBy: ctx.user, reference: assetNo,
  });
  await db.update(assets).set({
    revalReserve: String(r2(num(a.revalReserve) + (up ? delta : 0))),
    impairment: String(r2(num(a.impairment) + (up ? 0 : Math.abs(delta)))),
    nbv: String(r2(newValue)),
  }).where(and(eq(assets.clientId, ctx.clientId), eq(assets.assetNo, assetNo)));
  return { docNo: res.docNo, delta, message: `${up ? "Revaluation surplus" : "Impairment"} of ${Math.abs(delta).toFixed(2)} posted` };
}

export async function disposeAsset(ctx: Ctx, assetNo: string, proceeds: number, date: string, bankAccount = "141000") {
  const [a] = await db.select().from(assets)
    .where(and(eq(assets.clientId, ctx.clientId), eq(assets.assetNo, assetNo)));
  if (!a) throw new OpsError("Asset not found.");
  if (a.status !== "ACTIVE") throw new OpsError("Asset is already disposed.");
  const cost = num(a.cost), accum = num(a.accumDep), nbv = r2(cost - accum);
  const gain = r2(proceeds - nbv);
  const lines: JournalLineInput[] = [
    { account: bankAccount, dr: r2(proceeds), desc: `Disposal proceeds ${assetNo}` },
    { account: "111500", dr: accum, desc: `Remove accumulated depreciation ${assetNo}` },
    { account: "110300", cr: cost, desc: `Remove cost ${assetNo}` },
  ];
  if (gain > 0) lines.push({ account: "510400", cr: gain, desc: `Gain on disposal ${assetNo}` });
  if (gain < 0) lines.push({ account: "730500", dr: Math.abs(gain), cc: a.costCenter, desc: `Loss on disposal ${assetNo}` });

  const res = await postDocument({
    clientId: ctx.clientId, postDate: date, module: "FA", docType: "AD",
    lines, createdBy: ctx.user, reference: assetNo,
  });
  await db.update(assets).set({
    status: "DISPOSED", disposalDate: date, disposalProceeds: String(r2(proceeds)), nbv: "0",
  }).where(and(eq(assets.clientId, ctx.clientId), eq(assets.assetNo, assetNo)));
  return { docNo: res.docNo, gain, message: `Asset ${assetNo} disposed — ${gain >= 0 ? "gain" : "loss"} ${Math.abs(gain).toFixed(2)}` };
}

/* ================================================================
   5. PREPAYMENTS, ACCRUALS & DEFERRED INCOME
   ================================================================ */
export async function createPrepayment(ctx: Ctx, p: {
  kind?: string; description: string; totalAmount: number; balanceAccount?: string;
  expenseAccount: string; startPeriod: string; periods: number; costCenter?: string;
  bp?: string; postInitial?: boolean; creditAccount?: string;
}) {
  // AUDIT FIX 9 — a negative schedule would amortise a credit into the
  // expense account every period instead of a genuine prepayment/accrual.
  if (!(p.totalAmount > 0)) throw new OpsError("The total amount must be greater than zero.");
  if (!p.periods || p.periods < 1) throw new OpsError("Enter at least one period to amortise over.");
  if (!p.description?.trim()) throw new OpsError("A description is required.");
  const prepayNo = await nextNumber(ctx.clientId, "PREPAY", "PP-");
  const kind = p.kind || "PREPAY";
  const balanceAccount = p.balanceAccount || (kind === "PREPAY" ? "130500" : kind === "DEFERRED" ? "410500" : "410400");
  const perPeriod = r2(p.totalAmount / Math.max(p.periods, 1));

  await db.insert(prepayments).values({
    clientId: ctx.clientId, prepayNo, kind, description: p.description, bp: p.bp || "",
    totalAmount: String(r2(p.totalAmount)), balanceAccount, expenseAccount: p.expenseAccount,
    startPeriod: p.startPeriod, periods: p.periods, perPeriod: String(perPeriod),
    costCenter: p.costCenter || "CC-ADM",
  });

  let glDoc = "";
  if (p.postInitial !== false && kind === "PREPAY") {
    const [per] = await db.select().from(fiscalPeriods)
      .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, p.startPeriod)));
    const res = await postDocument({
      clientId: ctx.clientId, postDate: per?.startDate || firstOf(p.startPeriod), module: "FI", docType: "PP",
      lines: [
        { account: balanceAccount, dr: r2(p.totalAmount), bp: p.bp, desc: `Prepayment — ${p.description}` },
        { account: p.creditAccount || "141000", cr: r2(p.totalAmount), desc: `Payment for ${p.description}` },
      ],
      createdBy: ctx.user, reference: prepayNo,
    });
    glDoc = res.docNo;
  }
  return { prepayNo, glDoc, perPeriod, message: `${kind} schedule ${prepayNo} created — ${perPeriod.toFixed(2)} per period over ${p.periods} periods` };
}

/** Amortises every active schedule due in a period. */
export async function runAmortisation(ctx: Ctx, periodCode: string) {
  return withPeriodLock(ctx.clientId, periodCode, "amortisation", () => runAmortisationInner(ctx, periodCode));
}

async function runAmortisationInner(ctx: Ctx, periodCode: string) {
  const [period] = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
  if (!period) throw new OpsError(`Period ${periodCode} does not exist.`);

  const list = await db.select().from(prepayments)
    .where(and(eq(prepayments.clientId, ctx.clientId), eq(prepayments.status, "ACTIVE")));
  const lines: JournalLineInput[] = [];
  let count = 0, total = 0;

  for (const s of list) {
    if (s.lastRunPeriod >= periodCode || s.startPeriod > periodCode) continue;
    const remaining = r2(num(s.totalAmount) - num(s.amortised));
    if (remaining <= 0) continue;
    const amount = Math.min(num(s.perPeriod), remaining);
    if (s.kind === "DEFERRED") {
      lines.push({ account: s.balanceAccount, dr: amount, desc: `Release deferred income — ${s.description}` });
      lines.push({ account: s.expenseAccount, cr: amount, cc: s.costCenter, desc: `Revenue recognised — ${s.description}` });
    } else {
      lines.push({ account: s.expenseAccount, dr: amount, cc: s.costCenter, desc: `${s.kind === "ACCRUAL" ? "Accrued" : "Amortised"} — ${s.description}` });
      lines.push({ account: s.balanceAccount, cr: amount, bp: s.bp, desc: `${s.kind} release — ${s.description}` });
    }
    const newAmort = r2(num(s.amortised) + amount);
    await db.update(prepayments).set({
      amortised: String(newAmort), lastRunPeriod: periodCode,
      status: newAmort >= num(s.totalAmount) - 0.01 ? "COMPLETE" : "ACTIVE",
    }).where(and(eq(prepayments.clientId, ctx.clientId), eq(prepayments.prepayNo, s.prepayNo)));
    count++; total = r2(total + amount);
  }
  if (!lines.length) return { posted: 0, total: 0, message: `No schedules due in ${periodCode}.` };
  const res = await postDocument({
    clientId: ctx.clientId, postDate: period.endDate, module: "FI", docType: "AMORT",
    lines, createdBy: ctx.user, reference: `AMORT-${periodCode}`,
  });
  return { posted: count, total, docNo: res.docNo, message: `${count} schedules amortised in ${periodCode} (${total.toFixed(2)})` };
}

/* ================================================================
   6. PAYROLL — editable, relief/deduction aware, Ghana compliant
   ================================================================ */
/**
 * Adds or updates one employee. There is no ceiling on headcount — the
 * composite (clientId, empNo) key and auto-numbering scale to any size
 * workforce, and bulkImportEmployees below lets a whole payroll be loaded
 * in one pass.
 */
export async function upsertEmployee(ctx: Ctx, p: Partial<typeof employees.$inferInsert> & { empNo?: string; name: string }) {
  if (!p.name?.trim()) throw new OpsError("Employee name is required.");
  // AUDIT FIX 7 — a negative basic salary silently flips every downstream
  // calculation (SSNIT, PAYE, net pay) and understates total payroll cost.
  if (p.basicSalary !== undefined && num(p.basicSalary) < 0) {
    throw new OpsError("Basic salary cannot be negative.");
  }
  if (p.tier3Employee !== undefined && num(p.tier3Employee) < 0) {
    throw new OpsError("Tier 3 contribution cannot be negative.");
  }
  const empNo = p.empNo || (await nextNumber(ctx.clientId, "EMP", "EMP-"));
  const row = {
    clientId: ctx.clientId, empNo, name: p.name.trim(),
    email: (p.email ?? "").trim(), phone: (p.phone ?? "").trim(),
    ssnit: p.ssnit ?? "", tin: p.tin ?? "", jobTitle: p.jobTitle ?? "",
    department: p.department ?? "", employmentType: p.employmentType ?? "PERMANENT",
    costCenter: p.costCenter ?? "CC-ADM", basicSalary: String(p.basicSalary ?? 0),
    currency: p.currency ?? "GHS", isResident: p.isResident ?? true,
    ssnitApplicable: p.ssnitApplicable ?? true,
    tier3Employee: String(p.tier3Employee ?? 0), tier3Employer: String(p.tier3Employer ?? 0),
    bankCode: p.bankCode ?? "", bankAccount: p.bankAccount ?? "",
    startDate: p.startDate ?? null, terminationDate: p.terminationDate ?? null,
    active: p.active ?? true,
  };
  await db.insert(employees).values(row).onConflictDoUpdate({
    target: [employees.clientId, employees.empNo],
    set: {
      name: row.name, email: row.email, phone: row.phone, ssnit: row.ssnit, tin: row.tin,
      jobTitle: row.jobTitle, department: row.department, employmentType: row.employmentType,
      costCenter: row.costCenter, basicSalary: row.basicSalary, currency: row.currency,
      isResident: row.isResident, ssnitApplicable: row.ssnitApplicable,
      tier3Employee: row.tier3Employee, tier3Employer: row.tier3Employer,
      bankCode: row.bankCode, bankAccount: row.bankAccount,
      startDate: row.startDate, terminationDate: row.terminationDate, active: row.active,
    },
  });
  return { empNo, message: `Employee ${empNo} saved` };
}

/** Terminates an employee (leaver) without deleting their payroll history. */
export async function terminateEmployee(ctx: Ctx, empNo: string, terminationDate: string) {
  const [e] = await db.select().from(employees)
    .where(and(eq(employees.clientId, ctx.clientId), eq(employees.empNo, empNo)));
  if (!e) throw new OpsError(`Employee ${empNo} not found.`);
  await db.update(employees).set({ active: false, terminationDate })
    .where(and(eq(employees.clientId, ctx.clientId), eq(employees.empNo, empNo)));
  return { message: `${e.name} marked as a leaver effective ${terminationDate} and excluded from future payroll runs.` };
}

/**
 * Bulk-loads any number of employees from CSV text so a payroll of any size
 * can be onboarded in one action. Columns: Name, BasicSalary, JobTitle,
 * Department, CostCenter, Email, Phone, SSNIT, TIN, EmploymentType,
 * Resident(Y/N), BankCode, BankAccount — only Name and BasicSalary required.
 */
export async function bulkImportEmployees(ctx: Ctx, csv: string) {
  const rows = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (rows.length < 2) throw new OpsError("Provide a header row plus at least one employee row.");
  const header = rows[0].toLowerCase().split(",").map((h) => h.trim());
  const idx = (names: string[]) => header.findIndex((h) => names.some((n) => h.includes(n)));
  const iName = idx(["name"]), iSalary = idx(["basic", "salary"]), iTitle = idx(["title", "job"]);
  const iDept = idx(["department", "dept"]), iCc = idx(["cost", "centre", "center"]);
  const iEmail = idx(["email"]), iPhone = idx(["phone", "mobile"]), iSsnit = idx(["ssnit", "security"]);
  const iTin = idx(["tin"]), iType = idx(["type", "employment"]), iRes = idx(["resident"]);
  const iBankCode = idx(["bankcode", "bank code"]), iBankAcct = idx(["bankaccount", "account"]);
  if (iName < 0 || iSalary < 0) throw new OpsError("The file must contain at least a Name and a BasicSalary column.");

  const created: string[] = [];
  const errors: string[] = [];
  for (let i = 1; i < rows.length; i++) {
    const cells = rows[i].split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
    const name = cells[iName];
    const salary = Number(cells[iSalary]);
    if (!name) { errors.push(`Row ${i + 1}: missing name`); continue; }
    if (!Number.isFinite(salary) || salary < 0) { errors.push(`Row ${i + 1}: invalid basic salary for ${name}`); continue; }
    try {
      const r = await upsertEmployee(ctx, {
        name, basicSalary: salary,
        jobTitle: iTitle >= 0 ? cells[iTitle] : "", department: iDept >= 0 ? cells[iDept] : "",
        costCenter: iCc >= 0 && cells[iCc] ? cells[iCc] : "CC-ADM",
        email: iEmail >= 0 ? cells[iEmail] : "", phone: iPhone >= 0 ? cells[iPhone] : "",
        ssnit: iSsnit >= 0 ? cells[iSsnit] : "", tin: iTin >= 0 ? cells[iTin] : "",
        employmentType: iType >= 0 && cells[iType] ? cells[iType].toUpperCase() : "PERMANENT",
        isResident: iRes >= 0 ? !/^n/i.test(cells[iRes]) : true,
        bankCode: iBankCode >= 0 ? cells[iBankCode] : "", bankAccount: iBankAcct >= 0 ? cells[iBankAcct] : "",
      } as never);
      created.push(r.empNo);
    } catch (e) {
      errors.push(`Row ${i + 1} (${name}): ${(e as Error).message}`);
    }
  }
  if (!created.length) throw new OpsError(`No employees could be imported. ${errors.slice(0, 3).join("; ")}`);
  return {
    created: created.length, errors: errors.length, errorDetail: errors.slice(0, 15),
    message: `${created.length} employee(s) imported${errors.length ? `, ${errors.length} row(s) skipped` : ""}.`,
  };
}

export async function upsertPayComponent(ctx: Ctx, p: {
  id?: number; empNo?: string; code: string; name: string; kind: string;
  basis?: string; rate?: number; amount?: number; taxable?: boolean; periodCode?: string;
}) {
  const row = {
    clientId: ctx.clientId, empNo: p.empNo || "*", code: p.code, name: p.name, kind: p.kind,
    basis: p.basis || "FIXED", rate: String(p.rate ?? 0), amount: String(p.amount ?? 0),
    taxable: p.taxable ?? true, periodCode: p.periodCode || "*",
  };
  if (p.id) {
    await db.update(payComponents).set(row).where(eq(payComponents.id, p.id));
    return { id: p.id, message: `Component ${p.code} updated` };
  }
  const [ins] = await db.insert(payComponents).values(row).returning();
  return { id: ins.id, message: `Component ${p.code} added` };
}

export async function deletePayComponent(ctx: Ctx, id: number) {
  await db.delete(payComponents).where(and(eq(payComponents.id, id), eq(payComponents.clientId, ctx.clientId)));
  return { message: "Component removed" };
}

/**
 * Calculates payroll for a period. Components can apply on BASIC, GROSS or NET,
 * which is what makes the Ghanaian allowance/deduction mix work correctly.
 */
export async function calculatePayroll(ctx: Ctx, periodCode: string) {
  const [period] = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
  if (!period) throw new OpsError(`Period ${periodCode} does not exist.`);

  const [client] = await db.select().from(clients).where(eq(clients.id, ctx.clientId));
  // Global reach: Ghana workspaces run the statutory PAYE/SSNIT engine; every
  // other workspace runs a configurable flat-rate or no-withholding scheme so
  // the platform is usable outside Ghana without mis-applying Ghanaian law.
  const taxMode = client?.payrollTaxMode || "GH_PAYE";
  const flatRate = num(client?.payrollFlatRatePct);
  const statutoryApplies = taxMode === "GH_PAYE";

  const staff = await db.select().from(employees)
    .where(and(eq(employees.clientId, ctx.clientId), eq(employees.active, true)))
    .orderBy(asc(employees.empNo));
  if (!staff.length) throw new OpsError("No active employees. Add staff on the Payroll desk first.");

  const comps = await db.select().from(payComponents)
    .where(and(eq(payComponents.clientId, ctx.clientId), eq(payComponents.active, true)));

  const results = staff.map((e) => {
    const mine = comps.filter((c) => (c.empNo === "*" || c.empNo === e.empNo) && (c.periodCode === "*" || c.periodCode === periodCode));
    const basic = num(e.basicSalary);

    const valueOf = (c: typeof comps[number], base: number) => {
      switch (c.basis) {
        case "PCT_BASIC": return r2((basic * num(c.rate)) / 100);
        case "PCT_GROSS": return r2((base * num(c.rate)) / 100);
        case "PCT_NET": return r2((base * num(c.rate)) / 100);
        default: return r2(num(c.amount));
      }
    };

    const allowanceComps = mine.filter((c) => c.kind === "ALLOWANCE");
    let allowances = 0, taxableAllow = 0;
    const detail: Record<string, number> = {};
    for (const c of allowanceComps) {
      const v = valueOf(c, basic);
      allowances = r2(allowances + v);
      if (c.taxable) taxableAllow = r2(taxableAllow + v);
      detail[c.code] = v;
    }
    const gross = r2(basic + allowances);

    // SSNIT only applies to the Ghana statutory scheme. International
    // workspaces configure their own equivalent via DEDUCTION components.
    const ssnitEe = statutoryApplies && e.ssnitApplicable ? r2((basic * SSNIT.employee) / 100) : 0;
    const ssnitEr = statutoryApplies && e.ssnitApplicable ? r2((basic * SSNIT.employerTier1) / 100) : 0;
    const tier3Cap = r2((basic * SSNIT.tier3CapPct) / 100);
    const tier3Ee = statutoryApplies ? Math.min(num(e.tier3Employee), tier3Cap) : 0;

    // Reliefs reduce chargeable income.
    let reliefs = 0;
    for (const c of mine.filter((x) => x.kind === "RELIEF")) {
      const v = valueOf(c, gross);
      reliefs = r2(reliefs + v);
      detail[`RELIEF_${c.code}`] = v;
    }

    const taxableBase = r2(basic + taxableAllow);
    const chargeable = Math.max(0, r2(taxableBase - ssnitEe - tier3Ee - reliefs));
    const { tax: paye, trace } = taxMode === "GH_PAYE"
      ? computePaye(chargeable, period.startDate, e.isResident)
      : taxMode === "FLAT_RATE"
        ? { tax: r2((chargeable * flatRate) / 100), trace: [{ label: `Flat rate ${flatRate}%`, amount: chargeable, rate: flatRate, tax: r2((chargeable * flatRate) / 100) }] }
        : { tax: 0, trace: [] };

    // Post-tax deductions: FIXED / PCT_BASIC / PCT_GROSS computed here; PCT_NET on pre-deduction net.
    const preNet = r2(gross - ssnitEe - tier3Ee - paye);
    let otherDed = 0;
    for (const c of mine.filter((x) => x.kind === "DEDUCTION")) {
      const v = c.basis === "PCT_NET" ? r2((preNet * num(c.rate)) / 100) : valueOf(c, gross);
      otherDed = r2(otherDed + v);
      detail[`DED_${c.code}`] = v;
    }
    const net = r2(preNet - otherDed);

    return {
      empNo: e.empNo, name: e.name, costCenter: e.costCenter, basic, allowances, gross,
      ssnitEe, ssnitEr, tier3Ee, tier3Er: num(e.tier3Employer), reliefs,
      taxable: chargeable, paye, otherDeductions: otherDed, net, trace, detail,
    };
  });

  const totals = results.reduce((t, r) => ({
    gross: r2(t.gross + r.gross), paye: r2(t.paye + r.paye),
    ssnitEe: r2(t.ssnitEe + r.ssnitEe), ssnitEr: r2(t.ssnitEr + r.ssnitEr),
    net: r2(t.net + r.net), tier3Ee: r2(t.tier3Ee + r.tier3Ee),
    tier3Er: r2(t.tier3Er + r.tier3Er), other: r2(t.other + r.otherDeductions),
  }), { gross: 0, paye: 0, ssnitEe: 0, ssnitEr: 0, net: 0, tier3Ee: 0, tier3Er: 0, other: 0 });

  return { periodCode, periodEnd: period.endDate, results, totals };
}

export async function postPayroll(ctx: Ctx, periodCode: string) {
  return withPeriodLock(ctx.clientId, periodCode, "payroll", () => postPayrollInner(ctx, periodCode));
}

async function postPayrollInner(ctx: Ctx, periodCode: string) {
  const existing = await db.select().from(payrollRuns)
    .where(and(eq(payrollRuns.clientId, ctx.clientId), eq(payrollRuns.periodCode, periodCode)));
  if (existing.some((r) => r.status === "POSTED")) {
    throw new OpsError(`Payroll for ${periodCode} is already posted (${existing[0].runNo}).`);
  }
  const calc = await calculatePayroll(ctx, periodCode);
  const t = calc.totals;
  const runNo = await nextNumber(ctx.clientId, "PRUN", "PR-");

  const byCc = new Map<string, number>();
  for (const r of calc.results) byCc.set(r.costCenter, r2((byCc.get(r.costCenter) ?? 0) + r.gross));

  const lines: JournalLineInput[] = [];
  for (const [cc, amt] of byCc) lines.push({ account: "700100", dr: amt, cc, desc: `Gross pay ${periodCode}` });
  if (t.ssnitEr > 0) lines.push({ account: "700200", dr: t.ssnitEr, cc: "CC-ADM", desc: `Employer SSNIT ${periodCode}` });
  if (t.tier3Er > 0) lines.push({ account: "700300", dr: t.tier3Er, cc: "CC-ADM", desc: `Employer Tier 3 ${periodCode}` });
  if (t.paye > 0) lines.push({ account: "420300", cr: t.paye, bp: "GRA", desc: `PAYE payable ${periodCode}`, taxCode: "PAYE" });
  if (t.ssnitEe + t.ssnitEr > 0) {
    const tier1 = r2(((t.ssnitEe + t.ssnitEr) * SSNIT.tier1Share) / (SSNIT.tier1Share + SSNIT.tier2Share));
    const tier2 = r2(t.ssnitEe + t.ssnitEr - tier1);
    lines.push({ account: "420600", cr: tier1, bp: "SSNIT", desc: `SSNIT Tier 1 ${periodCode}` });
    lines.push({ account: "420700", cr: tier2, bp: "SSNIT", desc: `SSNIT Tier 2 ${periodCode}` });
  }
  if (t.tier3Ee + t.tier3Er > 0) lines.push({ account: "420800", cr: r2(t.tier3Ee + t.tier3Er), desc: `Provident fund ${periodCode}` });
  if (t.other > 0) lines.push({ account: "430200", cr: t.other, desc: `Staff deductions ${periodCode}` });
  lines.push({ account: "430100", cr: t.net, desc: `Net salaries payable ${periodCode}` });

  const res = await postDocument({
    clientId: ctx.clientId, postDate: calc.periodEnd, module: "HR", docType: "PY",
    lines, createdBy: ctx.user, reference: runNo,
  });

  await db.insert(payrollRuns).values({
    clientId: ctx.clientId, runNo, periodCode, status: "POSTED",
    grossTotal: String(t.gross), payeTotal: String(t.paye), ssnitEeTotal: String(t.ssnitEe),
    ssnitErTotal: String(t.ssnitEr), netTotal: String(t.net), glDoc: res.docNo, createdBy: ctx.user,
  });
  await db.insert(payslips).values(calc.results.map((r) => ({
    clientId: ctx.clientId, runNo, empNo: r.empNo, basic: String(r.basic),
    allowances: String(r.allowances), gross: String(r.gross), ssnitEe: String(r.ssnitEe),
    ssnitEr: String(r.ssnitEr), tier3Ee: String(r.tier3Ee), reliefs: String(r.reliefs),
    taxable: String(r.taxable), paye: String(r.paye), otherDeductions: String(r.otherDeductions),
    net: String(r.net), detail: r.detail,
  })));

  return { runNo, docNo: res.docNo, totals: t, message: `Payroll ${runNo} posted for ${periodCode} — net ${t.net.toFixed(2)}` };
}

/* ================================================================
   7. INVENTORY — weighted average valuation + NRV (IAS 2)
   ================================================================ */
/**
 * CONCURRENCY-SAFE stock receipt. Wrapped in a transaction with a row lock
 * (SELECT ... FOR UPDATE) so that simultaneous receipts/issues on the same
 * item serialise correctly instead of losing updates under load — the exact
 * failure mode of a naive read-then-write that most light-weight systems get
 * wrong when more than one user posts against the same SKU at once.
 */
export async function receiveStock(ctx: Ctx, materialNo: string, qty: number, unitCost: number, ref: string, date?: string) {
  if (!(qty > 0)) throw new OpsError("Quantity received must be greater than zero.");
  if (unitCost < 0) throw new OpsError("Unit cost cannot be negative.");
  return db.transaction(async (tx) => {
    const [m] = await tx.select().from(materials)
      .where(and(eq(materials.clientId, ctx.clientId), eq(materials.materialNo, materialNo)))
      .for("update");
    if (!m) throw new OpsError(`Material ${materialNo} not found.`);
    const newQty = r2(num(m.qtyOnHand) + qty);
    const newVal = r2(num(m.valueOnHand) + qty * unitCost);
    await tx.insert(stockMoves).values({
      clientId: ctx.clientId, materialNo, moveDate: date || today(), moveType: "RECEIPT",
      qty: String(qty), unitCost: String(r2(unitCost)), value: String(r2(qty * unitCost)),
      balQty: String(newQty), balValue: String(newVal), reference: ref,
    });
    await tx.update(materials).set({ qtyOnHand: String(newQty), valueOnHand: String(newVal) })
      .where(and(eq(materials.clientId, ctx.clientId), eq(materials.materialNo, materialNo)));
    return { qty: newQty, value: newVal };
  });
}

export async function issueStock(ctx: Ctx, materialNo: string, qty: number, ref: string, date?: string) {
  if (!(qty > 0)) throw new OpsError("Quantity issued must be greater than zero.");
  const { m, issueQty, value, wavg } = await db.transaction(async (tx) => {
    const [row] = await tx.select().from(materials)
      .where(and(eq(materials.clientId, ctx.clientId), eq(materials.materialNo, materialNo)))
      .for("update");
    if (!row) throw new OpsError(`Material ${materialNo} not found.`);
    const onHand = num(row.qtyOnHand);
    const avgCost = onHand > 0 ? r2(num(row.valueOnHand) / onHand) : num(row.stdPrice);
    const qtyOut = Math.min(qty, Math.max(onHand, 0));
    const val = r2(qtyOut * avgCost);
    const newQty = r2(onHand - qtyOut);
    const newVal = r2(Math.max(num(row.valueOnHand) - val, 0));
    await tx.insert(stockMoves).values({
      clientId: ctx.clientId, materialNo, moveDate: date || today(), moveType: "ISSUE",
      qty: String(-qtyOut), unitCost: String(avgCost), value: String(-val),
      balQty: String(newQty), balValue: String(newVal), reference: ref,
    });
    await tx.update(materials).set({ qtyOnHand: String(newQty), valueOnHand: String(newVal) })
      .where(and(eq(materials.clientId, ctx.clientId), eq(materials.materialNo, materialNo)));
    return { m: row, issueQty: qtyOut, value: val, wavg: avgCost };
  });
  if (value > 0) {
    await postDocument({
      clientId: ctx.clientId, postDate: date || today(), module: "INV", docType: "GI",
      lines: [
        { account: "600100", dr: value, material: materialNo, desc: `Cost of goods sold — ${m.description}` },
        { account: "120300", cr: value, material: materialNo, desc: `Stock issue ${ref}` },
      ],
      createdBy: ctx.user, reference: ref,
    }).catch(() => undefined);
  }
  return { issued: issueQty, value, wavg };
}

/** IAS 2 — write inventory down to the lower of cost and NRV. */
/**
 * IAS 2 — writes inventory down to the lower of cost and net realisable
 * value. FIXED: this previously posted the write-down journal entry without
 * ever reducing the item's own carrying value (`valueOnHand`), so calling it
 * a second time recomputed and posted the identical write-down again — a
 * deterministic double-charge, not just a theoretical race. The carrying
 * value is now actually reduced to NRV, so a repeat run correctly finds
 * nothing further to write down.
 */
export async function revalueInventoryToNRV(ctx: Ctx, date?: string) {
  return withPeriodLock(ctx.clientId, date || today(), "inventory-nrv", () => revalueInventoryToNRVInner(ctx, date));
}

async function revalueInventoryToNRVInner(ctx: Ctx, date?: string) {
  const list = await db.select().from(materials).where(eq(materials.clientId, ctx.clientId));
  const lines: JournalLineInput[] = [];
  const updates: { materialNo: string; newValue: number }[] = [];
  let total = 0;
  for (const m of list) {
    const qty = num(m.qtyOnHand);
    if (qty <= 0) continue;
    const cost = num(m.valueOnHand);
    const nrv = r2(qty * num(m.nrv));
    if (nrv > 0 && nrv < cost) {
      const writedown = r2(cost - nrv);
      lines.push({ account: "600700", dr: writedown, material: m.materialNo, desc: `NRV write-down ${m.materialNo}` });
      lines.push({ account: "120900", cr: writedown, material: m.materialNo, desc: `Provision for obsolete stock ${m.materialNo}` });
      updates.push({ materialNo: m.materialNo, newValue: nrv });
      total = r2(total + writedown);
    }
  }
  if (!lines.length) return { total: 0, message: "No inventory is carried above its net realisable value." };
  const res = await postDocument({
    clientId: ctx.clientId, postDate: date || today(), module: "INV", docType: "NRV",
    lines, createdBy: ctx.user, reference: "IAS2-NRV",
  });
  for (const u of updates) {
    await db.update(materials).set({ valueOnHand: String(u.newValue) })
      .where(and(eq(materials.clientId, ctx.clientId), eq(materials.materialNo, u.materialNo)));
  }
  return { total, docNo: res.docNo, message: `Inventory written down to NRV by ${total.toFixed(2)}` };
}

/* ================================================================
   8. OPENING BALANCES, FX REVALUATION & MONTH-END CLOSE
   ================================================================ */
export async function postOpeningBalances(ctx: Ctx, p: {
  asAtDate: string; lines: { account: string; bp?: string; debit?: number; credit?: number }[];
}) {
  const gl: JournalLineInput[] = p.lines
    .filter((l) => l.account && ((l.debit ?? 0) !== 0 || (l.credit ?? 0) !== 0))
    .map((l) => ({ account: l.account, bp: l.bp, dr: l.debit ?? 0, cr: l.credit ?? 0, desc: "Opening balance brought forward" }));
  if (gl.length < 1) throw new OpsError("Enter at least one opening balance line.");
  const dr = r2(gl.reduce((s, l) => s + (l.dr ?? 0), 0));
  const cr = r2(gl.reduce((s, l) => s + (l.cr ?? 0), 0));
  const diff = r2(dr - cr);
  if (diff !== 0) {
    gl.push({
      account: "990200", [diff > 0 ? "cr" : "dr"]: Math.abs(diff),
      desc: "Opening balance equity (suspense) — review and clear",
    } as JournalLineInput);
  }
  const res = await postDocument({
    clientId: ctx.clientId, postDate: p.asAtDate, module: "FI", docType: "OB",
    lines: gl, createdBy: ctx.user, reference: "OPENING",
    reason: "Migration opening balances",
  });
  return { ...res, suspense: Math.abs(diff), message: `Opening balances posted as ${res.docNo}${diff !== 0 ? ` (${Math.abs(diff).toFixed(2)} to opening balance equity)` : ""}` };
}

// IAS 21.16 / 21.23(a) — only MONETARY items (cash, receivables, payables,
// loans, deposits, lease liabilities) are retranslated at the closing rate.
// Revenue, expense, COGS, equity, PPE, intangibles, inventory and
// prepayments are non-monetary and stay at their historical transaction-date
// rate for the whole of their life — IAS 21 is explicit that these are never
// revalued again once initially recognised.
const MONETARY_SUBTYPES = new Set([
  "CASH", "BANK", "CASH_EQUIV", "AR", "AR_OTHER", "AP", "AP_OTHER", "AP_CLEARING",
  "ACCRUAL", "ST_LOAN", "LT_LOAN", "OVERDRAFT", "LEASE", "DEPOSIT", "SUSPENSE", "TRUST",
]);

/**
 * IAS 21 — retranslate monetary FC balances at the closing mid rate.
 *
 * BUG FIX: this previously retranslated EVERY foreign-currency journal line
 * regardless of account type, including revenue accounts. Because an
 * unsettled invoice posts equal-and-opposite foreign-currency movements to
 * the receivable (monetary — should move) and the revenue account
 * (non-monetary — should NOT move), including the revenue leg caused the two
 * movements to cancel out algebraically, so the function reported "no
 * movement" even when a real, material FX gain or loss had accrued on an
 * open receivable. The revaluation is now restricted to monetary
 * balance-sheet accounts only, matching IAS 21 exactly.
 */
export async function revalueForeignCurrency(ctx: Ctx, periodCode: string) {
  return withPeriodLock(ctx.clientId, periodCode, "fx-revaluation", () => revalueForeignCurrencyInner(ctx, periodCode));
}

async function revalueForeignCurrencyInner(ctx: Ctx, periodCode: string) {
  const [period] = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
  if (!period) throw new OpsError(`Period ${periodCode} does not exist.`);

  const coa = await db.select({ accountNo: accounts.accountNo, subType: accounts.subType })
    .from(accounts).where(eq(accounts.clientId, ctx.clientId));
  const subTypeOf = new Map(coa.map((a) => [a.accountNo, a.subType]));

  const rows = await db.select({
    account: journalLines.account, currency: journalLines.currency,
    fc: sql<string>`sum(${journalLines.debitFc} - ${journalLines.creditFc})`,
    base: sql<string>`sum(${journalLines.debit} - ${journalLines.credit})`,
  }).from(journalLines)
    .where(and(eq(journalLines.clientId, ctx.clientId), sql`${journalLines.currency} <> 'GHS'`, sql`${journalLines.periodCode} <= ${periodCode}`))
    .groupBy(journalLines.account, journalLines.currency);

  const lines: JournalLineInput[] = [];
  const skippedNonMonetary: string[] = [];
  let net = 0;
  for (const r of rows) {
    if (!MONETARY_SUBTYPES.has(subTypeOf.get(r.account) ?? "")) {
      if (Math.abs(num(r.fc)) >= 0.01) skippedNonMonetary.push(r.account);
      continue;
    }
    const fc = num(r.fc);
    if (Math.abs(fc) < 0.01) continue;
    const closing = await getRate(r.currency, period.endDate);
    const shouldBe = r2(fc * closing);
    const diff = r2(shouldBe - num(r.base));
    if (Math.abs(diff) < 0.01) continue;
    lines.push({ account: r.account, [diff > 0 ? "dr" : "cr"]: Math.abs(diff), desc: `FX retranslation ${r.currency} @ ${closing}` } as JournalLineInput);
    net = r2(net + diff);
  }
  if (!lines.length) {
    return {
      total: 0,
      message: skippedNonMonetary.length
        ? `No monetary foreign currency balances require retranslation (non-monetary balances such as revenue remain correctly at their historical rate).`
        : "No foreign currency balances require retranslation.",
    };
  }
  lines.push(net > 0
    ? { account: "510600", cr: Math.abs(net), desc: `Unrealised FX gain ${periodCode}` }
    : { account: "750400", dr: Math.abs(net), desc: `Unrealised FX loss ${periodCode}` });

  const res = await postDocument({
    clientId: ctx.clientId, postDate: period.endDate, module: "FI", docType: "FXREV",
    lines, createdBy: ctx.user, reference: `FX-${periodCode}`,
  });
  return { total: net, docNo: res.docNo, message: `FX revaluation posted — net ${net >= 0 ? "gain" : "loss"} ${Math.abs(net).toFixed(2)}` };
}

/** Orchestrated month-end: depreciation → amortisation → NRV → FX → VAT → lock. */
export async function monthEndClose(ctx: Ctx, periodCode: string, opts: { lock?: boolean } = {}) {
  const steps: { step: string; result: string; ok: boolean }[] = [];
  const run = async (name: string, fn: () => Promise<{ message: string }>) => {
    try { steps.push({ step: name, result: (await fn()).message, ok: true }); }
    catch (e) { steps.push({ step: name, result: (e as Error).message, ok: false }); }
  };
  await run("Depreciation", () => runDepreciation(ctx, periodCode));
  await run("Prepayments & accruals", () => runAmortisation(ctx, periodCode));
  await run("Inventory NRV test (IAS 2)", () => revalueInventoryToNRV(ctx));
  await run("FX retranslation (IAS 21)", () => revalueForeignCurrency(ctx, periodCode));
  await run("VAT control settlement", () => settleVatControl(ctx, periodCode));

  const [chk] = await db.select({
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines).where(and(eq(journalLines.clientId, ctx.clientId), eq(journalLines.periodCode, periodCode)));
  const balanced = Math.abs(num(chk?.dr) - num(chk?.cr)) < 0.01;
  steps.push({ step: "Trial balance check", result: balanced ? "Period is in balance" : `OUT OF BALANCE by ${(num(chk?.dr) - num(chk?.cr)).toFixed(2)}`, ok: balanced });

  if (opts.lock && balanced) {
    await db.update(fiscalPeriods).set({ status: "CLOSED", closedBy: ctx.user, closedAt: new Date() })
      .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
    steps.push({ step: "Period lock", result: `${periodCode} closed`, ok: true });
  }
  return { periodCode, steps, balanced, message: `Month-end routine completed for ${periodCode}` };
}

/** Nets output VAT against input VAT into the control account. */
export async function settleVatControl(ctx: Ctx, periodCode: string) {
  return withPeriodLock(ctx.clientId, periodCode, "vat-settle", () => settleVatControlInner(ctx, periodCode));
}

async function settleVatControlInner(ctx: Ctx, periodCode: string) {
  const [period] = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.code, periodCode)));
  if (!period) throw new OpsError("Period not found.");
  const bal = async (acct: string) => {
    const [r] = await db.select({
      dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
      cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
    }).from(journalLines).where(and(
      eq(journalLines.clientId, ctx.clientId), eq(journalLines.account, acct),
      eq(journalLines.periodCode, periodCode),
    ));
    return { dr: num(r?.dr), cr: num(r?.cr) };
  };
  const output = await bal("420100");
  const input = await bal("131000");
  const outNet = r2(output.cr - output.dr);
  const inNet = r2(input.dr - input.cr);
  if (outNet === 0 && inNet === 0) return { message: "No VAT movement in this period." };
  const lines: JournalLineInput[] = [];
  if (outNet !== 0) lines.push({ account: "420100", dr: outNet, desc: `Clear output VAT ${periodCode}`, taxCode: "VAT" });
  if (inNet !== 0) lines.push({ account: "131000", cr: inNet, desc: `Clear input VAT ${periodCode}`, taxCode: "VAT" });
  const net = r2(outNet - inNet);
  lines.push(net >= 0
    ? { account: "420200", cr: Math.abs(net), bp: "GRA", desc: `VAT payable to GRA ${periodCode}` }
    : { account: "420200", dr: Math.abs(net), bp: "GRA", desc: `VAT recoverable from GRA ${periodCode}` });
  const res = await postDocument({
    clientId: ctx.clientId, postDate: period.endDate, module: "TAX", docType: "VAT",
    lines, createdBy: ctx.user, reference: `VAT-${periodCode}`,
  });
  return { docNo: res.docNo, net, message: `VAT control settled — ${net >= 0 ? "payable" : "recoverable"} ${Math.abs(net).toFixed(2)}` };
}

/** Year-end: close P&L to retained earnings. */
export async function yearEndClose(ctx: Ctx, fiscalYear: number) {
  return withPeriodLock(ctx.clientId, String(fiscalYear), "year-end", () => yearEndCloseInner(ctx, fiscalYear));
}

async function yearEndCloseInner(ctx: Ctx, fiscalYear: number) {
  // AUDIT FIX 5 — a second run would transfer the profit to reserves twice.
  const prior = await db.select({ docNo: journalLines.docNo }).from(journalLines).where(and(
    eq(journalLines.clientId, ctx.clientId), eq(journalLines.docType, "YE"),
    eq(journalLines.reference, `YE-${fiscalYear}`),
  )).limit(1);
  if (prior.length) {
    throw new OpsError(`Fiscal year ${fiscalYear} has already been closed by document ${prior[0].docNo}. Reverse that document first if you need to re-run the close.`);
  }

  const rows = await db.select({
    account: journalLines.account,
    bal: sql<string>`sum(${journalLines.debit} - ${journalLines.credit})`,
  }).from(journalLines)
    .where(and(eq(journalLines.clientId, ctx.clientId), eq(journalLines.fiscalYear, fiscalYear)))
    .groupBy(journalLines.account);

  const pl = rows.filter((r) => /^[5-7]/.test(r.account) && Math.abs(num(r.bal)) > 0.005);
  if (!pl.length) throw new OpsError(`No profit or loss balances found for ${fiscalYear}.`);
  const lines: JournalLineInput[] = [];
  let net = 0;
  for (const r of pl) {
    const b = num(r.bal);
    lines.push({ account: r.account, [b > 0 ? "cr" : "dr"]: Math.abs(b), desc: `Year-end close ${fiscalYear}` } as JournalLineInput);
    net = r2(net + b);
  }
  lines.push(net > 0
    ? { account: "310100", dr: Math.abs(net), desc: `Loss for ${fiscalYear} to retained earnings` }
    : { account: "310100", cr: Math.abs(net), desc: `Profit for ${fiscalYear} to retained earnings` });

  const periods = await db.select().from(fiscalPeriods)
    .where(and(eq(fiscalPeriods.clientId, ctx.clientId), eq(fiscalPeriods.year, fiscalYear)))
    .orderBy(desc(fiscalPeriods.period));
  const res = await postDocument({
    clientId: ctx.clientId, postDate: periods[0]?.endDate || today(), module: "FI", docType: "YE",
    lines, createdBy: ctx.user, reference: `YE-${fiscalYear}`, reason: "Year-end close",
  });
  return { docNo: res.docNo, profit: r2(-net), message: `${fiscalYear} closed — ${net <= 0 ? "profit" : "loss"} of ${Math.abs(net).toFixed(2)} transferred to retained earnings` };
}

/** Quick helper so the firm can bill a client for work done. */
export async function billClientForServices(ctx: Ctx, p: { clientBpNo: string; description: string; amount: number; taxCode?: string }) {
  return createTradeDoc(ctx, {
    docKind: "SINV", bp: p.clientBpNo,
    lines: [{ description: p.description, qty: 1, unitPrice: p.amount, account: "516100", taxCode: p.taxCode || "STD" }],
    narrative: "Professional services rendered",
  });
}

export async function listClientsLite() {
  return db.select({ id: clients.id, name: clients.name, sector: clients.sector, isFirm: clients.isFirm }).from(clients);
}

export { whtFor };
