export type SessionUser = {
  id: number;
  email: string;
  name: string;
  role: "owner" | "client";
  clientId: string | null;
};
export type ClientCompany = {
  id: string;
  name: string;
  industry: string;
  currency: string;
  active: boolean;
  createdBy: string;
};
export type ClientAdminRow = ClientCompany & {
  stats: { lines: number; docs: number; debits: number };
  users: { id: number; email: string; name: string; active: boolean; lastLoginAt: string | null }[];
};
export type MePayload = {
  user: SessionUser | null;
  clients?: ClientCompany[];
  activeClient?: ClientCompany | null;
};

export type Account = { accountNo: string; description: string; type: string };
export type Partner = { bpNo: string; name: string; type: string };
export type CostCenter = { ccCode: string; ccName: string };
export type Material = { materialNo: string; description: string; type: string; stdPrice: string };
export type PO = {
  poNo: string; vendor: string; material: string; qty: string; price: string;
  total: string; cc: string; status: string; createdBy: string;
};
export type SO = {
  soNo: string; customer: string; material: string; qty: string; price: string;
  total: string; status: string; createdBy: string;
};
export type MasterPayload = {
  accounts: Account[];
  partners: Partner[];
  costCenters: CostCenter[];
  materials: Material[];
  purchaseOrders: PO[];
  salesOrders: SO[];
};

export type JournalRow = {
  id: number; docNo: string; lineNo: number; postDate: string; module: string;
  docType: string; account: string; bp: string; costCenter: string; material: string;
  description: string; debit: number; credit: number; createdBy: string; reference: string;
};

export type TBRow = {
  accountNo: string; description: string; type: string;
  totalDr: number; totalCr: number; balance: number;
};
export type FinRow = TBRow & { amount: number };

export type ReportsPayload = {
  trialBalance: TBRow[];
  byModule: { module: string; debits: number; credits: number; transactions: number }[];
  byCostCenter: { costCenter: string; debits: number; credits: number; net: number }[];
  pl: FinRow[];
  bs: FinRow[];
  totals: {
    revenue: number; expenses: number; netIncome: number;
    totalAssets: number; totalLiabilities: number; totalEquity: number;
    totalDebits: number; totalCredits: number;
  };
  journal: JournalRow[];
  ledger: {
    docNo: string; postDate: string; module: string; description: string;
    debit: number; credit: number; runningBal: number;
  }[];
};
