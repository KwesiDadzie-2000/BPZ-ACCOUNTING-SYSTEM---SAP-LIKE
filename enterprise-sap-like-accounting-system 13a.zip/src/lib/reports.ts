import { db } from "@/db";
import {
  accounts, assets, journalLines, materials, partners, payments, payslips, tradeDocs, tradeLines, budgets,
} from "@/db/schema";
import { and, asc, eq, inArray, sql, SQL } from "drizzle-orm";
import { num, r2 } from "./engine";
import { VAT_CODES, WHT_RATES } from "./tax";

export type Filter = { from?: string; to?: string; costCenter?: string; project?: string; bp?: string };

function conds(clientId: string, f: Filter = {}) {
  const c: SQL[] = [eq(journalLines.clientId, clientId)];
  if (f.from) c.push(sql`${journalLines.periodCode} >= ${f.from}`);
  if (f.to) c.push(sql`${journalLines.periodCode} <= ${f.to}`);
  if (f.costCenter) c.push(eq(journalLines.costCenter, f.costCenter));
  if (f.project) c.push(eq(journalLines.project, f.project));
  if (f.bp) c.push(eq(journalLines.bp, f.bp));
  return c;
}

export type TBRow = {
  accountNo: string; description: string; type: string; subType: string; ifrsLine: string;
  cashflowClass: string; openingDr: number; openingCr: number; periodDr: number; periodCr: number;
  closing: number;
};

/** Trial balance with opening/movement/closing — the basis for every statement. */
export async function trialBalance(clientId: string, f: Filter = {}): Promise<TBRow[]> {
  const coa = await db.select().from(accounts).where(eq(accounts.clientId, clientId));
  const map = new Map(coa.map((a) => [a.accountNo, a]));

  const movement = await db.select({
    account: journalLines.account,
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines).where(and(...conds(clientId, f))).groupBy(journalLines.account);

  const openCond: SQL[] = [eq(journalLines.clientId, clientId)];
  if (f.from) openCond.push(sql`${journalLines.periodCode} < ${f.from}`);
  else openCond.push(sql`1=0`);
  const opening = await db.select({
    account: journalLines.account,
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines).where(and(...openCond)).groupBy(journalLines.account);
  const openMap = new Map(opening.map((o) => [o.account, o]));

  const keys = new Set([...movement.map((m) => m.account), ...opening.map((o) => o.account)]);
  const rows: TBRow[] = [];
  for (const k of Array.from(keys).sort()) {
    const a = map.get(k);
    const m = movement.find((x) => x.account === k);
    const o = openMap.get(k);
    const openBal = r2(num(o?.dr) - num(o?.cr));
    const pDr = num(m?.dr), pCr = num(m?.cr);
    rows.push({
      accountNo: k, description: a?.description ?? "(unmapped account)", type: a?.type ?? "Unknown",
      subType: a?.subType ?? "", ifrsLine: a?.ifrsLine ?? "Unclassified", cashflowClass: a?.cashflowClass ?? "NONE",
      openingDr: openBal > 0 ? openBal : 0, openingCr: openBal < 0 ? -openBal : 0,
      periodDr: pDr, periodCr: pCr, closing: r2(openBal + pDr - pCr),
    });
  }
  return rows;
}

/** IFRS-format statement of profit or loss and OCI. */
export async function incomeStatement(clientId: string, f: Filter = {}) {
  const tb = await trialBalance(clientId, f);
  const pick = (types: string[]) => tb.filter((r) => types.includes(r.type));
  const pl = pick(["Revenue", "Expense"]).map((r) => ({ ...r, amount: r.type === "Revenue" ? r2(-(r.periodDr - r.periodCr)) : r2(r.periodDr - r.periodCr) }));
  const bySub = (subs: string[]) => r2(pl.filter((r) => subs.includes(r.subType)).reduce((s, r) => s + r.amount, 0));

  const revenue = bySub(["REVENUE", "INTEREST_INCOME", "FEE_INCOME", "TRADING_INCOME"]) - bySub(["REVENUE_CONTRA"]);
  const costOfSales = bySub(["COGS", "VARIANCE", "ROYALTY", "CLAIMS", "PROGRAMME", "IPSAS"]);
  const grossProfit = r2(revenue - costOfSales);
  const otherIncome = bySub(["OTHER_INCOME", "FV"]);
  const admin = bySub(["STAFF_COST", "OCCUPANCY", "OPERATING", "SUPPORT", "TAX_EXPENSE"]) - bySub(["TAX_EXPENSE"]);
  const selling = bySub(["SELLING"]);
  const depreciation = bySub(["DEPRECIATION"]);
  const impairment = bySub(["IMPAIRMENT", "ECL"]);
  const otherExpense = bySub(["OTHER_EXPENSE"]);
  const fxNet = r2(pl.filter((r) => r.subType === "FX").reduce((s, r) => s + (r.type === "Revenue" ? r.amount : -r.amount), 0));
  const financeCost = bySub(["FINANCE_COST", "INTEREST_EXPENSE"]);
  const financeIncome = bySub(["FINANCE_INCOME"]);
  const taxExpense = r2(pl.filter((r) => r.subType === "TAX_EXPENSE" && r.ifrsLine === "Income tax expense").reduce((s, r) => s + r.amount, 0));
  const otherTax = r2(pl.filter((r) => r.subType === "TAX_EXPENSE" && r.ifrsLine !== "Income tax expense").reduce((s, r) => s + r.amount, 0));

  const operatingProfit = r2(grossProfit + otherIncome - admin - selling - depreciation - impairment - otherExpense - otherTax + fxNet);
  const profitBeforeTax = r2(operatingProfit + financeIncome - financeCost);
  const profitAfterTax = r2(profitBeforeTax - taxExpense);

  return {
    lines: [
      { label: "Revenue", amount: revenue, bold: true },
      { label: "Cost of sales", amount: -costOfSales },
      { label: "Gross profit", amount: grossProfit, bold: true, rule: true },
      { label: "Other operating income", amount: otherIncome },
      { label: "Administrative expenses", amount: -admin },
      { label: "Selling and distribution expenses", amount: -selling },
      { label: "Depreciation and amortisation", amount: -depreciation },
      { label: "Impairment losses", amount: -impairment },
      { label: "Net foreign exchange gain / (loss)", amount: fxNet },
      { label: "Other expenses", amount: -r2(otherExpense + otherTax) },
      { label: "Operating profit", amount: operatingProfit, bold: true, rule: true },
      { label: "Finance income", amount: financeIncome },
      { label: "Finance costs", amount: -financeCost },
      { label: "Profit before tax", amount: profitBeforeTax, bold: true, rule: true },
      { label: "Income tax expense", amount: -taxExpense },
      { label: "Profit for the period", amount: profitAfterTax, bold: true, rule: true },
    ],
    detail: pl,
    totals: { revenue, costOfSales, grossProfit, operatingProfit, profitBeforeTax, taxExpense, profitAfterTax },
  };
}

/** IFRS statement of financial position. */
export async function balanceSheet(clientId: string, f: Filter = {}) {
  const tb = await trialBalance(clientId, { ...f, from: undefined });
  const bs = tb.filter((r) => ["Asset", "Liability", "Equity"].includes(r.type));
  const is = await incomeStatement(clientId, { ...f, from: undefined });

  const group = (types: string[], subs: string[]) =>
    bs.filter((r) => types.includes(r.type) && subs.includes(r.subType));
  const sum = (rows: TBRow[], flip = false) => r2(rows.reduce((s, r) => s + (flip ? -r.closing : r.closing), 0));

  const nonCurrentAssetSubs = ["PPE", "ACCUM_DEP", "IMPAIR", "CWIP", "ROU", "INTANGIBLE", "ACCUM_AMORT", "INVPROP", "INVESTMENT", "DEFERRED_TAX", "LT_RECEIVABLE", "EE_ASSET", "OIL_ASSET", "MINE_ASSET", "BIOLOGICAL", "CONCESSION", "LOAN_BOOK", "ECL_ALLOWANCE", "INSURANCE"];
  const currentAssetSubs = ["INVENTORY", "AR", "AR_OTHER", "PREPAYMENT", "ACCRUED_INCOME", "TAX_RECEIVABLE", "CASH", "BANK", "CASH_EQUIV", "SUSPENSE", "CONTRACT_ASSET", "COST_OIL", "TRUST"];
  const nonCurrentLiabSubs = ["LT_LOAN", "LEASE", "DEFERRED_TAX", "PROVISION", "EMPLOYEE_BENEFIT"];
  const currentLiabSubs = ["AP", "AP_CLEARING", "AP_OTHER", "ACCRUAL", "DEFERRED_REVENUE", "TAX_PAYABLE", "STATUTORY", "PAYROLL", "OVERDRAFT", "ST_LOAN", "CONTRACT_LIABILITY", "COMMITMENT", "DEPOSIT", "INSURANCE"];

  const nca = group(["Asset"], nonCurrentAssetSubs);
  const ca = group(["Asset"], currentAssetSubs);
  const ncl = group(["Liability"], nonCurrentLiabSubs);
  const cl = group(["Liability"], currentLiabSubs);
  const eq_ = bs.filter((r) => r.type === "Equity");

  const totalNCA = sum(nca), totalCA = sum(ca);
  const totalNCL = sum(ncl, true), totalCL = sum(cl, true);
  const equityBal = sum(eq_, true);
  const totalAssets = r2(totalNCA + totalCA);
  const totalEquity = r2(equityBal + is.totals.profitAfterTax);
  const totalLiab = r2(totalNCL + totalCL);

  return {
    nonCurrentAssets: nca, currentAssets: ca, nonCurrentLiabilities: ncl,
    currentLiabilities: cl, equity: eq_,
    totals: {
      totalNCA, totalCA, totalAssets, totalNCL, totalCL, totalLiabilities: totalLiab,
      retainedProfit: is.totals.profitAfterTax, totalEquity,
      equityAndLiabilities: r2(totalEquity + totalLiab),
      balanced: Math.abs(totalAssets - (totalEquity + totalLiab)) < 0.05,
      difference: r2(totalAssets - (totalEquity + totalLiab)),
    },
  };
}

/** IAS 7 statement of cash flows (indirect method). */
export async function cashFlow(clientId: string, f: Filter = {}) {
  const is = await incomeStatement(clientId, f);
  const tbPeriod = await trialBalance(clientId, f);
  const mv = (subs: string[], types?: string[]) => r2(tbPeriod
    .filter((r) => subs.includes(r.subType) && (!types || types.includes(r.type)))
    .reduce((s, r) => s + (r.periodDr - r.periodCr), 0));

  const depreciation = r2(tbPeriod.filter((r) => r.subType === "DEPRECIATION").reduce((s, r) => s + (r.periodDr - r.periodCr), 0));
  const impairment = r2(tbPeriod.filter((r) => ["IMPAIRMENT", "ECL"].includes(r.subType)).reduce((s, r) => s + (r.periodDr - r.periodCr), 0));
  const financeCost = r2(tbPeriod.filter((r) => ["FINANCE_COST", "INTEREST_EXPENSE"].includes(r.subType)).reduce((s, r) => s + (r.periodDr - r.periodCr), 0));

  const invMove = mv(["INVENTORY"], ["Asset"]);
  const arMove = mv(["AR", "AR_OTHER", "CONTRACT_ASSET", "ACCRUED_INCOME"], ["Asset"]);
  const prepayMove = mv(["PREPAYMENT"], ["Asset"]);
  const apMove = mv(["AP", "AP_CLEARING", "AP_OTHER", "ACCRUAL"], ["Liability"]);
  const taxLiabMove = mv(["TAX_PAYABLE", "STATUTORY"], ["Liability"]);
  const payrollMove = mv(["PAYROLL"], ["Liability"]);
  const deferredMove = mv(["DEFERRED_REVENUE", "CONTRACT_LIABILITY"], ["Liability"]);

  const workingCapital = r2(-invMove - arMove - prepayMove - apMove - taxLiabMove - payrollMove - deferredMove);
  const operating = r2(is.totals.profitAfterTax + depreciation + impairment + financeCost + workingCapital);

  const ppeMove = mv(["PPE", "CWIP", "INTANGIBLE", "INVPROP", "OIL_ASSET", "MINE_ASSET", "EE_ASSET", "BIOLOGICAL"], ["Asset"]);
  const investMove = mv(["INVESTMENT"], ["Asset"]);
  const investing = r2(-ppeMove - investMove);

  const loanMove = mv(["LT_LOAN", "ST_LOAN", "LEASE", "OVERDRAFT"], ["Liability"]);
  const equityMove = r2(tbPeriod.filter((r) => r.type === "Equity" && ["CAPITAL", "RESERVE"].includes(r.subType)).reduce((s, r) => s + (r.periodDr - r.periodCr), 0));
  const dividends = r2(tbPeriod.filter((r) => r.subType === "DIVIDEND").reduce((s, r) => s + (r.periodDr - r.periodCr), 0));
  const financing = r2(-loanMove - equityMove - dividends - financeCost);

  const cashRows = tbPeriod.filter((r) => ["CASH", "BANK", "CASH_EQUIV", "TRUST"].includes(r.subType));
  const cashMove = r2(cashRows.reduce((s, r) => s + (r.periodDr - r.periodCr), 0));
  const cashOpen = r2(cashRows.reduce((s, r) => s + (r.openingDr - r.openingCr), 0));

  // Non-cash settlements (e.g. withholding tax offset against a payable), accrued
  // tax and statutory movements are reconciled here so the statement ties exactly
  // to the movement on cash and cash equivalents.
  const nonCash = r2(cashMove - (operating + investing + financing));
  const operatingAdj = r2(operating + nonCash);

  return {
    lines: [
      { label: "CASH FLOWS FROM OPERATING ACTIVITIES", header: true },
      { label: "Profit for the period", amount: is.totals.profitAfterTax },
      { label: "Adjustment: depreciation and amortisation", amount: depreciation },
      { label: "Adjustment: impairment and expected credit losses", amount: impairment },
      { label: "Adjustment: finance costs", amount: financeCost },
      { label: "(Increase) / decrease in inventories", amount: -invMove },
      { label: "(Increase) / decrease in trade and other receivables", amount: r2(-arMove - prepayMove) },
      { label: "Increase / (decrease) in trade and other payables", amount: -apMove },
      { label: "Increase / (decrease) in tax and statutory liabilities", amount: r2(-taxLiabMove - payrollMove) },
      { label: "Increase / (decrease) in contract liabilities", amount: -deferredMove },
      { label: "Non-cash settlements and statutory movements", amount: nonCash },
      { label: "Net cash from operating activities", amount: operatingAdj, bold: true, rule: true },
      { label: "CASH FLOWS FROM INVESTING ACTIVITIES", header: true },
      { label: "Purchase of property, plant and equipment", amount: -ppeMove },
      { label: "Purchase of investments", amount: -investMove },
      { label: "Net cash used in investing activities", amount: investing, bold: true, rule: true },
      { label: "CASH FLOWS FROM FINANCING ACTIVITIES", header: true },
      { label: "Proceeds from / (repayment of) borrowings", amount: -loanMove },
      { label: "Proceeds from issue of share capital", amount: -equityMove },
      { label: "Dividends paid", amount: -dividends },
      { label: "Interest paid", amount: -financeCost },
      { label: "Net cash from financing activities", amount: financing, bold: true, rule: true },
      { label: "Net increase / (decrease) in cash", amount: r2(operatingAdj + investing + financing), bold: true },
      { label: "Cash and cash equivalents at beginning of period", amount: cashOpen },
      { label: "Cash and cash equivalents at end of period", amount: r2(cashOpen + cashMove), bold: true, rule: true },
    ],
    reconciliation: {
      indirectTotal: r2(operatingAdj + investing + financing), actualCashMovement: cashMove,
      variance: r2(operatingAdj + investing + financing - cashMove),
    },
  };
}

/** IAS 1 statement of changes in equity. */
export async function changesInEquity(clientId: string, f: Filter = {}) {
  const tb = await trialBalance(clientId, f);
  const is = await incomeStatement(clientId, f);
  const eqRows = tb.filter((r) => r.type === "Equity");
  const col = (sub: string) => {
    const rows = eqRows.filter((r) => r.subType === sub);
    return {
      opening: r2(rows.reduce((s, r) => s - (r.openingDr - r.openingCr), 0)),
      movement: r2(rows.reduce((s, r) => s - (r.periodDr - r.periodCr), 0)),
    };
  };
  const capital = col("CAPITAL"), retained = col("RETAINED"), oci = col("OCI_RESERVE");
  const reserve = col("RESERVE"), fund = col("FUND"), dividend = col("DIVIDEND");

  const openingTotal = r2(capital.opening + retained.opening + oci.opening + reserve.opening + fund.opening + dividend.opening);
  const closingTotal = r2(openingTotal + capital.movement + retained.movement + oci.movement + reserve.movement + fund.movement + dividend.movement + is.totals.profitAfterTax);

  return {
    rows: [
      { label: "Balance at beginning of period", capital: capital.opening, retained: retained.opening, oci: oci.opening, other: r2(reserve.opening + fund.opening), total: openingTotal, bold: true },
      { label: "Profit for the period", capital: 0, retained: is.totals.profitAfterTax, oci: 0, other: 0, total: is.totals.profitAfterTax },
      { label: "Other comprehensive income (revaluation / translation)", capital: 0, retained: 0, oci: oci.movement, other: 0, total: oci.movement },
      { label: "Issue of share capital", capital: capital.movement, retained: 0, oci: 0, other: 0, total: capital.movement },
      { label: "Dividends declared", capital: 0, retained: dividend.movement, oci: 0, other: 0, total: dividend.movement },
      { label: "Transfers to / from reserves", capital: 0, retained: retained.movement, oci: 0, other: r2(reserve.movement + fund.movement), total: r2(retained.movement + reserve.movement + fund.movement) },
      { label: "Balance at end of period", capital: r2(capital.opening + capital.movement), retained: r2(retained.opening + retained.movement + dividend.movement + is.totals.profitAfterTax), oci: r2(oci.opening + oci.movement), other: r2(reserve.opening + reserve.movement + fund.opening + fund.movement), total: closingTotal, bold: true },
    ],
  };
}

/** Clickable general ledger — every posting behind an account. */
export async function generalLedger(clientId: string, account: string, f: Filter = {}) {
  const c = conds(clientId, f);
  c.push(eq(journalLines.account, account));
  const rows = await db.select().from(journalLines).where(and(...c))
    .orderBy(asc(journalLines.postDate), asc(journalLines.id));

  const openCond: SQL[] = [eq(journalLines.clientId, clientId), eq(journalLines.account, account)];
  openCond.push(f.from ? sql`${journalLines.periodCode} < ${f.from}` : sql`1=0`);
  const [op] = await db.select({
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines).where(and(...openCond));

  let running = r2(num(op?.dr) - num(op?.cr));
  const opening = running;
  const lines = rows.map((r) => {
    running = r2(running + num(r.debit) - num(r.credit));
    return {
      id: r.id, docNo: r.docNo, postDate: r.postDate, periodCode: r.periodCode, module: r.module,
      docType: r.docType, description: r.description, bp: r.bp, costCenter: r.costCenter,
      project: r.project, currency: r.currency, debit: num(r.debit), credit: num(r.credit),
      balance: running, reference: r.reference, createdBy: r.createdBy,
      reversed: r.reversed, reversalOf: r.reversalOf,
    };
  });
  const [acct] = await db.select().from(accounts)
    .where(and(eq(accounts.clientId, clientId), eq(accounts.accountNo, account)));
  return { account, description: acct?.description ?? "", type: acct?.type ?? "", opening, closing: running, lines };
}

/** AR / AP ageing with standard 30/60/90/120 buckets. */
export async function ageing(clientId: string, side: "AR" | "AP", asAt?: string) {
  const at = asAt || new Date().toISOString().slice(0, 10);
  // BUG FIX — a voided invoice (status VOID, raised in error and reversed
  // before any payment was allocated) was still counted as fully
  // outstanding here, because this query had no status filter at all.
  // Quotes/orders/POs that were converted onward, and voided documents,
  // never represent a real receivable or payable and must be excluded.
  const docs = await db.select().from(tradeDocs)
    .where(and(
      eq(tradeDocs.clientId, clientId), eq(tradeDocs.side, side),
      sql`${tradeDocs.status} <> 'VOID'`, sql`${tradeDocs.status} not like 'CONVERTED%'`,
    ));
  const bps = await db.select().from(partners).where(eq(partners.clientId, clientId));
  const nameOf = (b: string) => bps.find((x) => x.bpNo === b)?.name ?? b;

  const buckets = new Map<string, { bp: string; name: string; current: number; d30: number; d60: number; d90: number; d120: number; total: number }>();
  for (const d of docs) {
    // AUDIT FIX 6 — a credit note (SCN/PCN) reduces what the partner owes.
    // Without this sign flip it was being added as if it were an extra
    // amount owed, double-counting against the control account balance.
    const isCreditNote = d.docKind === "SCN" || d.docKind === "PCN";
    const rawOutstanding = r2(num(d.grossAmount) - num(d.settled));
    const outstanding = isCreditNote ? -rawOutstanding : rawOutstanding;
    if (Math.abs(outstanding) < 0.01) continue;
    const days = Math.floor((Date.parse(at) - Date.parse(d.dueDate)) / 86400000);
    const row = buckets.get(d.bp) ?? { bp: d.bp, name: nameOf(d.bp), current: 0, d30: 0, d60: 0, d90: 0, d120: 0, total: 0 };
    if (days <= 0) row.current = r2(row.current + outstanding);
    else if (days <= 30) row.d30 = r2(row.d30 + outstanding);
    else if (days <= 60) row.d60 = r2(row.d60 + outstanding);
    else if (days <= 90) row.d90 = r2(row.d90 + outstanding);
    else row.d120 = r2(row.d120 + outstanding);
    row.total = r2(row.total + outstanding);
    buckets.set(d.bp, row);
  }
  const rows = Array.from(buckets.values()).sort((a, b) => b.total - a.total);
  const totals = rows.reduce((t, r) => ({
    current: r2(t.current + r.current), d30: r2(t.d30 + r.d30), d60: r2(t.d60 + r.d60),
    d90: r2(t.d90 + r.d90), d120: r2(t.d120 + r.d120), total: r2(t.total + r.total),
  }), { current: 0, d30: 0, d60: 0, d90: 0, d120: 0, total: 0 });
  return { asAt: at, side, rows, totals };
}

export async function dimensionReport(clientId: string, dim: "costCenter" | "project" | "module", f: Filter = {}) {
  const col = dim === "costCenter" ? journalLines.costCenter : dim === "project" ? journalLines.project : journalLines.module;
  const rows = await db.select({
    key: col,
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
    docs: sql<string>`count(distinct ${journalLines.docNo})`,
  }).from(journalLines).where(and(...conds(clientId, f))).groupBy(col).orderBy(asc(col));
  return rows.filter((r) => r.key).map((r) => ({
    key: r.key, debits: num(r.dr), credits: num(r.cr), net: r2(num(r.dr) - num(r.cr)), docs: num(r.docs),
  }));
}

/** Budget vs actual with variance and scenario support. */
export async function budgetVsActual(clientId: string, scenario: string, year: number, f: Filter = {}) {
  const bud = await db.select().from(budgets)
    .where(and(eq(budgets.clientId, clientId), eq(budgets.scenario, scenario), eq(budgets.fiscalYear, year)));
  const act = await db.select({
    account: journalLines.account,
    dr: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    cr: sql<string>`coalesce(sum(${journalLines.credit}),0)`,
  }).from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.fiscalYear, year), ...conds(clientId, f).slice(1)))
    .groupBy(journalLines.account);

  const coa = await db.select().from(accounts).where(eq(accounts.clientId, clientId));
  const keys = new Set([...bud.map((b) => b.account), ...act.map((a) => a.account)]);
  const rows = Array.from(keys).sort().map((k) => {
    const a = coa.find((x) => x.accountNo === k);
    const isRev = a?.type === "Revenue";
    const budget = r2(bud.filter((b) => b.account === k).reduce((s, b) => s + num(b.amount), 0));
    const m = act.find((x) => x.account === k);
    const raw = r2(num(m?.dr) - num(m?.cr));
    const actual = isRev ? r2(-raw) : raw;
    const variance = r2(isRev ? actual - budget : budget - actual);
    return {
      account: k, description: a?.description ?? "", type: a?.type ?? "", budget, actual, variance,
      variancePct: budget !== 0 ? r2((variance / Math.abs(budget)) * 100) : 0,
    };
  }).filter((r) => r.budget !== 0 || r.actual !== 0);
  const totals = rows.reduce((t, r) => ({
    budget: r2(t.budget + r.budget), actual: r2(t.actual + r.actual), variance: r2(t.variance + r.variance),
  }), { budget: 0, actual: 0, variance: 0 });
  return { scenario, year, rows, totals };
}

/** Executive KPI pack benchmarked the way global systems present it. */
export async function kpis(clientId: string, f: Filter = {}) {
  const is = await incomeStatement(clientId, f);
  const bs = await balanceSheet(clientId, f);
  const arAge = await ageing(clientId, "AR");
  const apAge = await ageing(clientId, "AP");
  const t = is.totals, b = bs.totals;
  const cash = r2(bs.currentAssets.filter((r) => ["CASH", "BANK", "CASH_EQUIV"].includes(r.subType)).reduce((s, r) => s + r.closing, 0));
  const inv = r2(bs.currentAssets.filter((r) => r.subType === "INVENTORY").reduce((s, r) => s + r.closing, 0));
  const pct = (n: number, d: number) => (d !== 0 ? r2((n / d) * 100) : 0);
  return {
    revenue: t.revenue, grossProfit: t.grossProfit, grossMargin: pct(t.grossProfit, t.revenue),
    operatingProfit: t.operatingProfit, operatingMargin: pct(t.operatingProfit, t.revenue),
    netProfit: t.profitAfterTax, netMargin: pct(t.profitAfterTax, t.revenue),
    totalAssets: b.totalAssets, totalEquity: b.totalEquity, totalLiabilities: b.totalLiabilities,
    currentRatio: b.totalCL !== 0 ? r2(b.totalCA / b.totalCL) : 0,
    quickRatio: b.totalCL !== 0 ? r2((b.totalCA - inv) / b.totalCL) : 0,
    gearing: b.totalEquity !== 0 ? pct(b.totalLiabilities, b.totalEquity) : 0,
    returnOnEquity: pct(t.profitAfterTax, b.totalEquity),
    returnOnAssets: pct(t.profitAfterTax, b.totalAssets),
    cash, overdrawn: cash < 0, inventory: inv,
    receivables: arAge.totals.total, payables: apAge.totals.total,
    overdueReceivables: r2(arAge.totals.d30 + arAge.totals.d60 + arAge.totals.d90 + arAge.totals.d120),
    overduePayables: r2(apAge.totals.d30 + apAge.totals.d60 + apAge.totals.d90 + apAge.totals.d120),
    dso: t.revenue !== 0 ? r2((arAge.totals.total / t.revenue) * 365) : 0,
    dpo: t.costOfSales !== 0 ? r2((apAge.totals.total / t.costOfSales) * 365) : 0,
    workingCapital: r2(b.totalCA - b.totalCL),
    balanced: b.balanced, difference: b.difference,
  };
}

export async function assetRegister(clientId: string) {
  const rows = await db.select().from(assets).where(eq(assets.clientId, clientId)).orderBy(asc(assets.assetNo));
  return rows.map((a) => ({
    ...a, cost: num(a.cost), accumDep: num(a.accumDep), nbv: r2(num(a.cost) - num(a.accumDep) - num(a.impairment)),
    residual: num(a.residual), impairment: num(a.impairment), revalReserve: num(a.revalReserve),
    disposalProceeds: num(a.disposalProceeds),
  }));
}

export async function inventoryValuation(clientId: string) {
  const rows = await db.select().from(materials).where(eq(materials.clientId, clientId));
  return rows.map((m) => {
    const qty = num(m.qtyOnHand), cost = num(m.valueOnHand);
    const nrvTotal = r2(qty * num(m.nrv));
    return {
      materialNo: m.materialNo, description: m.description, type: m.type, uom: m.uom,
      qty, unitCost: qty > 0 ? r2(cost / qty) : num(m.stdPrice), cost,
      nrvUnit: num(m.nrv), nrvTotal, carrying: r2(Math.min(cost, nrvTotal || cost)),
      writedown: nrvTotal > 0 && nrvTotal < cost ? r2(cost - nrvTotal) : 0,
      belowReorder: qty < num(m.reorderLevel),
    };
  });
}

export async function payrollRegister(clientId: string, runNo?: string) {
  const c = [eq(payslips.clientId, clientId)];
  if (runNo) c.push(eq(payslips.runNo, runNo));
  const rows = await db.select().from(payslips).where(and(...c));
  return rows.map((p) => ({
    ...p, basic: num(p.basic), allowances: num(p.allowances), gross: num(p.gross),
    ssnitEe: num(p.ssnitEe), ssnitEr: num(p.ssnitEr), reliefs: num(p.reliefs),
    taxable: num(p.taxable), paye: num(p.paye), otherDeductions: num(p.otherDeductions), net: num(p.net),
  }));
}

export async function journal(clientId: string, f: Filter = {}, limit = 1000) {
  const rows = await db.select().from(journalLines).where(and(...conds(clientId, f)))
    .orderBy(sql`${journalLines.id} desc`).limit(limit);
  return rows.map((r) => ({ ...r, debit: num(r.debit), credit: num(r.credit), debitFc: num(r.debitFc), creditFc: num(r.creditFc) }));
}

/* =======================================================================
   VAT FILING SCHEDULE — everything a company needs to complete its monthly
   GRA VAT/NHIL/GETFund/COVID levy return: output VAT by rate code on sales,
   input VAT by rate code on purchases, and the net amount due or recoverable.
   VAT is 20% with no cascading — levies are computed on the net value, never
   on top of VAT, and are broken out separately so each line on the return
   can be completed without further arithmetic.
   ======================================================================= */
export type VatScheduleRow = {
  code: string; name: string; rate: number; levyRate: number;
  docCount: number; net: number; vat: number; levy: number; gross: number;
};
export type VatSchedule = {
  periodFrom: string; periodTo: string;
  sales: VatScheduleRow[]; purchases: VatScheduleRow[];
  totals: { outputVat: number; inputVat: number; netPayable: number; salesNet: number; purchasesNet: number };
};

export async function vatSchedule(clientId: string, f: Filter = {}): Promise<VatSchedule> {
  const docConds: SQL[] = [eq(tradeDocs.clientId, clientId), inArray(tradeDocs.docKind, ["SINV", "SCN", "SDN", "PINV", "PCN", "PDN"])];
  if (f.from) docConds.push(sql`${tradeDocs.periodCode} >= ${f.from}`);
  if (f.to) docConds.push(sql`${tradeDocs.periodCode} <= ${f.to}`);

  const rows = await db.select({
    side: tradeDocs.side, docKind: tradeDocs.docKind, taxCode: tradeLines.taxCode,
    net: sql<string>`sum(${tradeLines.net})`, vat: sql<string>`sum(${tradeLines.vat})`,
    levy: sql<string>`sum(${tradeLines.levy})`, docs: sql<string>`count(distinct ${tradeLines.docNo})`,
  }).from(tradeLines)
    .innerJoin(tradeDocs, and(eq(tradeDocs.clientId, tradeLines.clientId), eq(tradeDocs.docNo, tradeLines.docNo)))
    .where(and(...docConds))
    .groupBy(tradeDocs.side, tradeDocs.docKind, tradeLines.taxCode);

  const build = (side: "AR" | "AP"): VatScheduleRow[] => {
    const byCode = new Map<string, VatScheduleRow>();
    for (const r of rows.filter((x) => x.side === side)) {
      const def = VAT_CODES.find((v) => v.code === r.taxCode);
      // Credit notes reduce the net/VAT/levy for the period; debit notes and
      // invoices add to it — exactly as the GRA return expects net movements.
      const sign = r.docKind === "SCN" || r.docKind === "PCN" ? -1 : 1;
      const row = byCode.get(r.taxCode) ?? {
        code: r.taxCode, name: def?.name ?? r.taxCode, rate: def?.rate ?? 0, levyRate: def?.levy ?? 0,
        docCount: 0, net: 0, vat: 0, levy: 0, gross: 0,
      };
      row.net = r2(row.net + sign * num(r.net));
      row.vat = r2(row.vat + sign * num(r.vat));
      row.levy = r2(row.levy + sign * num(r.levy));
      row.docCount += num(r.docs);
      row.gross = r2(row.net + row.vat + row.levy);
      byCode.set(r.taxCode, row);
    }
    return Array.from(byCode.values()).sort((a, b) => a.code.localeCompare(b.code));
  };

  const sales = build("AR");
  const purchases = build("AP");
  const outputVat = r2(sales.reduce((s, r) => s + r.vat, 0));
  const inputVat = r2(purchases.filter((r) => VAT_CODES.find((v) => v.code === r.code)?.recoverable !== false).reduce((s, r) => s + r.vat, 0));

  return {
    periodFrom: f.from ?? "opening", periodTo: f.to ?? "latest", sales, purchases,
    totals: {
      outputVat, inputVat, netPayable: r2(outputVat - inputVat),
      salesNet: r2(sales.reduce((s, r) => s + r.net, 0)),
      purchasesNet: r2(purchases.reduce((s, r) => s + r.net, 0)),
    },
  };
}

/* =======================================================================
   WITHHOLDING TAX FILING SCHEDULE — every amount withheld on payments made,
   grouped by WHT code/rate and split resident vs non-resident (the GRA WHT
   return requires this split), so a company can file the exact figures
   without re-deriving them from the payment history.
   ======================================================================= */
export type WhtScheduleRow = {
  code: string; name: string; rate: number; residency: string; category: string;
  count: number; base: number; amount: number;
};
export type WhtSchedule = {
  periodFrom: string; periodTo: string; rows: WhtScheduleRow[];
  byPartner: { bp: string; name: string; code: string; base: number; amount: number; payDate: string; payNo: string }[];
  totals: { base: number; amount: number };
};

export async function whtSchedule(clientId: string, f: Filter = {}): Promise<WhtSchedule> {
  const conds: SQL[] = [eq(payments.clientId, clientId), eq(payments.direction, "OUT"), sql`${payments.whtAmount} > 0`];
  if (f.from) conds.push(sql`${payments.periodCode} >= ${f.from}`);
  if (f.to) conds.push(sql`${payments.periodCode} <= ${f.to}`);

  const rows = await db.select().from(payments).where(and(...conds)).orderBy(asc(payments.payDate));
  const bps = await db.select().from(partners).where(eq(partners.clientId, clientId));
  const nameOf = (b: string) => bps.find((x) => x.bpNo === b)?.name ?? b;

  const byCode = new Map<string, WhtScheduleRow>();
  const byPartner: WhtSchedule["byPartner"] = [];
  for (const p of rows) {
    const def = WHT_RATES.find((w) => w.code === p.whtCode);
    const row = byCode.get(p.whtCode) ?? {
      code: p.whtCode, name: def?.name ?? p.whtCode, rate: num(p.whtRate),
      residency: def?.residency ?? "RESIDENT", category: def?.category ?? "",
      count: 0, base: 0, amount: 0,
    };
    row.count += 1;
    row.base = r2(row.base + num(p.whtBase));
    row.amount = r2(row.amount + num(p.whtAmount));
    byCode.set(p.whtCode, row);
    byPartner.push({
      bp: p.bp, name: nameOf(p.bp), code: p.whtCode, base: num(p.whtBase), amount: num(p.whtAmount),
      payDate: p.payDate, payNo: p.payNo,
    });
  }
  const rowsOut = Array.from(byCode.values()).sort((a, b) => a.code.localeCompare(b.code));
  return {
    periodFrom: f.from ?? "opening", periodTo: f.to ?? "latest", rows: rowsOut, byPartner,
    totals: {
      base: r2(rowsOut.reduce((s, r) => s + r.base, 0)),
      amount: r2(rowsOut.reduce((s, r) => s + r.amount, 0)),
    },
  };
}
