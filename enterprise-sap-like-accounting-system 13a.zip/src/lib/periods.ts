import { db } from "@/db";
import { fiscalPeriods } from "@/db/schema";
import { and, asc, eq, gte, lte } from "drizzle-orm";

export type PeriodRow = typeof fiscalPeriods.$inferSelect;

const pad = (n: number) => String(n).padStart(2, "0");
export const periodCode = (year: number, period: number) => `${year}-${pad(period)}`;

function lastDay(y: number, m: number) {
  return new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
}

/**
 * Generates fiscal periods for a span of years. `fyStartMonth` lets a client
 * run e.g. an April–March year. Periods are labelled by fiscal year and can be
 * extended indefinitely by calling again with a later `toYear`.
 */
export async function ensurePeriods(clientId: string, fromYear: number, toYear: number, fyStartMonth = 1) {
  const rows: (typeof fiscalPeriods.$inferInsert)[] = [];
  for (let fy = fromYear; fy <= toYear; fy++) {
    for (let p = 1; p <= 12; p++) {
      const absMonth = fyStartMonth - 1 + (p - 1);
      const calYear = fy + Math.floor(absMonth / 12);
      const calMonth = (absMonth % 12) + 1;
      rows.push({
        clientId,
        code: periodCode(fy, p),
        year: fy,
        period: p,
        startDate: `${calYear}-${pad(calMonth)}-01`,
        endDate: lastDay(calYear, calMonth),
        status: "OPEN",
      });
    }
  }
  if (rows.length) await db.insert(fiscalPeriods).values(rows).onConflictDoNothing();
  return rows.length;
}

/** Guarantees coverage around "now" and auto-extends into the future. */
export async function ensureCoverage(clientId: string, fyStartMonth = 1, forDate?: string) {
  const target = new Date(forDate || new Date().toISOString().slice(0, 10));
  const y = target.getUTCFullYear();
  await ensurePeriods(clientId, y - 3, y + 3, fyStartMonth);
}

export async function listPeriods(clientId: string) {
  return db.select().from(fiscalPeriods).where(eq(fiscalPeriods.clientId, clientId))
    .orderBy(asc(fiscalPeriods.year), asc(fiscalPeriods.period));
}

/** Resolves which fiscal period a posting date falls into. */
export async function periodForDate(clientId: string, postDate: string): Promise<PeriodRow | null> {
  const [row] = await db.select().from(fiscalPeriods)
    .where(and(
      eq(fiscalPeriods.clientId, clientId),
      lte(fiscalPeriods.startDate, postDate),
      gte(fiscalPeriods.endDate, postDate),
    ))
    .limit(1);
  return row ?? null;
}

export class PeriodError extends Error {}

/** Enforces period control — the heart of month-end integrity. */
export async function assertPostable(clientId: string, postDate: string): Promise<PeriodRow> {
  let p = await periodForDate(clientId, postDate);
  if (!p) {
    await ensureCoverage(clientId, 1, postDate);
    p = await periodForDate(clientId, postDate);
  }
  if (!p) throw new PeriodError(`No fiscal period is defined for ${postDate}.`);
  if (p.status !== "OPEN") {
    throw new PeriodError(`Period ${p.code} is ${p.status}. Re-open it before posting to ${postDate}.`);
  }
  return p;
}

export async function setPeriodStatus(clientId: string, code: string, status: string, by: string) {
  await db.update(fiscalPeriods)
    .set({ status, closedBy: status === "OPEN" ? "" : by, closedAt: status === "OPEN" ? null : new Date() })
    .where(and(eq(fiscalPeriods.clientId, clientId), eq(fiscalPeriods.code, code)));
}

export async function currentPeriod(clientId: string) {
  const today = new Date().toISOString().slice(0, 10);
  return (await periodForDate(clientId, today)) ?? (await listPeriods(clientId))[0] ?? null;
}

/** Inclusive period-code range used by every report filter. */
export function periodRange(from: string, to: string) {
  return { from, to };
}
