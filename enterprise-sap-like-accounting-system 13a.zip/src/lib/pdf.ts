import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";
import { db } from "@/db";
import { clients, partners, tradeDocs, tradeLines } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { num, r2 } from "./engine";
import { ageing } from "./reports";

const NAVY = rgb(0.047, 0.176, 0.322); // #0c2d52
const GOLD = rgb(0.961, 0.663, 0.122); // #f5a91f
const GREY = rgb(0.4, 0.44, 0.49);
const LIGHT = rgb(0.95, 0.97, 0.98);

const DOC_TITLES: Record<string, string> = {
  QUOTE: "QUOTATION", SO: "SALES ORDER", SINV: "TAX INVOICE", SCN: "CREDIT NOTE", SDN: "DEBIT NOTE",
  PO: "PURCHASE ORDER", PINV: "SUPPLIER INVOICE", PCN: "SUPPLIER CREDIT NOTE", PDN: "SUPPLIER DEBIT NOTE",
  DINV: "STATUTORY / DIRECT INVOICE",
};

const money = (n: number | string) =>
  Number(n ?? 0).toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/**
 * Renders a professional, print-ready PDF for a sales/purchase document —
 * the single most visible gap between an internal ledger tool and something
 * a client can actually hand to their own customer. Built with pdf-lib so no
 * headless browser or external rendering service is required.
 */
export async function renderTradeDocPdf(clientId: string, docNo: string): Promise<Uint8Array> {
  const [doc] = await db.select().from(tradeDocs)
    .where(and(eq(tradeDocs.clientId, clientId), eq(tradeDocs.docNo, docNo)));
  if (!doc) throw new Error(`Document ${docNo} not found.`);
  const lines = await db.select().from(tradeLines)
    .where(and(eq(tradeLines.clientId, clientId), eq(tradeLines.docNo, docNo)));
  const [client] = await db.select().from(clients).where(eq(clients.id, clientId));
  const [bp] = await db.select().from(partners)
    .where(and(eq(partners.clientId, clientId), eq(partners.bpNo, doc.bp)));

  const pdf = await PDFDocument.create();
  pdf.setTitle(`${DOC_TITLES[doc.docKind] ?? doc.docKind} ${doc.docNo}`);
  pdf.setProducer("BPZ Enterprise Platform");
  const page = pdf.addPage(PageSizes.A4);
  const { width, height } = page.getSize();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);

  let y = height - 40;
  const margin = 44;

  // Header band
  page.drawRectangle({ x: 0, y: height - 90, width, height: 90, color: NAVY });
  page.drawText(client?.name ?? clientId, { x: margin, y: height - 38, size: 15, font: bold, color: rgb(1, 1, 1) });
  page.drawText(client?.sector ? client.sector.replace(/_/g, " ") : "", { x: margin, y: height - 55, size: 9, font, color: rgb(0.85, 0.88, 0.92) });
  if (client?.tin) page.drawText(`TIN: ${client.tin}`, { x: margin, y: height - 68, size: 9, font, color: rgb(0.85, 0.88, 0.92) });
  page.drawRectangle({ x: width - 210, y: height - 90, width: 210, height: 4, color: GOLD });
  page.drawText(DOC_TITLES[doc.docKind] ?? doc.docKind, { x: width - 210, y: height - 48, size: 18, font: bold, color: rgb(1, 1, 1) });
  page.drawText(doc.docNo, { x: width - 210, y: height - 68, size: 11, font, color: GOLD });

  y = height - 120;
  const colX = width - 210;
  page.drawText(`Document date: ${doc.docDate}`, { x: colX, y, size: 9.5, font, color: GREY }); y -= 14;
  page.drawText(`Due date: ${doc.dueDate}`, { x: colX, y, size: 9.5, font, color: GREY }); y -= 14;
  page.drawText(`Currency: ${doc.currency}`, { x: colX, y, size: 9.5, font, color: GREY }); y -= 14;
  page.drawText(`Status: ${doc.status}`, { x: colX, y, size: 9.5, font, color: GREY });

  let ly = height - 120;
  page.drawText(doc.side === "AR" ? "BILL TO" : "SUPPLIER", { x: margin, y: ly, size: 9, font: bold, color: NAVY }); ly -= 14;
  page.drawText(bp?.name ?? doc.bp, { x: margin, y: ly, size: 11, font: bold, color: rgb(0.1, 0.1, 0.1) }); ly -= 13;
  if (bp?.tin) { page.drawText(`TIN: ${bp.tin}`, { x: margin, y: ly, size: 9, font, color: GREY }); ly -= 13; }
  if (bp?.email) { page.drawText(bp.email, { x: margin, y: ly, size: 9, font, color: GREY }); ly -= 13; }
  if (bp?.phone) { page.drawText(bp.phone, { x: margin, y: ly, size: 9, font, color: GREY }); }

  // Line item table
  y = height - 215;
  const tableX = margin, tableW = width - margin * 2;
  const cols = [
    { h: "Description", w: 0.42 }, { h: "Qty", w: 0.08, right: true }, { h: "Unit Price", w: 0.14, right: true },
    { h: "Net", w: 0.12, right: true }, { h: "VAT/Levy", w: 0.12, right: true }, { h: "Total", w: 0.12, right: true },
  ];
  page.drawRectangle({ x: tableX, y: y - 20, width: tableW, height: 22, color: NAVY });
  let cx = tableX;
  for (const c of cols) {
    const w = c.w * tableW;
    page.drawText(c.h, { x: cx + (c.right ? w - font.widthOfTextAtSize(c.h, 8.5) - 6 : 6), y: y - 14, size: 8.5, font: bold, color: rgb(1, 1, 1) });
    cx += w;
  }
  y -= 22;

  for (const [i, l] of lines.entries()) {
    const rowH = 20;
    if (y - rowH < 140) break; // single-page MVP; overflow lines are still in the system/Excel export
    if (i % 2 === 1) page.drawRectangle({ x: tableX, y: y - rowH, width: tableW, height: rowH, color: LIGHT });
    cx = tableX;
    const vatLevy = r2(num(l.vat) + num(l.levy));
    const vals = [l.description || "", num(l.qty).toFixed(2), money(l.unitPrice), money(l.net), money(vatLevy), money(l.total)];
    for (let ci = 0; ci < cols.length; ci++) {
      const c = cols[ci]; const w = c.w * tableW;
      const text = String(vals[ci]).slice(0, ci === 0 ? 48 : 20);
      const tw = font.widthOfTextAtSize(text, 9);
      page.drawText(text, { x: cx + (c.right ? w - tw - 6 : 6), y: y - 14, size: 9, font, color: rgb(0.15, 0.15, 0.15) });
      cx += w;
    }
    y -= rowH;
  }

  // Totals box
  y -= 10;
  const boxW = 230, boxX = width - margin - boxW;
  const totalsRows: [string, string, boolean?][] = [
    ["Net amount", money(doc.netAmount)],
    ["VAT (20%)", money(doc.vatAmount)],
    ...(num(doc.levyAmount) > 0 ? [["Levies", money(doc.levyAmount)] as [string, string]] : []),
    ["Total due", money(doc.grossAmount), true],
    ["Settled", money(doc.settled)],
    ["Balance outstanding", money(r2(num(doc.grossAmount) - num(doc.settled))), true],
  ];
  for (const [label, val, isBold] of totalsRows) {
    if (isBold) page.drawRectangle({ x: boxX, y: y - 16, width: boxW, height: 18, color: NAVY });
    page.drawText(label, { x: boxX + 8, y: y - 12, size: 9.5, font: isBold ? bold : font, color: isBold ? rgb(1, 1, 1) : rgb(0.25, 0.25, 0.25) });
    const tw = (isBold ? bold : font).widthOfTextAtSize(val, 9.5);
    page.drawText(val, { x: boxX + boxW - tw - 8, y: y - 12, size: 9.5, font: isBold ? bold : font, color: isBold ? rgb(1, 1, 1) : rgb(0.25, 0.25, 0.25) });
    y -= 18;
  }

  if (doc.narrative) {
    page.drawText("Notes:", { x: margin, y: y - 6, size: 9, font: bold, color: NAVY });
    page.drawText(doc.narrative.slice(0, 110), { x: margin, y: y - 20, size: 9, font, color: GREY });
  }

  // Footer
  page.drawLine({ start: { x: margin, y: 60 }, end: { x: width - margin, y: 60 }, thickness: 0.75, color: rgb(0.85, 0.85, 0.85) });
  page.drawText("Generated by the BPZ Enterprise Financial Platform — IFRS-compliant accounting, payroll, tax and advisory.",
    { x: margin, y: 44, size: 7.5, font, color: GREY });
  page.drawText(`Document ${doc.docNo} · Posted ${doc.glDoc || "not yet posted"} · ${new Date().toLocaleString()}`,
    { x: margin, y: 32, size: 7.5, font, color: GREY });

  return pdf.save();
}

/** Renders a customer/vendor statement of account (open items + ageing) as a PDF. */
export async function renderStatementPdf(clientId: string, bpNo: string): Promise<Uint8Array> {
  const [client] = await db.select().from(clients).where(eq(clients.id, clientId));
  const [bp] = await db.select().from(partners).where(and(eq(partners.clientId, clientId), eq(partners.bpNo, bpNo)));
  if (!bp) throw new Error(`Business partner ${bpNo} not found.`);
  const ledger = await generalLedgerForBp(clientId, bpNo);
  const age = await ageing(clientId, bp.type === "Customer" ? "AR" : "AP");
  const myAge = age.rows.find((r) => r.bp === bpNo);

  const pdf = await PDFDocument.create();
  pdf.setTitle(`Statement of Account — ${bp.name}`);
  const page = pdf.addPage(PageSizes.A4);
  const { width, height } = page.getSize();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const margin = 44;

  page.drawRectangle({ x: 0, y: height - 80, width, height: 80, color: NAVY });
  page.drawText(client?.name ?? clientId, { x: margin, y: height - 36, size: 14, font: bold, color: rgb(1, 1, 1) });
  page.drawText("STATEMENT OF ACCOUNT", { x: margin, y: height - 56, size: 11, font, color: GOLD });
  page.drawRectangle({ x: 0, y: height - 80, width: 200, height: 4, color: GOLD });

  let y = height - 110;
  page.drawText(bp.name, { x: margin, y, size: 12, font: bold }); y -= 16;
  page.drawText(`As at ${new Date().toISOString().slice(0, 10)}`, { x: margin, y, size: 9.5, font, color: GREY }); y -= 24;

  const cols = [{ h: "Doc No", w: 0.16 }, { h: "Date", w: 0.12 }, { h: "Module", w: 0.12 }, { h: "Description", w: 0.36 },
    { h: "Debit", w: 0.12, right: true }, { h: "Credit", w: 0.12, right: true }];
  const tableW = width - margin * 2;
  page.drawRectangle({ x: margin, y: y - 18, width: tableW, height: 20, color: NAVY });
  let cx = margin;
  for (const c of cols) { page.drawText(c.h, { x: cx + 6, y: y - 13, size: 8, font: bold, color: rgb(1, 1, 1) }); cx += c.w * tableW; }
  y -= 20;

  for (const [i, l] of ledger.slice(0, 26).entries()) {
    const rowH = 16;
    if (i % 2 === 1) page.drawRectangle({ x: margin, y: y - rowH, width: tableW, height: rowH, color: LIGHT });
    cx = margin;
    const vals = [l.docNo, l.postDate, l.module, (l.description || "").slice(0, 46), money(l.debit), money(l.credit)];
    for (let ci = 0; ci < cols.length; ci++) {
      const c = cols[ci]; const w = c.w * tableW;
      const text = String(vals[ci]);
      const tw = font.widthOfTextAtSize(text, 8.5);
      page.drawText(text, { x: cx + (c.right ? w - tw - 6 : 6), y: y - 12, size: 8.5, font });
      cx += w;
    }
    y -= rowH;
  }

  y -= 12;
  if (myAge) {
    const boxX = width - margin - 240;
    page.drawRectangle({ x: boxX, y: y - 18, width: 240, height: 20, color: NAVY });
    page.drawText("Ageing summary", { x: boxX + 8, y: y - 13, size: 9, font: bold, color: rgb(1, 1, 1) });
    y -= 20;
    const buckets: [string, number][] = [["Current", myAge.current], ["1-30 days", myAge.d30], ["31-60 days", myAge.d60], ["61-90 days", myAge.d90], ["90+ days", myAge.d120]];
    for (const [label, val] of buckets) {
      page.drawText(label, { x: boxX + 8, y: y - 12, size: 9, font });
      const tw = font.widthOfTextAtSize(money(val), 9);
      page.drawText(money(val), { x: boxX + 232 - tw, y: y - 12, size: 9, font });
      y -= 15;
    }
    page.drawRectangle({ x: boxX, y: y - 16, width: 240, height: 18, color: GOLD });
    page.drawText("Total outstanding", { x: boxX + 8, y: y - 12, size: 9.5, font: bold, color: NAVY });
    const tw = bold.widthOfTextAtSize(money(myAge.total), 9.5);
    page.drawText(money(myAge.total), { x: boxX + 232 - tw, y: y - 12, size: 9.5, font: bold, color: NAVY });
  }

  page.drawText("Generated by the BPZ Enterprise Financial Platform.", { x: margin, y: 30, size: 7.5, font, color: GREY });
  return pdf.save();
}

async function generalLedgerForBp(clientId: string, bpNo: string) {
  const { db: _db } = await import("@/db");
  const { journalLines } = await import("@/db/schema");
  const rows = await _db.select().from(journalLines)
    .where(and(eq(journalLines.clientId, clientId), eq(journalLines.bp, bpNo)))
    .orderBy(journalLines.postDate);
  return rows.map((r) => ({ ...r, debit: num(r.debit), credit: num(r.credit) }));
}
