import { db } from "@/db";
import {
  accounts, bankAccounts, clients, costCenters, employees, journalLines, materials, partners, users,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { coaForSector } from "./coa";
import { SECTORS } from "./constants";
import { hashPassword, permsFor, slugId, tempPassword, FIRM_ID } from "./auth";
import { ensureCoverage } from "./periods";
import { seedTaxRates } from "./tax";

/* ---------- Sector-tailored cost centres ---------- */
const BASE_CC: [string, string, string][] = [
  ["CC-ADM", "Administration & Finance", "DEPT"],
  ["CC-SLS", "Sales & Marketing", "DEPT"],
  ["CC-OPS", "Operations", "DEPT"],
  ["CC-HR", "Human Resources", "DEPT"],
  ["CC-PRC", "Procurement & Supply Chain", "DEPT"],
  ["CC-IT", "Information Technology", "DEPT"],
];

const SECTOR_CC: Record<string, [string, string, string][]> = {
  MANUFACTURING: [["CC-PROD", "Production / Factory", "PROD"], ["CC-QC", "Quality Control", "PROD"], ["CC-MNT", "Plant Maintenance", "PROD"], ["CC-WH", "Warehouse & Stores", "PROD"]],
  CONSTRUCTION: [["CC-SITE", "Site Operations", "PROJ"], ["CC-QS", "Quantity Surveying", "PROJ"], ["CC-PLANT", "Plant & Equipment Yard", "PROD"], ["CC-HSE", "Health, Safety & Environment", "DEPT"]],
  OIL_GAS_UPSTREAM: [["CC-EXPL", "Exploration", "PROJ"], ["CC-DRILL", "Drilling & Completions", "PROJ"], ["CC-PROD-O", "Production Operations", "PROD"], ["CC-HSE", "HSE & Regulatory", "DEPT"], ["CC-JV", "Joint Venture / Partner Accounting", "DEPT"]],
  OIL_GAS_DOWNSTREAM: [["CC-DEPOT", "Depot & Bulk Storage", "PROD"], ["CC-RETAIL", "Retail Station Network", "PROD"], ["CC-HAUL", "Haulage & Distribution", "PROD"]],
  MINING: [["CC-MINE", "Mining Operations", "PROD"], ["CC-PLANT-M", "Processing Plant", "PROD"], ["CC-GEO", "Geology & Exploration", "PROJ"], ["CC-ENV", "Environment & Community", "DEPT"], ["CC-HSE", "Health & Safety", "DEPT"]],
  ENERGY_POWER: [["CC-GEN", "Generation", "PROD"], ["CC-TND", "Transmission & Distribution", "PROD"], ["CC-REG", "Regulatory & Tariff", "DEPT"]],
  BANKING: [["CC-RETAILB", "Retail Banking", "PROD"], ["CC-CORP", "Corporate Banking", "PROD"], ["CC-TREAS", "Treasury", "PROD"], ["CC-RISK", "Risk & Compliance", "DEPT"]],
  HEALTHCARE: [["CC-OPD", "Outpatient Department", "PROD"], ["CC-WARD", "Inpatient & Wards", "PROD"], ["CC-LAB", "Laboratory & Imaging", "PROD"], ["CC-PHAR", "Pharmacy", "PROD"]],
  EDUCATION: [["CC-ACAD", "Academic / Teaching", "PROD"], ["CC-BOARD", "Boarding & Catering", "PROD"], ["CC-LIB", "Library & Resources", "DEPT"]],
  HOSPITALITY: [["CC-ROOMS", "Rooms Division", "PROD"], ["CC-FB", "Food & Beverage", "PROD"], ["CC-EVENTS", "Events & Banqueting", "PROD"]],
  AGRIC: [["CC-FARM", "Farm Operations", "PROD"], ["CC-IRRIG", "Irrigation", "PROD"], ["CC-POST", "Post-harvest & Storage", "PROD"]],
  TRANSPORT_LOGISTICS: [["CC-FLEET", "Fleet Operations", "PROD"], ["CC-WHSE", "Warehousing", "PROD"], ["CC-CLEAR", "Clearing & Forwarding", "PROD"]],
  PROFESSIONAL_SERVICES: [["CC-AUDIT", "Assurance & Bookkeeping", "PROD"], ["CC-TAXD", "Tax Services", "PROD"], ["CC-ADV", "Advisory", "PROD"], ["CC-PAY", "Payroll Bureau", "PROD"]],
  NGO_NPO: [["CC-PROG", "Programmes", "PROJ"], ["CC-ME", "Monitoring & Evaluation", "DEPT"], ["CC-GOV", "Governance & Support", "DEPT"]],
  RETAIL_WHOLESALE: [["CC-STORE", "Store Operations", "PROD"], ["CC-ECOM", "E-commerce", "PROD"]],
  TELECOM: [["CC-NET", "Network Operations", "PROD"], ["CC-CARE", "Customer Care", "DEPT"]],
  REAL_ESTATE: [["CC-DEV", "Development Projects", "PROJ"], ["CC-PM", "Property Management", "PROD"]],
};

const SECTOR_MATERIALS: Record<string, [string, string, string, string, number, number][]> = {
  MANUFACTURING: [["RM-001", "Steel Rods 12mm", "Raw Material", "KG", 48, 0], ["RM-002", "Packaging Cartons", "Raw Material", "EA", 3.5, 0], ["FG-001", "Finished Widget", "Finished Good", "EA", 180, 320]],
  CONSTRUCTION: [["MAT-CEM", "Portland Cement 50kg", "Raw Material", "BAG", 95, 0], ["MAT-IRON", "Iron Rods 16mm", "Raw Material", "LEN", 140, 0], ["MAT-AGG", "Granite Chippings", "Raw Material", "M3", 320, 0]],
  OIL_GAS_DOWNSTREAM: [["PET-PMS", "Petrol (PMS)", "Finished Good", "LTR", 12.4, 15.99], ["PET-AGO", "Diesel (AGO)", "Finished Good", "LTR", 13.1, 16.49], ["PET-LPG", "LPG", "Finished Good", "KG", 9.8, 13.5]],
  MINING: [["CON-CYN", "Sodium Cyanide", "Consumable", "KG", 32, 0], ["CON-BALL", "Grinding Media / Mill Balls", "Consumable", "KG", 18, 0], ["ORE-STK", "Ore Stockpile", "Raw Material", "TON", 210, 0]],
  HEALTHCARE: [["DRG-001", "Paracetamol 500mg (pack)", "Consumable", "PK", 12, 22], ["CON-GLV", "Examination Gloves", "Consumable", "BOX", 45, 70]],
  RETAIL_WHOLESALE: [["SKU-001", "Rice 5kg", "Merchandise", "BAG", 85, 120], ["SKU-002", "Cooking Oil 5L", "Merchandise", "EA", 110, 155]],
  HOSPITALITY: [["FB-001", "Beverages — Assorted", "Merchandise", "EA", 8, 20], ["FB-002", "Dry Food Provisions", "Raw Material", "KG", 25, 0]],
  AGRIC: [["AG-SEED", "Maize Seed (certified)", "Raw Material", "KG", 18, 0], ["AG-FERT", "NPK Fertiliser 50kg", "Raw Material", "BAG", 320, 0]],
  GENERAL: [["ITM-001", "General Stock Item A", "Merchandise", "EA", 100, 160], ["ITM-002", "Office Consumables", "Consumable", "EA", 25, 0]],
};

/** Installs the full sector-tailored master data set for a workspace. */
export async function ensureMasterData(clientId: string) {
  const [c] = await db.select().from(clients).where(eq(clients.id, clientId)).limit(1);
  if (!c) return;
  const sector = c.sector || "GENERAL";

  const coa = coaForSector(sector);
  await db.insert(accounts).values(coa.map((a) => ({
    clientId, accountNo: a.no, description: a.desc, type: a.type, subType: a.sub,
    ifrsLine: a.ifrs, cashflowClass: a.cf, isBank: !!a.bank, isControl: !!a.control, sector,
  }))).onConflictDoNothing();

  const ccs = [...BASE_CC, ...(SECTOR_CC[sector] ?? [])];
  await db.insert(costCenters).values(
    ccs.map(([ccCode, ccName, ccType]) => ({ clientId, ccCode, ccName, ccType })),
  ).onConflictDoNothing();

  const mats = SECTOR_MATERIALS[sector] ?? SECTOR_MATERIALS.GENERAL;
  await db.insert(materials).values(mats.map(([materialNo, description, type, uom, std, sale]) => ({
    clientId, materialNo, description, type, uom,
    stdPrice: String(std), salesPrice: String(sale), nrv: String(sale || std),
  }))).onConflictDoNothing();

  await db.insert(bankAccounts).values([
    { clientId, bankCode: "BANK-01", bankName: "Main Current Account", accountNo: "0000000001", glAccount: "141000", currency: c.currency },
    { clientId, bankCode: "BANK-USD", bankName: "USD Foreign Currency Account", accountNo: "0000000002", glAccount: "141500", currency: "USD" },
    { clientId, bankCode: "MOMO", bankName: "Mobile Money Wallet", accountNo: "0244000000", glAccount: "142000", currency: "GHS" },
  ]).onConflictDoNothing();

  await db.insert(partners).values([
    { clientId, bpNo: "C-0001", name: "Sample Customer Ltd", type: "Customer", currency: c.currency, creditDays: 30 },
    { clientId, bpNo: "V-0001", name: "Sample Local Vendor Ltd", type: "Vendor", isResident: true, whtCode: "R_SERVICES", currency: c.currency },
    { clientId, bpNo: "V-0002", name: "Sample Overseas Supplier Inc", type: "Vendor", isResident: false, whtCode: "NR_SERVICES", currency: "USD" },
    {
      clientId, bpNo: "GRA", type: "Vendor", isResident: true, whtCode: "R_EXEMPT", currency: c.currency,
      name: c.country === "GH" ? "Ghana Revenue Authority" : "Tax / Revenue Authority",
    },
    {
      clientId, bpNo: "SSNIT", type: "Vendor", isResident: true, whtCode: "R_EXEMPT", currency: c.currency,
      name: c.country === "GH" ? "Social Security & National Insurance Trust" : (c.statutoryLabel || "Statutory Social Security Body"),
    },
  ]).onConflictDoNothing();

  await ensureCoverage(clientId, c.fyStartMonth);
  await seedTaxRates();
}

export type ProvisionInput = {
  name: string; sector: string; currency?: string; tin?: string;
  contactName?: string; email: string; serviceLines?: string[];
  fyStartMonth?: number; vatRegistered?: boolean; createdBy: string;
  country?: string; payrollTaxMode?: string; payrollFlatRatePct?: number; statutoryLabel?: string;
};

/** Owner action: create a client company, its workspace and its first login. */
export async function provisionClient(input: ProvisionInput) {
  const email = (input.email || "").trim().toLowerCase();
  if (!input.name?.trim()) throw new Error("Company name is required.");
  if (!email.includes("@")) throw new Error("A valid login email is required.");
  if (!SECTORS.find((s) => s.key === input.sector)) throw new Error("Please select a valid sector.");
  const dup = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (dup.length) throw new Error(`A login already exists for ${email}.`);

  const country = (input.country || "GH").toUpperCase().slice(0, 2);
  const payrollTaxMode = country === "GH" ? "GH_PAYE" : (input.payrollTaxMode || "FLAT_RATE");

  const id = slugId(input.name);
  await db.insert(clients).values({
    id,
    name: input.name.trim(),
    shortName: input.name.trim().slice(0, 24),
    sector: input.sector,
    currency: input.currency || (country === "GH" ? "GHS" : "USD"),
    tin: input.tin || "",
    vatRegistered: input.vatRegistered ?? true,
    serviceLines: input.serviceLines ?? ["BOOKKEEPING"],
    fyStartMonth: input.fyStartMonth ?? 1,
    country,
    payrollTaxMode,
    payrollFlatRatePct: String(input.payrollFlatRatePct ?? 0),
    statutoryLabel: input.statutoryLabel || (country === "GH" ? "SSNIT" : "Social Security"),
    createdBy: input.createdBy,
  });

  await ensureMasterData(id);

  const temp = tempPassword();
  const [user] = await db.insert(users).values({
    email,
    name: input.contactName?.trim() || input.name.trim(),
    passwordHash: hashPassword(temp),
    role: "CLIENT_ADMIN",
    clientId: id,
    isFirmStaff: false,
    mustChangePassword: true,
    tempPassword: temp,
    jobTitle: "Client Administrator",
    permissions: permsFor("CLIENT_ADMIN"),
  }).returning();

  return {
    clientId: id, userId: user.id, email, tempPassword: temp,
    workspaceUrl: `/login?email=${encodeURIComponent(email)}&ws=${encodeURIComponent(id)}`,
    message: `Client ${input.name} provisioned with a ${input.sector} workspace`,
  };
}

/** Full platform reset (owner only). Keeps the owner login and the firm workspace. */
export async function resetSystem(keepOwnerEmail: string) {
  const tables = [
    "journal_lines", "trade_docs", "trade_lines", "payments", "payment_allocations",
    "bank_statement_lines", "bank_recs", "bank_accounts", "assets", "depreciation_runs",
    "prepayments", "employees", "pay_components", "payroll_runs", "payslips",
    "budgets", "projects", "engagements", "timesheets", "approvals", "stock_moves",
    "materials", "partners", "cost_centers", "accounts", "fiscal_periods",
    "number_ranges", "activity_log",
  ];
  for (const t of tables) await db.execute(sql.raw(`TRUNCATE TABLE ${t} RESTART IDENTITY CASCADE`));
  await db.delete(users).where(sql`lower(email) <> ${keepOwnerEmail.toLowerCase()}`);
  await db.delete(clients).where(sql`id <> ${FIRM_ID}`);
  await ensureMasterData(FIRM_ID);
  return { message: "System reset complete. Only the owner login and the BPZ firm workspace remain." };
}

export const DEMO_CLIENT_ID = "BPZ-DEMO";
export const DEMO_EMAIL = (process.env.DEMO_EMAIL || "demo@bpz.com.gh").toLowerCase();
export const DEMO_PASSWORD = process.env.DEMO_PASSWORD || "Demo@12345";

/**
 * Guarantees a working demonstration workspace exists with STABLE, documented
 * credentials — called from the same bootstrap path as `ensureOwner()`.
 *
 * This closes the real gap that broke "the demo client login": every demo
 * client previously created during manual testing had a randomised slug ID
 * and a one-time temporary password that only ever appeared in an API
 * response. On a fresh deployment none of that exists, so there was
 * literally no demo account to sign in to. This function makes the demo
 * account part of the application's own startup contract, exactly like the
 * owner account, so `demo@bpz.com.gh` / `Demo@12345` always works.
 */
export async function ensureDemoClient() {
  const [existing] = await db.select().from(clients).where(eq(clients.id, DEMO_CLIENT_ID)).limit(1);
  if (!existing) {
    await db.insert(clients).values({
      id: DEMO_CLIENT_ID, name: "Demo Trading Company Ltd", shortName: "Demo Co",
      sector: "RETAIL_WHOLESALE", currency: "GHS", tin: "C0000000001",
      vatRegistered: true, serviceLines: ["BOOKKEEPING", "PAYROLL", "TAX"],
      fyStartMonth: 1, country: "GH", payrollTaxMode: "GH_PAYE",
      createdBy: "system",
    }).onConflictDoNothing();
  }
  await ensureMasterData(DEMO_CLIENT_ID);

  const [demoUser] = await db.select().from(users).where(eq(users.email, DEMO_EMAIL)).limit(1);
  if (!demoUser) {
    await db.insert(users).values({
      email: DEMO_EMAIL, name: "Demo Client User", passwordHash: hashPassword(DEMO_PASSWORD),
      role: "CLIENT_ADMIN", clientId: DEMO_CLIENT_ID, isFirmStaff: false,
      mustChangePassword: false, jobTitle: "Finance Manager",
      permissions: permsFor("CLIENT_ADMIN"),
    }).onConflictDoNothing();
  } else if (demoUser.clientId !== DEMO_CLIENT_ID) {
    // Guards against a stale/renamed demo account ever shadowing the fixed email.
    await db.update(users).set({ clientId: DEMO_CLIENT_ID, active: true }).where(eq(users.id, demoUser.id));
  }

  // Seed illustrative transactions exactly once — re-running on every boot
  // would otherwise duplicate demo documents each time the app restarts.
  const [hasActivity] = await db.select({ id: journalLines.id }).from(journalLines)
    .where(eq(journalLines.clientId, DEMO_CLIENT_ID)).limit(1);
  if (!hasActivity) {
    await seedDemoTransactions({ clientId: DEMO_CLIENT_ID, user: "system@bpz.com.gh" }).catch(() => undefined);
  }

  return { clientId: DEMO_CLIENT_ID, email: DEMO_EMAIL };
}

/** Posts a realistic day of activity into a workspace — used for the demo account and the "Load demonstration data" action. */
export async function seedDemoTransactions(ctx: { clientId: string; user: string }) {
  const M = await import("./ops");
  const { postDocument } = await import("./engine");
  const log: string[] = [];
  const t = new Date();
  const period = `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, "0")}`;
  const day = t.toISOString().slice(0, 10);

  const cap = await postDocument({
    clientId: ctx.clientId, postDate: day, module: "FI", docType: "OB",
    lines: [
      { account: "141000", dr: 750000, desc: "Opening bank balance" },
      { account: "300100", cr: 750000, desc: "Stated capital introduced" },
    ],
    createdBy: ctx.user, reference: "SEED",
  });
  log.push(`Opening capital posted (${cap.docNo})`);

  const si = await M.createTradeDoc(ctx, {
    docKind: "SINV", bp: "C-0001",
    lines: [{ description: "Supply of goods and services", qty: 10, unitPrice: 12500, account: "500100", taxCode: "STD" }],
  });
  log.push(si.message);

  const pi = await M.createTradeDoc(ctx, {
    docKind: "PINV", bp: "V-0001",
    lines: [{ description: "Professional services received", qty: 1, unitPrice: 40000, account: "720500", taxCode: "STD" }],
  });
  log.push(pi.message);

  const pay = await M.createPayment(ctx, {
    direction: "OUT", bp: "V-0001", bankCode: "BANK-01",
    allocations: [{ docNo: pi.docNo, amount: Math.round(pi.gross * 0.6 * 100) / 100 }],
    whtCode: "R_SERVICES", narrative: "60% part payment with 7.5% WHT",
  });
  log.push(pay.message);

  const rec = await M.createPayment(ctx, {
    direction: "IN", bp: "C-0001", bankCode: "BANK-01",
    allocations: [{ docNo: si.docNo, amount: Math.round(si.gross * 0.5 * 100) / 100 }],
    narrative: "50% receipt from customer",
  });
  log.push(rec.message);

  const fa = await M.createAsset(ctx, { description: "Toyota Hilux double cabin", assetClass: "MOTOR", cost: 420000, costCenter: "CC-OPS" });
  log.push(fa.message);
  const fa2 = await M.createAsset(ctx, { description: "Dell workstations (10 units)", assetClass: "COMPUTER", cost: 95000, costCenter: "CC-ADM" });
  log.push(fa2.message);

  const pp = await M.createPrepayment(ctx, {
    description: "Annual motor and property insurance", totalAmount: 36000,
    expenseAccount: "710400", startPeriod: period, periods: 12, costCenter: "CC-ADM",
  });
  log.push(pp.message);

  await seedDemoEmployees(ctx.clientId);
  log.push("Three sample employees added to payroll");

  const dep = await M.runDepreciation(ctx, period);
  log.push(dep.message);
  const am = await M.runAmortisation(ctx, period);
  log.push(am.message);
  const pr = await M.postPayroll(ctx, period).catch((e) => ({ message: `Payroll: ${(e as Error).message}` }));
  log.push(pr.message);

  return { log, message: `Demonstration data created (${log.length} steps)` };
}

export async function seedDemoEmployees(clientId: string) {
  await db.insert(employees).values([
    { clientId, empNo: "EMP-0001", name: "Kwame Mensah", jobTitle: "Finance Manager", costCenter: "CC-ADM", basicSalary: "8500", ssnit: "C1234567890", tin: "P001234567" },
    { clientId, empNo: "EMP-0002", name: "Ama Owusu", jobTitle: "Senior Accountant", costCenter: "CC-ADM", basicSalary: "5200", ssnit: "C1234567891", tin: "P001234568" },
    { clientId, empNo: "EMP-0003", name: "Yaw Boateng", jobTitle: "Operations Supervisor", costCenter: "CC-OPS", basicSalary: "3800", ssnit: "C1234567892", tin: "P001234569" },
  ]).onConflictDoNothing();
}
