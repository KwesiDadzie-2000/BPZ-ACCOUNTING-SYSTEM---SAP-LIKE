/**
 * In-memory sliding-window rate limiter. This protects a single running
 * instance against scripted abuse (credential stuffing, API hammering) at
 * essentially zero cost. It intentionally does NOT claim to be a distributed
 * limiter — if the platform is later deployed across multiple instances, this
 * should be swapped for a shared store (e.g. Redis). Documented as a known
 * scaling boundary rather than silently pretending to be enterprise-grade.
 */
type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

// Periodic sweep so the map never grows unbounded on a long-running process.
let lastSweep = Date.now();
function sweep() {
  const now = Date.now();
  if (now - lastSweep < 60_000) return;
  lastSweep = now;
  for (const [k, b] of buckets) if (b.resetAt < now) buckets.delete(k);
}

export type RateLimitResult = { allowed: boolean; remaining: number; retryAfterSec: number };

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  sweep();
  const now = Date.now();
  const existing = buckets.get(key);
  if (!existing || existing.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1, retryAfterSec: Math.ceil(windowMs / 1000) };
  }
  existing.count += 1;
  const allowed = existing.count <= limit;
  return { allowed, remaining: Math.max(0, limit - existing.count), retryAfterSec: Math.ceil((existing.resetAt - now) / 1000) };
}

/** Best-effort client identifier from standard proxy headers, falling back to a constant. */
export function clientIp(req: Request): string {
  const h = req.headers;
  return (
    h.get("x-forwarded-for")?.split(",")[0].trim() ||
    h.get("x-real-ip") ||
    "unknown"
  );
}
