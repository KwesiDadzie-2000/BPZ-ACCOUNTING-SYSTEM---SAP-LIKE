import { NextRequest, NextResponse } from "next/server";
import { AuthError, requireWorkspace } from "@/lib/auth";
import { renderStatementPdf, renderTradeDocPdf } from "@/lib/pdf";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { clientId } = await requireWorkspace();
    const q = req.nextUrl.searchParams;
    const kind = q.get("kind") || "doc";

    if (kind === "statement") {
      const bp = q.get("bp");
      if (!bp) return NextResponse.json({ error: "A business partner is required." }, { status: 400 });
      const buf = await renderStatementPdf(clientId, bp);
      return new NextResponse(Buffer.from(buf), {
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `inline; filename="Statement_${bp}.pdf"`,
          "Cache-Control": "no-store",
        },
      });
    }

    const docNo = q.get("docNo");
    if (!docNo) return NextResponse.json({ error: "A document number is required." }, { status: 400 });
    const buf = await renderTradeDocPdf(clientId, docNo);
    return new NextResponse(Buffer.from(buf), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="${docNo}.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: e instanceof AuthError ? e.status : 500 },
    );
  }
}
