import { NextRequest, NextResponse } from "next/server";
import { AuthError, requireWorkspace } from "@/lib/auth";
import { buildWorkbook } from "@/lib/excel";
import { db } from "@/db";
import { clients } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { clientId } = await requireWorkspace();
    const q = req.nextUrl.searchParams;
    const buf = await buildWorkbook(clientId, {
      from: q.get("from") || undefined,
      to: q.get("to") || undefined,
      costCenter: q.get("costCenter") || undefined,
      project: q.get("project") || undefined,
    });
    const [c] = await db.select().from(clients).where(eq(clients.id, clientId));
    const safe = (c?.name ?? clientId).replace(/[^A-Za-z0-9]+/g, "_").slice(0, 40);
    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(Buffer.from(buf), {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="BPZ_${safe}_${stamp}.xlsx"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: e instanceof AuthError ? e.status : 500 });
  }
}
