import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { attachments } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { AuthError, requireWorkspace } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Streams a single attachment's binary content, scoped strictly to the caller's workspace. */
export async function GET(req: NextRequest) {
  try {
    const { clientId } = await requireWorkspace();
    const id = Number(req.nextUrl.searchParams.get("id"));
    if (!id) return NextResponse.json({ error: "An attachment id is required." }, { status: 400 });

    const [row] = await db.select().from(attachments)
      .where(and(eq(attachments.id, id), eq(attachments.clientId, clientId)));
    if (!row) return NextResponse.json({ error: "Attachment not found." }, { status: 404 });

    const buf = Buffer.from(row.data, "base64");
    return new NextResponse(buf, {
      headers: {
        "Content-Type": row.mimeType || "application/octet-stream",
        "Content-Disposition": `inline; filename="${row.fileName.replace(/"/g, "")}"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: e instanceof AuthError ? e.status : 500 },
    );
  }
}
