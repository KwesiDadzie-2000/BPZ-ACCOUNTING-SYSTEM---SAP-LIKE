import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { clients, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  ACTIVE_CLIENT_COOKIE, AuthError, FIRM_ID, SESSION_COOKIE, SEVEN_DAYS, authCookieOptions,
  createToken, deliverResetLink, ensureOwner, getSessionUser, hashPassword, issueResetToken,
  permsFor, redeemResetToken, requireUser, verifyPassword,
} from "@/lib/auth";
import { ensureDemoClient, ensureMasterData } from "@/lib/provision";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";
const fail = (e: unknown) =>
  NextResponse.json({ error: (e as Error).message }, { status: e instanceof AuthError ? e.status : 400 });

export async function GET() {
  try {
    await ensureOwner();
    await ensureDemoClient();
    await ensureMasterData(FIRM_ID);
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ user: null });
    const all = await db.select().from(clients).orderBy(clients.name);
    const visible = user.isFirmStaff ? all : all.filter((c) => c.id === user.clientId);
    const { cookies } = await import("next/headers");
    const jar = await cookies();
    const wanted = jar.get(ACTIVE_CLIENT_COOKIE)?.value;
    const activeClient = user.isFirmStaff
      ? (visible.find((c) => c.id === wanted) ?? visible.find((c) => c.isFirm) ?? visible[0] ?? null)
      : (visible[0] ?? null);
    return NextResponse.json({ user, clients: visible, activeClient });
  } catch (e) { return fail(e); }
}

export async function POST(req: NextRequest) {
  try {
    await ensureOwner();
    await ensureDemoClient();
    const body = (await req.json()) as Record<string, string>;
    const action = body.action || "login";

    // Rate limit every auth action by IP — on top of the per-account lockout
    // below, this blunts scripted credential-stuffing and brute-force runs
    // against the login and password-reset endpoints.
    const ipKey = `auth:${clientIp(req)}:${action}`;
    const ipLimit = rateLimit(ipKey, action === "login" ? 20 : 30, 5 * 60_000);
    if (!ipLimit.allowed) {
      return NextResponse.json(
        { error: `Too many requests from this network. Try again in about ${Math.ceil(ipLimit.retryAfterSec / 60)} minute(s).` },
        { status: 429 },
      );
    }

    if (action === "login") {
      const email = (body.email || "").trim().toLowerCase();
      const [u] = await db.select().from(users).where(eq(users.email, email)).limit(1);

      // Brute-force protection: five failed attempts locks the account for
      // fifteen minutes, mirroring mainstream SaaS accounting platforms.
      const LOCK_AFTER = 5;
      const LOCK_MINUTES = 15;
      if (u?.lockedUntil && u.lockedUntil.getTime() > Date.now()) {
        const mins = Math.ceil((u.lockedUntil.getTime() - Date.now()) / 60000);
        return NextResponse.json(
          { error: `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? "" : "s"}.` },
          { status: 429 },
        );
      }

      if (!u || !u.active || !verifyPassword(body.password || "", u.passwordHash)) {
        if (u) {
          const attempts = u.failedLogins + 1;
          await db.update(users).set({
            failedLogins: attempts,
            lockedUntil: attempts >= LOCK_AFTER ? new Date(Date.now() + LOCK_MINUTES * 60000) : null,
          }).where(eq(users.id, u.id));
          if (attempts >= LOCK_AFTER) {
            return NextResponse.json(
              { error: `Too many failed attempts. The account is locked for ${LOCK_MINUTES} minutes.` },
              { status: 429 },
            );
          }
        }
        return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
      }
      if (u.clientId) {
        const [c] = await db.select().from(clients).where(eq(clients.id, u.clientId)).limit(1);
        if (c && !c.active && !u.isFirmStaff) {
          return NextResponse.json({ error: "Your workspace has been suspended. Please contact BPZ." }, { status: 403 });
        }
        await ensureMasterData(u.clientId);
      }
      await db.update(users).set({ lastLoginAt: new Date(), failedLogins: 0, lockedUntil: null }).where(eq(users.id, u.id));
      const res = NextResponse.json({
        user: { id: u.id, email: u.email, name: u.name, role: u.role, clientId: u.clientId, isFirmStaff: u.isFirmStaff },
        mustChangePassword: u.mustChangePassword,
      });
      res.cookies.set(SESSION_COOKIE, createToken(u.id), authCookieOptions(SEVEN_DAYS));
      res.cookies.set(ACTIVE_CLIENT_COOKIE, u.clientId ?? FIRM_ID, authCookieOptions(SEVEN_DAYS));
      return res;
    }

    if (action === "logout") {
      const res = NextResponse.json({ ok: true });
      res.cookies.set(SESSION_COOKIE, "", { ...authCookieOptions(0) });
      res.cookies.set(ACTIVE_CLIENT_COOKIE, "", { ...authCookieOptions(0) });
      return res;
    }

    if (action === "changePassword") {
      const me = await requireUser();
      const [u] = await db.select().from(users).where(eq(users.id, me.id)).limit(1);
      if (!u) throw new AuthError("User not found.", 404);
      if (!u.mustChangePassword && !verifyPassword(body.currentPassword || "", u.passwordHash)) {
        throw new AuthError("Your current password is incorrect.", 403);
      }
      const pw = body.newPassword || "";
      if (pw.length < 8) throw new AuthError("The new password must be at least 8 characters.", 400);
      if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) throw new AuthError("Include at least one letter and one number.", 400);
      await db.update(users)
        .set({ passwordHash: hashPassword(pw), mustChangePassword: false, tempPassword: "" })
        .where(eq(users.id, me.id));
      return NextResponse.json({ message: "Password updated. Your workspace is now fully unlocked." });
    }

    if (action === "forgotPassword") {
      const email = (body.email || "").trim().toLowerCase();
      const issued = email ? await issueResetToken(email) : null;
      // Always return the same generic response whether or not the account
      // exists — this prevents the endpoint being used to enumerate which
      // email addresses have a login.
      const generic = { message: "If an account exists for that email, a reset link has been issued." };
      if (!issued) return NextResponse.json(generic);
      const origin = req.headers.get("origin") || "";
      const link = `${origin}/login?resetToken=${encodeURIComponent(issued.token)}`;
      const delivery = await deliverResetLink(email, link);
      // No email provider is configured for this deployment, so the link is
      // surfaced directly rather than silently discarded — an owner/admin
      // can relay it, and the architecture is ready for real email delivery
      // the moment SMTP/RESEND/SENDGRID credentials are added.
      return NextResponse.json({ ...generic, resetLink: delivery.emailed ? undefined : link, emailed: delivery.emailed });
    }

    if (action === "resetPasswordWithToken") {
      const result = await redeemResetToken(String(body.token || ""), String(body.newPassword || ""));
      return NextResponse.json({ message: `Password reset for ${result.email}. You can now sign in.` });
    }

    if (action === "updateProfile") {
      const me = await requireUser();
      await db.update(users).set({
        name: body.name || undefined,
        phone: body.phone ?? undefined,
        jobTitle: body.jobTitle ?? undefined,
      }).where(eq(users.id, me.id));
      return NextResponse.json({ message: "Profile updated." });
    }

    if (action === "switchWorkspace") {
      const me = await requireUser();
      if (!me.isFirmStaff) throw new AuthError("You may only work inside your own workspace.", 403);
      const [c] = await db.select().from(clients).where(eq(clients.id, body.clientId)).limit(1);
      if (!c) throw new AuthError("Workspace not found.", 404);
      await ensureMasterData(c.id);
      const res = NextResponse.json({ activeClient: c, message: `Now working in ${c.name}` });
      res.cookies.set(ACTIVE_CLIENT_COOKIE, c.id, authCookieOptions(SEVEN_DAYS));
      return res;
    }

    return NextResponse.json({ error: `Unknown action ${action}` }, { status: 400 });
  } catch (e) { return fail(e); }
}

export const _permsFor = permsFor;
