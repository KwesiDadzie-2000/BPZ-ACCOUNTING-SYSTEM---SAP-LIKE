import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  accounts, assets, bankAccounts, bankRecs, bankStatementLines, budgets, clients, costCenters,
  employees, engagements, fiscalPeriods, materials, partners, payComponents, payments,
  payrollRuns, prepayments, projects, taxRates, tradeDocs,
} from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { AuthError, requireWorkspace } from "@/lib/auth";
import { ensureMasterData } from "@/lib/provision";
import {
  ASSET_CLASSES, CA_CLASSES, COUNTRIES, CURRENCIES, DIRECT_PAYMENT_CATEGORIES, EMPLOYMENT_TYPES,
  PAYROLL_TAX_MODES, PERMISSIONS, ROLES, SECTORS, SERVICE_LINES,
} from "@/lib/constants";
import { VAT_CODES, WHT_RATES, PAYE_BANDS_2026_09, PERSONAL_RELIEFS, CIT_RATES } from "@/lib/tax";
import { WORK_TEMPLATES } from "@/lib/advisory";
import { latestRates } from "@/lib/fx";
import { listApprovals, openItems } from "@/lib/ops";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { user, clientId, isFirmWs } = await requireWorkspace();
    await ensureMasterData(clientId);
    const bp = req.nextUrl.searchParams.get("bp") ?? undefined;

    const w = <T extends { clientId: unknown }>(t: { clientId: never }) => eq(t.clientId as never, clientId);

    const [
      client, coa, bps, ccs, mats, banks, periods, docs, pays, fa, pre, emps,
      comps, runs, recs, stmts, proj, engs, buds, rates, items, pendingApprovals,
    ] = await Promise.all([
      db.select().from(clients).where(eq(clients.id, clientId)).then((r) => r[0]),
      db.select().from(accounts).where(eq(accounts.clientId, clientId)).orderBy(asc(accounts.accountNo)),
      db.select().from(partners).where(eq(partners.clientId, clientId)).orderBy(asc(partners.bpNo)),
      db.select().from(costCenters).where(eq(costCenters.clientId, clientId)).orderBy(asc(costCenters.ccCode)),
      db.select().from(materials).where(eq(materials.clientId, clientId)).orderBy(asc(materials.materialNo)),
      db.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId)),
      db.select().from(fiscalPeriods).where(eq(fiscalPeriods.clientId, clientId)).orderBy(desc(fiscalPeriods.year), desc(fiscalPeriods.period)),
      db.select().from(tradeDocs).where(eq(tradeDocs.clientId, clientId)).orderBy(desc(tradeDocs.createdAt)).limit(400),
      db.select().from(payments).where(eq(payments.clientId, clientId)).orderBy(desc(payments.createdAt)).limit(300),
      db.select().from(assets).where(eq(assets.clientId, clientId)).orderBy(asc(assets.assetNo)),
      db.select().from(prepayments).where(eq(prepayments.clientId, clientId)),
      db.select().from(employees).where(eq(employees.clientId, clientId)).orderBy(asc(employees.empNo)),
      db.select().from(payComponents).where(eq(payComponents.clientId, clientId)),
      db.select().from(payrollRuns).where(eq(payrollRuns.clientId, clientId)).orderBy(desc(payrollRuns.createdAt)),
      db.select().from(bankRecs).where(eq(bankRecs.clientId, clientId)).orderBy(desc(bankRecs.createdAt)).limit(50),
      db.select().from(bankStatementLines).where(eq(bankStatementLines.clientId, clientId)).orderBy(desc(bankStatementLines.stmtDate)).limit(500),
      db.select().from(projects).where(eq(projects.clientId, clientId)),
      db.select().from(engagements).where(eq(engagements.clientId, clientId)).orderBy(desc(engagements.createdAt)),
      db.select().from(budgets).where(eq(budgets.clientId, clientId)),
      latestRates(),
      openItems(clientId, bp),
      listApprovals(clientId, "PENDING"),
    ]);

    const allClients = user.isFirmStaff
      ? await db.select({ id: clients.id, name: clients.name, sector: clients.sector, isFirm: clients.isFirm, active: clients.active, currency: clients.currency }).from(clients).orderBy(asc(clients.name))
      : [];

    const taxCfg = await db.select().from(taxRates).orderBy(asc(taxRates.scope), asc(taxRates.seq)).limit(400);

    return NextResponse.json({
      user, clientId, isFirmWs, client, allClients,
      accounts: coa, partners: bps, costCenters: ccs, materials: mats, bankAccounts: banks,
      periods, tradeDocs: docs, payments: pays, assets: fa, prepayments: pre,
      employees: emps, payComponents: comps, payrollRuns: runs, bankRecs: recs,
      statementLines: stmts, projects: proj, engagements: engs, budgets: buds,
      fxRates: rates, openItems: items, taxRates: taxCfg, pendingApprovals,
      reference: {
        sectors: SECTORS, serviceLines: SERVICE_LINES, assetClasses: ASSET_CLASSES,
        caClasses: CA_CLASSES, currencies: CURRENCIES, vatCodes: VAT_CODES,
        whtRates: WHT_RATES, payeBands: PAYE_BANDS_2026_09, reliefs: PERSONAL_RELIEFS,
        citRates: CIT_RATES, roles: ROLES, permissions: PERMISSIONS, templates: WORK_TEMPLATES,
        countries: COUNTRIES, payrollTaxModes: PAYROLL_TAX_MODES, employmentTypes: EMPLOYMENT_TYPES,
        directPaymentCategories: DIRECT_PAYMENT_CATEGORIES,
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: (e as Error).message },
      { status: e instanceof AuthError ? e.status : 500 },
    );
  }
}
