import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { activityLog, clients, journalLines, users } from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import {
  ACTIVE_CLIENT_COOKIE, AuthError, FIRM_ID, SEVEN_DAYS, authCookieOptions, hashPassword,
  logActivity, permsFor, requireOwner, tempPassword,
} from "@/lib/auth";
import { ensureMasterData, provisionClient, resetSystem } from "@/lib/provision";
import { ensurePeriods } from "@/lib/periods";
import { ROLES } from "@/lib/constants";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";
const S = (v: unknown, d = "") => (typeof v === "string" && v ? v.trim() : d);
const fail = (e: unknown) =>
  NextResponse.json({ error: (e as Error).message }, { status: e instanceof AuthError ? e.status : 400 });

export async function GET() {
  try {
    await requireOwner();
    const rows = await db.select().from(clients).orderBy(desc(clients.createdAt));
    const allUsers = await db.select().from(users).orderBy(desc(users.createdAt));
    const stats = await db.select({
      clientId: journalLines.clientId,
      lines: sql<string>`count(*)`,
      docs: sql<string>`count(distinct ${journalLines.docNo})`,
      value: sql<string>`coalesce(sum(${journalLines.debit}),0)`,
    }).from(journalLines).groupBy(journalLines.clientId);
    const recent = await db.select().from(activityLog).orderBy(desc(activityLog.createdAt)).limit(120);

    return NextResponse.json({
      clients: rows.map((c) => {
        const s = stats.find((x) => x.clientId === c.id);
        return {
          ...c,
          stats: { lines: Number(s?.lines ?? 0), docs: Number(s?.docs ?? 0), value: Number(s?.value ?? 0) },
          users: allUsers.filter((u) => u.clientId === c.id).map((u) => ({
            id: u.id, email: u.email, name: u.name, role: u.role, active: u.active,
            mustChangePassword: u.mustChangePassword, tempPassword: u.tempPassword,
            jobTitle: u.jobTitle, lastLoginAt: u.lastLoginAt,
          })),
        };
      }),
      firmStaff: allUsers.filter((u) => u.isFirmStaff).map((u) => ({
        id: u.id, email: u.email, name: u.name, role: u.role, active: u.active,
        jobTitle: u.jobTitle, mustChangePassword: u.mustChangePassword,
        tempPassword: u.tempPassword, lastLoginAt: u.lastLoginAt,
      })),
      activity: recent,
      roles: ROLES,
    });
  } catch (e) { return fail(e); }
}

export async function POST(req: NextRequest) {
  const limited = rateLimit(`admin:${clientIp(req)}`, 120, 60_000);
  if (!limited.allowed) {
    return NextResponse.json({ error: "Too many requests. Please slow down and try again shortly." }, { status: 429 });
  }
  try {
    const owner = await requireOwner();
    const body = (await req.json()) as Record<string, unknown>;
    const action = S(body.action);

    if (action === "client.create") {
      const r = await provisionClient({
        name: S(body.name), sector: S(body.sector, "GENERAL"), currency: S(body.currency, "GHS"),
        tin: S(body.tin), contactName: S(body.contactName), email: S(body.email),
        serviceLines: (body.serviceLines as string[]) ?? ["BOOKKEEPING"],
        fyStartMonth: Number(body.fyStartMonth) || 1,
        vatRegistered: body.vatRegistered !== false, createdBy: owner.email,
        country: S(body.country, "GH"), payrollTaxMode: S(body.payrollTaxMode) || undefined,
        payrollFlatRatePct: Number(body.payrollFlatRatePct) || 0,
        statutoryLabel: S(body.statutoryLabel) || undefined,
      });
      await logActivity(r.clientId, owner, action, `${S(body.name)} / ${r.email}`);
      const res = NextResponse.json(r);
      res.cookies.set(ACTIVE_CLIENT_COOKIE, r.clientId, authCookieOptions(SEVEN_DAYS));
      return res;
    }

    if (action === "client.update") {
      const id = S(body.clientId);
      await db.update(clients).set({
        name: S(body.name) || undefined, sector: S(body.sector) || undefined,
        currency: S(body.currency) || undefined, tin: S(body.tin),
        serviceLines: (body.serviceLines as string[]) ?? undefined,
        fyStartMonth: body.fyStartMonth ? Number(body.fyStartMonth) : undefined,
        vatRegistered: body.vatRegistered !== undefined ? body.vatRegistered === true : undefined,
        country: S(body.country) || undefined,
        payrollTaxMode: S(body.payrollTaxMode) || undefined,
        payrollFlatRatePct: body.payrollFlatRatePct !== undefined ? String(Number(body.payrollFlatRatePct) || 0) : undefined,
        statutoryLabel: S(body.statutoryLabel) || undefined,
      }).where(eq(clients.id, id));
      await ensureMasterData(id);
      return NextResponse.json({ message: "Client profile updated." });
    }

    if (action === "client.toggle") {
      const [c] = await db.select().from(clients).where(eq(clients.id, S(body.clientId)));
      if (!c) throw new AuthError("Client not found.", 404);
      if (c.isFirm) throw new AuthError("The BPZ firm workspace cannot be suspended.", 400);
      await db.update(clients).set({ active: !c.active }).where(eq(clients.id, c.id));
      await db.update(users).set({ active: !c.active }).where(eq(users.clientId, c.id));
      return NextResponse.json({ message: `${c.name} ${c.active ? "suspended" : "reactivated"} (logins updated)` });
    }

    if (action === "client.extendPeriods") {
      const n = await ensurePeriods(S(body.clientId), Number(body.fromYear), Number(body.toYear), Number(body.fyStartMonth) || 1);
      return NextResponse.json({ message: `Fiscal calendar extended — ${n} periods processed.` });
    }

    if (action === "user.create") {
      const email = S(body.email).toLowerCase();
      if (!email.includes("@")) throw new AuthError("A valid email is required.", 400);
      const dup = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (dup.length) throw new AuthError(`A login already exists for ${email}.`, 400);
      const role = S(body.role, "CLIENT_USER");
      if (!ROLES[role]) throw new AuthError("Unknown role.", 400);
      const isFirmStaff = role === "OWNER" || role === "FIRM_MANAGER" || role === "FIRM_STAFF";
      const clientId = isFirmStaff ? null : S(body.clientId);
      if (!isFirmStaff && !clientId) throw new AuthError("Select the client workspace for this user.", 400);
      const temp = tempPassword();
      const [u] = await db.insert(users).values({
        email, name: S(body.name) || email, passwordHash: hashPassword(temp), role,
        clientId, isFirmStaff, mustChangePassword: true, tempPassword: temp,
        jobTitle: S(body.jobTitle), permissions: (body.permissions as string[]) ?? permsFor(role),
        approvalLimit: String(Number(body.approvalLimit) || 0),
      }).returning();
      await logActivity(clientId ?? FIRM_ID, owner, action, email);
      return NextResponse.json({
        userId: u.id, email, tempPassword: temp,
        workspaceUrl: `/login?email=${encodeURIComponent(email)}`,
        message: `Login created for ${email}`,
      });
    }

    if (action === "user.resetPassword") {
      const [u] = await db.select().from(users).where(eq(users.id, Number(body.userId)));
      if (!u) throw new AuthError("User not found.", 404);
      const temp = S(body.password) || tempPassword();
      await db.update(users).set({
        passwordHash: hashPassword(temp), mustChangePassword: true, tempPassword: temp,
      }).where(eq(users.id, u.id));
      return NextResponse.json({
        tempPassword: temp, email: u.email,
        workspaceUrl: `/login?email=${encodeURIComponent(u.email)}`,
        message: `Temporary password reissued for ${u.email}`,
      });
    }

    if (action === "user.update") {
      const id = Number(body.userId);
      const [u] = await db.select().from(users).where(eq(users.id, id));
      if (!u) throw new AuthError("User not found.", 404);
      const role = S(body.role) || u.role;
      if (!ROLES[role]) throw new AuthError("Unknown role.", 400);
      await db.update(users).set({
        name: S(body.name) || undefined, role, jobTitle: S(body.jobTitle),
        permissions: (body.permissions as string[]) ?? permsFor(role),
        approvalLimit: body.approvalLimit !== undefined ? String(Number(body.approvalLimit)) : undefined,
      }).where(eq(users.id, id));
      return NextResponse.json({ message: `${u.email} updated — role ${role}` });
    }

    if (action === "user.toggle") {
      const [u] = await db.select().from(users).where(eq(users.id, Number(body.userId)));
      if (!u) throw new AuthError("User not found.", 404);
      if (u.role === "OWNER") throw new AuthError("The owner login cannot be disabled.", 400);
      await db.update(users).set({ active: !u.active }).where(eq(users.id, u.id));
      return NextResponse.json({ message: `${u.email} ${u.active ? "access restricted" : "access restored"}` });
    }

    if (action === "user.delete") {
      const [u] = await db.select().from(users).where(eq(users.id, Number(body.userId)));
      if (!u) throw new AuthError("User not found.", 404);
      if (u.role === "OWNER") throw new AuthError("The owner login cannot be deleted.", 400);
      await db.delete(users).where(eq(users.id, u.id));
      return NextResponse.json({ message: `${u.email} removed` });
    }

    if (action === "owner.updateProfile") {
      const newEmail = S(body.email).toLowerCase();
      if (newEmail && newEmail !== owner.email) {
        const dup = await db.select().from(users).where(eq(users.email, newEmail)).limit(1);
        if (dup.length) throw new AuthError("That email is already in use.", 400);
      }
      await db.update(users).set({
        name: S(body.name) || undefined, email: newEmail || undefined,
        phone: S(body.phone), jobTitle: S(body.jobTitle),
      }).where(eq(users.id, owner.id));
      return NextResponse.json({ message: "Owner profile updated." });
    }

    if (action === "firm.update") {
      await db.update(clients).set({
        name: S(body.name) || undefined, tin: S(body.tin),
        currency: S(body.currency) || undefined,
        fyStartMonth: body.fyStartMonth ? Number(body.fyStartMonth) : undefined,
      }).where(eq(clients.id, FIRM_ID));
      return NextResponse.json({ message: "Firm profile updated." });
    }

    if (action === "system.reset") {
      if (S(body.confirm) !== "RESET") {
        throw new AuthError('Type RESET in the confirmation box to proceed.', 400);
      }
      const r = await resetSystem(owner.email);
      const res = NextResponse.json(r);
      res.cookies.set(ACTIVE_CLIENT_COOKIE, FIRM_ID, authCookieOptions(SEVEN_DAYS));
      return res;
    }

    if (action === "system.purgeClient") {
      const id = S(body.clientId);
      if (id === FIRM_ID) throw new AuthError("The firm workspace cannot be deleted.", 400);
      const [c] = await db.select().from(clients).where(eq(clients.id, id));
      if (!c) throw new AuthError("Client not found.", 404);
      if (S(body.confirm) !== c.name) throw new AuthError(`Type the exact client name "${c.name}" to confirm.`, 400);
      for (const t of ["journal_lines", "trade_docs", "trade_lines", "payments", "payment_allocations",
        "bank_statement_lines", "bank_recs", "bank_accounts", "assets", "depreciation_runs",
        "prepayments", "employees", "pay_components", "payroll_runs", "payslips", "budgets",
        "projects", "engagements", "timesheets", "approvals", "stock_moves", "materials",
        "partners", "cost_centers", "accounts", "fiscal_periods", "number_ranges", "activity_log"]) {
        await db.execute(sql.raw(`DELETE FROM ${t} WHERE client_id = '${id.replace(/'/g, "''")}'`));
      }
      await db.delete(users).where(eq(users.clientId, id));
      await db.delete(clients).where(eq(clients.id, id));
      const res = NextResponse.json({ message: `${c.name} and all its data have been permanently deleted.` });
      res.cookies.set(ACTIVE_CLIENT_COOKIE, FIRM_ID, authCookieOptions(SEVEN_DAYS));
      return res;
    }

    throw new AuthError(`Unknown action: ${action}`, 400);
  } catch (e) { return fail(e); }
}
