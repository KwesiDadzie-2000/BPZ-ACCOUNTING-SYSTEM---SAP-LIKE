import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  accounts, attachments, budgets, costCenters, engagements, materials, partners, projects,
  taxRates, tradeDocs, bankAccounts, fiscalPeriods,
} from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { AuthError, can, logActivity, requireWorkspace, resolveTargetClient, requirePerm } from "@/lib/auth";
import { postDocument, nextNumber, PostingError } from "@/lib/engine";
import { PeriodError, ensurePeriods, setPeriodStatus } from "@/lib/periods";
import { refreshRates } from "@/lib/fx";
import { ensureMasterData, seedDemoEmployees, seedDemoTransactions } from "@/lib/provision";
import { templateByKey } from "@/lib/advisory";
import * as O from "@/lib/ops";
import { clientIp, rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

const S = (v: unknown, d = "") => (typeof v === "string" && v ? v : d);
const N = (v: unknown) => Number(v ?? 0);
const B = (v: unknown) => v === true || v === "true";

export async function POST(req: NextRequest) {
  // Blunt-instrument protection against scripted/automated abuse of the
  // transaction endpoint — generous enough not to interfere with normal
  // multi-tab bookkeeping use, tight enough to stop a runaway script.
  const limited = rateLimit(`txn:${clientIp(req)}`, 240, 60_000);
  if (!limited.allowed) {
    return NextResponse.json({ error: "Too many requests. Please slow down and try again shortly." }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try { body = (await req.json()) as Record<string, unknown>; }
  catch { return NextResponse.json({ error: "Invalid request body." }, { status: 400 }); }

  const action = S(body.action);
  try {
    const ws = await requireWorkspace();
    // Firm staff may post into a client workspace; clients are locked to their own.
    const clientId = await resolveTargetClient(ws.user, S(body.targetClient) || undefined);
    await ensureMasterData(clientId);
    const ctx: O.Ctx = {
      clientId, user: ws.user.email, role: ws.user.role,
      approvalLimit: ws.user.approvalLimit, canApprove: can(ws.user, "PAY_APPROVE"),
    };
    const ok = async (r: Record<string, unknown>) => {
      await logActivity(clientId, ws.user, action, String(r.message ?? ""));
      return NextResponse.json({ ...r, clientId, postedBy: ws.user.email });
    };

    switch (action) {
      /* ---------- General ledger ---------- */
      case "gl.journal": {
        requirePerm(ws.user, "GL_POST");
        const lines = (body.lines as { account: string; bp?: string; cc?: string; project?: string; desc?: string; dr?: number; cr?: number }[]) ?? [];
        const r = await postDocument({
          clientId, postDate: S(body.postDate) || undefined, module: "FI",
          docType: S(body.docType, "SA"), lines, createdBy: ws.user.email,
          reference: S(body.reference), currency: S(body.currency, "GHS"),
          reason: S(body.reason),
        });
        return ok({ ...r, message: `Journal ${r.docNo} posted in period ${r.period}` });
      }
      case "gl.reverse": {
        requirePerm(ws.user, "GL_REVERSE");
        return ok(await O.reverseTransaction(ctx, S(body.docNo), S(body.reason), S(body.reversalDate) || undefined));
      }
      case "gl.opening": {
        requirePerm(ws.user, "GL_POST");
        return ok(await O.postOpeningBalances(ctx, {
          asAtDate: S(body.asAtDate) || new Date().toISOString().slice(0, 10),
          lines: (body.lines as { account: string; bp?: string; debit?: number; credit?: number }[]) ?? [],
        }));
      }

      /* ---------- Sales & purchases ---------- */
      case "trade.create": {
        requirePerm(ws.user, S(body.docKind).startsWith("S") || S(body.docKind) === "QUOTE" ? "AR_MANAGE" : "AP_MANAGE");
        return ok(await O.createTradeDoc(ctx, {
          docKind: S(body.docKind), bp: S(body.bp), docDate: S(body.docDate) || undefined,
          dueDate: S(body.dueDate) || undefined, currency: S(body.currency) || undefined,
          costCenter: S(body.costCenter), project: S(body.project), narrative: S(body.narrative),
          lines: (body.lines as O.TradeLineIn[]) ?? [], autoPost: body.autoPost !== false,
        }));
      }
      case "trade.post": return ok(await O.postTradeDoc(ctx, S(body.docNo)));
      case "trade.convert": return ok(await O.convertTradeDoc(ctx, S(body.docNo), S(body.toKind)));

      /* ---------- Payment desk ---------- */
      case "pay.create": {
        requirePerm(ws.user, "PAY_CREATE");
        try {
          return ok(await O.createPayment(ctx, {
            direction: S(body.direction, "OUT") as "IN" | "OUT", bp: S(body.bp),
            bankCode: S(body.bankCode), payDate: S(body.payDate) || undefined,
            allocations: (body.allocations as { docNo: string; amount: number }[]) ?? [],
            whtCode: S(body.whtCode) || undefined,
            whtRateOverride: body.whtRateOverride !== undefined && body.whtRateOverride !== "" ? N(body.whtRateOverride) : undefined,
            method: S(body.method), narrative: S(body.narrative), currency: S(body.currency) || undefined,
            onAccountAmount: N(body.onAccountAmount),
          }));
        } catch (e) {
          if (e instanceof O.ApprovalRequiredError) {
            await logActivity(clientId, ws.user, "pay.queued", e.message);
            return NextResponse.json({ queued: true, approvalId: e.approvalId, message: e.message });
          }
          throw e;
        }
      }
      case "pay.direct": {
        requirePerm(ws.user, "PAY_CREATE");
        try {
          return ok(await O.directPayment(ctx, {
            direction: S(body.direction, "OUT") as "IN" | "OUT", categoryKey: S(body.categoryKey, "OTHER_DIRECT"),
            account: S(body.account), bankCode: S(body.bankCode), payDate: S(body.payDate) || undefined,
            amount: N(body.amount), bp: S(body.bp) || undefined, payeeName: S(body.payeeName) || undefined,
            narrative: S(body.narrative), currency: S(body.currency) || undefined,
          }));
        } catch (e) {
          if (e instanceof O.ApprovalRequiredError) {
            await logActivity(clientId, ws.user, "pay.direct.queued", e.message);
            return NextResponse.json({ queued: true, approvalId: e.approvalId, message: e.message });
          }
          throw e;
        }
      }
      case "pay.openItems":
        return NextResponse.json({ items: await O.openItems(clientId, S(body.bp) || undefined, (S(body.side) || undefined) as "AR" | "AP" | undefined) });
      case "trade.availableCredits":
        return NextResponse.json({ credits: await O.availableCredits(clientId, S(body.bp) || undefined, (S(body.side) || undefined) as "AR" | "AP" | undefined) });
      case "trade.applyCredit": {
        requirePerm(ws.user, "AR_MANAGE");
        return ok(await O.applyCreditNote(ctx, { creditDocNo: S(body.creditDocNo), invoiceDocNo: S(body.invoiceDocNo), amount: N(body.amount) }));
      }
      case "pay.listApprovals":
        return NextResponse.json({ approvals: await O.listApprovals(clientId, S(body.status, "PENDING")) });
      case "pay.decideApproval": {
        requirePerm(ws.user, "PAY_APPROVE");
        return ok(await O.decideApproval(ctx, Number(body.id), S(body.decision, "APPROVED") as "APPROVED" | "REJECTED", S(body.note)));
      }

      /* ---------- Banking ---------- */
      case "bank.import": {
        requirePerm(ws.user, "BANK_MANAGE");
        return ok(await O.importStatement(ctx, S(body.bankCode), S(body.csv)));
      }
      case "bank.autoMatch": return ok({ matched: await O.autoMatch(ctx, S(body.bankCode)), message: "Auto-matching complete" });
      case "bank.postLine": {
        requirePerm(ws.user, "BANK_MANAGE");
        return ok(await O.postStatementLine(ctx, Number(body.lineId), S(body.account), S(body.bp) || undefined, S(body.costCenter) || undefined));
      }
      case "bank.reconcile": {
        requirePerm(ws.user, "BANK_RECONCILE");
        return ok(await O.buildReconciliation(ctx, S(body.bankCode), S(body.periodCode)));
      }
      case "bank.updateRec":
        return ok(await O.updateReconciliation(ctx, S(body.recNo), {
          statementBalance: body.statementBalance !== undefined ? N(body.statementBalance) : undefined,
          notes: S(body.notes), status: S(body.status) || undefined,
        }));
      case "bank.addAccount": {
        requirePerm(ws.user, "MASTER_MANAGE");
        await db.insert(bankAccounts).values({
          clientId, bankCode: S(body.bankCode), bankName: S(body.bankName),
          accountNo: S(body.accountNo), glAccount: S(body.glAccount, "141000"),
          currency: S(body.currency, "GHS"), openingBalance: String(N(body.openingBalance)),
        }).onConflictDoNothing();
        return ok({ message: `Bank account ${S(body.bankCode)} added` });
      }

      /* ---------- Fixed assets ---------- */
      case "asset.create": {
        requirePerm(ws.user, "ASSET_MANAGE");
        return ok(await O.createAsset(ctx, {
          description: S(body.description), assetClass: S(body.assetClass), cost: N(body.cost),
          acquisitionDate: S(body.acquisitionDate) || undefined, residual: N(body.residual),
          usefulLife: body.usefulLife ? Number(body.usefulLife) : undefined,
          method: S(body.method) || undefined, costCenter: S(body.costCenter) || undefined,
          unitsTotal: N(body.unitsTotal), bankAccount: S(body.bankAccount) || undefined,
          capitalise: body.capitalise !== false,
        }));
      }
      case "asset.depreciate": return ok(await O.runDepreciation(ctx, S(body.periodCode)));
      case "asset.revalue": return ok(await O.revalueAsset(ctx, S(body.assetNo), N(body.newValue), S(body.date) || new Date().toISOString().slice(0, 10), S(body.reason, "Revaluation")));
      case "asset.dispose": return ok(await O.disposeAsset(ctx, S(body.assetNo), N(body.proceeds), S(body.date) || new Date().toISOString().slice(0, 10), S(body.bankAccount, "141000")));

      /* ---------- Prepayments & accruals ---------- */
      case "prepay.create":
        return ok(await O.createPrepayment(ctx, {
          kind: S(body.kind, "PREPAY"), description: S(body.description), totalAmount: N(body.totalAmount),
          expenseAccount: S(body.expenseAccount), balanceAccount: S(body.balanceAccount) || undefined,
          startPeriod: S(body.startPeriod), periods: Number(body.periods) || 12,
          costCenter: S(body.costCenter) || undefined, bp: S(body.bp) || undefined,
          postInitial: body.postInitial !== false, creditAccount: S(body.creditAccount) || undefined,
        }));
      case "prepay.run": return ok(await O.runAmortisation(ctx, S(body.periodCode)));

      /* ---------- Payroll ---------- */
      case "payroll.employee": {
        requirePerm(ws.user, "PAYROLL_MANAGE");
        return ok(await O.upsertEmployee(ctx, {
          empNo: S(body.empNo) || undefined, name: S(body.name), email: S(body.email), phone: S(body.phone),
          ssnit: S(body.ssnit), tin: S(body.tin),
          jobTitle: S(body.jobTitle), department: S(body.department), employmentType: S(body.employmentType, "PERMANENT"),
          costCenter: S(body.costCenter, "CC-ADM"),
          basicSalary: String(N(body.basicSalary)), currency: S(body.currency, "GHS"),
          isResident: body.isResident !== false,
          ssnitApplicable: body.ssnitApplicable !== false,
          tier3Employee: String(N(body.tier3Employee)), tier3Employer: String(N(body.tier3Employer)),
          bankCode: S(body.bankCode), bankAccount: S(body.bankAccount),
          startDate: S(body.startDate) || null, terminationDate: S(body.terminationDate) || null,
          active: body.active !== false,
        }));
      }
      case "payroll.terminate": {
        requirePerm(ws.user, "PAYROLL_MANAGE");
        return ok(await O.terminateEmployee(ctx, S(body.empNo), S(body.terminationDate) || new Date().toISOString().slice(0, 10)));
      }
      case "payroll.bulkImport": {
        requirePerm(ws.user, "PAYROLL_MANAGE");
        return ok(await O.bulkImportEmployees(ctx, S(body.csv)));
      }
      case "payroll.component": {
        requirePerm(ws.user, "PAYROLL_MANAGE");
        return ok(await O.upsertPayComponent(ctx, {
          id: body.id ? Number(body.id) : undefined, empNo: S(body.empNo) || "*", code: S(body.code),
          name: S(body.name), kind: S(body.kind, "ALLOWANCE"), basis: S(body.basis, "FIXED"),
          rate: N(body.rate), amount: N(body.amount), taxable: body.taxable !== false,
          periodCode: S(body.periodCode) || "*",
        }));
      }
      case "payroll.deleteComponent": return ok(await O.deletePayComponent(ctx, Number(body.id)));
      case "payroll.calculate":
        return NextResponse.json({ ...(await O.calculatePayroll(ctx, S(body.periodCode))), clientId });
      case "payroll.post": {
        requirePerm(ws.user, "PAYROLL_MANAGE");
        return ok(await O.postPayroll(ctx, S(body.periodCode)));
      }
      case "payroll.seedDemo": { await seedDemoEmployees(clientId); return ok({ message: "Sample employees added" }); }

      /* ---------- Inventory ---------- */
      case "inv.receive": return ok({ ...(await O.receiveStock(ctx, S(body.materialNo), N(body.qty), N(body.unitCost), S(body.reference, "MANUAL"), S(body.date) || undefined)), message: "Stock received" });
      case "inv.issue": return ok({ ...(await O.issueStock(ctx, S(body.materialNo), N(body.qty), S(body.reference, "MANUAL"), S(body.date) || undefined)), message: "Stock issued" });
      case "inv.nrv": return ok(await O.revalueInventoryToNRV(ctx, S(body.date) || undefined));
      case "inv.material": {
        requirePerm(ws.user, "MASTER_MANAGE");
        if (!S(body.materialNo)) throw new Error("An item code is required.");
        if (!S(body.description)) throw new Error("A description is required.");
        // AUDIT FIX 10 — negative prices/costs/reorder levels corrupt every
        // inventory valuation and COGS calculation downstream.
        for (const [field, label] of [["stdPrice", "Standard cost"], ["salesPrice", "Selling price"], ["nrv", "NRV"], ["reorderLevel", "Reorder level"]] as const) {
          if (body[field] !== undefined && body[field] !== "" && N(body[field]) < 0) {
            throw new Error(`${label} cannot be negative.`);
          }
        }
        await db.insert(materials).values({
          clientId, materialNo: S(body.materialNo), description: S(body.description),
          type: S(body.type, "Merchandise"), uom: S(body.uom, "EA"),
          stdPrice: String(N(body.stdPrice)), salesPrice: String(N(body.salesPrice)),
          nrv: String(N(body.nrv) || N(body.salesPrice)), reorderLevel: String(N(body.reorderLevel)),
        }).onConflictDoUpdate({
          target: [materials.clientId, materials.materialNo],
          set: { description: S(body.description), stdPrice: String(N(body.stdPrice)), salesPrice: String(N(body.salesPrice)), nrv: String(N(body.nrv) || N(body.salesPrice)) },
        });
        return ok({ message: `Item ${S(body.materialNo)} saved` });
      }
      case "inv.material.toggle": {
        requirePerm(ws.user, "MASTER_MANAGE");
        const [row] = await db.select().from(materials)
          .where(and(eq(materials.clientId, clientId), eq(materials.materialNo, S(body.materialNo))));
        if (!row) throw new Error(`Item ${S(body.materialNo)} not found.`);
        await db.update(materials).set({ active: !row.active })
          .where(and(eq(materials.clientId, clientId), eq(materials.materialNo, S(body.materialNo))));
        return ok({ message: `${row.description} ${row.active ? "deactivated" : "reactivated"}` });
      }

      /* ---------- Period control & close ---------- */
      case "period.extend": {
        requirePerm(ws.user, "PERIOD_CLOSE");
        const fromYear = Number(body.fromYear), toYear = Number(body.toYear);
        if (!Number.isFinite(fromYear) || !Number.isFinite(toYear)) throw new Error("Enter valid fiscal years.");
        if (toYear < fromYear) throw new Error("The ending year cannot be before the starting year.");
        if (toYear - fromYear > 50) throw new Error("Extend the calendar in spans of 50 years or fewer at a time.");
        const n = await ensurePeriods(clientId, fromYear, toYear, Number(body.fyStartMonth) || 1);
        return ok({ created: n, message: `Fiscal calendar extended — ${fromYear} to ${toYear} processed (${n} new period(s)).` });
      }
      case "period.status": {
        requirePerm(ws.user, "PERIOD_CLOSE");
        await setPeriodStatus(clientId, S(body.periodCode), S(body.status, "OPEN"), ws.user.email);
        return ok({ message: `Period ${S(body.periodCode)} set to ${S(body.status)}` });
      }
      case "close.month": {
        requirePerm(ws.user, "PERIOD_CLOSE");
        return ok(await O.monthEndClose(ctx, S(body.periodCode), { lock: B(body.lock) }));
      }
      case "close.year": {
        requirePerm(ws.user, "PERIOD_CLOSE");
        return ok(await O.yearEndClose(ctx, Number(body.fiscalYear)));
      }
      case "close.vat": return ok(await O.settleVatControl(ctx, S(body.periodCode)));
      case "close.fx": return ok(await O.revalueForeignCurrency(ctx, S(body.periodCode)));

      /* ---------- Master data ---------- */
      case "master.partner": {
        requirePerm(ws.user, "MASTER_MANAGE");
        const bpNo = S(body.bpNo) || (await nextNumber(clientId, "DOC", S(body.type) === "Customer" ? "C-" : "V-"));
        await db.insert(partners).values({
          clientId, bpNo, name: S(body.name), type: S(body.type, "Vendor"), tin: S(body.tin),
          isResident: body.isResident !== false, whtCode: S(body.whtCode),
          vatRegistered: B(body.vatRegistered), currency: S(body.currency, "GHS"),
          creditDays: Number(body.creditDays) || 30, email: S(body.email), phone: S(body.phone),
        }).onConflictDoUpdate({
          target: [partners.clientId, partners.bpNo],
          set: { name: S(body.name), tin: S(body.tin), isResident: body.isResident !== false, whtCode: S(body.whtCode), creditDays: Number(body.creditDays) || 30, email: S(body.email), phone: S(body.phone) },
        });
        return ok({ bpNo, message: `Business partner ${bpNo} saved` });
      }
      case "master.partner.toggle": {
        requirePerm(ws.user, "MASTER_MANAGE");
        const [row] = await db.select().from(partners)
          .where(and(eq(partners.clientId, clientId), eq(partners.bpNo, S(body.bpNo))));
        if (!row) throw new Error(`Business partner ${S(body.bpNo)} not found.`);
        await db.update(partners).set({ active: !row.active })
          .where(and(eq(partners.clientId, clientId), eq(partners.bpNo, S(body.bpNo))));
        return ok({ message: `${row.name} ${row.active ? "deactivated" : "reactivated"}` });
      }
      case "master.account": {
        requirePerm(ws.user, "MASTER_MANAGE");
        await db.insert(accounts).values({
          clientId, accountNo: S(body.accountNo), description: S(body.description),
          type: S(body.type, "Expense"), subType: S(body.subType, "OPERATING"),
          ifrsLine: S(body.ifrsLine, "Administrative expenses"), cashflowClass: S(body.cashflowClass, "OPERATING"),
        }).onConflictDoUpdate({
          target: [accounts.clientId, accounts.accountNo],
          set: { description: S(body.description), subType: S(body.subType), ifrsLine: S(body.ifrsLine) },
        });
        return ok({ message: `Account ${S(body.accountNo)} saved` });
      }
      case "master.account.toggle": {
        requirePerm(ws.user, "MASTER_MANAGE");
        const [row] = await db.select().from(accounts)
          .where(and(eq(accounts.clientId, clientId), eq(accounts.accountNo, S(body.accountNo))));
        if (!row) throw new Error(`Account ${S(body.accountNo)} not found.`);
        await db.update(accounts).set({ active: !row.active })
          .where(and(eq(accounts.clientId, clientId), eq(accounts.accountNo, S(body.accountNo))));
        return ok({ message: `Account ${row.accountNo} ${row.active ? "deactivated" : "reactivated"}` });
      }
      case "master.costCenter": {
        requirePerm(ws.user, "MASTER_MANAGE");
        await db.insert(costCenters).values({ clientId, ccCode: S(body.ccCode), ccName: S(body.ccName), ccType: S(body.ccType, "DEPT") }).onConflictDoNothing();
        return ok({ message: `Cost centre ${S(body.ccCode)} saved` });
      }
      case "master.project": {
        requirePerm(ws.user, "MASTER_MANAGE");
        const projectNo = S(body.projectNo) || (await nextNumber(clientId, "DOC", "PRJ-"));
        await db.insert(projects).values({
          clientId, projectNo, name: S(body.name), sector: S(body.sector, "GENERAL"),
          kind: S(body.kind, "CONTRACT"), customer: S(body.customer),
          contractValue: String(N(body.contractValue)), budgetCost: String(N(body.budgetCost)),
        }).onConflictDoNothing();
        return ok({ projectNo, message: `Project ${projectNo} created` });
      }

      /* ---------- Budgets & scenarios ---------- */
      case "budget.upsert": {
        requirePerm(ws.user, "BUDGET_MANAGE");
        const rows = (body.rows as { periodCode: string; account: string; amount: number; costCenter?: string }[]) ?? [];
        const scenario = S(body.scenario, "BASE");
        const year = Number(body.fiscalYear) || new Date().getUTCFullYear();
        if (rows.length) {
          const validAccounts = new Set((await db.select({ a: accounts.accountNo }).from(accounts)
            .where(eq(accounts.clientId, clientId))).map((r) => r.a));
          const bad = rows.find((r) => !validAccounts.has(r.account));
          if (bad) throw new Error(`Account ${bad.account} does not exist in the chart of accounts.`);
        }
        await db.delete(budgets).where(and(eq(budgets.clientId, clientId), eq(budgets.scenario, scenario), eq(budgets.fiscalYear, year)));
        if (rows.length) {
          await db.insert(budgets).values(rows.map((r) => ({
            clientId, scenario, fiscalYear: year, periodCode: r.periodCode,
            account: r.account, costCenter: r.costCenter ?? "", amount: String(N(r.amount)),
          })));
        }
        return ok({ message: `Budget scenario ${scenario} saved for ${year} (${rows.length} lines)` });
      }

      /* ---------- Practice management ---------- */
      case "eng.create": {
        requirePerm(ws.user, "ADVISORY_MANAGE");
        const tpl = templateByKey(S(body.templateKey));
        const engNo = await nextNumber(clientId, "ENG", "ENG-");
        await db.insert(engagements).values({
          clientId, engNo, serviceLine: S(body.serviceLine, tpl?.serviceLine ?? "ADVISORY"),
          title: S(body.title, tpl?.title ?? "Engagement"), templateKey: S(body.templateKey),
          periodCode: S(body.periodCode), assignedTo: S(body.assignedTo, ws.user.email),
          feeAmount: String(N(body.feeAmount)), chargeTo: S(body.chargeTo, "CLIENT"),
          dueDate: S(body.dueDate) || null,
          checklist: (tpl?.checklist ?? []).map((item) => ({ item, done: false, note: "" })),
        });
        return ok({ engNo, message: `Engagement ${engNo} opened` });
      }
      case "eng.update": {
        requirePerm(ws.user, "ADVISORY_MANAGE");
        await db.update(engagements).set({
          status: S(body.status) || undefined,
          quantitative: (body.quantitative as Record<string, number>) ?? undefined,
          qualitative: (body.qualitative as Record<string, string>) ?? undefined,
          checklist: (body.checklist as { item: string; done: boolean; note: string }[]) ?? undefined,
          conclusion: S(body.conclusion) || undefined,
        }).where(and(eq(engagements.clientId, clientId), eq(engagements.engNo, S(body.engNo))));
        return ok({ message: `Engagement ${S(body.engNo)} updated` });
      }
      case "eng.bill": {
        requirePerm(ws.user, "AR_MANAGE");
        return ok(await O.billClientForServices(ctx, {
          clientBpNo: S(body.bp), description: S(body.description, "Professional services"),
          amount: N(body.amount), taxCode: S(body.taxCode, "STD"),
        }));
      }

      /* ---------- Tax configuration ---------- */
      case "tax.update": {
        requirePerm(ws.user, "TAX_MANAGE");
        // AUDIT FIX 11 — an out-of-range rate (negative, or an implausible
        // percentage) would silently invert or inflate every computation
        // that reads this rate (VAT, WHT, PAYE bands, CIT).
        const rate = N(body.rate);
        if (!Number.isFinite(rate) || rate < 0 || rate > 100) {
          throw new Error("The rate must be a percentage between 0 and 100.");
        }
        if (S(body.effectiveTo) && S(body.effectiveFrom) && S(body.effectiveTo) < S(body.effectiveFrom)) {
          throw new Error("The effective-to date cannot be before the effective-from date.");
        }
        await db.update(taxRates).set({
          rate: String(rate), name: S(body.name) || undefined,
          effectiveFrom: S(body.effectiveFrom) || undefined,
          effectiveTo: S(body.effectiveTo) || null, note: S(body.note),
        }).where(eq(taxRates.id, Number(body.id)));
        return ok({ message: `Tax rate updated to ${rate}%` });
      }
      case "tax.create": {
        requirePerm(ws.user, "TAX_MANAGE");
        const newRate = N(body.rate);
        if (!Number.isFinite(newRate) || newRate < 0 || newRate > 100) {
          throw new Error("The rate must be a percentage between 0 and 100.");
        }
        if (!S(body.code)) throw new Error("A tax code is required.");
        if (!S(body.name)) throw new Error("A description is required.");
        await db.insert(taxRates).values({
          scope: S(body.scope, "WHT"), code: S(body.code), name: S(body.name),
          rate: String(newRate), bandFrom: String(N(body.bandFrom)), bandTo: String(N(body.bandTo)),
          residency: S(body.residency, "ANY"), sector: S(body.sector, "ALL"), basis: S(body.basis),
          effectiveFrom: S(body.effectiveFrom) || new Date().toISOString().slice(0, 10),
          note: S(body.note), seq: Number(body.seq) || 0,
        });
        return ok({ message: `Tax rate ${S(body.code)} created` });
      }

      /* ---------- FX ---------- */
      case "fx.refresh": {
        const r = await refreshRates(true);
        return ok({ ...r, message: `Exchange rates refreshed from ${r.source} (${r.count} currencies)` });
      }

      /* ---------- Attachments ---------- */
      case "attach.upload": {
        const base64 = S(body.data);
        const sizeBytes = Math.ceil((base64.length * 3) / 4);
        if (sizeBytes > 4 * 1024 * 1024) {
          throw new Error("Attachments are limited to 4 MB per file.");
        }
        if (!base64) throw new Error("No file content received.");
        const [row] = await db.insert(attachments).values({
          clientId, refType: S(body.refType, "TRADE_DOC"), refNo: S(body.refNo),
          fileName: S(body.fileName, "attachment"), mimeType: S(body.mimeType, "application/octet-stream"),
          sizeBytes, data: base64, note: S(body.note), uploadedBy: ws.user.email,
        }).returning({ id: attachments.id });
        await logActivity(clientId, ws.user, action, `${S(body.fileName)} → ${S(body.refType)} ${S(body.refNo)}`);
        return NextResponse.json({ id: row.id, message: `${S(body.fileName)} attached` });
      }
      case "attach.list": {
        const rows = await db.select({
          id: attachments.id, refType: attachments.refType, refNo: attachments.refNo,
          fileName: attachments.fileName, mimeType: attachments.mimeType, sizeBytes: attachments.sizeBytes,
          note: attachments.note, uploadedBy: attachments.uploadedBy, uploadedAt: attachments.uploadedAt,
        }).from(attachments).where(and(
          eq(attachments.clientId, clientId),
          eq(attachments.refType, S(body.refType, "TRADE_DOC")),
          eq(attachments.refNo, S(body.refNo)),
        ));
        return NextResponse.json({ attachments: rows });
      }
      case "attach.delete": {
        await db.delete(attachments).where(and(eq(attachments.clientId, clientId), eq(attachments.id, Number(body.id))));
        return ok({ message: "Attachment removed" });
      }

      /* ---------- Demo ---------- */
      case "demo.seed": return ok(await seedDemoTransactions(ctx));

      default:
        return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (e) {
    const status = e instanceof AuthError ? e.status
      : e instanceof PeriodError || e instanceof PostingError || e instanceof O.OpsError ? 400 : 400;
    return NextResponse.json({ error: (e as Error).message }, { status });
  }
}

/** Builds a realistic demonstration dataset inside any workspace. */
