import { NextRequest, NextResponse } from "next/server";
import { AuthError, requireWorkspace } from "@/lib/auth";
import * as R from "@/lib/reports";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { clientId } = await requireWorkspace();
    const q = req.nextUrl.searchParams;
    const f: R.Filter = {
      from: q.get("from") || undefined,
      to: q.get("to") || undefined,
      costCenter: q.get("costCenter") || undefined,
      project: q.get("project") || undefined,
      bp: q.get("bp") || undefined,
    };
    const view = q.get("view") || "all";

    if (view === "ledger") {
      return NextResponse.json(await R.generalLedger(clientId, q.get("account") || "", f));
    }
    if (view === "budget") {
      return NextResponse.json(await R.budgetVsActual(clientId, q.get("scenario") || "BASE", Number(q.get("year")) || new Date().getUTCFullYear(), f));
    }
    if (view === "journal") {
      return NextResponse.json({ journal: await R.journal(clientId, f, 2000) });
    }
    if (view === "vat") {
      return NextResponse.json(await R.vatSchedule(clientId, f));
    }
    if (view === "wht") {
      return NextResponse.json(await R.whtSchedule(clientId, f));
    }

    const [tb, is, bs, cf, soc, arAge, apAge, kpi, reg, inv, pay, cc, proj, mod, jrn, vat, wht] = await Promise.all([
      R.trialBalance(clientId, f), R.incomeStatement(clientId, f), R.balanceSheet(clientId, f),
      R.cashFlow(clientId, f), R.changesInEquity(clientId, f),
      R.ageing(clientId, "AR"), R.ageing(clientId, "AP"), R.kpis(clientId, f),
      R.assetRegister(clientId), R.inventoryValuation(clientId), R.payrollRegister(clientId),
      R.dimensionReport(clientId, "costCenter", f), R.dimensionReport(clientId, "project", f),
      R.dimensionReport(clientId, "module", f), R.journal(clientId, f, 600),
      R.vatSchedule(clientId, f), R.whtSchedule(clientId, f),
    ]);

    return NextResponse.json({
      clientId, filter: f, trialBalance: tb, incomeStatement: is, balanceSheet: bs,
      cashFlow: cf, changesInEquity: soc, arAgeing: arAge, apAgeing: apAge, kpis: kpi,
      assetRegister: reg, inventory: inv, payroll: pay, byCostCenter: cc, byProject: proj,
      byModule: mod, journal: jrn, vatSchedule: vat, whtSchedule: wht,
    });
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: e instanceof AuthError ? e.status : 500 });
  }
}
