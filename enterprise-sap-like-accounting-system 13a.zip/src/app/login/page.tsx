"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { BpzMark } from "@/components/ui";

type Stage = "login" | "reset" | "forgot" | "resetToken";

function LoginInner() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [stage, setStage] = useState<Stage>("login");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [resetLink, setResetLink] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const e = params.get("email");
    if (e) setEmail(e);
    if (params.get("ws")) setInfo("Your BPZ workspace is ready. Sign in with the temporary password supplied by your account manager.");
    const token = params.get("resetToken");
    if (token) { setResetToken(token); setStage("resetToken"); setInfo("Choose a new password to regain access to your account."); }
  }, [params]);

  async function doLogin(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", email, password }),
      });
      const d = await res.json();
      if (!res.ok) { setError(d.error ?? "Sign-in failed"); return; }
      if (d.mustChangePassword) {
        setStage("reset");
        setInfo("This is your first sign-in. Please choose a permanent password to unlock your workspace.");
        return;
      }
      router.replace("/"); router.refresh();
    } finally { setBusy(false); }
  }

  async function doReset(e: React.FormEvent) {
    e.preventDefault();
    if (newPw !== confirmPw) { setError("The two passwords do not match."); return; }
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "changePassword", newPassword: newPw }),
      });
      const d = await res.json();
      if (!res.ok) { setError(d.error ?? "Could not set the password"); return; }
      router.replace("/"); router.refresh();
    } finally { setBusy(false); }
  }

  async function doForgot(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(""); setResetLink("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "forgotPassword", email }),
      });
      const d = await res.json();
      if (!res.ok) { setError(d.error ?? "Could not process the request"); return; }
      setInfo(d.message);
      if (d.resetLink) setResetLink(d.resetLink);
    } finally { setBusy(false); }
  }

  async function doResetWithToken(e: React.FormEvent) {
    e.preventDefault();
    if (newPw !== confirmPw) { setError("The two passwords do not match."); return; }
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "resetPasswordWithToken", token: resetToken, newPassword: newPw }),
      });
      const d = await res.json();
      if (!res.ok) { setError(d.error ?? "Could not reset the password"); return; }
      setStage("login"); setInfo(d.message); setNewPw(""); setConfirmPw("");
    } finally { setBusy(false); }
  }

  const titles: Record<Stage, { h: string; sub: string }> = {
    login: { h: "Sign in to your workspace", sub: "Enter the credentials issued to you by BPZ." },
    reset: { h: "Set your permanent password", sub: "Minimum 8 characters, including a letter and a number." },
    forgot: { h: "Reset your password", sub: "Enter your account email and we'll issue a secure reset link." },
    resetToken: { h: "Choose a new password", sub: "This link is single-use and expires one hour after it was issued." },
  };

  return (
    <div className="bpz-gradient flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-5xl overflow-hidden rounded-2xl bg-white shadow-2xl md:grid md:grid-cols-[1.05fr_1fr]">
        {/* Brand panel */}
        <div className="bpz-gradient relative hidden flex-col justify-between p-9 text-white md:flex">
          <div>
            <div className="flex items-center gap-3">
              <BpzMark size={48} />
              <div>
                <p className="font-display text-xl font-bold leading-tight">BPZ</p>
                <p className="text-[15.5px] uppercase tracking-[0.08em] text-[var(--gold-400)]">Chartered Accountants &amp; Advisors</p>
              </div>
            </div>
            <div className="bpz-gold-rule mt-6 h-[3px] w-28 rounded" />
            <h2 className="font-display mt-6 text-2xl font-bold leading-snug">
              Enterprise Financial<br />Platform
            </h2>
            <p className="mt-3 max-w-sm text-[15.5px] leading-relaxed text-white/90">
              IFRS-compliant accounting, payroll, tax and advisory — tailored to every sector
              of the Ghanaian economy, with live Bank of Ghana exchange rates.
            </p>
          </div>
          <ul className="mt-8 grid grid-cols-2 gap-x-4 gap-y-2.5 text-[16px] text-white/92">
            {["Universal Journal (ACDOCA)", "Fiscal years & period control", "Multi-currency with FX revaluation",
              "Payment desk with withholding tax", "Bank import & reconciliation", "Fixed assets & depreciation",
              "Payroll under Act 1178", "Budgets, forecasts & scenarios", "Full IFRS statement set", "Excel export"]
              .map((f) => <li key={f} className="flex gap-1.5"><span className="text-[var(--gold-400)]">▸</span>{f}</li>)}
          </ul>
          <p className="mt-8 text-[13px] text-white/90">
            Accounting · Bookkeeping · Payroll · Tax Planning · Business Advisory
          </p>
        </div>

        {/* Form panel */}
        <div className="p-8 md:p-10">
          <div className="mb-6 md:hidden">
            <BpzMark size={44} dark />
            <p className="font-display mt-2 text-lg font-bold text-[var(--bpz-900)]">BPZ Enterprise Platform</p>
          </div>

          <h1 className="font-display text-lg font-bold text-[var(--bpz-900)]">{titles[stage].h}</h1>
          <p className="mt-1 text-[16px] text-slate-600">{titles[stage].sub}</p>
          <div className="bpz-gold-rule mt-3 h-[2px] w-20 rounded" />

          {error && <div className="mt-4 rounded-lg bg-rose-50 px-3 py-2 text-[16px] text-rose-700">✕ {error}</div>}
          {info && !error && <div className="mt-4 rounded-lg bg-[var(--bpz-100)] px-3 py-2 text-[16px] text-[var(--bpz-800)]">ℹ {info}</div>}
          {resetLink && (
            <div className="mt-2 rounded-lg border border-dashed border-[var(--gold-500)] bg-[var(--gold-100)] px-3 py-2 text-[14px] text-[var(--bpz-900)]">
              No email service is configured for this deployment, so here is your one-time reset link:
              <br /><a href={resetLink} className="break-all font-mono text-[var(--bpz-700)] underline">{resetLink}</a>
            </div>
          )}

          {stage === "login" && (
            <form onSubmit={doLogin} className="mt-5 space-y-4">
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">Email address</span>
                <input type="email" required autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="owner@bpz.com.gh"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)] focus:ring-2 focus:ring-[var(--bpz-500)]/15" />
              </label>
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">Password</span>
                <input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)] focus:ring-2 focus:ring-[var(--bpz-500)]/15" />
              </label>
              <button type="submit" disabled={busy}
                className="w-full rounded-lg bg-[var(--bpz-800)] py-2.5 text-[15.5px] font-semibold text-white transition hover:bg-[var(--bpz-700)] disabled:opacity-50">
                {busy ? "Signing in…" : "Sign in"}
              </button>
              <button type="button" onClick={() => { setStage("forgot"); setError(""); setInfo(""); }}
                className="w-full text-center text-[16px] text-[var(--bpz-700)] hover:underline">
                Forgot your password?
              </button>
            </form>
          )}

          {stage === "reset" && (
            <form onSubmit={doReset} className="mt-5 space-y-4">
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">New password</span>
                <input type="password" required minLength={8} value={newPw} onChange={(e) => setNewPw(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)]" />
              </label>
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">Confirm new password</span>
                <input type="password" required minLength={8} value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)]" />
              </label>
              <button type="submit" disabled={busy}
                className="w-full rounded-lg bg-[var(--gold-500)] py-2.5 text-[15.5px] font-bold text-[var(--bpz-900)] transition hover:bg-[var(--gold-400)] disabled:opacity-50">
                {busy ? "Saving…" : "Set password & enter workspace"}
              </button>
            </form>
          )}

          {stage === "forgot" && (
            <form onSubmit={doForgot} className="mt-5 space-y-4">
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">Account email</span>
                <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)]" />
              </label>
              <button type="submit" disabled={busy}
                className="w-full rounded-lg bg-[var(--bpz-800)] py-2.5 text-[15.5px] font-semibold text-white transition hover:bg-[var(--bpz-700)] disabled:opacity-50">
                {busy ? "Sending…" : "Send reset link"}
              </button>
              <button type="button" onClick={() => { setStage("login"); setError(""); setInfo(""); setResetLink(""); }}
                className="w-full text-center text-[16px] text-[var(--bpz-700)] hover:underline">
                Back to sign in
              </button>
            </form>
          )}

          {stage === "resetToken" && (
            <form onSubmit={doResetWithToken} className="mt-5 space-y-4">
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">New password</span>
                <input type="password" required minLength={8} value={newPw} onChange={(e) => setNewPw(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)]" />
              </label>
              <label className="block">
                <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">Confirm new password</span>
                <input type="password" required minLength={8} value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-[15.5px] focus:border-[var(--bpz-500)]" />
              </label>
              <button type="submit" disabled={busy}
                className="w-full rounded-lg bg-[var(--gold-500)] py-2.5 text-[15.5px] font-bold text-[var(--bpz-900)] transition hover:bg-[var(--gold-400)] disabled:opacity-50">
                {busy ? "Saving…" : "Reset password"}
              </button>
            </form>
          )}

          <div className="mt-6 space-y-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-[14px] leading-relaxed text-slate-600">
            <p><b className="text-slate-700">Owner access:</b> owner@bpz.com.gh / Bpz@Owner2026</p>
            <p><b className="text-slate-700">Try the demo client workspace:</b> demo@bpz.com.gh / Demo@12345</p>
            <p>New client logins are issued from the Owner Console with a one-time temporary password.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="bpz-gradient min-h-screen" />}>
      <LoginInner />
    </Suspense>
  );
}
