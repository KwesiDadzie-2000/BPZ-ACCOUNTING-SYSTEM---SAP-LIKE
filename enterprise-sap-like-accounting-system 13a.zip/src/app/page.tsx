"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Badge, BpzMark, Button, Card, Empty, Field, Input, Modal, SectionTitle, Select,
  Stat, Table, TextArea, Toast, money,
} from "@/components/ui";
import { Dashboard, TradeDesk, PaymentDesk, Banking, Assets, Payroll, type WS, type RPT, type Post } from "@/components/panels";
import { GeneralLedger, CloseDesk, Reports, TaxCentre, Practice } from "@/components/panels2";

/* eslint-disable @typescript-eslint/no-explicit-any */
const NAV: { group: string; items: [string, string][] }[] = [
  { group: "Overview", items: [["dash", "📊 Dashboard"]] },
  { group: "Transact", items: [["sales", "🧾 Sales & AR"], ["purch", "📦 Purchases & AP"], ["payments", "💳 Payment Desk"], ["banking", "🏦 Banking & Rec"]] },
  { group: "Accounting", items: [["gl", "📒 General Ledger"], ["assets", "🏭 Fixed Assets"], ["prepay", "🗓 Prepayments"], ["inventory", "📦 Inventory"], ["close", "📅 Period Close"]] },
  { group: "People & Tax", items: [["payroll", "👥 Payroll"], ["tax", "🧮 Tax Centre"]] },
  { group: "Insight", items: [["reports", "📈 Reports"], ["budget", "🎯 Budget & Forecast"]] },
  { group: "Practice", items: [["practice", "💼 Service Delivery"], ["master", "🗂 Master Data"]] },
  { group: "Administration", items: [["owner", "🏛 Owner Console"], ["profile", "👤 My Profile"], ["guide", "📖 Setup Guide"], ["handbook", "📚 User Handbook"]] },
];

export default function Home() {
  const router = useRouter();
  const [tab, setTab] = useState("dash");
  const [ws, setWs] = useState<WS>(null);
  const [rpt, setRpt] = useState<RPT>(null);
  const [admin, setAdmin] = useState<any>(null);
  const [ledger, setLedger] = useState<any>(null);
  const [filter, setFilter] = useState<any>({});
  const [toast, setToast] = useState<{ kind: "ok" | "err" | "info"; msg: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);
  const [syncing, setSyncing] = useState(false);

  const qs = (f: any) => new URLSearchParams(Object.entries(f).filter(([, v]) => v) as [string, string][]).toString();

  const load = useCallback(async (f = filter) => {
    setSyncing(true);
    try {
      const me = await fetch("/api/auth").then((r) => r.json()).catch(() => ({ user: null }));
      if (!me.user) { router.replace("/login"); return; }
      if (me.user.mustChangePassword) { router.replace("/login"); return; }
      const [w, r] = await Promise.all([
        fetch("/api/workspace").then((x) => x.json()),
        fetch(`/api/reports?${qs(f)}`).then((x) => x.json()),
      ]);
      if (!w.error) setWs(w);
      if (!r.error) setRpt(r);
      if (me.user.role === "OWNER") {
        const a = await fetch("/api/admin").then((x) => x.json()).catch(() => null);
        if (a && !a.error) setAdmin(a);
      }
      setReady(true);
      setLastSynced(new Date());
    } finally {
      setSyncing(false);
    }
  }, [filter, router]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 6000); return () => clearTimeout(t); }, [toast]);

  // Multi-device / multi-user sync: this app has no websocket layer, so two
  // people working in the same workspace from different devices rely on
  // polling plus "refresh on return" to see each other's work promptly.
  // Polling pauses while a mutation is in flight (`busy`) or the tab is
  // hidden, so it never fights with an in-progress edit or wastes requests
  // on a backgrounded tab.
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState === "visible" && !busy) void load();
    }, 25_000);
    return () => clearInterval(interval);
  }, [load, busy]);

  useEffect(() => {
    const onFocusOrVisible = () => {
      if (document.visibilityState !== "visible") return;
      // Only resync if it has been a few seconds since the last sync, so
      // rapid tab-switching doesn't trigger a storm of requests.
      if (!lastSynced || Date.now() - lastSynced.getTime() > 4000) void load();
    };
    document.addEventListener("visibilitychange", onFocusOrVisible);
    window.addEventListener("focus", onFocusOrVisible);
    return () => {
      document.removeEventListener("visibilitychange", onFocusOrVisible);
      window.removeEventListener("focus", onFocusOrVisible);
    };
  }, [load, lastSynced]);

  const call = useCallback(async (url: string, payload: Record<string, unknown>) => {
    setBusy(true);
    try {
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const d = await res.json();
      if (!res.ok) { setToast({ kind: "err", msg: d.error ?? "The action could not be completed." }); return { error: d.error }; }
      if (d.message) setToast({ kind: "ok", msg: `${d.message}${d.docNo ? ` · document ${d.docNo}` : ""}` });
      await load();
      return d;
    } catch (e) {
      setToast({ kind: "err", msg: (e as Error).message }); return { error: (e as Error).message };
    } finally { setBusy(false); }
  }, [load]);

  const post: Post = useCallback((action, payload = {}) => call("/api/txn", { action, ...payload }), [call]);
  const adminPost = useCallback((action: string, payload: Record<string, unknown> = {}) => call("/api/admin", { action, ...payload }), [call]);

  const drill = useCallback(async (account: string) => {
    const d = await fetch(`/api/reports?view=ledger&account=${account}&${qs(filter)}`).then((r) => r.json());
    setLedger(d); setTab("reports");
    setToast({ kind: "info", msg: `Opened ledger for account ${account} — see the Account Ledger tab.` });
  }, [filter]);

  const applyFilter = (f: any) => { setFilter(f); void load(f); };

  if (!ready || !ws) {
    return <div className="bpz-gradient flex min-h-screen items-center justify-center text-[15.5px] text-white/90">Loading your BPZ workspace…</div>;
  }

  const user = ws.user;
  const isOwner = user?.role === "OWNER";
  const client = ws.client;
  const nav = NAV.map((g) => ({ ...g, items: g.items.filter(([k]) => (k !== "owner" || isOwner)) })).filter((g) => g.items.length);

  return (
    <div className="min-h-screen bg-slate-100">
      {/* ================= HEADER ================= */}
      <header className="no-print sticky top-0 z-40 bpz-gradient text-white shadow-lg">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3 px-4 py-2.5">
          <button className="rounded-lg px-2 py-1 text-white/92 hover:bg-white/10 lg:hidden" onClick={() => setNavOpen((v) => !v)}>☰</button>
          <div className="flex items-center gap-2.5">
            <BpzMark size={36} />
            <div className="leading-tight">
              <p className="font-display text-[16px] font-bold">BPZ Enterprise Platform</p>
              <p className="text-[13px] text-white/90">Accounting · Payroll · Tax · Advisory</p>
            </div>
          </div>

          <div className="ml-2 hidden min-w-0 border-l border-white/15 pl-3 md:block">
            <p className="truncate text-[15px] font-semibold">{client?.name}</p>
            <p className="truncate text-[13px] text-white/90">
              {client?.isFirm ? "Firm workspace" : "Client workspace"} · {client?.sector} · {client?.currency}
            </p>
          </div>

          <div className="ml-auto flex flex-wrap items-center gap-2">
            {user?.isFirmStaff && (ws.allClients ?? []).length > 0 && (
              <select value={ws.clientId} disabled={busy}
                onChange={(e) => call("/api/auth", { action: "switchWorkspace", clientId: e.target.value })}
                className="max-w-[230px] rounded-lg border border-white/20 bg-white/10 px-2 py-1.5 text-[16px] text-white outline-none [&>option]:text-slate-800">
                {ws.allClients.map((c: any) => (
                  <option key={c.id} value={c.id}>{c.isFirm ? "★ " : ""}{c.name}{c.active ? "" : " (suspended)"}</option>
                ))}
              </select>
            )}
            <div className="hidden items-center gap-2 rounded-lg bg-white/10 px-2.5 py-1 text-[14px] sm:flex">
              <Badge tone={isOwner ? "gold" : "blue"}>{user?.role?.replace("_", " ")}</Badge>
              <span className="max-w-[160px] truncate text-white/92">{user?.email}</span>
            </div>
            <SyncIndicator lastSynced={lastSynced} syncing={syncing} onRefresh={() => load()} />
            <a href={`/api/export?${qs(filter)}`} className="rounded-lg bg-[var(--gold-500)] px-2.5 py-1.5 text-[16px] font-semibold text-[var(--bpz-900)] hover:bg-[var(--gold-400)]">⬇ Excel</a>
            <button onClick={() => call("/api/auth", { action: "logout" }).then(() => router.replace("/login"))}
              className="rounded-lg border border-white/25 px-2.5 py-1.5 text-[16px] hover:bg-white/10">Sign out</button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1600px] gap-4 px-4 py-4">
        {/* ================= SIDEBAR ================= */}
        <aside className={`no-print ${navOpen ? "block" : "hidden"} w-56 shrink-0 lg:block`}>
          <nav className="sticky top-[74px] space-y-3">
            {nav.map((g) => (
              <div key={g.group}>
                <p className="mb-1 px-2 text-[16px] font-bold uppercase tracking-[0.12em] text-slate-600">{g.group}</p>
                <div className="space-y-0.5">
                  {g.items.map(([k, l]) => (
                    <button key={k} onClick={() => { setTab(k); setNavOpen(false); }}
                      className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-[15px] font-medium transition ${
                        tab === k ? "bg-[var(--bpz-800)] text-white shadow-sm" : "text-slate-600 hover:bg-white hover:text-[var(--bpz-800)]"}`}>
                      {l}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </nav>
        </aside>

        {/* ================= MAIN ================= */}
        <main className="min-w-0 flex-1 pb-12">
          {tab === "dash" && <Dashboard ws={ws} rpt={rpt} post={post} busy={busy} go={setTab} />}
          {tab === "sales" && <TradeDesk ws={ws} post={post} busy={busy} side="AR" />}
          {tab === "purch" && <TradeDesk ws={ws} post={post} busy={busy} side="AP" />}
          {tab === "payments" && <PaymentDesk ws={ws} post={post} busy={busy} />}
          {tab === "banking" && <Banking ws={ws} post={post} busy={busy} />}
          {tab === "gl" && <GeneralLedger ws={ws} rpt={rpt} post={post} busy={busy} onDrill={drill} />}
          {tab === "assets" && <Assets ws={ws} rpt={rpt} post={post} busy={busy} />}
          {tab === "payroll" && <Payroll ws={ws} post={post} busy={busy} />}
          {tab === "close" && <CloseDesk ws={ws} post={post} busy={busy} />}
          {tab === "tax" && <TaxCentre ws={ws} post={post} busy={busy} />}
          {tab === "practice" && <Practice ws={ws} post={post} busy={busy} />}
          {tab === "reports" && <Reports ws={ws} rpt={rpt} filter={filter} setFilter={applyFilter} ledger={ledger} onDrill={drill} exportUrl={`/api/export?${qs(filter)}`} />}
          {tab === "prepay" && <Prepayments ws={ws} post={post} busy={busy} />}
          {tab === "inventory" && <Inventory ws={ws} rpt={rpt} post={post} busy={busy} />}
          {tab === "budget" && <Budgets ws={ws} post={post} busy={busy} />}
          {tab === "master" && <MasterData ws={ws} post={post} busy={busy} />}
          {tab === "owner" && isOwner && <OwnerConsole admin={admin} ws={ws} adminPost={adminPost} busy={busy} setToast={setToast} />}
          {tab === "profile" && <Profile user={user} call={call} busy={busy} isOwner={isOwner} adminPost={adminPost} />}
          {tab === "guide" && <SetupGuide ws={ws} go={setTab} />}
          {tab === "handbook" && <Handbook ws={ws} go={setTab} />}
        </main>
      </div>

      <Toast toast={toast} />
    </div>
  );
}

/* ==================== PREPAYMENTS ==================== */
/**
 * Shows every user, on every device, that their screen reflects the shared
 * database and not a stale local copy — and gives them a one-click way to
 * force a resync if they suspect a colleague has just posted something.
 */
function SyncIndicator({ lastSynced, syncing, onRefresh }: { lastSynced: Date | null; syncing: boolean; onRefresh: () => void }) {
  const [, forceTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const seconds = lastSynced ? Math.max(0, Math.floor((Date.now() - lastSynced.getTime()) / 1000)) : null;
  const label = seconds === null ? "Syncing…" : seconds < 3 ? "Synced just now" : seconds < 60 ? `Synced ${seconds}s ago` : `Synced ${Math.floor(seconds / 60)}m ago`;
  return (
    <button onClick={onRefresh} title="Click to sync now — picks up anything a colleague posted on another device"
      className="hidden items-center gap-1.5 rounded-lg bg-white/10 px-2.5 py-1 text-[14px] text-white/92 hover:bg-white/20 md:flex">
      <span className={`inline-block h-1.5 w-1.5 rounded-full ${syncing ? "animate-pulse bg-[var(--gold-400)]" : "bg-emerald-400"}`} />
      {label}
    </button>
  );
}

function Prepayments({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [period, setPeriod] = useState(ws?.periods?.[0]?.code ?? "");
  return (
    <div className="space-y-5">
      <SectionTitle hint="Prepayments, accruals and deferred income are scheduled once and released automatically each period.">
        Prepayments, Accruals &amp; Deferred Income
      </SectionTitle>
      <div className="grid gap-4 xl:grid-cols-[400px_1fr]">
        <Card title="Create a schedule">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("prepay.create", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Type"><Select name="kind" defaultValue="PREPAY">
              <option value="PREPAY">Prepayment (expense paid in advance)</option>
              <option value="ACCRUAL">Accrual (expense incurred, not yet billed)</option>
              <option value="DEFERRED">Deferred income (revenue received in advance)</option></Select></Field>
            <Field label="Description"><Input name="description" required placeholder="Annual insurance premium" /></Field>
            <Field label="Total amount"><Input name="totalAmount" type="number" step="0.01" required /></Field>
            <Field label="Expense / revenue account"><Select name="expenseAccount" required defaultValue="710400">
              {(ws?.accounts ?? []).filter((a: any) => ["Expense", "Revenue"].includes(a.type)).map((a: any) =>
                <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}</Select></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Start period"><Select name="startPeriod" required defaultValue={period}>
                {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select></Field>
              <Field label="Number of periods"><Input name="periods" type="number" defaultValue={12} /></Field>
            </div>
            <Field label="Cost centre"><Select name="costCenter" defaultValue="CC-ADM">
              {(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode} · {c.ccName}</option>)}</Select></Field>
            <Button type="submit" variant="gold" disabled={busy}>Create schedule</Button>
          </form>
        </Card>
        <div className="space-y-4">
          <Card title="Run amortisation" subtitle="Releases every schedule due in the chosen period. Safe to re-run.">
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Period"><Select value={period} onChange={(e) => setPeriod(e.target.value)} className="w-40">
                {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code} ({p.status})</option>)}</Select></Field>
              <Button variant="gold" disabled={busy} onClick={() => post("prepay.run", { periodCode: period })}>Run amortisation</Button>
            </div>
          </Card>
          <Card title="Schedules">
            <Table cols={["Ref", "Type", "Description", { h: "Total", align: "right" }, { h: "Amortised", align: "right" }, { h: "Balance", align: "right" }, { h: "Per period", align: "right" }, "Start", "Periods", "Last run", "Status"]}
              rows={(ws?.prepayments ?? []).map((p: any) => [
                p.prepayNo, <Badge key="k" tone="blue">{p.kind}</Badge>, p.description,
                money(p.totalAmount), money(p.amortised), money(Number(p.totalAmount) - Number(p.amortised)),
                money(p.perPeriod), p.startPeriod, p.periods, p.lastRunPeriod || "—",
                <Badge key="s" tone={p.status === "ACTIVE" ? "green" : "slate"}>{p.status}</Badge>])}
              empty="No schedules created" />
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ==================== INVENTORY ==================== */
function Inventory({ ws, rpt, post, busy }: { ws: WS; rpt: RPT; post: Post; busy: boolean }) {
  const inv = rpt?.inventory ?? [];
  const totCost = inv.reduce((s: number, m: any) => s + m.cost, 0);
  const totWd = inv.reduce((s: number, m: any) => s + m.writedown, 0);
  return (
    <div className="space-y-5">
      <SectionTitle hint="Perpetual weighted-average valuation with automatic cost of sales posting and IAS 2 net realisable value testing.">
        Inventory Management
      </SectionTitle>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Stock items" value={String(inv.length)} />
        <Stat label="Inventory at cost" value={money(totCost)} tone="blue" />
        <Stat label="NRV write-down required" value={money(totWd)} tone={totWd > 0 ? "red" : "green"} />
        <Stat label="Items below reorder level" value={String(inv.filter((m: any) => m.belowReorder).length)} tone="gold" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Add / update an item">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("inv.material", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Item code"><Input name="materialNo" required /></Field>
            <Field label="Description"><Input name="description" required /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Type"><Select name="type" defaultValue="Merchandise">
                {["Raw Material", "Work in Progress", "Finished Good", "Merchandise", "Consumable", "Spare Part"].map((t) => <option key={t}>{t}</option>)}</Select></Field>
              <Field label="Unit of measure"><Input name="uom" defaultValue="EA" /></Field>
              <Field label="Standard cost"><Input name="stdPrice" type="number" step="0.01" defaultValue={0} /></Field>
              <Field label="Selling price"><Input name="salesPrice" type="number" step="0.01" defaultValue={0} /></Field>
              <Field label="NRV per unit"><Input name="nrv" type="number" step="0.01" defaultValue={0} /></Field>
              <Field label="Reorder level"><Input name="reorderLevel" type="number" step="0.01" defaultValue={0} /></Field>
            </div>
            <Button type="submit" variant="gold" disabled={busy}>Save item</Button>
          </form>
        </Card>
        <Card title="Stock movement" className="lg:col-span-2">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post(String(f.get("dir")) === "IN" ? "inv.receive" : "inv.issue", Object.fromEntries(f)); }}>
            <Field label="Direction"><Select name="dir" defaultValue="IN" className="w-32"><option value="IN">Receipt</option><option value="OUT">Issue</option></Select></Field>
            <Field label="Item"><Select name="materialNo" required className="w-48">
              {(ws?.materials ?? []).map((m: any) => <option key={m.materialNo} value={m.materialNo}>{m.materialNo} · {m.description}</option>)}</Select></Field>
            <Field label="Quantity"><Input name="qty" type="number" step="0.01" required className="w-28" /></Field>
            <Field label="Unit cost (receipts)"><Input name="unitCost" type="number" step="0.01" className="w-32" /></Field>
            <Field label="Reference"><Input name="reference" className="w-40" placeholder="GRN / issue note" /></Field>
            <Button type="submit" variant="primary" disabled={busy}>Post movement</Button>
            <Button type="button" variant="ghost" disabled={busy} onClick={() => post("inv.nrv")}>Run NRV write-down</Button>
          </form>
          <div className="mt-4">
            <Table cols={["Item", "Description", "UoM", { h: "Qty on hand", align: "right" }, { h: "Unit cost", align: "right" },
              { h: "Cost value", align: "right" }, { h: "NRV", align: "right" }, { h: "Carrying", align: "right" }, "Alert", "Status", ""]}
              rows={inv.map((m: any) => {
                const master = (ws?.materials ?? []).find((x: any) => x.materialNo === m.materialNo);
                return [m.materialNo, m.description, m.uom, money(m.qty), money(m.unitCost), money(m.cost),
                money(m.nrvTotal), money(m.carrying),
                m.writedown > 0 ? <Badge key="a" tone="red">Write down {money(m.writedown)}</Badge>
                  : m.belowReorder ? <Badge key="b" tone="amber">Below reorder</Badge> : <Badge key="c" tone="green">OK</Badge>,
                <Badge key="s" tone={master?.active !== false ? "green" : "red"}>{master?.active !== false ? "Active" : "Inactive"}</Badge>,
                <Button key="x" size="sm" variant="ghost" disabled={busy} onClick={() => post("inv.material.toggle", { materialNo: m.materialNo })}>
                  {master?.active !== false ? "Deactivate" : "Reactivate"}</Button>];
              })}
              empty="No stock items" />
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ==================== BUDGETS ==================== */
function Budgets({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const year = new Date().getUTCFullYear();
  const [scenario, setScenario] = useState("BASE");
  const [bva, setBva] = useState<any>(null);
  const [rows, setRows] = useState<{ account: string; periodCode: string; amount: string }[]>([{ account: "", periodCode: `${year}-01`, amount: "" }]);

  const loadBva = async (s = scenario) => {
    const d = await fetch(`/api/reports?view=budget&scenario=${s}&year=${year}`).then((r) => r.json());
    setBva(d);
  };
  useEffect(() => { void loadBva(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [scenario]);

  return (
    <div className="space-y-5">
      <SectionTitle hint="Build base, upside and downside scenarios, then track actual performance against each one.">
        Budgeting, Forecasting &amp; Scenario Planning
      </SectionTitle>
      <Card title="Scenario" right={<div className="flex gap-2">
        <Select value={scenario} onChange={(e) => setScenario(e.target.value)} className="w-44">
          {["BASE", "UPSIDE", "DOWNSIDE", "FORECAST", "STRETCH"].map((s) => <option key={s}>{s}</option>)}</Select>
        <Button size="sm" variant="ghost" onClick={() => loadBva()}>Refresh</Button></div>}>
        <div className="scroll-thin overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-[16px]">
            <thead className="bg-[var(--bpz-50)] text-[13px] uppercase tracking-wide text-[var(--bpz-800)]">
              <tr>{["Account", "Period", "Budget amount", ""].map((h) => <th key={h} className="px-2 py-2 text-left font-bold">{h}</th>)}</tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-t border-slate-100">
                  <td className="px-1.5 py-1 min-w-[240px]"><Select value={r.account} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, account: e.target.value } : x))}>
                    <option value="">— select —</option>
                    {(ws?.accounts ?? []).filter((a: any) => ["Revenue", "Expense"].includes(a.type)).map((a: any) =>
                      <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}</Select></td>
                  <td className="px-1.5 py-1"><Select value={r.periodCode} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, periodCode: e.target.value } : x))}>
                    {(ws?.periods ?? []).filter((p: any) => p.year === year).map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select></td>
                  <td className="px-1.5 py-1 w-36"><Input type="number" step="0.01" value={r.amount} onChange={(e) => setRows(rows.map((x, j) => j === i ? { ...x, amount: e.target.value } : x))} /></td>
                  <td className="px-1 py-1"><Button size="sm" variant="ghost" onClick={() => setRows(rows.filter((_, j) => j !== i))}>✕</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button variant="ghost" onClick={() => setRows([...rows, { account: "", periodCode: `${year}-01`, amount: "" }])}>+ Add budget line</Button>
          <Button variant="gold" disabled={busy}
            onClick={() => post("budget.upsert", { scenario, fiscalYear: year, rows: rows.filter((r) => r.account).map((r) => ({ ...r, amount: Number(r.amount) || 0 })) }).then(() => loadBva())}>
            Save scenario {scenario}
          </Button>
        </div>
      </Card>
      <Card title={`Budget versus actual — ${scenario} ${year}`}>
        <Table cols={["Account", "Description", "Type", { h: "Budget", align: "right" }, { h: "Actual", align: "right" }, { h: "Variance", align: "right" }, { h: "Variance %", align: "right" }]}
          rows={[...(bva?.rows ?? []).map((r: any) => [r.account, r.description, r.type, money(r.budget), money(r.actual),
            <span key="v" className={r.variance < 0 ? "text-rose-600" : "text-emerald-600"}>{money(r.variance)}</span>, `${r.variancePct.toFixed(1)}%`]),
            ...(bva?.totals ? [["", <b key="t">TOTAL</b>, "", <b key="b">{money(bva.totals.budget)}</b>, <b key="a">{money(bva.totals.actual)}</b>, <b key="v">{money(bva.totals.variance)}</b>, ""]] : [])]}
          empty="No budget lines saved for this scenario" />
      </Card>
    </div>
  );
}

/* ==================== MASTER DATA ==================== */
function MasterData({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [t, setT] = useState("bp");
  return (
    <div className="space-y-5">
      <SectionTitle hint="Business partners, accounts, cost centres and projects — the backbone every module reads from.">Master Data</SectionTitle>
      <div className="flex flex-wrap gap-1.5">
        {[["bp", "Business Partners"], ["coa", "Chart of Accounts"], ["cc", "Cost Centres"], ["prj", "Projects"]].map(([k, l]) => (
          <button key={k} onClick={() => setT(k)} className={`rounded-lg px-3 py-1.5 text-[16px] font-medium ${t === k ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-600"}`}>{l}</button>
        ))}
      </div>

      {t === "bp" && <>
        <Card title="Add or update a business partner" subtitle="The WHT code and residency flag drive the Payment Desk automatically.">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            const o = Object.fromEntries(f) as Record<string, unknown>; o.isResident = f.get("isResident") === "on";
            post("master.partner", o); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Code (blank = auto)"><Input name="bpNo" className="w-28" /></Field>
            <Field label="Name"><Input name="name" required className="w-56" /></Field>
            <Field label="Type"><Select name="type" defaultValue="Vendor" className="w-32"><option>Vendor</option><option>Customer</option><option>Employee</option></Select></Field>
            <Field label="TIN"><Input name="tin" className="w-32" /></Field>
            <Field label="WHT code"><Select name="whtCode" className="w-56"><option value="">None</option>
              {(ws?.reference?.whtRates ?? []).map((w: any) => <option key={w.code} value={w.code}>{w.code} — {w.rate}%</option>)}</Select></Field>
            <Field label="Currency"><Select name="currency" defaultValue="GHS" className="w-24">{(ws?.reference?.currencies ?? []).map((c: string) => <option key={c}>{c}</option>)}</Select></Field>
            <Field label="Credit days"><Input name="creditDays" type="number" defaultValue={30} className="w-24" /></Field>
            <label className="flex items-center gap-1.5 pb-1.5 text-[16px]"><input type="checkbox" name="isResident" defaultChecked /> Resident</label>
            <Button type="submit" variant="gold" disabled={busy}>Save</Button>
          </form>
        </Card>
        <Card title="Business partners" subtitle="Deactivate a partner to hide it from new documents without losing its history.">
          <Table cols={["Code", "Name", "Type", "TIN", "Residency", "WHT code", "Currency", { h: "Credit days", align: "right" }, "Status", ""]}
            rows={(ws?.partners ?? []).map((p: any) => [p.bpNo, p.name, <Badge key="t" tone="blue">{p.type}</Badge>, p.tin || "—",
              <Badge key="r" tone={p.isResident ? "green" : "amber"}>{p.isResident ? "Resident" : "Non-resident"}</Badge>,
              p.whtCode || "—", p.currency, p.creditDays,
              <Badge key="s" tone={p.active ? "green" : "red"}>{p.active ? "Active" : "Inactive"}</Badge>,
              <Button key="x" size="sm" variant="ghost" disabled={busy} onClick={() => post("master.partner.toggle", { bpNo: p.bpNo })}>{p.active ? "Deactivate" : "Reactivate"}</Button>])} />
        </Card>
      </>}

      {t === "coa" && <>
        <Card title="Add a G/L account">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("master.account", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Account number"><Input name="accountNo" required className="w-32" /></Field>
            <Field label="Description"><Input name="description" required className="w-72" /></Field>
            <Field label="Type"><Select name="type" defaultValue="Expense" className="w-32">{["Asset", "Liability", "Equity", "Revenue", "Expense"].map((x) => <option key={x}>{x}</option>)}</Select></Field>
            <Field label="Sub-type"><Input name="subType" defaultValue="OPERATING" className="w-40" /></Field>
            <Field label="IFRS line"><Input name="ifrsLine" defaultValue="Administrative expenses" className="w-56" /></Field>
            <Button type="submit" variant="gold" disabled={busy}>Add account</Button>
          </form>
        </Card>
        <Card title={`Chart of accounts — ${(ws?.accounts ?? []).length} accounts tailored to ${ws?.client?.sector}`}
          subtitle="Deactivating an account hides it from new postings while keeping its history intact.">
          <Table cols={["Account", "Description", "Type", "Sub-type", "IFRS line", "Cash flow", "Status", ""]}
            rows={(ws?.accounts ?? []).map((a: any) => [a.accountNo, a.description, a.type, a.subType, a.ifrsLine, a.cashflowClass,
              <Badge key="s" tone={a.active ? "green" : "red"}>{a.active ? "Active" : "Inactive"}</Badge>,
              <Button key="x" size="sm" variant="ghost" disabled={busy} onClick={() => post("master.account.toggle", { accountNo: a.accountNo })}>{a.active ? "Deactivate" : "Reactivate"}</Button>])} />
        </Card>
      </>}

      {t === "cc" && <>
        <Card title="Add a cost centre">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("master.costCenter", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Code"><Input name="ccCode" required className="w-32" /></Field>
            <Field label="Name"><Input name="ccName" required className="w-64" /></Field>
            <Field label="Type"><Select name="ccType" defaultValue="DEPT" className="w-32">{["DEPT", "PROD", "PROJ", "SERVICE"].map((x) => <option key={x}>{x}</option>)}</Select></Field>
            <Button type="submit" variant="gold" disabled={busy}>Add</Button>
          </form>
        </Card>
        <Card title="Cost centres">
          <Table cols={["Code", "Name", "Type"]} rows={(ws?.costCenters ?? []).map((c: any) => [c.ccCode, c.ccName, c.ccType])} />
        </Card>
      </>}

      {t === "prj" && <>
        <Card title="Create a project / contract" subtitle="Used by construction, oil & gas, mining and other project-driven sectors.">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("master.project", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
            <Field label="Project name"><Input name="name" required className="w-64" /></Field>
            <Field label="Kind"><Select name="kind" defaultValue="CONTRACT" className="w-40">
              {["CONTRACT", "BLOCK", "MINE_LEASE", "DEVELOPMENT", "GRANT", "INTERNAL"].map((x) => <option key={x}>{x}</option>)}</Select></Field>
            <Field label="Customer"><Select name="customer" className="w-44"><option value="">—</option>
              {(ws?.partners ?? []).filter((p: any) => p.type === "Customer").map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.name}</option>)}</Select></Field>
            <Field label="Contract value"><Input name="contractValue" type="number" step="0.01" className="w-36" /></Field>
            <Field label="Budget cost"><Input name="budgetCost" type="number" step="0.01" className="w-36" /></Field>
            <Button type="submit" variant="gold" disabled={busy}>Create</Button>
          </form>
        </Card>
        <Card title="Projects">
          <Table cols={["Project", "Name", "Kind", "Customer", { h: "Contract value", align: "right" }, { h: "Budget cost", align: "right" }, { h: "Cost to date", align: "right" }, "Status"]}
            rows={(ws?.projects ?? []).map((p: any) => [p.projectNo, p.name, p.kind, p.customer || "—",
              money(p.contractValue), money(p.budgetCost), money(p.costToDate), <Badge key="s" tone="green">{p.status}</Badge>])}
            empty="No projects" />
        </Card>
      </>}
    </div>
  );
}

/* ==================== OWNER CONSOLE ==================== */
function OwnerConsole({ admin, ws, adminPost, busy, setToast }: {
  admin: any; ws: WS; adminPost: (a: string, p?: Record<string, unknown>) => Promise<any>;
  busy: boolean; setToast: (t: any) => void;
}) {
  const [t, setT] = useState("clients");
  const [cred, setCred] = useState<any>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const clients = admin?.clients ?? [];
  const staff = admin?.firmStaff ?? [];
  const sectors = ws?.reference?.sectors ?? [];
  const lines = ws?.reference?.serviceLines ?? [];
  const roles = ws?.reference?.roles ?? {};
  const countries = ws?.reference?.countries ?? [];
  const taxModes = ws?.reference?.payrollTaxModes ?? [];
  const [newCountry, setNewCountry] = useState("GH");
  const selectedCountry = countries.find((c: any) => c.code === newCountry);

  const showCred = (r: any) => {
    if (r?.tempPassword) {
      const origin = typeof window !== "undefined" ? window.location.origin : "";
      setCred({ ...r, fullUrl: `${origin}${r.workspaceUrl ?? "/login"}` });
    }
  };

  return (
    <div className="space-y-5">
      <SectionTitle hint="Create clients, issue and restrict logins, assign roles and service lines, and administer the platform.">
        Owner Console
      </SectionTitle>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Client workspaces" value={String(clients.filter((c: any) => !c.isFirm).length)} tone="blue" />
        <Stat label="Total logins" value={String(clients.reduce((s: number, c: any) => s + c.users.length, 0) + staff.length)} />
        <Stat label="Documents posted" value={String(clients.reduce((s: number, c: any) => s + c.stats.docs, 0))} />
        <Stat label="Value processed" value={money(clients.reduce((s: number, c: any) => s + c.stats.value, 0))} tone="gold" />
      </div>

      <div className="flex flex-wrap gap-1.5">
        {[["clients", "Clients & Workspaces"], ["staff", "Firm Staff"], ["roles", "Roles & Permissions"], ["activity", "Activity Log"], ["danger", "System Administration"]].map(([k, l]) => (
          <button key={k} onClick={() => setT(k)} className={`rounded-lg px-3 py-1.5 text-[16px] font-medium ${t === k ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-600"}`}>{l}</button>
        ))}
      </div>

      {t === "clients" && <>
        <Card title="Create a client account" subtitle="Provisions an isolated workspace with a sector-tailored chart of accounts, fiscal calendar and a temporary login.">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            const o = Object.fromEntries(f) as Record<string, unknown>;
            o.serviceLines = f.getAll("serviceLines"); o.vatRegistered = f.get("vatRegistered") === "on";
            const form = e.currentTarget;
            adminPost("client.create", o).then((r) => { if (r && !r.error) { showCred(r); form.reset(); } }); }}>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Company name"><Input name="name" required placeholder="Acme Manufacturing Ltd" /></Field>
              <Field label="Sector" hint="Determines the chart of accounts, cost centres, asset classes and tax profile">
                <Select name="sector" required defaultValue="GENERAL">
                  {Object.entries(sectors.reduce((g: any, s: any) => ({ ...g, [s.group]: [...(g[s.group] ?? []), s] }), {})).map(([grp, list]: any) => (
                    <optgroup key={grp} label={grp}>{list.map((s: any) => <option key={s.key} value={s.key}>{s.name}</option>)}</optgroup>
                  ))}
                </Select></Field>
              <Field label="Country" hint="Ghana runs full statutory PAYE/SSNIT; every other country runs a configurable scheme">
                <Select name="country" value={newCountry} onChange={(e) => setNewCountry(e.target.value)}>
                  {countries.map((c: any) => <option key={c.code} value={c.code}>{c.name}</option>)}
                </Select></Field>
              <Field label="Reporting currency"><Select name="currency" defaultValue={selectedCountry?.currency ?? "GHS"} key={selectedCountry?.currency}>
                {(ws?.reference?.currencies ?? []).map((c: string) => <option key={c} value={c}>{c}</option>)}</Select></Field>
              <Field label="TIN / tax reference"><Input name="tin" placeholder="C0001234567" /></Field>
              <Field label="Contact person"><Input name="contactName" /></Field>
              <Field label="Login email"><Input name="email" type="email" required placeholder="finance@acme.com" /></Field>
              <Field label="Financial year starts"><Select name="fyStartMonth" defaultValue={1}>
                {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map((m, i) => <option key={m} value={i + 1}>{m}</option>)}</Select></Field>
              {newCountry !== "GH" && (<>
                <Field label="Payroll tax regime"><Select name="payrollTaxMode" defaultValue="FLAT_RATE">
                  {taxModes.filter((m: any) => m.key !== "GH_PAYE").map((m: any) => <option key={m.key} value={m.key}>{m.name}</option>)}</Select></Field>
                <Field label="Flat withholding rate (%)" hint={`Typical for ${selectedCountry?.name ?? "this country"}: ${selectedCountry?.defaultFlatRate ?? 0}%`}>
                  <Input name="payrollFlatRatePct" type="number" step="0.01" defaultValue={selectedCountry?.defaultFlatRate ?? 0} key={selectedCountry?.defaultFlatRate} /></Field>
                <Field label="Statutory scheme label" hint="Shown on payslips instead of SSNIT">
                  <Input name="statutoryLabel" defaultValue={selectedCountry?.statutoryLabel ?? "Social Security"} key={selectedCountry?.statutoryLabel} /></Field>
              </>)}
            </div>
            <Field label="Service lines engaged">
              <div className="flex flex-wrap gap-2 rounded-lg border border-slate-200 p-2.5">
                {lines.map((l: any) => (
                  <label key={l.key} className="flex items-center gap-1.5 text-[16px]">
                    <input type="checkbox" name="serviceLines" value={l.key} defaultChecked={l.key === "BOOKKEEPING"} /> {l.name}
                  </label>))}
              </div></Field>
            <label className="flex items-center gap-1.5 text-[16px]"><input type="checkbox" name="vatRegistered" defaultChecked /> VAT registered</label>
            <Button type="submit" variant="gold" disabled={busy}>Create client &amp; issue login</Button>
          </form>
        </Card>

        {clients.map((c: any) => (
          <Card key={c.id} title={`${c.name} · ${c.id}`}
            subtitle={`${c.sector} · ${c.country ?? "GH"} · ${c.currency} · ${c.payrollTaxMode === "GH_PAYE" ? "Ghana PAYE/SSNIT" : c.payrollTaxMode === "FLAT_RATE" ? `${c.payrollFlatRatePct}% flat payroll tax` : "No payroll withholding"} · ${c.stats.docs} documents · ${money(c.stats.value)} processed`}
            right={<div className="flex flex-wrap gap-2">
              {c.isFirm ? <Badge tone="gold">FIRM</Badge> : <Badge tone={c.active ? "green" : "red"}>{c.active ? "Active" : "Suspended"}</Badge>}
              <AddUserButton clientId={c.id} roles={roles} adminPost={adminPost} busy={busy} onCred={showCred} />
              {!c.isFirm && <ClientRegimeButton client={c} countries={countries} taxModes={taxModes} adminPost={adminPost} busy={busy} />}
              {!c.isFirm && <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("client.toggle", { clientId: c.id })}>{c.active ? "Suspend" : "Reactivate"}</Button>}
            </div>}>
            <Table cols={["User", "Email", "Role", "Status", "Temp password", "Last login", "Actions"]}
              rows={c.users.map((u: any) => [
                u.name, u.email, <Badge key="r" tone="blue">{u.role}</Badge>,
                <Badge key="s" tone={u.active ? "green" : "red"}>{u.active ? "Active" : "Restricted"}</Badge>,
                u.mustChangePassword && u.tempPassword ? <code key="t" className="rounded bg-amber-50 px-1 text-[14px] text-amber-800">{u.tempPassword}</code> : "—",
                u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : "Never",
                <span key="a" className="flex flex-wrap gap-1">
                  <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.resetPassword", { userId: u.id }).then(showCred)}>Reissue login</Button>
                  <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.toggle", { userId: u.id })}>{u.active ? "Restrict" : "Restore"}</Button>
                  {u.role !== "OWNER" && <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.delete", { userId: u.id })}>Delete</Button>}
                </span>])}
              empty="No logins for this workspace" />
          </Card>
        ))}
      </>}

      {t === "staff" && (
        <Card title="Firm staff" subtitle="Firm staff can work inside any client workspace; clients can only see their own."
          right={<AddUserButton clientId="" roles={roles} adminPost={adminPost} busy={busy} onCred={showCred} firmOnly />}>
          <Table cols={["Name", "Email", "Role", "Job title", "Status", "Temp password", "Last login", "Actions"]}
            rows={staff.map((u: any) => [u.name, u.email, <Badge key="r" tone="gold">{u.role}</Badge>, u.jobTitle || "—",
              <Badge key="s" tone={u.active ? "green" : "red"}>{u.active ? "Active" : "Restricted"}</Badge>,
              u.mustChangePassword && u.tempPassword ? <code key="t" className="rounded bg-amber-50 px-1 text-[14px]">{u.tempPassword}</code> : "—",
              u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString() : "Never",
              <span key="a" className="flex gap-1">
                <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.resetPassword", { userId: u.id }).then(showCred)}>Reissue</Button>
                {u.role !== "OWNER" && <>
                  <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.toggle", { userId: u.id })}>{u.active ? "Restrict" : "Restore"}</Button>
                  <Button size="sm" variant="ghost" disabled={busy} onClick={() => adminPost("user.delete", { userId: u.id })}>Delete</Button></>}
              </span>])} />
        </Card>
      )}

      {t === "roles" && (
        <Card title="Roles and permissions" subtitle="Each role carries a fixed permission set that the API enforces on every request.">
          <Table cols={["Role", "Description", "Permissions"]}
            rows={Object.entries(roles).map(([k, v]: any) => [<b key="k">{k}</b>, v.name,
              <div key="p" className="flex flex-wrap gap-1">{v.perms.map((p: string) => <Badge key={p} tone="slate">{p}</Badge>)}</div>])} />
        </Card>
      )}

      {t === "activity" && (
        <Card title="Platform activity log" subtitle="Every posting and administrative action, by user and workspace.">
          <Table cols={["When", "Workspace", "User", "Role", "Action", "Detail"]}
            rows={(admin?.activity ?? []).map((a: any) => [new Date(a.createdAt).toLocaleString(), a.clientId, a.userEmail,
              <Badge key="r" tone="blue">{a.role}</Badge>, a.action,
              <span key="d" className="block max-w-[420px] truncate" title={a.detail}>{a.detail}</span>])}
            empty="No activity recorded" />
        </Card>
      )}

      {t === "danger" && <>
        <Card title="Firm profile">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); adminPost("firm.update", Object.fromEntries(f)); }}>
            <Field label="Firm name"><Input name="name" defaultValue={clients.find((c: any) => c.isFirm)?.name} className="w-80" /></Field>
            <Field label="TIN"><Input name="tin" defaultValue={clients.find((c: any) => c.isFirm)?.tin} className="w-40" /></Field>
            <Field label="Currency"><Select name="currency" defaultValue="GHS" className="w-28">{(ws?.reference?.currencies ?? []).map((c: string) => <option key={c}>{c}</option>)}</Select></Field>
            <Button type="submit" variant="primary" disabled={busy}>Save</Button>
          </form>
        </Card>
        <Card title="Delete a client workspace" subtitle="Permanently removes the workspace, its ledger and all its logins. This cannot be undone.">
          <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); adminPost("system.purgeClient", Object.fromEntries(f)); }}>
            <Field label="Workspace"><Select name="clientId" required className="w-72">
              <option value="">— select —</option>
              {clients.filter((c: any) => !c.isFirm).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></Field>
            <Field label="Type the exact client name to confirm"><Input name="confirm" required className="w-72" /></Field>
            <Button type="submit" variant="danger" disabled={busy}>Delete permanently</Button>
          </form>
        </Card>
        <Card title="Reset the entire platform" subtitle="Clears every client, ledger and login. Only your owner account and the BPZ firm workspace survive.">
          <Button variant="danger" onClick={() => setResetOpen(true)}>Reset the whole system…</Button>
        </Card>
        <Modal open={resetOpen} title="Confirm full system reset" onClose={() => setResetOpen(false)}>
          <div className="space-y-3">
            <p className="rounded-lg bg-rose-50 px-3 py-2 text-[15px] text-rose-800">
              This permanently deletes every client workspace, all accounting data, all documents and all logins
              other than your own. There is no recovery.
            </p>
            <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
              adminPost("system.reset", Object.fromEntries(f)).then(() => setResetOpen(false)); }} className="space-y-3">
              <Field label="Type RESET to confirm"><Input name="confirm" required placeholder="RESET" /></Field>
              <Button type="submit" variant="danger" disabled={busy}>I understand — reset everything</Button>
            </form>
          </div>
        </Modal>
      </>}

      <Modal open={!!cred} title="Login credentials issued" onClose={() => setCred(null)}>
        <div className="space-y-3 text-[15.5px]">
          <p className="rounded-lg bg-emerald-50 px-3 py-2 text-emerald-800">
            Share these details with the user. They will be required to set a permanent password at first sign-in.
          </p>
          <div className="space-y-2 rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div><span className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Email</span><p className="font-mono">{cred?.email}</p></div>
            <div><span className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Temporary password</span>
              <p className="font-mono text-base font-bold text-[var(--bpz-800)]">{cred?.tempPassword}</p></div>
            <div><span className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Workspace link</span>
              <p className="break-all font-mono text-[16px]">{cred?.fullUrl}</p></div>
          </div>
          <Button variant="gold" onClick={() => {
            navigator.clipboard?.writeText(`BPZ workspace access\nEmail: ${cred?.email}\nTemporary password: ${cred?.tempPassword}\nSign in: ${cred?.fullUrl}`);
            setToast({ kind: "ok", msg: "Credentials copied to the clipboard" });
          }}>Copy all details</Button>
        </div>
      </Modal>
    </div>
  );
}

function AddUserButton({ clientId, roles, adminPost, busy, onCred, firmOnly }: {
  clientId: string; roles: any; adminPost: (a: string, p?: Record<string, unknown>) => Promise<any>;
  busy: boolean; onCred: (r: any) => void; firmOnly?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const opts = Object.entries(roles).filter(([k]) => firmOnly ? k.startsWith("FIRM") : k.startsWith("CLIENT"));
  return (
    <>
      <Button size="sm" variant="gold" onClick={() => setOpen(true)}>+ Add login</Button>
      <Modal open={open} title="Create a login" onClose={() => setOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          adminPost("user.create", { ...Object.fromEntries(f), clientId })
            .then((r) => { if (r && !r.error) { onCred(r); setOpen(false); } }); }}>
          <Field label="Full name"><Input name="name" required /></Field>
          <Field label="Email"><Input name="email" type="email" required /></Field>
          <Field label="Role"><Select name="role" required defaultValue={opts[0]?.[0]}>
            {opts.map(([k, v]: any) => <option key={k} value={k}>{v.name}</option>)}</Select></Field>
          <Field label="Job title"><Input name="jobTitle" /></Field>
          <Field label="Approval limit" hint="Maximum payment value this user may approve"><Input name="approvalLimit" type="number" step="0.01" defaultValue={0} /></Field>
          <Button type="submit" variant="gold" disabled={busy}>Create login &amp; generate temporary password</Button>
        </form>
      </Modal>
    </>
  );
}

function ClientRegimeButton({ client, countries, taxModes, adminPost, busy }: {
  client: any; countries: any[]; taxModes: any[];
  adminPost: (a: string, p?: Record<string, unknown>) => Promise<any>; busy: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [country, setCountry] = useState(client.country ?? "GH");
  const selected = countries.find((c) => c.code === country);
  return (
    <>
      <Button size="sm" variant="ghost" onClick={() => setOpen(true)}>Country &amp; payroll regime</Button>
      <Modal open={open} title={`${client.name} — country & payroll regime`} onClose={() => setOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          adminPost("client.update", { clientId: client.id, ...Object.fromEntries(f) }).then((r) => { if (r && !r.error) setOpen(false); }); }}>
          <p className="rounded-lg bg-[var(--bpz-50)] px-3 py-2 text-[16px] text-slate-600">
            Changing the country switches the payroll tax engine for future runs only — past payslips and postings are
            never recalculated.
          </p>
          <Field label="Country">
            <Select name="country" value={country} onChange={(e) => setCountry(e.target.value)}>
              {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
            </Select></Field>
          {country !== "GH" ? (<>
            <Field label="Payroll tax regime"><Select name="payrollTaxMode" defaultValue={client.payrollTaxMode === "GH_PAYE" ? "FLAT_RATE" : client.payrollTaxMode}>
              {taxModes.filter((m: any) => m.key !== "GH_PAYE").map((m: any) => <option key={m.key} value={m.key}>{m.name}</option>)}</Select></Field>
            <Field label="Flat withholding rate (%)"><Input name="payrollFlatRatePct" type="number" step="0.01" defaultValue={client.payrollFlatRatePct ?? selected?.defaultFlatRate ?? 0} /></Field>
            <Field label="Statutory scheme label"><Input name="statutoryLabel" defaultValue={client.statutoryLabel || selected?.statutoryLabel} /></Field>
          </>) : (
            <input type="hidden" name="payrollTaxMode" value="GH_PAYE" />
          )}
          <Button type="submit" variant="gold" disabled={busy}>Save regime</Button>
        </form>
      </Modal>
    </>
  );
}

/* ==================== PROFILE ==================== */
function Profile({ user, call, busy, isOwner, adminPost }: {
  user: any; call: (u: string, p: Record<string, unknown>) => Promise<any>; busy: boolean;
  isOwner: boolean; adminPost: (a: string, p?: Record<string, unknown>) => Promise<any>;
}) {
  return (
    <div className="space-y-5">
      <SectionTitle hint="Update your details and change your password.">My Profile</SectionTitle>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Personal details">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            if (isOwner) adminPost("owner.updateProfile", Object.fromEntries(f));
            else call("/api/auth", { action: "updateProfile", ...Object.fromEntries(f) }); }}>
            <Field label="Full name"><Input name="name" defaultValue={user?.name} /></Field>
            {isOwner && <Field label="Email address" hint="Changing this changes your sign-in username"><Input name="email" type="email" defaultValue={user?.email} /></Field>}
            <Field label="Job title"><Input name="jobTitle" defaultValue={user?.jobTitle} /></Field>
            <Field label="Phone"><Input name="phone" /></Field>
            <Button type="submit" variant="gold" disabled={busy}>Save profile</Button>
          </form>
        </Card>
        <Card title="Change password">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            const form = e.currentTarget;
            call("/api/auth", { action: "changePassword", currentPassword: f.get("currentPassword"), newPassword: f.get("newPassword") })
              .then((r) => { if (r && !r.error) form.reset(); }); }}>
            <Field label="Current password"><Input name="currentPassword" type="password" required /></Field>
            <Field label="New password" hint="Minimum 8 characters, including a letter and a number"><Input name="newPassword" type="password" required minLength={8} /></Field>
            <Button type="submit" variant="gold" disabled={busy}>Change password</Button>
          </form>
          <div className="mt-4 rounded-lg bg-[var(--bpz-50)] p-3 text-[16px] text-slate-600">
            <b>Your access:</b> {user?.role} · {user?.isFirmStaff ? "Firm staff — may work in any client workspace" : "Client user — restricted to your own workspace"}
            <div className="mt-1.5 flex flex-wrap gap-1">{(user?.permissions ?? []).map((p: string) => <Badge key={p} tone="slate">{p}</Badge>)}</div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ==================== SETUP GUIDE ==================== */
function SetupGuide({ ws, go }: { ws: WS; go: (t: string) => void }) {
  const steps: { n: string; title: string; body: string; tab?: string }[] = [
    { n: "1", title: "Create the client and choose its sector", tab: "owner", body: "In the Owner Console, create the client account. The sector you choose drives everything downstream: the chart of accounts, cost centres, fixed asset classes, stock items and the tax profile. A temporary password and a direct workspace link are issued for you to pass to the client." },
    { n: "2", title: "Set the fiscal calendar", tab: "close", body: "Periods are generated automatically for three years either side of today. Use Period Control to extend the calendar as far forward as you need and to set the month in which the financial year begins." },
    { n: "3", title: "Load opening balances", tab: "gl", body: "On the General Ledger tab switch to Opening Balances and enter the migration trial balance as at the day before you go live. Any imbalance is parked in Opening Balance Equity (990200) for you to investigate and clear." },
    { n: "4", title: "Complete the master data", tab: "master", body: "Add customers and suppliers with their TIN, residency and withholding tax code — these drive the Payment Desk automatically. Add cost centres and, for project-based sectors, the contracts or blocks." },
    { n: "5", title: "Set up banking", tab: "banking", body: "Record each bank account and its G/L mapping. Import a statement as CSV; the system classifies each line, proposes an account and matches it against existing postings." },
    { n: "6", title: "Build the fixed asset register", tab: "assets", body: "Capitalise each asset against a class. General classes apply everywhere; specialised classes appear for your sector — for example development wells and FPSO for upstream petroleum, deferred stripping for mining, scaffolding for construction." },
    { n: "7", title: "Configure payroll", tab: "payroll", body: "Add employees with their basic salary, SSNIT applicability and residency. Add allowances, deductions and reliefs, choosing whether each applies on basic, gross or net pay. Calculate to preview, then post." },
    { n: "8", title: "Review the tax configuration", tab: "tax", body: "Confirm the PAYE schedule, VAT rate and withholding tax codes. Every rate is date-effective, so when the GRA amends a rate you add the new rate with its effective date and prior periods keep their original treatment." },
    { n: "9", title: "Transact", tab: "sales", body: "Raise quotations, convert them to orders and then to invoices. Record supplier invoices. Settle through the Payment Desk, in full or in part, with withholding tax applied on the VAT-exclusive value." },
    { n: "10", title: "Run the month-end close", tab: "close", body: "The close routine runs depreciation, prepayment and accrual releases, the NRV test, foreign currency retranslation and VAT settlement, then checks the trial balance before optionally locking the period." },
    { n: "11", title: "Report and export", tab: "reports", body: "Produce the full IFRS statement set — profit or loss, financial position, cash flows and changes in equity — plus ageings and the drill-down ledger. Export everything to a formatted Excel workbook." },
    { n: "12", title: "Deliver the service", tab: "practice", body: "Open an engagement from the work template library. Complete the quantitative schedule, the qualitative commentary and the sign-off checklist, then raise the fee invoice." },
  ];
  return (
    <div className="space-y-5">
      <SectionTitle hint="A twelve-step path from an empty workspace to a reported, closed and billed period.">Setup &amp; Operating Guide</SectionTitle>
      <Card tone="tint">
        <div className="grid gap-3 md:grid-cols-3 text-[16px]">
          <div><p className="font-bold text-[var(--bpz-900)]">Framework</p><p className="text-slate-600">IFRS / IAS as adopted in Ghana. Statements follow IAS 1 and IAS 7 presentation.</p></div>
          <div><p className="font-bold text-[var(--bpz-900)]">Tax basis</p><p className="text-slate-600">Income Tax Act 2015 (Act 896) as amended by Act 1178; VAT at 20% with no cascading; comprehensive resident and non-resident withholding.</p></div>
          <div><p className="font-bold text-[var(--bpz-900)]">Exchange rates</p><p className="text-slate-600">Bank of Ghana daily interbank mid rate, fetched automatically with an open-API fallback.</p></div>
        </div>
      </Card>
      <div className="grid gap-3 lg:grid-cols-2">
        {steps.map((s) => (
          <div key={s.n} className="animate-fade-up rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-[var(--bpz-800)] text-[16px] font-bold text-[var(--gold-400)]">{s.n}</div>
              <div className="min-w-0">
                <h4 className="font-display text-[15.5px] font-bold text-[var(--bpz-900)]">{s.title}</h4>
                <p className="mt-1 text-[16px] leading-relaxed text-slate-600">{s.body}</p>
                {s.tab && <Button size="sm" variant="ghost" className="mt-2" onClick={() => go(s.tab!)}>Go to this step →</Button>}
              </div>
            </div>
          </div>
        ))}
      </div>
      <Card title="Sector coverage" subtitle={`${(ws?.reference?.sectors ?? []).length} sectors, each with its own chart of accounts, cost centres, asset classes and tax profile.`}>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries((ws?.reference?.sectors ?? []).reduce((g: any, s: any) => ({ ...g, [s.group]: [...(g[s.group] ?? []), s] }), {})).map(([grp, list]: any) => (
            <div key={grp} className="rounded-lg border border-slate-200 p-3">
              <p className="mb-1.5 text-[13px] font-bold uppercase tracking-wider text-[var(--gold-700)]">{grp}</p>
              <ul className="space-y-0.5 text-[16px] text-slate-600">{list.map((s: any) => <li key={s.key}>• {s.name}</li>)}</ul>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ==================== USER HANDBOOK ==================== */
type GlossaryItem = { term: string; def: string };
type HandbookSection = { key: string; title: string; icon: string; intro?: string; glossary?: GlossaryItem[]; notes?: string[]; tab?: string };

const HANDBOOK: HandbookSection[] = [
  {
    key: "concepts", title: "Core Concepts", icon: "🧩",
    intro: "Every module in the platform is built from the same handful of building blocks. Understanding these first makes every screen in the system self-explanatory.",
    glossary: [
      { term: "Workspace", def: "One company's complete, isolated set of books — its own chart of accounts, partners, documents and users. The firm (BPZ) has a workspace; every client has its own. Nothing ever crosses between workspaces." },
      { term: "Fiscal Period", def: "A calendar month inside a fiscal year (e.g. 2026-01). Every transaction is dated into exactly one period. A period can be OPEN (postable), CLOSED (locked after month-end) or re-opened by an authorised user. Periods are generated automatically and can be extended indefinitely." },
      { term: "Cost Centre", def: "A tag — usually a department, site or project — attached to a transaction so cost and revenue can be analysed by where they were earned or incurred, independently of which G/L account was used. Optional on most documents; required only where your sector template expects it (e.g. construction site costing)." },
      { term: "Business Partner (BP)", def: "Any customer, supplier or employee the company transacts with. Set up once in Master Data with a code (e.g. C-0001 for a customer, V-0001 for a vendor), then reused on every quotation, invoice, payment and payslip. Residency and the default withholding-tax code live here so they don't need re-entering each time." },
      { term: "G/L Account", def: "A line in the Chart of Accounts (e.g. 500100 Revenue — Goods). Every document ultimately debits and credits G/L accounts; the system usually proposes a sensible default so you rarely need to pick one manually." },
      { term: "Tax Code", def: "Determines the VAT rate and any levy applied to a line: STD (20% standard), ZERO (exports), EXEMPT, OUT (outside the scope), RC (reverse charge on imported services), FLAT (3% flat-rate retail scheme). VAT in this system never cascades — levies are always computed on the net value, never on top of VAT." },
      { term: "WHT Code", def: "The withholding tax category applied automatically when you pay a supplier (goods 3%, works 5%, services 7.5% for residents; 15–20% for non-residents, among many others). Set once on the vendor record; the Payment Desk applies it and computes the exact amount." },
      { term: "Currency & FX Rate", def: "Any document can be raised in a foreign currency. The system fetches the Bank of Ghana mid rate automatically for the document date and converts to GHS for the ledger — you never have to look up or type a rate yourself." },
      { term: "Document Number", def: "Every document type has its own numbered series (SI- for sales invoices, PI- for purchase invoices, PV- for payments, and so on) allocated automatically and gaplessly by the system." },
      { term: "GL Doc", def: "The Universal Journal document number created when a transaction is posted. A quotation or order has no GL Doc because it hasn't hit the ledger yet; an invoice, payment or journal always does." },
    ],
  },
  {
    key: "sales", title: "Sales & Receivables", icon: "🧾", tab: "sales",
    intro: "Raise a quotation, convert it step by step into cash, or skip straight to an invoice — the system never forces you through steps you don't need.",
    notes: [
      "Quotation → Sales Order → Sales Invoice is an optional chain. Use the 'Convert' button on the document register to move a document to the next stage without retyping it.",
      "You do not have to start with a quotation. Selecting 'Sales Invoice' directly as the document type raises and posts the invoice immediately — ideal for walk-in sales, retainers, or anything agreed informally.",
      "Each line is either a Service line (no stock impact — consulting, rent recharges, commission) or a Material/Goods line (selected from your stock items, which reduces inventory and records the cost of goods sold automatically at the weighted-average cost).",
      "A Credit Note reduces what the customer owes; a Debit Note increases it. Neither is paid through the Payment Desk directly — apply a credit note against an invoice from the 'Apply a credit note' panel on the Payment Desk instead.",
      "Partial payment is always allowed: the Payment Desk lets you enter any amount up to the outstanding balance, and the invoice shows PART-PAID until it is fully settled.",
    ],
  },
  {
    key: "purchases", title: "Purchases & Payables", icon: "📦", tab: "purch",
    intro: "Purchases are either for stock (materials you will resell or consume in production) or for services and overheads — the system treats each correctly without you needing to configure anything extra. A separate mode on the same screen handles bills that never go through procurement at all.",
    notes: [
      "Supplier Purchase mode: a Purchase Order is optional, used only to commit to a supplier before delivery — useful for stock and large contracts. For rent, subscriptions, professional fees and anything that simply arrives as a genuine supplier bill, choose 'Purchase Invoice' directly and post it straight away.",
      "Direct / Statutory Invoice mode: for utility bills, insurance premiums, regulatory fees and permits, and penalties or fines — none of which has a purchase order or, often, a conventional 'vendor invoice'. Pick the category, the payee, and the amount; the system recognises the payable immediately with no procurement step. It then appears in the Payment Desk's open items exactly like a supplier invoice, ready to be paid in full or in part, whenever you choose.",
      "Self-assessed statutory remittances — PAYE, VAT, withholding tax, SSNIT, Tier 3, corporate tax instalments — never need an invoice step at all, because the liability already exists on the books automatically the moment payroll is posted or VAT is settled. For these, use 'Direct & Statutory Payment' on the Payment Desk to clear the liability directly, with no invoice to raise first.",
      "Material/Goods lines receive stock into inventory at the price you enter and update the weighted-average cost used for every future sale. Service lines post straight to the expense account you choose and never touch inventory.",
      "Input VAT on a purchase is automatically tracked as recoverable (unless the tax code says otherwise) and nets off against output VAT in the VAT Filing Schedule.",
      "Withholding tax is not applied when any invoice is raised — it is calculated and deducted automatically when you pay through the Payment Desk, based on the payee's WHT code or whichever code you choose at the point of payment.",
    ],
  },
  {
    key: "payments", title: "Payment Desk", icon: "💳", tab: "payments",
    intro: "Every cash movement in or out of the business — whether or not it relates to an invoice — runs through this one desk so withholding tax, approvals and foreign-exchange gains or losses are always handled consistently.",
    glossary: [
      { term: "Full / partial settlement", def: "Enter any amount up to an invoice's outstanding balance; the invoice updates to PART-PAID or PAID automatically. There is no separate 'partial payment' mode — it is the same screen." },
      { term: "On-account amount", def: "Money paid or received with no invoice yet — an advance to a supplier or a deposit from a customer. Posts to a dedicated advance/deposit account and can be matched to a real invoice later." },
      { term: "Approval limit", def: "Set per user in the Owner Console. A payment above a user's limit is queued for a colleague holding the PAY_APPROVE permission to approve before it posts — nothing is lost, it simply waits." },
      { term: "Realised FX gain/loss", def: "If a foreign-currency invoice is settled on a day when the exchange rate has moved since the invoice was raised, the difference is calculated automatically and posted to the foreign exchange gain/loss account — you never need to calculate this by hand." },
      { term: "Direct & Statutory Payment", def: "A separate mode on the Payment Desk for anything that never goes through procurement: utility bills, PAYE/VAT/WHT/CIT remittances, SSNIT and provident fund contributions, insurance premiums, regulatory fees, and penalties or fines. Choose a category, confirm the G/L account, and post straight to the bank — no purchase order, no supplier invoice, and no withholding tax applied." },
    ],
    notes: [
      "Use 'Supplier / Customer Settlement' when you are paying down an invoice you raised in the system, or receiving against one.",
      "Use 'Direct & Statutory Payment' for anything that was never a purchase in the first place — the categories are grouped into Taxes & Statutory Remittances, Pension & Provident Fund, Insurance, Utilities & Regulatory, and Penalties & Fines, each pre-mapped to the correct account.",
      "A direct payment can be made to a business partner already on file (GRA and SSNIT are pre-loaded) or to a free-text payee name for a one-off body you don't want to create a full vendor record for.",
    ],
  },
  {
    key: "banking", title: "Banking & Reconciliation", icon: "🏦", tab: "banking",
    intro: "Import a bank statement, let the system suggest how to classify each line, then produce a reconciliation that ties the bank statement to the ledger.",
    notes: [
      "Import accepts a CSV export from internet banking with Date, Narrative, Debit, Credit (and optionally Balance/Reference) columns in any order — the importer detects them by header name.",
      "Narratives are matched against common patterns (payroll, SSNIT, PAYE, VAT, WHT, utilities, fuel, bank charges, etc.) and a G/L account is suggested automatically; you can change it before posting.",
      "Re-importing the same statement is detected and skipped — duplicate rows are never double-posted.",
      "Running the reconciliation again for the same bank and period refreshes the existing draft rather than creating a pile of duplicate reconciliations.",
    ],
  },
  {
    key: "assets", title: "Fixed Assets", icon: "🏭", tab: "assets",
    intro: "A full asset register with general classes available to every sector and specialised classes that appear automatically based on the client's sector.",
    notes: [
      "Depreciation methods: Straight Line (even charge every period), Reducing Balance (percentage of the remaining net book value), and Units of Production (charged in proportion to usage for plant, vehicles and extractive assets).",
      "Running depreciation for a period is safe to repeat — each asset is only charged once per period, however many times you run it.",
      "Revaluation posts an uplift to the revaluation surplus (other comprehensive income) or a reduction as an impairment charge to profit or loss, exactly as IAS 16 and IAS 36 require.",
      "Disposal removes the cost and accumulated depreciation and posts the resulting gain or loss automatically.",
    ],
  },
  {
    key: "payroll", title: "Payroll Desk", icon: "👥", tab: "payroll",
    intro: "Scales to any headcount — add staff one at a time or bulk-import a whole payroll — and adapts its tax engine to the country the workspace operates in.",
    glossary: [
      { term: "Basic salary", def: "The fixed monthly salary before any allowance. Statutory contributions (SSNIT, PAYE) are calculated from this and from taxable allowances." },
      { term: "Allowance", def: "An addition to gross pay (transport, housing, etc.). Marked taxable or non-taxable; taxable allowances increase the PAYE calculation." },
      { term: "Deduction", def: "A reduction from net pay after tax (union dues, loan repayments). Can be a fixed amount or a percentage of basic, gross or net pay." },
      { term: "Relief", def: "Reduces the income subject to PAYE before tax is calculated (marriage/responsibility, child education, old age, disability, training) — entered as the monthly equivalent of the statutory annual amount." },
      { term: "Basis (FIXED / PCT_BASIC / PCT_GROSS / PCT_NET)", def: "Controls how an allowance, deduction or relief is calculated: a fixed cedi amount, or a percentage of basic salary, gross pay, or net pay." },
      { term: "Termination (leaver)", def: "Marks an employee inactive from a given date. Their full payslip history is kept; they are simply excluded from every future payroll run." },
    ],
    notes: [
      "Ghana workspaces run the full statutory engine: PAYE under the Income Tax (Amendment) Act 2026 (Act 1178, effective 1 September 2026), SSNIT at 5.5% employee / 13% employer of basic salary, and Tier 3 up to 16.5% of basic.",
      "Workspaces outside Ghana use a configurable flat-rate withholding (or no withholding) instead, so the platform never silently applies Ghanaian tax law to a non-Ghanaian company.",
      "Bulk-import a payroll from a CSV with Name and BasicSalary columns (plus any optional columns you have) to onboard any number of employees in one action.",
    ],
  },
  {
    key: "tax", title: "Tax Centre", icon: "🧮", tab: "tax",
    intro: "Every statutory rate in the system — PAYE bands, VAT, and every withholding tax code — is stored as data with an effective date, so a change in the law never requires a code change, and historical periods keep the rate that applied at the time.",
    notes: [
      "Rates are edited directly in the Tax Centre by a user with the TAX_MANAGE permission; set the new rate and the date it takes effect, and the system automatically uses the old rate for anything dated before that and the new rate from that date onward.",
      "The Reports tab has a dedicated VAT Filing Schedule and Withholding Tax Filing Schedule, pre-built in exactly the shape needed to complete the monthly GRA returns.",
    ],
  },
  {
    key: "reports", title: "Reports & Compliance", icon: "📈", tab: "reports",
    intro: "A full IFRS statement set, ageing analysis, and the two compliance schedules every Ghanaian business needs to file on time.",
    notes: [
      "Statement of Profit or Loss, Statement of Financial Position, Statement of Cash Flows (indirect method) and Statement of Changes in Equity are all produced directly from the ledger — there is nothing to reconcile manually.",
      "Click any account on the Trial Balance or Chart of Accounts to open its full transaction history (the 'drill-down' ledger).",
      "The VAT Filing Schedule shows output VAT, input VAT and the net amount to pay or recover, broken out by rate code. The Withholding Tax Filing Schedule shows every amount withheld, by code and by supplier.",
      "Every report respects the period filter at the top of the Reports page, so you can produce figures for any single month, quarter or custom range.",
    ],
  },
  {
    key: "sync", title: "Working as a Team — Multiple Users & Devices", icon: "🔄",
    intro: "The platform is a normal multi-user web application: everyone works against the same shared database, from as many devices and browser tabs as you like, with no special setup.",
    notes: [
      "Every post (an invoice, a payment, a journal) is written straight to the shared database and is immediately visible to everyone else who refreshes their screen.",
      "The screen resynchronises itself automatically roughly every 25 seconds while the tab is open and visible, and immediately whenever you switch back to the tab or the browser window regains focus — so returning from another application shows you the latest figures without a manual refresh.",
      "The small indicator in the top header (a green dot and 'Synced Xs ago') shows how fresh your screen is; click it at any time to force an immediate resync, for example right after a colleague tells you they've just posted something.",
      "Two people can safely work in the same area at the same time. The parts of the system most exposed to simultaneous edits — inventory receipts and issues in particular — are protected at the database level so that concurrent updates are queued and applied correctly rather than one silently overwriting the other.",
      "Numbering of documents, payments and journals is allocated atomically by the database, so two people creating an invoice at the same moment can never be given the same number.",
    ],
  },
  {
    key: "security", title: "Security, Roles & Approvals", icon: "🔐",
    intro: "Access is controlled by role, every login is protected against guessing attacks, and high-value payments can require a second person's approval.",
    glossary: [
      { term: "Role", def: "OWNER (the firm's managing partner — full access to every workspace), FIRM_MANAGER / FIRM_STAFF (BPZ staff, can work inside any client workspace), CLIENT_ADMIN / CLIENT_USER / CLIENT_VIEWER (locked to one client's own workspace only)." },
      { term: "Permission", def: "A specific capability (e.g. PAY_APPROVE, PAYROLL_MANAGE, TAX_MANAGE) granted to a role or individually to a user. The server checks every action against the caller's permissions, not just the menu shown on screen." },
      { term: "Approval limit", def: "The maximum payment value a user may post without a second approval. Set per user in the Owner Console." },
      { term: "Account lockout", def: "Five failed sign-in attempts lock an account for fifteen minutes, even if the correct password is used during the lockout — this defends against automated password guessing." },
      { term: "Forgot password", def: "A user can request a reset link from the login screen; it is single-use and expires after one hour. No indication is given as to whether an email address has an account, to prevent account enumeration." },
      { term: "Temporary password", def: "Every login created by the Owner Console must be changed by the user the first time they sign in." },
    ],
  },
];

function Handbook({ ws, go }: { ws: WS; go: (t: string) => void }) {
  const [active, setActive] = useState(HANDBOOK[0].key);
  const section = HANDBOOK.find((s) => s.key === active) ?? HANDBOOK[0];
  return (
    <div className="space-y-5">
      <SectionTitle hint="A field-by-field reference for every module — what each item means, and how the pieces fit together.">
        User Handbook
      </SectionTitle>

      <div className="flex flex-wrap gap-1.5">
        {HANDBOOK.map((s) => (
          <button key={s.key} onClick={() => setActive(s.key)}
            className={`rounded-lg px-3 py-1.5 text-[16px] font-medium transition ${active === s.key ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-600 hover:bg-slate-50"}`}>
            {s.icon} {s.title}
          </button>
        ))}
      </div>

      <Card title={`${section.icon} ${section.title}`} subtitle={section.intro}
        right={section.tab && <Button size="sm" variant="ghost" onClick={() => go(section.tab!)}>Open this module →</Button>}>
        <div className="space-y-5">
          {section.glossary && (
            <div className="grid gap-3 sm:grid-cols-2">
              {section.glossary.map((g) => (
                <div key={g.term} className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                  <p className="font-display text-[15px] font-bold text-[var(--bpz-900)]">{g.term}</p>
                  <p className="mt-1 text-[16px] leading-relaxed text-slate-600">{g.def}</p>
                </div>
              ))}
            </div>
          )}
          {section.notes && (
            <ul className="space-y-2">
              {section.notes.map((n, i) => (
                <li key={i} className="flex gap-2 text-[15px] leading-relaxed text-slate-700">
                  <span className="mt-0.5 shrink-0 text-[var(--gold-700)]">●</span>{n}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Card>

      <Card title="Still unsure where to start?" tone="tint">
        <p className="text-[15px] text-slate-600">
          The <b>Setup Guide</b> walks through the twelve steps of taking a brand-new workspace from empty to fully
          reported, in order. This Handbook is the reference to come back to whenever a specific field or
          screen needs explaining.
        </p>
        <Button size="sm" variant="ghost" className="mt-2" onClick={() => go("guide")}>Open the Setup Guide →</Button>
      </Card>
    </div>
  );
}
