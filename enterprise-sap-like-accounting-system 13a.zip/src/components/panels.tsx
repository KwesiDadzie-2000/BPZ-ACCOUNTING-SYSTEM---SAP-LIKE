"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Badge, Button, Card, Empty, Field, Input, Modal, SectionTitle, Select,
  Stat, StatementTable, Table, TextArea, money, pct,
} from "./ui";

/* eslint-disable @typescript-eslint/no-explicit-any */
export type WS = any;
export type RPT = any;
export type Post = (action: string, payload?: Record<string, unknown>) => Promise<any>;

const todayStr = () => new Date().toISOString().slice(0, 10);
const curPeriod = () => { const d = new Date(); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`; };

const Grid = ({ cols = 2, children }: { cols?: number; children: React.ReactNode }) => (
  <div className={`grid gap-3 ${cols === 2 ? "sm:grid-cols-2" : cols === 3 ? "sm:grid-cols-3" : cols === 4 ? "sm:grid-cols-2 lg:grid-cols-4" : ""}`}>{children}</div>
);

// BUG FIX — "PART-PAID" contains the substring "PAID", so the previous
// ordering matched it against the green/fully-settled branch FIRST and a
// partially-paid invoice displayed the same green "fully settled" badge as a
// fully paid one everywhere in the app. Checking the more specific
// "partial/pending" states before the general "settled" states fixes it.
const statusTone = (s: string) =>
  /PART|DRAFT|UNMATCHED|PLANNED/i.test(s) ? "amber"
    : /CLOSED|LOCKED|SUSPEND|DISPOSED|VOID|REVERSED/i.test(s) ? "red"
    : /^PAID$|APPLIED|BALANCED|POSTED|MATCHED|COMPLETE|ACTIVE|OPEN$/i.test(s) ? "green" : "slate";

const fmtBytes = (n: number) => n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(2)} MB`;

/**
 * Attach supporting documents (receipts, contracts, delivery notes) to any
 * transaction — receipts, signed quotes, bank advices — without leaving the
 * record itself. Stored directly in the database (4 MB cap per file) since
 * no external object storage is configured for this deployment.
 */
function AttachButton({ refType, refNo, post, busy }: { refType: string; refNo: string; post: Post; busy: boolean }) {
  const [open, setOpen] = useState(false);
  const [list, setList] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    const r = await post("attach.list", { refType, refNo });
    if (r && !r.error) setList(r.attachments ?? []);
  };
  const onOpen = () => { setOpen(true); void load(); };

  const onFile = async (file: File) => {
    if (file.size > 4 * 1024 * 1024) { alert("Attachments are limited to 4 MB per file."); return; }
    setUploading(true);
    try {
      const buf = await file.arrayBuffer();
      const base64 = btoa(Array.from(new Uint8Array(buf)).map((b) => String.fromCharCode(b)).join(""));
      const r = await post("attach.upload", { refType, refNo, fileName: file.name, mimeType: file.type || "application/octet-stream", data: base64 });
      if (r && !r.error) await load();
    } finally { setUploading(false); }
  };

  return (
    <>
      <Button size="sm" variant="ghost" onClick={onOpen}>📎 {list.length > 0 ? list.length : ""}</Button>
      <Modal open={open} title={`Attachments — ${refNo}`} onClose={() => setOpen(false)}>
        <div className="space-y-3">
          <label className="flex cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-[15px] text-slate-600 hover:border-[var(--bpz-500)] hover:bg-[var(--bpz-50)]">
            {uploading ? "Uploading…" : "Click to choose a file (receipt, contract, delivery note) — max 4 MB"}
            <input type="file" className="hidden" disabled={uploading || busy}
              onChange={(e) => { const f = e.target.files?.[0]; if (f) void onFile(f); e.target.value = ""; }} />
          </label>
          <Table cols={["File", "Size", "Uploaded by", "When", ""]}
            rows={list.map((a) => [
              <a key="f" href={`/api/attachment?id=${a.id}`} target="_blank" rel="noreferrer" className="text-[var(--bpz-700)] underline">{a.fileName}</a>,
              fmtBytes(a.sizeBytes), a.uploadedBy, new Date(a.uploadedAt).toLocaleString(),
              <Button key="d" size="sm" variant="ghost" disabled={busy} onClick={() => post("attach.delete", { id: a.id }).then(load)}>✕</Button>,
            ])}
            empty="No files attached yet" />
        </div>
      </Modal>
    </>
  );
}

/* ==================== DASHBOARD ==================== */
export function Dashboard({ ws, rpt, post, busy, go }: { ws: WS; rpt: RPT; post: Post; busy: boolean; go: (t: string) => void }) {
  const k = rpt?.kpis ?? {};
  const bal = rpt?.balanceSheet?.totals;
  const ccy = ws?.client?.currency ?? "GHS";
  const fx = (ws?.fxRates ?? []).filter((r: any) => r.currency !== "GHS").slice(0, 6);
  const openPeriods = (ws?.periods ?? []).filter((p: any) => p.status === "OPEN").length;

  return (
    <div className="space-y-5">
      <SectionTitle hint={`${ws?.client?.name ?? ""} · ${ws?.client?.sector ?? ""} · reporting in ${ccy}`}>Executive Dashboard</SectionTitle>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <Stat icon="💰" label="Revenue" value={money(k.revenue)} sub={`Gross margin ${pct(k.grossMargin ?? 0)}`} tone="blue" />
        <Stat icon="📈" label="Operating profit" value={money(k.operatingProfit)} sub={`Margin ${pct(k.operatingMargin ?? 0)}`} tone={(k.operatingProfit ?? 0) >= 0 ? "green" : "red"} />
        <Stat icon="🏦" label="Net profit" value={money(k.netProfit)} sub={`Margin ${pct(k.netMargin ?? 0)}`} tone={(k.netProfit ?? 0) >= 0 ? "green" : "red"} />
        <Stat icon="🏛" label="Total assets" value={money(k.totalAssets)} sub={`Equity ${money(k.totalEquity)}`} />
        <Stat icon="💵" label="Cash & equivalents" value={money(k.cash)} sub={`Working capital ${money(k.workingCapital)}`} tone="gold" />
        <Stat icon="⚖️" label="Current ratio" value={`${(k.currentRatio ?? 0).toFixed(2)}x`} sub={`Quick ${(k.quickRatio ?? 0).toFixed(2)}x`} />
      </div>

      <div className={`rounded-xl px-4 py-2.5 text-[15px] font-medium ${bal?.balanced ? "bg-emerald-50 text-emerald-800" : "bg-rose-50 text-rose-800"}`}>
        {bal?.balanced ? "✓ Statement of financial position balances" : `✕ Balance sheet out of balance by ${money(bal?.difference)}`}
        {" — "}Assets {money(bal?.totalAssets)} vs Equity + Liabilities {money(bal?.equityAndLiabilities)} · {openPeriods} open fiscal periods
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Receivables ageing" subtitle="Click through to the Reports desk for detail">
          <Table cols={["Bucket", { h: "Amount", align: "right" }]} dense
            rows={[["Current", money(rpt?.arAgeing?.totals?.current)], ["1–30 days", money(rpt?.arAgeing?.totals?.d30)],
            ["31–60 days", money(rpt?.arAgeing?.totals?.d60)], ["61–90 days", money(rpt?.arAgeing?.totals?.d90)],
            ["90+ days", money(rpt?.arAgeing?.totals?.d120)], [<b key="t">Total</b>, <b key="v">{money(rpt?.arAgeing?.totals?.total)}</b>]]} />
          <p className="mt-2 text-[14px] text-slate-600">Debtor days (DSO): <b>{(k.dso ?? 0).toFixed(0)}</b></p>
        </Card>
        <Card title="Payables ageing">
          <Table cols={["Bucket", { h: "Amount", align: "right" }]} dense
            rows={[["Current", money(rpt?.apAgeing?.totals?.current)], ["1–30 days", money(rpt?.apAgeing?.totals?.d30)],
            ["31–60 days", money(rpt?.apAgeing?.totals?.d60)], ["61–90 days", money(rpt?.apAgeing?.totals?.d90)],
            ["90+ days", money(rpt?.apAgeing?.totals?.d120)], [<b key="t">Total</b>, <b key="v">{money(rpt?.apAgeing?.totals?.total)}</b>]]} />
          <p className="mt-2 text-[14px] text-slate-600">Creditor days (DPO): <b>{(k.dpo ?? 0).toFixed(0)}</b></p>
        </Card>
        <Card title="Live exchange rates" subtitle="Bank of Ghana mid rate, refreshed daily"
          right={<Button size="sm" variant="ghost" disabled={busy} onClick={() => post("fx.refresh")}>↻ Refresh</Button>}>
          <Table cols={["Currency", { h: "GHS per unit", align: "right" }, "Source"]} dense maxH="max-h-56"
            rows={fx.map((r: any) => [r.currency, money(r.midRate, 4), <Badge key="s" tone={r.source === "BOG" ? "green" : "amber"}>{r.source}</Badge>])}
            empty="Rates loading" />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Activity by module">
          <Table cols={["Module", { h: "Debits", align: "right" }, { h: "Credits", align: "right" }, { h: "Docs", align: "right" }]} dense
            rows={(rpt?.byModule ?? []).map((m: any) => [m.key, money(m.debits), money(m.credits), m.docs])} empty="No postings yet" />
        </Card>
        <Card title="Cost centre performance">
          <Table cols={["Cost centre", { h: "Debits", align: "right" }, { h: "Credits", align: "right" }, { h: "Net", align: "right" }]} dense
            rows={(rpt?.byCostCenter ?? []).map((c: any) => [
              `${c.key} · ${(ws?.costCenters ?? []).find((x: any) => x.ccCode === c.key)?.ccName ?? ""}`,
              money(c.debits), money(c.credits), money(c.net)])} empty="No cost centre activity" />
        </Card>
      </div>

      <ControlExceptions ws={ws} rpt={rpt} go={go} />

      <Card title="Quick actions">
        <div className="flex flex-wrap gap-2">
          {[["sales", "🧾 Raise an invoice"], ["payments", "💳 Make a payment"], ["banking", "🏦 Import a statement"],
            ["payroll", "👥 Run payroll"], ["close", "📅 Month-end close"], ["reports", "📊 Financial statements"]]
            .map(([t, l]) => <Button key={t} variant="ghost" onClick={() => go(t)}>{l}</Button>)}
          <Button variant="gold" disabled={busy} onClick={() => post("demo.seed")}>✨ Load demonstration data</Button>
        </div>
      </Card>
    </div>
  );
}

/** Continuous-control monitor: the exception list a reviewer should clear daily. */
function ControlExceptions({ ws, rpt, go }: { ws: WS; rpt: RPT; go: (t: string) => void }) {
  const k = rpt?.kpis ?? {};
  const bs = rpt?.balanceSheet?.totals;
  const tb = rpt?.trialBalance ?? [];
  const bal = (acct: string) => Math.abs(tb.find((r: any) => r.accountNo === acct)?.closing ?? 0);
  const unmatched = (ws?.statementLines ?? []).filter((l: any) => l.status === "UNMATCHED").length;
  const unpostedDocs = (ws?.tradeDocs ?? []).filter((d: any) => !d.glDoc && !["QUOTE", "SO", "PO"].includes(d.docKind)).length;
  const openRecs = (ws?.bankRecs ?? []).filter((r: any) => Math.abs(Number(r.difference)) > 0.01).length;
  const nrv = (rpt?.inventory ?? []).filter((m: any) => m.writedown > 0).length;
  const openPeriodsPast = (ws?.periods ?? []).filter((p: any) => p.status === "OPEN" && p.endDate < new Date().toISOString().slice(0, 10)).length;

  const items = [
    { ok: bs?.balanced, bad: `Balance sheet out of balance by ${money(bs?.difference)}`, good: "Balance sheet balances", tab: "reports" },
    { ok: !k.overdrawn, bad: `Bank and cash overdrawn by ${money(Math.abs(k.cash ?? 0))}`, good: "Cash position positive", tab: "banking" },
    { ok: bal("990100") < 0.01, bad: `Suspense account 990100 holds ${money(bal("990100"))}`, good: "Suspense account clear", tab: "gl" },
    { ok: bal("990200") < 0.01, bad: `Opening balance equity 990200 holds ${money(bal("990200"))}`, good: "Opening balance equity clear", tab: "gl" },
    { ok: bal("149000") < 0.01, bad: `Bank suspense 149000 holds ${money(bal("149000"))}`, good: "No unidentified bank receipts", tab: "banking" },
    { ok: bal("410200") < 0.01, bad: `GR/IR clearing holds ${money(bal("410200"))}`, good: "GR/IR clearing settled", tab: "purch" },
    { ok: unmatched === 0, bad: `${unmatched} bank statement line(s) unmatched`, good: "All statement lines cleared", tab: "banking" },
    { ok: unpostedDocs === 0, bad: `${unpostedDocs} document(s) not posted to the ledger`, good: "All documents posted", tab: "sales" },
    { ok: openRecs === 0, bad: `${openRecs} bank reconciliation(s) not balanced`, good: "Reconciliations balanced", tab: "banking" },
    { ok: nrv === 0, bad: `${nrv} stock item(s) carried above net realisable value`, good: "Inventory within NRV", tab: "inventory" },
    { ok: (k.overdueReceivables ?? 0) === 0, bad: `${money(k.overdueReceivables)} of receivables past due`, good: "No overdue receivables", tab: "reports" },
    { ok: openPeriodsPast <= 1, bad: `${openPeriodsPast} past period(s) still open`, good: "Period control current", tab: "close" },
  ];
  const fails = items.filter((i) => !i.ok);

  return (
    <Card title="Control exceptions" subtitle="Continuous close monitor — clear these before reporting the period."
      right={<Badge tone={fails.length === 0 ? "green" : fails.length > 4 ? "red" : "amber"}>
        {fails.length === 0 ? "All clear" : `${fails.length} to review`}</Badge>}>
      {fails.length === 0 ? (
        <p className="rounded-lg bg-emerald-50 px-3 py-2 text-[15px] text-emerald-800">
          ✓ Every control check passed. The ledger is clean and ready to report.
        </p>
      ) : (
        <div className="grid gap-1.5 sm:grid-cols-2">
          {fails.map((f, i) => (
            <button key={i} onClick={() => go(f.tab)}
              className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50/70 px-2.5 py-1.5 text-left text-[16px] text-amber-900 hover:bg-amber-100">
              <span className="mt-px">⚠</span><span className="flex-1">{f.bad}</span><span className="text-amber-600">→</span>
            </button>
          ))}
        </div>
      )}
    </Card>
  );
}

/* ==================== TRADE (SALES / PURCHASES) ==================== */
export function TradeDesk({ ws, post, busy, side }: { ws: WS; post: Post; busy: boolean; side: "AR" | "AP" }) {
  const isAR = side === "AR";
  const [mode, setMode] = useState<"SUPPLIER" | "DIRECT">("SUPPLIER");
  const kinds = isAR
    ? [["QUOTE", "Quotation / Estimate"], ["SO", "Sales Order"], ["SINV", "Sales Invoice"], ["SCN", "Credit Note"], ["SDN", "Debit Note"]]
    : [["PO", "Purchase Order"], ["PINV", "Purchase Invoice"], ["PCN", "Credit Note"], ["PDN", "Debit Note"]];
  const [kind, setKind] = useState(isAR ? "SINV" : "PINV");
  const [bp, setBp] = useState("");
  const [docDate, setDocDate] = useState(todayStr());
  const [ccy, setCcy] = useState(ws?.client?.currency ?? "GHS");
  const [cc, setCc] = useState("");
  const [narr, setNarr] = useState("");
  const blankLine = () => ({ lineType: "SERVICE", description: "", qty: 1, unitPrice: 0, discount: 0, taxCode: "STD", account: "", materialNo: "" });
  const [lines, setLines] = useState([blankLine()]);

  const partnersList = (ws?.partners ?? []).filter((p: any) => p.type === (isAR ? "Customer" : "Vendor") && p.active !== false);
  const revAccts = (ws?.accounts ?? []).filter((a: any) => a.active !== false && (isAR ? a.type === "Revenue" : a.type === "Expense" || a.subType === "INVENTORY"));
  const vat = (ws?.reference?.vatCodes ?? []);
  const selectedBp = partnersList.find((p: any) => p.bpNo === bp);

  const totals = useMemo(() => {
    let net = 0, tax = 0;
    for (const l of lines) {
      const n = (Number(l.qty) || 0) * (Number(l.unitPrice) || 0) - (Number(l.discount) || 0);
      const def = vat.find((v: any) => v.code === l.taxCode);
      net += n; tax += (n * ((def?.rate ?? 0) + (def?.levy ?? 0))) / 100;
    }
    return { net: Math.round(net * 100) / 100, tax: Math.round(tax * 100) / 100, gross: Math.round((net + tax) * 100) / 100 };
  }, [lines, vat]);

  const set = (i: number, patch: Record<string, unknown>) =>
    setLines((ls) => ls.map((l, x) => (x === i ? { ...l, ...patch } : l)));

  const docs = (ws?.tradeDocs ?? []).filter((d: any) => d.side === side);

  return (
    <div className="space-y-5">
      <SectionTitle hint={isAR ? "Quotations, orders, invoices, credit and debit notes — VAT at 20% with no cascading."
        : "Purchase orders, supplier invoices and adjustment notes with recoverable input VAT."}>
        {isAR ? "Sales & Receivables" : "Purchases & Payables"}
      </SectionTitle>

      {!isAR && (
        <>
          <div className="flex flex-wrap gap-1.5">
            <button onClick={() => setMode("SUPPLIER")}
              className={`rounded-lg px-3.5 py-2 text-[15px] font-semibold transition ${mode === "SUPPLIER" ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}>
              📦 Supplier Purchase
            </button>
            <button onClick={() => setMode("DIRECT")}
              className={`rounded-lg px-3.5 py-2 text-[15px] font-semibold transition ${mode === "DIRECT" ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}>
              🏛 Direct / Statutory Invoice
            </button>
          </div>

          {mode === "SUPPLIER" ? (
            <div className="rounded-xl border border-[var(--bpz-100)] bg-[var(--bpz-50)] px-4 py-3 text-[16px] leading-relaxed text-slate-600">
              <b className="text-[var(--bpz-900)]">Not every bill needs a Purchase Order.</b> Use a Purchase Order only when you want to
              commit to a supplier before goods or services arrive (useful for stock purchases and large contracts). For rent,
              subscriptions, professional fees and other genuine supplier bills — pick <b>Purchase Invoice</b> directly
              below and post it straight away; nothing forces you through the order step first.
            </div>
          ) : (
            <div className="rounded-xl border border-[var(--gold-600)]/30 bg-[var(--gold-100)] px-4 py-3 text-[16px] leading-relaxed text-slate-700">
              <b className="text-[var(--bpz-900)]">For bills that never go through procurement.</b> Utility bills, insurance
              premiums, regulatory fees and permits, and penalties or fines are recognised here as a payable the moment the bill
              or assessment arrives — no purchase order, no goods receipt. The invoice then appears in the Payment Desk's open
              items, ready to be settled in full or in part, exactly like a supplier invoice.
            </div>
          )}
        </>
      )}

      {!isAR && mode === "DIRECT" ? (
        <DirectInvoiceForm ws={ws} post={post} busy={busy} />
      ) : (
      <Card title={`Create ${isAR ? "a sales" : "a purchase"} document`}
        subtitle="Required: a document type, a partner, and at least one line with a value greater than zero.">
        <Grid cols={4}>
          <Field label="Document type" hint={isAR ? "Quote and Order do not post to the ledger; Invoice, Credit Note and Debit Note do." : "Order does not post to the ledger; Invoice, Credit Note and Debit Note do."}>
            <Select value={kind} onChange={(e) => setKind(e.target.value)}>
              {kinds.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></Field>
          <Field label={isAR ? "Customer" : "Supplier"} hint={selectedBp ? `${selectedBp.isResident ? "Resident" : "Non-resident"}${selectedBp.whtCode ? ` · WHT code ${selectedBp.whtCode}` : " · no WHT code set"}` : "Business partners are set up once in Master Data and reused on every document."}>
            <Select value={bp} onChange={(e) => setBp(e.target.value)}>
              <option value="">— select —</option>
              {partnersList.map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.bpNo} · {p.name}</option>)}</Select></Field>
          <Field label="Document date"><Input type="date" value={docDate} onChange={(e) => setDocDate(e.target.value)} /></Field>
          <Field label="Currency" hint={ccy !== (ws?.client?.currency ?? "GHS") ? "Converted to GHS at the Bank of Ghana rate for the document date." : undefined}>
            <Select value={ccy} onChange={(e) => setCcy(e.target.value)}>
              {(ws?.reference?.currencies ?? ["GHS"]).map((c: string) => <option key={c}>{c}</option>)}</Select></Field>
          <Field label="Cost centre" hint="Optional. Tags this document to a department/project for the cost-centre report — leave blank for general overhead.">
            <Select value={cc} onChange={(e) => setCc(e.target.value)}>
              <option value="">—</option>
              {(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode} · {c.ccName}</option>)}</Select></Field>
          <Field label="Narrative" className="sm:col-span-3"><Input value={narr} onChange={(e) => setNarr(e.target.value)} placeholder="Reference / description" /></Field>
        </Grid>

        <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[16px] leading-relaxed text-slate-600">
          Each line is either a <b>Material/Goods</b> line — picked from your stock items, which updates inventory quantities and
          cost automatically — or a <b>Service</b> line, for anything with no stock (consulting, rent, utilities, professional
          fees, software, repairs). Service lines post straight to the G/L account you choose and never touch inventory.
        </div>

        <div className="scroll-thin mt-3 overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-[16px]">
            <thead className="bg-[var(--bpz-50)] text-[13px] uppercase tracking-wide text-[var(--bpz-800)]">
              <tr>{["Type", "Description", "Material / Item", "G/L account", "Qty", "Unit price", "Discount", "Tax code", "Line total", ""]
                .map((h) => <th key={h} className="px-2 py-2 text-left font-bold">{h}</th>)}</tr>
            </thead>
            <tbody>
              {lines.map((l: any, i) => {
                const n = (Number(l.qty) || 0) * (Number(l.unitPrice) || 0) - (Number(l.discount) || 0);
                const def = vat.find((v: any) => v.code === l.taxCode);
                const isGoods = l.lineType === "GOODS";
                return (
                  <tr key={i} className="border-t border-slate-100">
                    <td className="px-1.5 py-1 w-28">
                      <Select value={l.lineType} onChange={(e) => set(i, { lineType: e.target.value, materialNo: e.target.value === "SERVICE" ? "" : l.materialNo })}>
                        <option value="SERVICE">Service</option>
                        <option value="GOODS">Material / Goods</option>
                      </Select>
                    </td>
                    <td className="px-1.5 py-1 min-w-[180px]"><Input value={l.description} onChange={(e) => set(i, { description: e.target.value })} placeholder={isGoods ? "Item description" : "e.g. Consulting fees, rent, utilities"} /></td>
                    <td className="px-1.5 py-1">
                      {isGoods ? (
                        <Select value={l.materialNo} onChange={(e) => {
                          const mat = (ws?.materials ?? []).find((m: any) => m.materialNo === e.target.value);
                          set(i, { materialNo: e.target.value, unitPrice: mat ? Number(isAR ? mat.salesPrice : mat.stdPrice) || l.unitPrice : l.unitPrice });
                        }}>
                          <option value="">— select a stock item —</option>
                          {(ws?.materials ?? []).filter((m: any) => m.active !== false).map((m: any) => <option key={m.materialNo} value={m.materialNo}>{m.materialNo} · {m.description}</option>)}
                        </Select>
                      ) : <span className="block px-1 text-[14px] text-slate-600">No stock item — service line</span>}
                    </td>
                    <td className="px-1.5 py-1 min-w-[150px]"><Select value={l.account} onChange={(e) => set(i, { account: e.target.value })}>
                      <option value="">{isGoods ? "Default (inventory/COGS)" : "Choose an account"}</option>{revAccts.map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description.slice(0, 28)}</option>)}</Select></td>
                    <td className="px-1.5 py-1 w-20"><Input type="number" step="0.01" value={l.qty} onChange={(e) => set(i, { qty: Number(e.target.value) })} /></td>
                    <td className="px-1.5 py-1 w-28"><Input type="number" step="0.01" value={l.unitPrice} onChange={(e) => set(i, { unitPrice: Number(e.target.value) })} /></td>
                    <td className="px-1.5 py-1 w-24"><Input type="number" step="0.01" value={l.discount} onChange={(e) => set(i, { discount: Number(e.target.value) })} /></td>
                    <td className="px-1.5 py-1 w-32"><Select value={l.taxCode} onChange={(e) => set(i, { taxCode: e.target.value })}>
                      {vat.map((v: any) => <option key={v.code} value={v.code}>{v.code} ({v.rate}%)</option>)}</Select></td>
                    <td className="tnum px-2 py-1 text-right font-medium">{money(n * (1 + ((def?.rate ?? 0) + (def?.levy ?? 0)) / 100))}</td>
                    <td className="px-1 py-1"><Button size="sm" variant="ghost" onClick={() => setLines((ls) => ls.filter((_, x) => x !== i))}>✕</Button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Button variant="ghost" onClick={() => setLines((ls) => [...ls, blankLine()])}>+ Add line</Button>
          <div className="tnum ml-auto flex gap-4 text-[15px]">
            <span>Net <b>{money(totals.net)}</b></span>
            <span>VAT &amp; levies <b>{money(totals.tax)}</b></span>
            <span className="text-[var(--bpz-800)]">Gross <b>{money(totals.gross)}</b></span>
          </div>
          <Button variant="gold" disabled={busy || !bp || totals.gross <= 0}
            onClick={() => post("trade.create", { docKind: kind, bp, docDate, currency: ccy, costCenter: cc, narrative: narr, lines: lines.map(({ lineType, ...rest }: any) => rest) })}>
            Create &amp; post document
          </Button>
        </div>
      </Card>
      )}

      <Card title={`${isAR ? "Sales" : "Purchase"} document register`} subtitle={isAR ? "Convert quotes to orders and orders to invoices; settle from the Payment Desk." : "Includes both supplier purchases and direct/statutory invoices; settle any of them from the Payment Desk."}>
        <Table cols={["Document", "Type", "Partner", "Date", "Due", "Ccy", { h: "Net", align: "right" }, { h: "VAT", align: "right" }, { h: "Gross", align: "right" }, { h: "Settled", align: "right" }, "Status", "Actions"]}
          rows={docs.map((d: any) => [
            d.docNo, <Badge key="k" tone={d.docKind === "DINV" ? "gold" : "blue"}>{d.docKind}</Badge>, d.bp, d.docDate, d.dueDate, d.currency,
            money(d.netAmount), money(d.vatAmount), money(d.grossAmount), money(d.settled),
            <Badge key="s" tone={statusTone(d.status)}>{d.status}</Badge>,
            <span key="a" className="flex gap-1">
              {["QUOTE", "SO", "PO"].includes(d.docKind) && (
                <Button size="sm" variant="ghost" disabled={busy}
                  onClick={() => post("trade.convert", { docNo: d.docNo, toKind: d.docKind === "QUOTE" ? "SO" : d.docKind === "SO" ? "SINV" : "PINV" })}>
                  → {d.docKind === "QUOTE" ? "Order" : "Invoice"}
                </Button>)}
              {!d.glDoc && !["QUOTE", "SO", "PO"].includes(d.docKind) && (
                <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("trade.post", { docNo: d.docNo })}>Post</Button>)}
              <a href={`/api/pdf?docNo=${encodeURIComponent(d.docNo)}`} target="_blank" rel="noreferrer"
                className="inline-flex items-center rounded-lg border border-slate-300 bg-white px-2 py-1 text-[14px] font-medium text-slate-700 hover:bg-slate-50">
                PDF ↗
              </a>
              <AttachButton refType="TRADE_DOC" refNo={d.docNo} post={post} busy={busy} />
            </span>,
          ])}
          empty={`No ${isAR ? "sales" : "purchase"} documents yet`} />
      </Card>
    </div>
  );
}

/**
 * Raises a payable for a bill or assessment that never goes through
 * procurement — utilities, insurance, regulatory fees/permits, penalties and
 * fines, and any other statutory item that is billed rather than
 * self-assessed. This creates a real document (DINV) that behaves exactly
 * like a supplier invoice from here on: it appears in the Payment Desk's
 * open items and can be settled in full or in part, with withholding tax
 * applied automatically if the payee's record calls for it (e.g. a premium
 * paid to a non-resident insurer).
 */
function DirectInvoiceForm({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const categories: any[] = (ws?.reference?.directPaymentCategories ?? []).filter((c: any) => c.invoiceable);
  const [categoryKey, setCategoryKey] = useState(categories[0]?.key ?? "OTHER_DIRECT");
  const [bp, setBp] = useState("");
  const [docDate, setDocDate] = useState(todayStr());
  const [dueDate, setDueDate] = useState("");
  const [taxCode, setTaxCode] = useState("OUT");
  const [cc, setCc] = useState("");
  const [narr, setNarr] = useState("");
  const blankLine = (acct: string) => ({ description: "", qty: 1, unitPrice: 0, account: acct, taxCode: "OUT" });
  const selected = categories.find((c) => c.key === categoryKey);
  const [lines, setLines] = useState([blankLine(selected?.account ?? "")]);

  const grouped = categories.reduce((g: Record<string, any[]>, c) => ({ ...g, [c.group]: [...(g[c.group] ?? []), c] }), {});
  const vendors = (ws?.partners ?? []).filter((p: any) => p.type === "Vendor" && p.active !== false);
  const selectedBp = vendors.find((p: any) => p.bpNo === bp);
  const vat = ws?.reference?.vatCodes ?? [];

  const set = (i: number, patch: Record<string, unknown>) => setLines((ls) => ls.map((l, x) => (x === i ? { ...l, ...patch } : l)));

  const totals = useMemo(() => {
    let net = 0, tax = 0;
    for (const l of lines) {
      const n = (Number(l.qty) || 0) * (Number(l.unitPrice) || 0);
      const def = vat.find((v: any) => v.code === l.taxCode);
      net += n; tax += (n * ((def?.rate ?? 0) + (def?.levy ?? 0))) / 100;
    }
    return { net: r2two(net), tax: r2two(tax), gross: r2two(net + tax) };
  }, [lines, vat]);

  return (
    <Card title="Raise a direct / statutory invoice" subtitle="Required: a category, a payee, and at least one line with a value greater than zero.">
      <Grid cols={4}>
        <Field label="Category" className="sm:col-span-2" hint={selected?.hint}>
          <Select value={categoryKey} onChange={(e) => {
            const c = categories.find((x) => x.key === e.target.value);
            setCategoryKey(e.target.value);
            setLines((ls) => ls.map((l) => (l.account === selected?.account ? { ...l, account: c?.account ?? "" } : l)));
          }}>
            {Object.entries(grouped).map(([grp, list]) => (
              <optgroup key={grp} label={grp}>{(list as any[]).map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}</optgroup>
            ))}
          </Select>
        </Field>
        <Field label="Payee" hint={selectedBp ? `${selectedBp.isResident ? "Resident" : "Non-resident"}${selectedBp.whtCode ? ` · WHT code ${selectedBp.whtCode} applies at payment` : " · no WHT applies"}` : "Choose the insurer, utility company or regulator from your vendor list — add one in Master Data if it isn't there yet."}>
          <Select value={bp} onChange={(e) => setBp(e.target.value)}>
            <option value="">— select a vendor —</option>
            {vendors.map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.bpNo} · {p.name}</option>)}
          </Select>
        </Field>
        <Field label="Invoice / assessment date"><Input type="date" value={docDate} onChange={(e) => setDocDate(e.target.value)} /></Field>
        <Field label="Due date" hint="Leave blank to use the payee's default credit terms."><Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></Field>
        <Field label="Cost centre"><Select value={cc} onChange={(e) => setCc(e.target.value)}>
          <option value="">—</option>
          {(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode} · {c.ccName}</option>)}
        </Select></Field>
        <Field label="Reference / narrative" className="sm:col-span-2"><Input value={narr} onChange={(e) => setNarr(e.target.value)} placeholder="e.g. Electricity bill account 123456, October 2026" /></Field>
      </Grid>

      <div className="scroll-thin mt-4 overflow-x-auto rounded-lg border border-slate-200">
        <table className="w-full text-[13px]">
          <thead className="bg-[var(--bpz-50)] text-[12.5px] uppercase tracking-wide text-[var(--bpz-800)]">
            <tr>{["Description", "G/L account", "Amount", "Tax code", "Line total", ""].map((h) => <th key={h} className="px-2 py-2 text-left font-bold">{h}</th>)}</tr>
          </thead>
          <tbody>
            {lines.map((l, i) => {
              const def = vat.find((v: any) => v.code === l.taxCode);
              const n = (Number(l.qty) || 0) * (Number(l.unitPrice) || 0);
              return (
                <tr key={i} className="border-t border-slate-100">
                  <td className="px-1.5 py-1 min-w-[220px]"><Input value={l.description} onChange={(e) => set(i, { description: e.target.value })} placeholder={selected?.label} /></td>
                  <td className="px-1.5 py-1 min-w-[180px]"><Select value={l.account} onChange={(e) => set(i, { account: e.target.value })}>
                    <option value="">— select —</option>
                    {(ws?.accounts ?? []).filter((a: any) => a.active !== false).map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}
                  </Select></td>
                  <td className="px-1.5 py-1 w-32"><Input type="number" step="0.01" value={l.unitPrice} onChange={(e) => set(i, { unitPrice: Number(e.target.value) })} /></td>
                  <td className="px-1.5 py-1 w-40"><Select value={l.taxCode} onChange={(e) => set(i, { taxCode: e.target.value })}>
                    {vat.map((v: any) => <option key={v.code} value={v.code}>{v.code} ({v.rate}%)</option>)}
                  </Select></td>
                  <td className="tnum px-2 py-1 text-right font-medium">{money(n * (1 + ((def?.rate ?? 0) + (def?.levy ?? 0)) / 100))}</td>
                  <td className="px-1 py-1"><Button size="sm" variant="ghost" onClick={() => setLines((ls) => ls.filter((_, x) => x !== i))}>✕</Button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-3">
        <Button variant="ghost" onClick={() => setLines((ls) => [...ls, blankLine(selected?.account ?? "")])}>+ Add line</Button>
        <div className="tnum ml-auto flex gap-4 text-[15px]">
          <span>Net <b>{money(totals.net)}</b></span>
          <span>VAT &amp; levies <b>{money(totals.tax)}</b></span>
          <span className="text-[var(--bpz-800)]">Gross <b>{money(totals.gross)}</b></span>
        </div>
        <Button variant="gold" disabled={busy || !bp || totals.gross <= 0}
          onClick={() => post("trade.create", {
            docKind: "DINV", bp, docDate, dueDate: dueDate || undefined, costCenter: cc, narrative: narr || selected?.label,
            lines: lines.map((l) => ({ description: l.description || selected?.label, qty: l.qty, unitPrice: l.unitPrice, account: l.account, taxCode: l.taxCode })),
          }).then((r) => { if (r && !r.error) { setLines([blankLine(selected?.account ?? "")]); setNarr(""); } })}>
          Raise invoice &amp; recognise payable
        </Button>
      </div>
      <p className="mt-3 text-[13px] text-slate-600">
        This creates the payable only — go to the Payment Desk to pay it, in full or in part, whenever you're ready.
      </p>
    </Card>
  );
}

/* ==================== PAYMENT DESK ==================== */
export function PaymentDesk({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [mode, setMode] = useState<"TRADE" | "DIRECT">("TRADE");
  const [direction, setDirection] = useState<"OUT" | "IN">("OUT");
  const [bp, setBp] = useState("");
  const [bank, setBank] = useState(ws?.bankAccounts?.[0]?.bankCode ?? "");
  const [payDate, setPayDate] = useState(todayStr());
  const [whtCode, setWhtCode] = useState("");
  const [whtOverride, setWhtOverride] = useState("");
  const [alloc, setAlloc] = useState<Record<string, string>>({});
  const [onAccountAmount, setOnAccountAmount] = useState("");
  const [narr, setNarr] = useState("");
  const myLimit = Number(ws?.user?.approvalLimit ?? 0);
  const canApprove = (ws?.user?.permissions ?? []).includes("PAY_APPROVE") || ws?.user?.role === "OWNER";

  const side = direction === "OUT" ? "AP" : "AR";
  const items = (ws?.openItems ?? []).filter((i: any) => i.side === side && (!bp || i.bp === bp));
  const partnersList = (ws?.partners ?? []).filter((p: any) => p.type === (direction === "OUT" ? "Vendor" : "Customer") && p.active !== false);
  const selectedBp = partnersList.find((p: any) => p.bpNo === bp);
  const whtList = (ws?.reference?.whtRates ?? []).filter((w: any) =>
    !selectedBp ? true : selectedBp.isResident ? w.residency === "RESIDENT" : w.residency === "NON_RESIDENT");

  const allocations = Object.entries(alloc)
    .map(([docNo, v]) => ({ docNo, amount: Number(v) || 0 }))
    .filter((a) => a.amount > 0);
  const onAccount = Number(onAccountAmount) || 0;
  const gross = r2two(allocations.reduce((s, a) => s + a.amount, 0) + onAccount);
  const effRate = whtOverride !== "" ? Number(whtOverride) : (whtList.find((w: any) => w.code === whtCode)?.rate ?? 0);
  const vatRate = 20;
  const approxNet = gross / (1 + vatRate / 100);
  const whtAmt = direction === "OUT" && whtCode ? Math.round(approxNet * effRate) / 100 : 0;
  const overLimit = !canApprove && gross > myLimit + 0.01;

  return (
    <div className="space-y-5">
      <SectionTitle hint="Every disbursement runs through this desk. Settle invoices in full or in part, record advances with no invoice yet, and let withholding tax and approval limits apply automatically.">
        Payment Desk
      </SectionTitle>

      {myLimit > 0 && !canApprove && (
        <div className="rounded-lg bg-[var(--bpz-50)] px-3.5 py-2 text-[16px] text-[var(--bpz-800)]">
          Your approval limit is <b>{money(myLimit)}</b>. Payments above this amount are queued for a checker to approve before they post.
        </div>
      )}

      <PendingApprovals ws={ws} post={post} busy={busy} canApprove={canApprove} />

      <div className="flex flex-wrap gap-1.5">
        <button onClick={() => setMode("TRADE")}
          className={`rounded-lg px-3.5 py-2 text-[15px] font-semibold transition ${mode === "TRADE" ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}>
          🧾 Supplier / Customer Settlement
        </button>
        <button onClick={() => setMode("DIRECT")}
          className={`rounded-lg px-3.5 py-2 text-[15px] font-semibold transition ${mode === "DIRECT" ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}>
          🏛 Direct &amp; Statutory Payment
        </button>
      </div>

      {mode === "DIRECT" ? (
        <DirectPaymentPanel ws={ws} post={post} busy={busy} myLimit={myLimit} canApprove={canApprove} />
      ) : (
      <div className="grid gap-4 xl:grid-cols-[360px_1fr]">
        <Card title="Payment header">
          <div className="space-y-3">
            <Field label="Direction"><Select value={direction} onChange={(e) => { setDirection(e.target.value as "OUT" | "IN"); setAlloc({}); setBp(""); setOnAccountAmount(""); }}>
              <option value="OUT">Outgoing — pay a supplier</option>
              <option value="IN">Incoming — receive from a customer</option></Select></Field>
            <Field label={direction === "OUT" ? "Supplier" : "Customer"}>
              <Select value={bp} onChange={(e) => { setBp(e.target.value); setAlloc({});
                const p = partnersList.find((x: any) => x.bpNo === e.target.value);
                setWhtCode(p?.whtCode ?? ""); }}>
                <option value="">— select —</option>
                {partnersList.map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.bpNo} · {p.name} {p.isResident ? "" : "(non-resident)"}</option>)}
              </Select></Field>
            <Field label="Bank account"><Select value={bank} onChange={(e) => setBank(e.target.value)}>
              {(ws?.bankAccounts ?? []).map((b: any) => <option key={b.bankCode} value={b.bankCode}>{b.bankCode} · {b.bankName} ({b.currency})</option>)}</Select></Field>
            <Field label="Payment date"><Input type="date" value={payDate} onChange={(e) => setPayDate(e.target.value)} /></Field>
            <Field label={direction === "OUT" ? "Advance to supplier (no invoice yet)" : "Deposit / retainer from customer (no invoice yet)"}
              hint="Posts to an advance or deposit control account and can be applied to a future invoice.">
              <Input type="number" step="0.01" value={onAccountAmount} onChange={(e) => setOnAccountAmount(e.target.value)} placeholder="0.00" /></Field>
            {direction === "OUT" && (
              <>
                <Field label="Withholding tax type" hint={selectedBp ? (selectedBp.isResident ? "Resident rates shown" : "Non-resident rates shown") : "Select a supplier to filter by residency"}>
                  <Select value={whtCode} onChange={(e) => setWhtCode(e.target.value)}>
                    <option value="">No withholding</option>
                    {whtList.map((w: any) => <option key={w.code} value={w.code}>{w.name} — {w.rate}%</option>)}
                  </Select></Field>
                <Field label="Override rate (%)" hint="Use for a reduced treaty rate under a DTA">
                  <Input type="number" step="0.01" value={whtOverride} onChange={(e) => setWhtOverride(e.target.value)} placeholder="Leave blank for the standard rate" /></Field>
              </>
            )}
            <Field label="Narrative"><Input value={narr} onChange={(e) => setNarr(e.target.value)} /></Field>

            <div className="rounded-lg bg-[var(--bpz-50)] p-3 text-[16px]">
              <div className="flex justify-between"><span>Gross (invoices + on account)</span><b className="tnum">{money(gross)}</b></div>
              <div className="flex justify-between text-slate-600"><span>Est. withholding @ {effRate}%</span><b className="tnum">({money(whtAmt)})</b></div>
              <div className="mt-1 flex justify-between border-t border-slate-300 pt-1 font-semibold text-[var(--bpz-900)]">
                <span>Net to {direction === "OUT" ? "pay" : "receive"}</span><b className="tnum">{money(gross - whtAmt)}</b></div>
              <p className="mt-1.5 text-[13px] text-slate-600">Final withholding, and any realised FX gain/loss on a foreign-currency invoice, are computed on the server at the exact settlement date.</p>
            </div>
            {overLimit && (
              <p className="rounded-lg bg-amber-50 px-3 py-2 text-[16px] text-amber-800">
                This exceeds your {money(myLimit)} approval limit — it will be queued for a checker rather than posted immediately.
              </p>
            )}
            <Button variant="gold" className="w-full" disabled={busy || !bp || (allocations.length === 0 && onAccount <= 0)}
              onClick={() => post("pay.create", { direction, bp, bankCode: bank, payDate, allocations, whtCode, whtRateOverride: whtOverride, narrative: narr, onAccountAmount: onAccount })
                .then((r) => { if (r && !r.error) { setAlloc({}); setOnAccountAmount(""); } })}>
              {overLimit ? "Submit for approval" : "Post payment"}
            </Button>
          </div>
        </Card>

        <Card title="Open items" subtitle="Enter any amount up to the outstanding balance to make a part payment.">
          <Table cols={["Document", "Type", "Date", "Due", { h: "Gross", align: "right" }, { h: "Settled", align: "right" }, { h: "Outstanding", align: "right" }, { h: "Allocate", align: "right" }]}
            rows={items.map((i: any) => [
              i.docNo, <Badge key="k" tone="blue">{i.docKind}</Badge>, i.docDate, i.dueDate,
              money(i.gross), money(i.settled), money(i.outstanding),
              <div key="a" className="flex items-center justify-end gap-1">
                <Input type="number" step="0.01" className="w-28 text-right" value={alloc[i.docNo] ?? ""}
                  onChange={(e) => setAlloc((a) => ({ ...a, [i.docNo]: e.target.value }))} placeholder="0.00" />
                <Button size="sm" variant="ghost" onClick={() => setAlloc((a) => ({ ...a, [i.docNo]: String(i.outstanding) }))}>Full</Button>
              </div>,
            ])}
            empty={bp ? "No open items for this partner" : "Select a partner to list open invoices"} />
        </Card>
      </div>
      )}

      {mode === "TRADE" && <ApplyCreditNote ws={ws} post={post} busy={busy} bp={bp} side={side} />}

      <Card title="Payment history & withholding tax schedule" subtitle="Both supplier/customer settlements and direct statutory payments appear here, distinguished by type.">
        <Table cols={["Payment", "Type", "Date", "Dir", "Partner / Payee", "Bank", { h: "Gross", align: "right" }, "WHT code", { h: "WHT", align: "right" }, { h: "Net paid", align: "right" }, "GL doc", ""]}
          rows={(ws?.payments ?? []).map((p: any) => [
            p.payNo,
            p.category === "DIRECT"
              ? <Badge key="c" tone="gold">{(ws?.reference?.directPaymentCategories ?? []).find((c: any) => c.key === p.directCategory)?.label ?? "Direct"}</Badge>
              : <Badge key="c" tone="blue">Supplier / Customer</Badge>,
            p.payDate, <Badge key="d" tone={p.direction === "OUT" ? "red" : "green"}>{p.direction}</Badge>,
            p.category === "DIRECT" ? (p.payeeName || p.bp || "—") : p.bp,
            p.bankAccount, money(p.grossAmount), p.whtCode || "—",
            money(p.whtAmount), money(p.netPaid), p.glDoc,
            <AttachButton key="att" refType="PAYMENT" refNo={p.payNo} post={post} busy={busy} />])}
          empty="No payments recorded" />
      </Card>
    </div>
  );
}

const r2two = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/**
 * Utilities, every form of tax and statutory remittance, pension and
 * provident fund contributions, insurance premiums, other regulatory
 * payments, and penalties or fines never pass through procurement — there is
 * no purchase order and usually no vendor invoice behind them. This panel
 * posts them straight to the correct account against the bank.
 */
function DirectPaymentPanel({ ws, post, busy, myLimit, canApprove }: {
  ws: WS; post: Post; busy: boolean; myLimit: number; canApprove: boolean;
}) {
  const categories: any[] = ws?.reference?.directPaymentCategories ?? [];
  const [direction, setDirection] = useState<"OUT" | "IN">("OUT");
  const [categoryKey, setCategoryKey] = useState(categories[0]?.key ?? "OTHER_DIRECT");
  const [account, setAccount] = useState(categories[0]?.account ?? "");
  const [bank, setBank] = useState(ws?.bankAccounts?.[0]?.bankCode ?? "");
  const [payDate, setPayDate] = useState(todayStr());
  const [amount, setAmount] = useState("");
  const [bp, setBp] = useState("");
  const [payeeName, setPayeeName] = useState("");
  const [narr, setNarr] = useState("");

  const selected = categories.find((c) => c.key === categoryKey);
  const grouped = categories.reduce((g: Record<string, any[]>, c) => ({ ...g, [c.group]: [...(g[c.group] ?? []), c] }), {});
  const amt = Number(amount) || 0;
  const overLimit = !canApprove && amt > myLimit + 0.01;
  const suggestedBp = (ws?.partners ?? []).find((p: any) => p.bpNo === selected?.suggestedBp);

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-[var(--gold-600)]/30 bg-[var(--gold-100)] px-4 py-3 text-[16px] leading-relaxed text-slate-700">
        <b className="text-[var(--bpz-900)]">No procurement document is created here.</b> Utility bills, PAYE/VAT/WHT/CIT
        remittances, SSNIT and provident fund contributions, insurance premiums, regulatory fees and
        penalties post straight to the ledger against the bank — exactly as an accounts department
        would raise a payment voucher, with no purchase order or supplier invoice in between.
      </div>

      <Card title="Direct or statutory payment">
        <Grid cols={4}>
          <Field label="Direction"><Select value={direction} onChange={(e) => setDirection(e.target.value as "OUT" | "IN")}>
            <option value="OUT">Outgoing payment</option>
            <option value="IN">Incoming receipt (e.g. a refund)</option>
          </Select></Field>
          <Field label="Category" className="sm:col-span-2" hint={selected?.hint}>
            <Select value={categoryKey} onChange={(e) => {
              const c = categories.find((x) => x.key === e.target.value);
              setCategoryKey(e.target.value); setAccount(c?.account ?? "");
            }}>
              {Object.entries(grouped).map(([grp, list]) => (
                <optgroup key={grp} label={grp}>{(list as any[]).map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}</optgroup>
              ))}
            </Select>
          </Field>
          <Field label="Payment date"><Input type="date" value={payDate} onChange={(e) => setPayDate(e.target.value)} /></Field>
          <Field label="G/L account" hint="Pre-filled from the category — change it if a different account applies.">
            <Select value={account} onChange={(e) => setAccount(e.target.value)}>
              <option value="">— select —</option>
              {(ws?.accounts ?? []).filter((a: any) => a.active !== false).map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}
            </Select>
          </Field>
          <Field label="Bank account"><Select value={bank} onChange={(e) => setBank(e.target.value)}>
            {(ws?.bankAccounts ?? []).map((b: any) => <option key={b.bankCode} value={b.bankCode}>{b.bankCode} · {b.bankName}</option>)}
          </Select></Field>
          <Field label="Amount"><Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" /></Field>
          <Field label="Pay to (optional)" hint={suggestedBp ? `Suggested: ${suggestedBp.bpNo} · ${suggestedBp.name}` : "Leave blank and type a payee name instead if this body is not in your partner list."}>
            <Select value={bp} onChange={(e) => setBp(e.target.value)}>
              <option value="">— none / use payee name —</option>
              {(ws?.partners ?? []).filter((p: any) => p.active !== false).map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.bpNo} · {p.name}</option>)}
            </Select>
          </Field>
          {!bp && <Field label="Payee name (free text)"><Input value={payeeName} onChange={(e) => setPayeeName(e.target.value)} placeholder="e.g. Electricity Company of Ghana" /></Field>}
          <Field label="Narrative / reference" className="sm:col-span-2"><Input value={narr} onChange={(e) => setNarr(e.target.value)} placeholder="e.g. PAYE for October 2026" /></Field>
        </Grid>

        {overLimit && (
          <p className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-[15px] text-amber-900">
            This exceeds your {money(myLimit)} approval limit — it will be queued for a checker rather than posted immediately.
          </p>
        )}

        <div className="mt-4 flex items-center justify-between">
          <p className="text-[14px] text-slate-600">No withholding tax is applied to direct and statutory payments.</p>
          <Button variant="gold" disabled={busy || !account || !bank || amt <= 0}
            onClick={() => post("pay.direct", { direction, categoryKey, account, bankCode: bank, payDate, amount: amt, bp, payeeName, narrative: narr })
              .then((r) => { if (r && !r.error) { setAmount(""); setNarr(""); setPayeeName(""); } })}>
            {overLimit ? "Submit for approval" : "Post direct payment"}
          </Button>
        </div>
      </Card>
    </div>
  );
}

/**
 * Resolves a credit note through a non-cash application against an open
 * invoice or debit note — the correct way to "settle" a credit note, as
 * opposed to running it (incorrectly) through the cash Payment Desk.
 */
function ApplyCreditNote({ ws, post, busy, bp, side }: { ws: WS; post: Post; busy: boolean; bp: string; side: "AR" | "AP" }) {
  const [credits, setCredits] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [creditDoc, setCreditDoc] = useState("");
  const [invoiceDoc, setInvoiceDoc] = useState("");
  const [amount, setAmount] = useState("");

  const load = async () => {
    if (!bp) { setCredits([]); setInvoices([]); return; }
    const [c, i] = await Promise.all([
      post("trade.availableCredits", { bp, side }),
      post("pay.openItems", { bp, side }),
    ]);
    setCredits(c?.credits ?? []);
    setInvoices(i?.items ?? []);
  };
  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [bp, side]);

  const selectedCredit = credits.find((c) => c.docNo === creditDoc);
  const selectedInvoice = invoices.find((i) => i.docNo === invoiceDoc);
  const maxApplicable = Math.min(selectedCredit?.available ?? 0, selectedInvoice?.outstanding ?? 0);

  if (!bp) return null;

  return (
    <Card title="Apply a credit note" subtitle="Nets a credit note against an outstanding invoice or debit note — no cash movement, no withholding tax.">
      {credits.length === 0 ? (
        <Empty icon="🧾" title="No credit notes available for this partner" hint="Credit notes you raise against this partner will appear here to apply against their invoices." />
      ) : (
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Credit note"><Select value={creditDoc} onChange={(e) => setCreditDoc(e.target.value)} className="w-56">
            <option value="">— select —</option>
            {credits.map((c) => <option key={c.docNo} value={c.docNo}>{c.docNo} · available {money(c.available)}</option>)}
          </Select></Field>
          <Field label="Apply against"><Select value={invoiceDoc} onChange={(e) => setInvoiceDoc(e.target.value)} className="w-56">
            <option value="">— select —</option>
            {invoices.map((i) => <option key={i.docNo} value={i.docNo}>{i.docNo} · outstanding {money(i.outstanding)}</option>)}
          </Select></Field>
          <Field label="Amount to apply"><Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-32" /></Field>
          <Button variant="ghost" disabled={!selectedCredit || !selectedInvoice} onClick={() => setAmount(String(maxApplicable))}>Max</Button>
          <Button variant="gold" disabled={busy || !creditDoc || !invoiceDoc || !amount}
            onClick={() => post("trade.applyCredit", { creditDocNo: creditDoc, invoiceDocNo: invoiceDoc, amount: Number(amount) })
              .then((r) => { if (r && !r.error) { setCreditDoc(""); setInvoiceDoc(""); setAmount(""); void load(); } })}>
            Apply credit
          </Button>
        </div>
      )}
    </Card>
  );
}

/** Maker-checker queue: payments above a user's approval limit wait here. */
function PendingApprovals({ ws, post, busy, canApprove }: { ws: WS; post: Post; busy: boolean; canApprove: boolean }) {
  const pending = ws?.pendingApprovals ?? [];
  if (!pending.length) return null;
  return (
    <Card title={`Pending approvals (${pending.length})`} subtitle="Payments awaiting a checker above the requester's approval limit.">
      <Table cols={["#", "Requested by", "Amount", "Note", "Requested", "Decision"]}
        rows={pending.map((a: any) => [
          a.id, a.requestedBy, money(a.amount), a.note || "—", new Date(a.createdAt).toLocaleString(),
          canApprove ? (
            <span key="d" className="flex gap-1">
              <Button size="sm" variant="gold" disabled={busy} onClick={() => post("pay.decideApproval", { id: a.id, decision: "APPROVED" })}>Approve &amp; post</Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("pay.decideApproval", { id: a.id, decision: "REJECTED" })}>Reject</Button>
            </span>
          ) : <span key="w" className="text-[14px] text-slate-600">Awaiting a checker</span>,
        ])} />
    </Card>
  );
}

/* ==================== BANKING ==================== */
export function Banking({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [bank, setBank] = useState(ws?.bankAccounts?.[0]?.bankCode ?? "");
  const [csv, setCsv] = useState("");
  const [period, setPeriod] = useState(curPeriod());
  const [addOpen, setAddOpen] = useState(false);
  const lines = (ws?.statementLines ?? []).filter((l: any) => l.bankCode === bank);
  const sample = "Date,Narrative,Reference,Debit,Credit,Balance\n2026-01-05,Customer receipt - Acme Ltd,TRF001,0,45000,245000\n2026-01-08,Electricity bill ECG,DD0012,3200,0,241800\n2026-01-15,PAYE remittance GRA,GRA0115,8750,0,233050";

  return (
    <div className="space-y-5">
      <SectionTitle hint="Import a bank statement, let the system classify and match it, then produce an editable reconciliation.">
        Banking &amp; Reconciliation
      </SectionTitle>

      <Card title="Bank accounts" right={<Button size="sm" variant="ghost" onClick={() => setAddOpen(true)}>+ Add account</Button>}>
        <Table cols={["Code", "Bank / account name", "Account number", "G/L account", "Currency", { h: "Opening balance", align: "right" }]}
          rows={(ws?.bankAccounts ?? []).map((b: any) => [b.bankCode, b.bankName, b.accountNo, b.glAccount, b.currency, money(b.openingBalance)])}
          empty="No bank accounts" />
      </Card>

      <Modal open={addOpen} title="Add a bank account" onClose={() => setAddOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => {
          e.preventDefault(); const f = new FormData(e.currentTarget);
          post("bank.addAccount", Object.fromEntries(f)).then(() => setAddOpen(false));
        }}>
          <Grid cols={2}>
            <Field label="Bank code"><Input name="bankCode" required placeholder="BANK-02" /></Field>
            <Field label="Bank / account name"><Input name="bankName" required placeholder="Ecobank Current Account" /></Field>
            <Field label="Account number"><Input name="accountNo" /></Field>
            <Field label="G/L account"><Select name="glAccount" defaultValue="141100">
              {(ws?.accounts ?? []).filter((a: any) => a.isBank).map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}</Select></Field>
            <Field label="Currency"><Select name="currency" defaultValue="GHS">{(ws?.reference?.currencies ?? []).map((c: string) => <option key={c}>{c}</option>)}</Select></Field>
            <Field label="Opening balance"><Input name="openingBalance" type="number" step="0.01" defaultValue={0} /></Field>
          </Grid>
          <Button type="submit" variant="gold" disabled={busy}>Add account</Button>
        </form>
      </Modal>

      <div className="grid gap-4 xl:grid-cols-[400px_1fr]">
        <Card title="Import a statement" subtitle="Paste CSV with Date, Narrative, Debit, Credit and optionally Balance / Reference.">
          <div className="space-y-3">
            <Field label="Bank account"><Select value={bank} onChange={(e) => setBank(e.target.value)}>
              {(ws?.bankAccounts ?? []).map((b: any) => <option key={b.bankCode} value={b.bankCode}>{b.bankCode} · {b.bankName}</option>)}</Select></Field>
            <Field label="Statement data (CSV)">
              <TextArea value={csv} onChange={(e) => setCsv(e.target.value)} rows={9} className="font-mono text-[14px]" placeholder={sample} /></Field>
            <div className="flex flex-wrap gap-2">
              <Button variant="ghost" onClick={() => setCsv(sample)}>Use sample</Button>
              <Button variant="gold" disabled={busy || !csv.trim()} onClick={() => post("bank.import", { bankCode: bank, csv }).then((r) => { if (r && !r.error) setCsv(""); })}>Import &amp; analyse</Button>
              <Button variant="ghost" disabled={busy} onClick={() => post("bank.autoMatch", { bankCode: bank })}>Re-run matching</Button>
            </div>
            <div className="rounded-lg bg-[var(--bpz-50)] p-3 text-[14px] leading-relaxed text-slate-600">
              The importer recognises payroll, SSNIT, PAYE, VAT, WHT, bank charges, interest, utilities, rent,
              fuel, telecoms and insurance narratives and proposes the correct G/L account. It then matches
              each line against existing postings on the bank account within a five-day window.
            </div>
          </div>
        </Card>

        <Card title="Statement lines" subtitle="Review the suggested account, change it if needed, then post.">
          <Table cols={["Date", "Narrative", { h: "Debit", align: "right" }, { h: "Credit", align: "right" }, "Status", "Post to account"]}
            rows={lines.map((l: any) => [
              l.stmtDate, <span key="n" className="block max-w-[260px] truncate" title={l.narrative}>{l.narrative}</span>,
              money(l.debit), money(l.credit),
              <Badge key="s" tone={statusTone(l.status)}>{l.status}</Badge>,
              l.status === "UNMATCHED" ? (
                <StatementPoster key="p" line={l} ws={ws} post={post} busy={busy} />
              ) : <span key="d" className="text-[14px] text-slate-600">{l.postedDoc || "matched"}</span>,
            ])}
            empty="No statement lines imported for this account" />
        </Card>
      </div>

      <Card title="Reconciliation" subtitle="Statement balance less unpresented cheques plus uncredited lodgements must equal the ledger balance."
        right={<div className="flex gap-2">
          <Select value={period} onChange={(e) => setPeriod(e.target.value)} className="w-32">
            {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select>
          <Button size="sm" variant="gold" disabled={busy} onClick={() => post("bank.reconcile", { bankCode: bank, periodCode: period })}>Prepare reconciliation</Button>
        </div>}>
        <Table cols={["Rec no", "Bank", "Period", { h: "Statement", align: "right" }, { h: "Ledger", align: "right" }, { h: "Unpresented", align: "right" }, { h: "Uncredited", align: "right" }, { h: "Difference", align: "right" }, "Status", "Edit"]}
          rows={(ws?.bankRecs ?? []).map((r: any) => [
            r.recNo, r.bankCode, r.periodCode, money(r.statementBalance), money(r.ledgerBalance),
            money(r.unpresentedChq), money(r.uncreditedLodg), money(r.difference),
            <Badge key="s" tone={statusTone(r.status)}>{r.status}</Badge>,
            <RecEditor key="e" rec={r} post={post} busy={busy} />,
          ])}
          empty="No reconciliations prepared yet" />
      </Card>
    </div>
  );
}

function StatementPoster({ line, ws, post, busy }: { line: any; ws: WS; post: Post; busy: boolean }) {
  const [acct, setAcct] = useState(line.suggestedAccount || "");
  return (
    <div className="flex items-center gap-1">
      <Select value={acct} onChange={(e) => setAcct(e.target.value)} className="w-44 text-[14px]">
        <option value="">— choose —</option>
        {(ws?.accounts ?? []).map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description.slice(0, 26)}</option>)}
      </Select>
      <Button size="sm" variant="ghost" disabled={busy || !acct} onClick={() => post("bank.postLine", { lineId: line.id, account: acct })}>Post</Button>
    </div>
  );
}

function RecEditor({ rec, post, busy }: { rec: any; post: Post; busy: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button size="sm" variant="ghost" onClick={() => setOpen(true)}>Edit</Button>
      <Modal open={open} title={`Edit reconciliation ${rec.recNo}`} onClose={() => setOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => {
          e.preventDefault(); const f = new FormData(e.currentTarget);
          post("bank.updateRec", { recNo: rec.recNo, statementBalance: Number(f.get("statementBalance")), notes: f.get("notes"), status: f.get("status") })
            .then(() => setOpen(false));
        }}>
          <Field label="Statement balance per bank"><Input name="statementBalance" type="number" step="0.01" defaultValue={rec.statementBalance} /></Field>
          <Field label="Status"><Select name="status" defaultValue={rec.status}>
            {["DRAFT", "BALANCED", "REVIEWED", "APPROVED"].map((s) => <option key={s}>{s}</option>)}</Select></Field>
          <Field label="Reconciling notes"><TextArea name="notes" defaultValue={rec.notes} placeholder="Explain each reconciling item" /></Field>
          <Button type="submit" variant="gold" disabled={busy}>Save reconciliation</Button>
        </form>
      </Modal>
    </>
  );
}

/* ==================== FIXED ASSETS ==================== */
export function Assets({ ws, rpt, post, busy }: { ws: WS; rpt: RPT; post: Post; busy: boolean }) {
  const [period, setPeriod] = useState(curPeriod());
  const sector = ws?.client?.sector ?? "GENERAL";
  const classes = (ws?.reference?.assetClasses ?? []).filter((c: any) => c.sectors.includes("*") || c.sectors.includes(sector));
  const specials = (ws?.reference?.assetClasses ?? []).filter((c: any) => !c.sectors.includes("*") && c.sectors.includes(sector));
  const reg = rpt?.assetRegister ?? [];
  const tot = reg.reduce((t: any, a: any) => ({ cost: t.cost + a.cost, dep: t.dep + a.accumDep, nbv: t.nbv + a.nbv }), { cost: 0, dep: 0, nbv: 0 });

  return (
    <div className="space-y-5">
      <SectionTitle hint={`General classes apply to every sector; ${specials.length} specialised classes are active for ${sector}.`}>
        Fixed Asset Register
      </SectionTitle>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Assets on register" value={String(reg.length)} />
        <Stat label="Gross cost" value={money(tot.cost)} tone="blue" />
        <Stat label="Accumulated depreciation" value={money(tot.dep)} tone="red" />
        <Stat label="Net book value" value={money(tot.nbv)} tone="green" />
      </div>

      <div className="grid gap-4 xl:grid-cols-[380px_1fr]">
        <Card title="Capitalise a new asset">
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("asset.create", Object.fromEntries(f)).then((r) => { if (r && !r.error) e.currentTarget?.reset?.(); }); }}>
            <Field label="Description"><Input name="description" required placeholder="Toyota Hilux double cabin" /></Field>
            <Field label="Asset class" hint="Specialised classes for your sector appear first">
              <Select name="assetClass" required defaultValue={specials[0]?.key ?? "MOTOR"}>
                {specials.length > 0 && <optgroup label={`${sector} — specialised`}>
                  {specials.map((c: any) => <option key={c.key} value={c.key}>{c.name}</option>)}</optgroup>}
                <optgroup label="General classes">
                  {classes.filter((c: any) => c.sectors.includes("*")).map((c: any) => <option key={c.key} value={c.key}>{c.name}</option>)}</optgroup>
              </Select></Field>
            <Grid cols={2}>
              <Field label="Cost"><Input name="cost" type="number" step="0.01" required defaultValue={0} /></Field>
              <Field label="Residual value"><Input name="residual" type="number" step="0.01" defaultValue={0} /></Field>
              <Field label="Useful life (years)"><Input name="usefulLife" type="number" placeholder="Class default" /></Field>
              <Field label="Method"><Select name="method" defaultValue="">
                <option value="">Class default</option><option value="SL">Straight line</option>
                <option value="RB">Reducing balance</option><option value="UOP">Units of production</option></Select></Field>
              <Field label="Acquisition date"><Input name="acquisitionDate" type="date" defaultValue={todayStr()} /></Field>
              <Field label="Cost centre"><Select name="costCenter" defaultValue="CC-ADM">
                {(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode}</option>)}</Select></Field>
            </Grid>
            <Button type="submit" variant="gold" disabled={busy}>Capitalise asset</Button>
          </form>
        </Card>

        <div className="space-y-4">
          <Card title="Depreciation run" subtitle="Posts straight-line, reducing-balance and units-of-production charges. Safe to re-run — each asset is charged once per period.">
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Period"><Select value={period} onChange={(e) => setPeriod(e.target.value)} className="w-36">
                {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code} ({p.status})</option>)}</Select></Field>
              <Button variant="gold" disabled={busy} onClick={() => post("asset.depreciate", { periodCode: period })}>Run depreciation</Button>
            </div>
          </Card>
          <Card title="Register">
            <Table cols={["Asset", "Description", "Class", "Acquired", "Method", { h: "Cost", align: "right" }, { h: "Accum. dep.", align: "right" }, { h: "NBV", align: "right" }, "CA class", "Status", "Actions"]}
              rows={reg.map((a: any) => [
                a.assetNo, a.description, a.assetClass, a.acquisitionDate, a.method,
                money(a.cost), money(a.accumDep), money(a.nbv), a.capitalAllowanceClass,
                <Badge key="s" tone={statusTone(a.status)}>{a.status}</Badge>,
                <AssetActions key="x" asset={a} post={post} busy={busy} />,
              ])}
              empty="No assets capitalised yet" />
          </Card>
        </div>
      </div>
    </div>
  );
}

function AssetActions({ asset, post, busy }: { asset: any; post: Post; busy: boolean }) {
  const [mode, setMode] = useState<"" | "reval" | "disp">("");
  return (
    <>
      <span className="flex gap-1">
        <Button size="sm" variant="ghost" disabled={busy || asset.status !== "ACTIVE"} onClick={() => setMode("reval")}>Revalue</Button>
        <Button size="sm" variant="ghost" disabled={busy || asset.status !== "ACTIVE"} onClick={() => setMode("disp")}>Dispose</Button>
      </span>
      <Modal open={mode !== ""} title={`${mode === "reval" ? "Revalue / impair" : "Dispose"} ${asset.assetNo}`} onClose={() => setMode("")}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          post(mode === "reval" ? "asset.revalue" : "asset.dispose", { assetNo: asset.assetNo, ...Object.fromEntries(f) }).then(() => setMode("")); }}>
          <p className="rounded bg-slate-50 px-3 py-2 text-[16px]">Current net book value: <b>{money(asset.nbv)}</b></p>
          {mode === "reval" ? (
            <>
              <Field label="Revised carrying amount" hint="An uplift credits the revaluation surplus (OCI); a reduction is charged as an impairment.">
                <Input name="newValue" type="number" step="0.01" required defaultValue={asset.nbv} /></Field>
              <Field label="Reason"><TextArea name="reason" required placeholder="Basis of the valuation and the valuer's reference" /></Field>
            </>
          ) : (
            <Field label="Disposal proceeds"><Input name="proceeds" type="number" step="0.01" required defaultValue={0} /></Field>
          )}
          <Field label="Date"><Input name="date" type="date" defaultValue={todayStr()} /></Field>
          <Button type="submit" variant="gold" disabled={busy}>Post</Button>
        </form>
      </Modal>
    </>
  );
}

/* ==================== PAYROLL ==================== */
export function Payroll({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [period, setPeriod] = useState(curPeriod());
  const [calc, setCalc] = useState<any>(null);
  const [empOpen, setEmpOpen] = useState(false);
  const [editEmp, setEditEmp] = useState<any>(null);
  const [compOpen, setCompOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkCsv, setBulkCsv] = useState("");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("active");
  const emps = ws?.employees ?? [];
  const comps = ws?.payComponents ?? [];
  const bands = ws?.reference?.payeBands ?? [];
  const taxMode = ws?.client?.payrollTaxMode ?? "GH_PAYE";
  const statutoryLabel = ws?.client?.statutoryLabel || "SSNIT";
  const flatRate = Number(ws?.client?.payrollFlatRatePct ?? 0);
  const empTypes = ws?.reference?.employmentTypes ?? ["PERMANENT"];

  const filtered = emps.filter((e: any) => {
    if (statusFilter === "active" && !e.active) return false;
    if (statusFilter === "inactive" && e.active) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return [e.empNo, e.name, e.jobTitle, e.department, e.costCenter, e.email].some((v: string) => (v || "").toLowerCase().includes(q));
  });

  const runCalc = async () => { const r = await post("payroll.calculate", { periodCode: period }); if (r && !r.error) setCalc(r); };
  const sampleCsv = "Name,BasicSalary,JobTitle,Department,CostCenter,Email,Phone,EmploymentType,Resident\nKofi Mensah,4500,Sales Executive,Sales,CC-SLS,kofi@example.com,0244000111,PERMANENT,Y\nJane Doe,7200,Project Engineer,Operations,CC-OPS,jane@example.com,0244000222,CONTRACT,Y";

  return (
    <div className="space-y-5">
      <SectionTitle hint="No limit on headcount — add staff one at a time or bulk-import a whole payroll. Reliefs and deductions apply on basic, gross or net pay, and the tax regime adapts automatically to the workspace's country.">
        Payroll Desk
      </SectionTitle>

      <div className={`rounded-xl px-4 py-2.5 text-[15px] font-medium ${taxMode === "GH_PAYE" ? "bg-[var(--bpz-100)] text-[var(--bpz-800)]" : "bg-amber-50 text-amber-800"}`}>
        {taxMode === "GH_PAYE"
          ? `Ghana statutory scheme active — PAYE under Act 1178 plus ${statutoryLabel} (5.5% employee / 13% employer) and Tier 3.`
          : taxMode === "FLAT_RATE"
            ? `International workspace — a flat ${flatRate}% withholding applies to chargeable income; ${statutoryLabel} is handled via custom deduction components.`
            : `International workspace — no payroll tax is withheld automatically; configure deductions manually if required.`}
      </div>

      {emps.length === 0 && (
        <Empty icon="👥" title="No employees on file yet"
          hint="Add staff one at a time, or bulk-import a whole payroll from a spreadsheet. Each employee carries a basic salary, residency status and statutory settings appropriate to this workspace's country."
          action={<div className="flex gap-2">
            <Button variant="gold" onClick={() => { setEditEmp(null); setEmpOpen(true); }}>+ Add an employee</Button>
            <Button variant="ghost" onClick={() => setBulkOpen(true)}>Bulk import from CSV</Button>
            {taxMode === "GH_PAYE" && <Button variant="ghost" disabled={busy} onClick={() => post("payroll.seedDemo")}>Load three sample employees</Button>}
          </div>} />
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <Stat label="Active employees" value={String(emps.filter((e: any) => e.active).length)} />
        <Stat label="Leavers" value={String(emps.filter((e: any) => !e.active).length)} />
        <Stat label="Monthly basic payroll" value={money(emps.filter((e: any) => e.active).reduce((s: number, e: any) => s + Number(e.basicSalary), 0))} tone="blue" />
        <Stat label="Pay components" value={String(comps.length)} />
        <Stat label="Payroll runs posted" value={String((ws?.payrollRuns ?? []).length)} />
      </div>

      <Card title={`Employees (${filtered.length} of ${emps.length})`}
        subtitle="Search, filter and manage a workforce of any size. Leavers keep their payroll history but are excluded from future runs."
        right={<div className="flex flex-wrap items-center gap-2">
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, title, department…" className="w-56" />
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-32">
            <option value="active">Active</option><option value="inactive">Leavers</option><option value="all">All</option>
          </Select>
          <Button size="sm" variant="ghost" onClick={() => setBulkOpen(true)}>⇪ Bulk import</Button>
          <Button size="sm" variant="gold" onClick={() => { setEditEmp(null); setEmpOpen(true); }}>+ Add employee</Button>
        </div>}>
        <Table cols={["Emp no", "Name", "Job title / dept.", "Type", "Cost centre", { h: "Basic salary", align: "right" }, "Residency", "Status", ""]}
          rows={filtered.map((e: any) => [
            e.empNo, <span key="n">{e.name}{e.email && <span className="block text-[15.5px] text-slate-600">{e.email}</span>}</span>,
            <span key="j">{e.jobTitle || "—"}{e.department && <span className="block text-[15.5px] text-slate-600">{e.department}</span>}</span>,
            <Badge key="t" tone="slate">{e.employmentType || "PERMANENT"}</Badge>,
            e.costCenter, money(e.basicSalary),
            <Badge key="r" tone={e.isResident ? "blue" : "amber"}>{e.isResident ? "Resident" : "Non-resident"}</Badge>,
            <Badge key="a" tone={e.active ? "green" : "red"}>{e.active ? "Active" : `Leaver${e.terminationDate ? ` ${e.terminationDate}` : ""}`}</Badge>,
            <span key="x" className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => { setEditEmp(e); setEmpOpen(true); }}>Edit</Button>
              {e.active && <TerminateButton emp={e} post={post} busy={busy} />}
            </span>,
          ])}
          empty={emps.length === 0 ? "No employees" : "No employees match this search"} />
      </Card>

      <Card title="Allowances, deductions & reliefs"
        subtitle="Basis FIXED, PCT_BASIC, PCT_GROSS or PCT_NET. Reliefs reduce chargeable income; deductions are applied after tax."
        right={<Button size="sm" variant="gold" onClick={() => setCompOpen(true)}>+ Add component</Button>}>
        <Table cols={["Code", "Name", "Applies to", "Kind", "Basis", { h: "Rate %", align: "right" }, { h: "Amount", align: "right" }, "Taxable", "Period", ""]}
          rows={comps.map((c: any) => [
            c.code, c.name, c.empNo === "*" ? "All employees" : c.empNo,
            <Badge key="k" tone={c.kind === "ALLOWANCE" ? "green" : c.kind === "RELIEF" ? "blue" : "amber"}>{c.kind}</Badge>,
            c.basis, Number(c.rate).toFixed(2), money(c.amount),
            c.taxable ? "Yes" : "No", c.periodCode === "*" ? "Every period" : c.periodCode,
            <Button key="d" size="sm" variant="ghost" disabled={busy} onClick={() => post("payroll.deleteComponent", { id: c.id })}>✕</Button>,
          ])}
          empty="No components defined — base pay only" />
      </Card>

      <Card title="Run payroll" right={<div className="flex gap-2">
        <Select value={period} onChange={(e) => { setPeriod(e.target.value); setCalc(null); }} className="w-36">
          {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code} ({p.status})</option>)}</Select>
        <Button size="sm" variant="ghost" disabled={busy || emps.filter((e: any) => e.active).length === 0} onClick={runCalc}>Calculate (preview)</Button>
        <Button size="sm" variant="gold" disabled={busy || !calc} onClick={() => post("payroll.post", { periodCode: period }).then(() => setCalc(null))}>Post to ledger</Button>
      </div>}>
        {!calc ? (
          <Empty icon="🧮" title="Preview before you post"
            hint="Calculate shows each payslip, the tax trace and the statutory totals for every active employee — however many there are. Nothing hits the ledger until you post." />
        ) : (
          <>
            <div className="mb-3 grid grid-cols-2 gap-3 md:grid-cols-6">
              <Stat label="Employees paid" value={String(calc.results.length)} />
              <Stat label="Gross" value={money(calc.totals.gross)} />
              <Stat label={`${statutoryLabel} (EE)`} value={money(calc.totals.ssnitEe)} />
              <Stat label={`${statutoryLabel} (ER)`} value={money(calc.totals.ssnitEr)} />
              <Stat label="Tax withheld" value={money(calc.totals.paye)} tone="red" />
              <Stat label="Net pay" value={money(calc.totals.net)} tone="green" />
            </div>
            <Table cols={["Emp", "Name", { h: "Basic", align: "right" }, { h: "Allowances", align: "right" }, { h: "Gross", align: "right" },
              { h: `${statutoryLabel} EE`, align: "right" }, { h: "Tier 3", align: "right" }, { h: "Reliefs", align: "right" },
              { h: "Chargeable", align: "right" }, { h: "Tax", align: "right" }, { h: "Other ded.", align: "right" }, { h: "Net pay", align: "right" }]}
              rows={calc.results.map((r: any) => [
                r.empNo, r.name, money(r.basic), money(r.allowances), money(r.gross), money(r.ssnitEe),
                money(r.tier3Ee), money(r.reliefs), money(r.taxable), money(r.paye), money(r.otherDeductions), money(r.net)])} />
          </>
        )}
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title={taxMode === "GH_PAYE" ? "PAYE schedule in force" : "Payroll tax configuration"}
          subtitle={taxMode === "GH_PAYE" ? "Monthly chargeable income — Act 1178, effective 1 September 2026. Editable in the Tax Centre." : "Set in the Owner Console when the client was created; amend via Client profile."}>
          {taxMode === "GH_PAYE" ? (<>
            <Table cols={["Band", { h: "Width (GHS)", align: "right" }, { h: "Rate", align: "right" }]} dense
              rows={bands.map((b: any) => [b.label, b.width > 1e12 ? "Balance" : money(b.width), `${b.rate}%`])} />
            <p className="mt-2 text-[14px] text-slate-600">Non-resident employment income is taxed at a flat 25%. SSNIT: employee 5.5%, employer 13% of basic. Tier 3 is deductible up to 16.5% of basic.</p>
          </>) : (
            <div className="space-y-2 text-[15px] text-slate-600">
              <p>Regime: <Badge tone="amber">{taxMode === "FLAT_RATE" ? `Flat rate ${flatRate}%` : "No withholding"}</Badge></p>
              <p>Statutory scheme label: <b>{statutoryLabel}</b></p>
              <p className="text-[14px] text-slate-600">
                This workspace is outside Ghana, so the Ghanaian PAYE/SSNIT engine does not apply. Use
                allowances, deductions and reliefs above to model this country&apos;s own statutory
                contributions and tax treatment precisely.
              </p>
            </div>
          )}
        </Card>
        <Card title="Posted payroll runs">
          <Table cols={["Run", "Period", { h: "Gross", align: "right" }, { h: "Tax", align: "right" }, { h: `${statutoryLabel} EE`, align: "right" }, { h: "Net", align: "right" }, "GL doc"]}
            rows={(ws?.payrollRuns ?? []).map((r: any) => [r.runNo, r.periodCode, money(r.grossTotal), money(r.payeTotal), money(r.ssnitEeTotal), money(r.netTotal), r.glDoc])}
            empty="No payroll posted yet" />
        </Card>
      </div>

      <Modal open={empOpen} title={editEmp ? `Edit ${editEmp.empNo}` : "Add an employee"} onClose={() => setEmpOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          const o = Object.fromEntries(f) as Record<string, unknown>;
          o.isResident = f.get("isResident") === "on"; o.ssnitApplicable = f.get("ssnitApplicable") === "on"; o.active = f.get("active") === "on";
          post("payroll.employee", o).then((r) => { if (r && !r.error) setEmpOpen(false); }); }}>
          {editEmp && <input type="hidden" name="empNo" value={editEmp.empNo} />}
          <Grid cols={2}>
            <Field label="Full name"><Input name="name" required defaultValue={editEmp?.name} /></Field>
            <Field label="Email"><Input name="email" type="email" defaultValue={editEmp?.email} /></Field>
            <Field label="Phone"><Input name="phone" defaultValue={editEmp?.phone} /></Field>
            <Field label="Job title"><Input name="jobTitle" defaultValue={editEmp?.jobTitle} /></Field>
            <Field label="Department"><Input name="department" defaultValue={editEmp?.department} /></Field>
            <Field label="Employment type"><Select name="employmentType" defaultValue={editEmp?.employmentType ?? "PERMANENT"}>
              {empTypes.map((t: string) => <option key={t} value={t}>{t.replace("_", " ")}</option>)}</Select></Field>
            <Field label={`${statutoryLabel} / social security number`}><Input name="ssnit" defaultValue={editEmp?.ssnit} /></Field>
            <Field label="Tax identification number"><Input name="tin" defaultValue={editEmp?.tin} /></Field>
            <Field label="Basic salary (monthly)"><Input name="basicSalary" type="number" step="0.01" required defaultValue={editEmp?.basicSalary ?? 0} /></Field>
            <Field label="Pay currency"><Select name="currency" defaultValue={editEmp?.currency ?? ws?.client?.currency ?? "GHS"}>
              {(ws?.reference?.currencies ?? []).map((c: string) => <option key={c} value={c}>{c}</option>)}</Select></Field>
            <Field label="Cost centre"><Select name="costCenter" defaultValue={editEmp?.costCenter ?? "CC-ADM"}>
              {(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode} · {c.ccName}</option>)}</Select></Field>
            <Field label="Start date"><Input name="startDate" type="date" defaultValue={editEmp?.startDate ?? ""} /></Field>
            <Field label="Bank code"><Select name="bankCode" defaultValue={editEmp?.bankCode ?? ""}>
              <option value="">—</option>{(ws?.bankAccounts ?? []).map((b: any) => <option key={b.bankCode} value={b.bankCode}>{b.bankCode} · {b.bankName}</option>)}</Select></Field>
            <Field label="Bank account number"><Input name="bankAccount" defaultValue={editEmp?.bankAccount} /></Field>
            {ws?.client?.payrollTaxMode === "GH_PAYE" && (<>
              <Field label="Tier 3 — employee" hint="Deductible up to 16.5% of basic"><Input name="tier3Employee" type="number" step="0.01" defaultValue={editEmp?.tier3Employee ?? 0} /></Field>
              <Field label="Tier 3 — employer"><Input name="tier3Employer" type="number" step="0.01" defaultValue={editEmp?.tier3Employer ?? 0} /></Field>
            </>)}
          </Grid>
          <div className="flex flex-wrap gap-4 text-[16px]">
            <label className="flex items-center gap-1.5"><input type="checkbox" name="isResident" defaultChecked={editEmp?.isResident ?? true} /> Resident for tax</label>
            {ws?.client?.payrollTaxMode === "GH_PAYE" && (
              <label className="flex items-center gap-1.5"><input type="checkbox" name="ssnitApplicable" defaultChecked={editEmp?.ssnitApplicable ?? true} /> {statutoryLabel} applicable</label>)}
            <label className="flex items-center gap-1.5"><input type="checkbox" name="active" defaultChecked={editEmp?.active ?? true} /> Active</label>
          </div>
          <Button type="submit" variant="gold" disabled={busy}>Save employee</Button>
        </form>
      </Modal>

      <Modal open={bulkOpen} title="Bulk import employees from CSV" onClose={() => setBulkOpen(false)}>
        <div className="space-y-3">
          <p className="text-[16px] text-slate-600">Paste a spreadsheet export. Only <b>Name</b> and <b>BasicSalary</b> are required — every other column is optional and matched by header name.</p>
          <TextArea value={bulkCsv} onChange={(e) => setBulkCsv(e.target.value)} rows={8} className="font-mono text-[14px]" placeholder={sampleCsv} />
          <div className="flex flex-wrap gap-2">
            <Button variant="ghost" onClick={() => setBulkCsv(sampleCsv)}>Use sample</Button>
            <Button variant="gold" disabled={busy || !bulkCsv.trim()}
              onClick={() => post("payroll.bulkImport", { csv: bulkCsv }).then((r) => { if (r && !r.error) { setBulkCsv(""); setBulkOpen(false); } })}>
              Import employees
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={compOpen} title="Add a pay component" onClose={() => setCompOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          const o = Object.fromEntries(f) as Record<string, unknown>; o.taxable = f.get("taxable") === "on";
          post("payroll.component", o).then(() => setCompOpen(false)); }}>
          <Grid cols={2}>
            <Field label="Code"><Input name="code" required placeholder="TRANSPORT" /></Field>
            <Field label="Name"><Input name="name" required placeholder="Transport allowance" /></Field>
            <Field label="Applies to"><Select name="empNo" defaultValue="*">
              <option value="*">All employees</option>
              {(ws?.employees ?? []).map((e: any) => <option key={e.empNo} value={e.empNo}>{e.empNo} · {e.name}</option>)}</Select></Field>
            <Field label="Kind"><Select name="kind" defaultValue="ALLOWANCE">
              <option value="ALLOWANCE">Allowance (adds to gross)</option>
              <option value="DEDUCTION">Deduction (after tax)</option>
              <option value="RELIEF">Relief (reduces chargeable income)</option></Select></Field>
            <Field label="Basis"><Select name="basis" defaultValue="FIXED">
              <option value="FIXED">Fixed amount</option><option value="PCT_BASIC">% of basic salary</option>
              <option value="PCT_GROSS">% of gross pay</option><option value="PCT_NET">% of net pay</option></Select></Field>
            <Field label="Rate (%)"><Input name="rate" type="number" step="0.01" defaultValue={0} /></Field>
            <Field label="Fixed amount"><Input name="amount" type="number" step="0.01" defaultValue={0} /></Field>
            <Field label="Applies in period"><Select name="periodCode" defaultValue="*">
              <option value="*">Every period (recurring)</option>
              {(ws?.periods ?? []).slice(0, 36).map((p: any) => <option key={p.code} value={p.code}>{p.code} only</option>)}</Select></Field>
          </Grid>
          <label className="flex items-center gap-1.5 text-[16px]"><input type="checkbox" name="taxable" defaultChecked /> Taxable (include in chargeable income)</label>
          <div className="rounded-lg bg-[var(--bpz-50)] p-3 text-[14px] text-slate-600">
            Statutory reliefs available in Ghana: marriage/responsibility GHS 1,200 p.a., child education GHS 600 per child
            (max 3), old age GHS 1,500, aged dependant GHS 1,000 (max 2), professional training GHS 2,000.
            Enter the monthly equivalent as a fixed relief. International workspaces can define their own.
          </div>
          <Button type="submit" variant="gold" disabled={busy}>Add component</Button>
        </form>
      </Modal>
    </div>
  );
}

function TerminateButton({ emp, post, busy }: { emp: any; post: Post; busy: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button size="sm" variant="ghost" onClick={() => setOpen(true)}>Terminate</Button>
      <Modal open={open} title={`Terminate ${emp.name}`} onClose={() => setOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          post("payroll.terminate", { empNo: emp.empNo, terminationDate: f.get("terminationDate") }).then(() => setOpen(false)); }}>
          <p className="rounded-lg bg-amber-50 px-3 py-2 text-[16px] text-amber-800">
            {emp.name} will be excluded from every future payroll run but all past payslips and postings are kept.
          </p>
          <Field label="Last day of employment"><Input name="terminationDate" type="date" required defaultValue={todayStr()} /></Field>
          <Button type="submit" variant="danger" disabled={busy}>Confirm termination</Button>
        </form>
      </Modal>
    </>
  );
}
