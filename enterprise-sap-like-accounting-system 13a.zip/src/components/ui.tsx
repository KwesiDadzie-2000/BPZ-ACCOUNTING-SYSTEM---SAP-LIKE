"use client";

import React from "react";

export const money = (n: number | string | null | undefined, dp = 2) => {
  const v = Number(n ?? 0);
  return v.toLocaleString("en-GH", { minimumFractionDigits: dp, maximumFractionDigits: dp });
};
export const pct = (n: number) => `${Number(n ?? 0).toFixed(1)}%`;

export function Card({ title, subtitle, children, right, tone = "white", className = "" }: {
  title?: string; subtitle?: string; children: React.ReactNode;
  right?: React.ReactNode; tone?: "white" | "tint"; className?: string;
}) {
  return (
    <section className={`animate-fade-up rounded-xl border border-slate-200 shadow-sm ${tone === "tint" ? "bg-[var(--bpz-100)]/40" : "bg-white"} ${className}`}>
      {(title || right) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-4 py-3">
          <div className="min-w-0">
            {title && <h3 className="font-display truncate text-[15.5px] font-semibold text-[var(--bpz-900)]">{title}</h3>}
            {subtitle && <p className="mt-0.5 text-[14px] leading-snug text-slate-600">{subtitle}</p>}
          </div>
          {right && <div className="flex flex-wrap items-center gap-2">{right}</div>}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Field({ label, hint, children, className = "" }: {
  label: string; hint?: string; children: React.ReactNode; className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1 block text-[13px] font-semibold uppercase tracking-wider text-slate-600">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[13px] leading-snug text-slate-600">{hint}</span>}
    </label>
  );
}

const base = "w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-[15.5px] text-slate-800 shadow-sm transition placeholder:text-slate-600 focus:border-[var(--bpz-500)] focus:ring-2 focus:ring-[var(--bpz-500)]/15 disabled:bg-slate-50";

export const Input = (p: React.InputHTMLAttributes<HTMLInputElement>) =>
  <input {...p} className={`${base} ${p.className ?? ""}`} />;
export const Select = (p: React.SelectHTMLAttributes<HTMLSelectElement>) =>
  <select {...p} className={`${base} ${p.className ?? ""}`} />;
export const TextArea = (p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) =>
  <textarea {...p} className={`${base} min-h-[70px] ${p.className ?? ""}`} />;

export function Button({ variant = "primary", size = "md", ...p }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "gold" | "danger" | "dark"; size?: "sm" | "md" }) {
  const sz = size === "sm" ? "px-2 py-1 text-[14px]" : "px-3 py-1.5 text-[15px]";
  const styles = {
    primary: "bg-[var(--bpz-800)] text-white hover:bg-[var(--bpz-700)] shadow-sm",
    gold: "bg-[var(--gold-500)] text-[var(--bpz-900)] hover:bg-[var(--gold-400)] shadow-sm font-semibold",
    ghost: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50",
    dark: "bg-slate-800 text-white hover:bg-slate-900",
    danger: "bg-rose-600 text-white hover:bg-rose-700",
  }[variant];
  return <button {...p} className={`inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition disabled:cursor-not-allowed disabled:opacity-45 ${sz} ${styles} ${p.className ?? ""}`} />;
}

// Every tone pair below is checked to exceed WCAG AAA (7:1) for small text,
// not just the AA minimum — chosen deliberately for users with low vision.
// Darker badge backgrounds plus a visible border (instead of colour alone)
// also help users with colour-vision deficiencies tell tones apart.
export function Badge({ children, tone = "slate" }: { children: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    slate: "bg-slate-100 text-slate-800 border border-slate-300",
    green: "bg-emerald-100 text-emerald-900 border border-emerald-300",
    red: "bg-rose-100 text-rose-900 border border-rose-300",
    amber: "bg-amber-100 text-amber-900 border border-amber-300",
    blue: "bg-[var(--bpz-100)] text-[var(--bpz-900)] border border-[var(--bpz-500)]/30",
    gold: "bg-[#fbeecb] text-[#4a3704] border border-[var(--gold-600)]/40",
    violet: "bg-violet-100 text-violet-900 border border-violet-300",
  };
  return <span className={`inline-block whitespace-nowrap rounded px-1.5 py-0.5 text-[13px] font-bold ${tones[tone] ?? tones.slate}`}>{children}</span>;
}

export type Col = { h: string; align?: "right" | "center"; w?: string };

export function Table({ cols, rows, empty = "No records", dense = false, maxH = "max-h-[560px]", onRow }: {
  cols: (string | Col)[]; rows: (string | number | React.ReactNode)[][];
  empty?: string; dense?: boolean; maxH?: string; onRow?: (i: number) => void;
}) {
  const norm = cols.map((c) => (typeof c === "string" ? { h: c } : c));
  return (
    <div className={`scroll-thin overflow-auto rounded-lg border border-slate-200 ${maxH}`}>
      <table className="w-full border-collapse text-[15px]">
        <thead className="sticky top-0 z-10 bg-[var(--bpz-50)] text-[13px] uppercase tracking-wider text-[var(--bpz-800)]">
          <tr>
            {norm.map((c, i) => (
              <th key={i} style={c.w ? { width: c.w } : undefined}
                className={`whitespace-nowrap border-b-2 border-[var(--bpz-100)] px-2.5 py-2 font-bold ${c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : "text-left"}`}>
                {c.h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={norm.length} className="px-3 py-8 text-center text-slate-600">{empty}</td></tr>
          ) : rows.map((r, ri) => (
            <tr key={ri} onClick={onRow ? () => onRow(ri) : undefined}
              className={`odd:bg-white even:bg-slate-50/50 hover:bg-[var(--bpz-100)]/50 ${onRow ? "cursor-pointer" : ""}`}>
              {r.map((c, ci) => (
                <td key={ci} className={`border-b border-slate-100 px-2.5 ${dense ? "py-1" : "py-1.5"} align-top text-slate-700 ${norm[ci]?.align === "right" ? "tnum text-right" : norm[ci]?.align === "center" ? "text-center" : ""}`}>
                  {c}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Stat({ label, value, sub, tone = "slate", icon }: {
  label: string; value: string; sub?: string; tone?: string; icon?: string;
}) {
  const tones: Record<string, string> = {
    slate: "text-[var(--bpz-900)]", green: "text-emerald-600", red: "text-rose-600",
    blue: "text-[var(--bpz-700)]", gold: "text-[var(--gold-700)]",
  };
  return (
    <div className="animate-fade-up rounded-xl border border-slate-200 bg-white p-3.5 shadow-sm">
      <p className="flex items-center gap-1.5 text-[13px] font-semibold uppercase tracking-wider text-slate-600">
        {icon && <span aria-hidden>{icon}</span>}{label}
      </p>
      <p className={`tnum mt-1 font-display text-lg font-bold ${tones[tone] ?? tones.slate}`}>{value}</p>
      {sub && <p className="mt-0.5 text-[15.5px] text-slate-600">{sub}</p>}
    </div>
  );
}

export function StatementTable({ lines, cols = ["Amount"] }: {
  lines: { label: string; amount?: number; bold?: boolean; rule?: boolean; header?: boolean }[];
  cols?: string[];
}) {
  return (
    <div className="scroll-thin max-h-[620px] overflow-auto rounded-lg border border-slate-200 bg-white">
      <table className="w-full text-[15px]">
        <thead className="sticky top-0 bg-[var(--bpz-50)] text-[13px] uppercase tracking-wider text-[var(--bpz-800)]">
          <tr>
            <th className="border-b-2 border-[var(--bpz-100)] px-3 py-2 text-left font-bold">Description</th>
            {cols.map((c) => <th key={c} className="border-b-2 border-[var(--bpz-100)] px-3 py-2 text-right font-bold">{c}</th>)}
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} className={l.header ? "bg-[var(--bpz-100)]/50" : ""}>
              <td className={`px-3 py-1.5 ${l.bold || l.header ? "font-semibold text-[var(--bpz-900)]" : "text-slate-700"} ${l.header ? "text-[14px] uppercase tracking-wide" : ""} ${l.rule ? "border-t border-slate-300" : ""}`}>
                {l.label}
              </td>
              <td className={`tnum px-3 py-1.5 text-right ${l.bold ? "font-bold text-[var(--bpz-900)]" : "text-slate-700"} ${l.rule ? "border-t border-slate-300" : ""}`}>
                {l.amount === undefined ? "" : (l.amount < 0 ? `(${money(Math.abs(l.amount))})` : money(l.amount))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Toast({ toast }: { toast: { kind: "ok" | "err" | "info"; msg: string } | null }) {
  if (!toast) return null;
  const tone = toast.kind === "ok" ? "bg-emerald-600" : toast.kind === "err" ? "bg-rose-600" : "bg-[var(--bpz-800)]";
  return (
    <div className={`no-print fixed bottom-5 right-5 z-[90] max-w-md animate-fade-up rounded-xl px-4 py-3 text-[15px] text-white shadow-2xl ${tone}`}>
      <span className="mr-1.5">{toast.kind === "ok" ? "✓" : toast.kind === "err" ? "✕" : "ℹ"}</span>
      {toast.msg}
    </div>
  );
}

export function Modal({ open, title, onClose, children, wide }: {
  open: boolean; title: string; onClose: () => void; children: React.ReactNode; wide?: boolean;
}) {
  if (!open) return null;
  return (
    <div className="no-print fixed inset-0 z-[80] flex items-start justify-center overflow-y-auto bg-slate-900/55 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className={`animate-fade-up my-8 w-full ${wide ? "max-w-5xl" : "max-w-2xl"} rounded-2xl bg-white shadow-2xl`} onClick={(e) => e.stopPropagation()}>
        <header className="bpz-gradient flex items-center justify-between rounded-t-2xl px-5 py-3">
          <h3 className="font-display text-sm font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="rounded-md px-2 py-0.5 text-white/92 hover:bg-white/15 hover:text-white">✕</button>
        </header>
        <div className="scroll-thin max-h-[76vh] overflow-y-auto p-5">{children}</div>
      </div>
    </div>
  );
}

export function Empty({ icon = "📋", title, hint, action }: {
  icon?: string; title: string; hint?: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 bg-slate-50/60 px-6 py-10 text-center">
      <div className="mb-2 text-3xl opacity-60">{icon}</div>
      <p className="font-display text-[15.5px] font-semibold text-slate-700">{title}</p>
      {hint && <p className="mt-1 max-w-md text-[16px] leading-relaxed text-slate-600">{hint}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

/** The BPZ Consult mark: ascending bars with a breakout arrow, as on the brand flyer. */
export function BpzMark({ size = 36, dark = false }: { size?: number; dark?: boolean }) {
  const bar = dark ? "#0c2d52" : "#ffffff";
  const gold = "#f5a91f";
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
      <rect width="40" height="40" rx="9" fill={dark ? "#ffffff" : "#0c2d52"} />
      <rect x="8" y="22" width="4.5" height="10" rx="1.2" fill={bar === "#ffffff" ? "#0c2d52" : bar} />
      <rect x="15" y="17" width="4.5" height="15" rx="1.2" fill={bar === "#ffffff" ? "#0c2d52" : bar} />
      <rect x="22" y="12" width="4.5" height="20" rx="1.2" fill={bar === "#ffffff" ? "#0c2d52" : bar} />
      <path d="M8 16L18 9L24 13L32 6" stroke={gold} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M26 6H32V12" stroke={gold} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SectionTitle({ children, hint }: { children: React.ReactNode; hint?: string }) {
  return (
    <div className="mb-1">
      <h2 className="font-display text-base font-bold text-[var(--bpz-900)]">{children}</h2>
      {hint && <p className="text-[16px] text-slate-600">{hint}</p>}
      <div className="bpz-gold-rule mt-1.5 h-[2px] w-24 rounded" />
    </div>
  );
}
