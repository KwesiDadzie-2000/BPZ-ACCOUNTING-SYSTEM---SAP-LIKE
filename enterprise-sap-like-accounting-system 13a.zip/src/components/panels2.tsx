"use client";

import React, { useMemo, useState } from "react";
import {
  Badge, Button, Card, Empty, Field, Input, Modal, SectionTitle, Select,
  Stat, StatementTable, Table, TextArea, money,
} from "./ui";
import type { WS, RPT, Post } from "./panels";

/* eslint-disable @typescript-eslint/no-explicit-any */
const todayStr = () => new Date().toISOString().slice(0, 10);
const curPeriod = () => { const d = new Date(); return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`; };
const Grid = ({ cols = 2, children }: { cols?: number; children: React.ReactNode }) => (
  <div className={`grid gap-3 ${cols === 2 ? "sm:grid-cols-2" : cols === 3 ? "sm:grid-cols-3" : "sm:grid-cols-2 lg:grid-cols-4"}`}>{children}</div>
);
const tone = (s: string) => /OPEN|ACTIVE|POSTED|COMPLETE/i.test(s) ? "green" : /CLOSED|LOCKED/i.test(s) ? "red" : "amber";

/* ==================== GENERAL LEDGER ==================== */
export function GeneralLedger({ ws, rpt, post, busy, onDrill }: {
  ws: WS; rpt: RPT; post: Post; busy: boolean; onDrill: (acct: string) => void;
}) {
  const [lines, setLines] = useState([
    { account: "", bp: "", cc: "", desc: "", dr: "", cr: "" },
    { account: "", bp: "", cc: "", desc: "", dr: "", cr: "" },
  ]);
  const [postDate, setPostDate] = useState(todayStr());
  const [ref, setRef] = useState("");
  const [ccy, setCcy] = useState("GHS");
  const [mode, setMode] = useState<"journal" | "opening">("journal");
  const [revDoc, setRevDoc] = useState("");
  const [revReason, setRevReason] = useState("");

  const t = useMemo(() => {
    const dr = lines.reduce((s, l) => s + (Number(l.dr) || 0), 0);
    const cr = lines.reduce((s, l) => s + (Number(l.cr) || 0), 0);
    return { dr, cr, diff: Math.round((dr - cr) * 100) / 100 };
  }, [lines]);
  const upd = (i: number, p: Record<string, string>) => setLines((ls) => ls.map((l, x) => (x === i ? { ...l, ...p } : l)));

  return (
    <div className="space-y-5">
      <SectionTitle hint="Post manual journals, migration opening balances and audit-trailed reversals. Every entry is period-controlled and must balance.">
        General Ledger
      </SectionTitle>

      <Card title={mode === "journal" ? "Manual journal entry" : "Opening balances (migration)"}
        subtitle={mode === "opening" ? "Any imbalance is automatically routed to Opening Balance Equity (990200) for you to clear." : undefined}
        right={<div className="flex gap-1">
          <Button size="sm" variant={mode === "journal" ? "primary" : "ghost"} onClick={() => setMode("journal")}>Journal</Button>
          <Button size="sm" variant={mode === "opening" ? "primary" : "ghost"} onClick={() => setMode("opening")}>Opening balances</Button>
        </div>}>
        <Grid cols={4}>
          <Field label={mode === "opening" ? "As at date" : "Posting date"}><Input type="date" value={postDate} onChange={(e) => setPostDate(e.target.value)} /></Field>
          <Field label="Reference"><Input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="Narrative / voucher" /></Field>
          {mode === "journal" && <Field label="Currency"><Select value={ccy} onChange={(e) => setCcy(e.target.value)}>
            {(ws?.reference?.currencies ?? ["GHS"]).map((c: string) => <option key={c}>{c}</option>)}</Select></Field>}
        </Grid>

        <div className="scroll-thin mt-3 overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-[16px]">
            <thead className="bg-[var(--bpz-50)] text-[13px] uppercase tracking-wide text-[var(--bpz-800)]">
              <tr>{["G/L account", "Partner", "Cost centre", "Line narrative", "Debit", "Credit", ""].map((h) =>
                <th key={h} className="px-2 py-2 text-left font-bold">{h}</th>)}</tr>
            </thead>
            <tbody>
              {lines.map((l, i) => (
                <tr key={i} className="border-t border-slate-100">
                  <td className="px-1.5 py-1 min-w-[210px]"><Select value={l.account} onChange={(e) => upd(i, { account: e.target.value })}>
                    <option value="">— select —</option>
                    {(ws?.accounts ?? []).filter((a: any) => a.active !== false).map((a: any) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>)}</Select></td>
                  <td className="px-1.5 py-1"><Select value={l.bp} onChange={(e) => upd(i, { bp: e.target.value })}>
                    <option value="">—</option>{(ws?.partners ?? []).map((p: any) => <option key={p.bpNo} value={p.bpNo}>{p.bpNo}</option>)}</Select></td>
                  <td className="px-1.5 py-1"><Select value={l.cc} onChange={(e) => upd(i, { cc: e.target.value })}>
                    <option value="">—</option>{(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode}</option>)}</Select></td>
                  <td className="px-1.5 py-1 min-w-[180px]"><Input value={l.desc} onChange={(e) => upd(i, { desc: e.target.value })} /></td>
                  <td className="px-1.5 py-1 w-28"><Input type="number" step="0.01" value={l.dr} onChange={(e) => upd(i, { dr: e.target.value, cr: "" })} /></td>
                  <td className="px-1.5 py-1 w-28"><Input type="number" step="0.01" value={l.cr} onChange={(e) => upd(i, { cr: e.target.value, dr: "" })} /></td>
                  <td className="px-1 py-1"><Button size="sm" variant="ghost" onClick={() => setLines((ls) => ls.filter((_, x) => x !== i))}>✕</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Button variant="ghost" onClick={() => setLines((ls) => [...ls, { account: "", bp: "", cc: "", desc: "", dr: "", cr: "" }])}>+ Add line</Button>
          <span className="tnum text-[15px]">Dr <b>{money(t.dr)}</b> · Cr <b>{money(t.cr)}</b></span>
          <Badge tone={t.diff === 0 && t.dr > 0 ? "green" : "red"}>
            {t.diff === 0 && t.dr > 0 ? "Balanced" : `Difference ${money(t.diff)}`}
          </Badge>
          <Button variant="gold" className="ml-auto"
            disabled={busy || t.dr === 0 || (mode === "journal" && t.diff !== 0)}
            onClick={() => post(mode === "journal" ? "gl.journal" : "gl.opening", {
              postDate, asAtDate: postDate, reference: ref, currency: ccy,
              lines: lines.filter((l) => l.account).map((l) => ({
                account: l.account, bp: l.bp, cc: l.cc, desc: l.desc,
                dr: Number(l.dr) || 0, cr: Number(l.cr) || 0,
                debit: Number(l.dr) || 0, credit: Number(l.cr) || 0,
              })),
            }).then((r) => { if (r && !r.error) setLines([{ account: "", bp: "", cc: "", desc: "", dr: "", cr: "" }, { account: "", bp: "", cc: "", desc: "", dr: "", cr: "" }]); })}>
            Post {mode === "opening" ? "opening balances" : "journal"}
          </Button>
        </div>
      </Card>

      <Card title="Reverse a document" subtitle="Reversals never delete. A mirror-image entry is posted and both documents remain in the audit trail. A reason is mandatory.">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Document number" hint="Enter the number exactly as shown — a payment number (e.g. PV-5100001), an invoice number (e.g. SI-3300004), or an internal GL document id.">
            <Input value={revDoc} onChange={(e) => setRevDoc(e.target.value)} placeholder="e.g. PV-5100001 or SI-3300004" className="w-56" /></Field>
          <Field label="Reason for reversal" className="min-w-[320px] flex-1">
            <Input value={revReason} onChange={(e) => setRevReason(e.target.value)} placeholder="Minimum 5 characters — this is retained permanently" /></Field>
          <Button variant="danger" disabled={busy || !revDoc || revReason.trim().length < 5}
            onClick={() => post("gl.reverse", { docNo: revDoc, reason: revReason }).then((r) => { if (r && !r.error) { setRevDoc(""); setRevReason(""); } })}>
            Reverse document
          </Button>
        </div>
        <div className="mt-3 rounded-lg bg-[var(--bpz-50)] p-3 text-[13px] leading-relaxed text-slate-700">
          <b className="text-[var(--bpz-900)]">What happens, by document type:</b>
          <ul className="mt-1.5 space-y-1">
            <li>• <b>Payment</b> — the payment is marked reversed and every invoice it was allocated to reopens (or returns to Part-Paid) in the Payment Desk, ready to be collected again.</li>
            <li>• <b>Invoice not yet paid</b> — it is voided and disappears from open items and ageing. An invoice with payments already allocated must have those payments reversed first.</li>
            <li>• <b>Bank-posted statement line</b> — it returns to Unmatched so it can be reclassified and posted correctly.</li>
            <li>• <b>Batch postings</b> (depreciation, payroll, amortisation runs, stock write-downs, asset capitalisation) are not reversible this way — the error message will tell you where to make the correction instead.</li>
          </ul>
        </div>
      </Card>

      <Card title="Chart of accounts" subtitle="Click any account to open its ledger and see every transaction behind the balance.">
        <Table cols={["Account", "Description", "Type", "Sub-type", "IFRS line", "Cash flow", ""]}
          rows={(ws?.accounts ?? []).map((a: any) => [
            <b key="n" className="text-[var(--bpz-800)]">{a.accountNo}</b>, a.description, a.type, a.subType, a.ifrsLine,
            a.cashflowClass === "NONE" ? "—" : a.cashflowClass,
            <Button key="d" size="sm" variant="ghost" onClick={() => onDrill(a.accountNo)}>Open ledger →</Button>,
          ])}
          empty="Chart of accounts loading" />
      </Card>

      <Card title="Universal Journal" subtitle="Every posting from every module lands here — the single source of truth.">
        <Table cols={["Doc", "Ln", "Date", "Period", "Module", "Type", "Account", "Partner", "Cost ctr", "Description", "Ccy", { h: "Debit", align: "right" }, { h: "Credit", align: "right" }, "User"]}
          rows={(rpt?.journal ?? []).map((j: any) => [
            j.reversed ? <s key="d">{j.docNo}</s> : j.docNo, j.lineNo, j.postDate, j.periodCode,
            <Badge key="m" tone="blue">{j.module}</Badge>, j.docType, j.account, j.bp, j.costCenter,
            <span key="x" className="block max-w-[240px] truncate" title={j.description}>{j.description}</span>,
            j.currency, money(j.debit), money(j.credit), j.createdBy])}
          empty="No postings yet" />
      </Card>
    </div>
  );
}

/* ==================== PERIOD CLOSE ==================== */
export function CloseDesk({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [period, setPeriod] = useState(curPeriod());
  const [lock, setLock] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [year, setYear] = useState(new Date().getUTCFullYear());
  const periods = ws?.periods ?? [];
  const years = Array.from(new Set(periods.map((p: any) => p.year))).sort() as number[];

  return (
    <div className="space-y-5">
      <SectionTitle hint="Fiscal periods govern every module. Nothing can be posted into a closed period until it is re-opened.">
        Period Control &amp; Month-End Close
      </SectionTitle>

      <div className="grid gap-4 xl:grid-cols-[420px_1fr]">
        <Card title="Automated month-end routine">
          <div className="space-y-3">
            <Field label="Period"><Select value={period} onChange={(e) => setPeriod(e.target.value)}>
              {periods.map((p: any) => <option key={p.code} value={p.code}>{p.code} — {p.startDate} to {p.endDate} ({p.status})</option>)}</Select></Field>
            <label className="flex items-center gap-2 text-[15px]">
              <input type="checkbox" checked={lock} onChange={(e) => setLock(e.target.checked)} />
              Lock the period afterwards if it balances
            </label>
            <Button variant="gold" className="w-full" disabled={busy}
              onClick={() => post("close.month", { periodCode: period, lock }).then((r) => { if (r && !r.error) setResult(r); })}>
              Run month-end close
            </Button>
            <ol className="space-y-1 rounded-lg bg-[var(--bpz-50)] p-3 text-[16px] text-slate-600">
              {["Depreciation on every active asset", "Prepayment, accrual and deferred income amortisation",
                "Inventory written down to net realisable value (IAS 2)", "Foreign currency retranslation (IAS 21)",
                "VAT control settlement to the GRA account", "Trial balance integrity check"]
                .map((s, i) => <li key={i} className="flex gap-2"><span className="font-bold text-[var(--gold-700)]">{i + 1}.</span>{s}</li>)}
            </ol>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("asset.depreciate", { periodCode: period })}>Depreciation only</Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("prepay.run", { periodCode: period })}>Amortisation only</Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("close.vat", { periodCode: period })}>VAT only</Button>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("close.fx", { periodCode: period })}>FX revaluation only</Button>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          {result && (
            <Card title={`Close results — ${result.periodCode}`}>
              <Table cols={["Step", "Outcome", "Status"]}
                rows={(result.steps ?? []).map((s: any) => [s.step, s.result,
                  <Badge key="s" tone={s.ok ? "green" : "red"}>{s.ok ? "OK" : "Attention"}</Badge>])} />
            </Card>
          )}
          <Card title="Year-end close" subtitle="Transfers all profit or loss balances to retained earnings.">
            <div className="flex flex-wrap items-end gap-2">
              <Field label="Fiscal year"><Select value={year} onChange={(e) => setYear(Number(e.target.value))} className="w-32">
                {years.map((y) => <option key={y} value={y}>{y}</option>)}</Select></Field>
              <Button variant="primary" disabled={busy} onClick={() => post("close.year", { fiscalYear: year })}>Run year-end close</Button>
            </div>
          </Card>
          <Card title="Extend the fiscal calendar" subtitle="Periods can be generated for any number of future years.">
            <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
              post("period.extend", Object.fromEntries(f)); }}>
              <Field label="From year"><Input name="fromYear" type="number" defaultValue={new Date().getUTCFullYear()} className="w-28" /></Field>
              <Field label="To year"><Input name="toYear" type="number" defaultValue={new Date().getUTCFullYear() + 5} className="w-28" /></Field>
              <Field label="FY starts in month"><Select name="fyStartMonth" defaultValue={ws?.client?.fyStartMonth ?? 1} className="w-32">
                {["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"].map((m, i) =>
                  <option key={m} value={i + 1}>{m}</option>)}</Select></Field>
              <Button type="submit" variant="ghost" disabled={busy}>Generate periods</Button>
            </form>
          </Card>
        </div>
      </div>

      <Card title="Fiscal calendar">
        <Table cols={["Period", "Fiscal year", "No.", "Start", "End", "Status", "Closed by", "Action"]}
          rows={periods.slice(0, 120).map((p: any) => [
            <b key="c">{p.code}</b>, p.year, p.period, p.startDate, p.endDate,
            <Badge key="s" tone={tone(p.status)}>{p.status}</Badge>, p.closedBy || "—",
            <span key="a" className="flex gap-1">
              {p.status === "OPEN"
                ? <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("period.status", { periodCode: p.code, status: "CLOSED" })}>Close</Button>
                : <Button size="sm" variant="ghost" disabled={busy} onClick={() => post("period.status", { periodCode: p.code, status: "OPEN" })}>Re-open</Button>}
            </span>,
          ])}
          empty="No periods" />
      </Card>
    </div>
  );
}

/* ==================== REPORTS ==================== */
export function Reports({ ws, rpt, filter, setFilter, ledger, onDrill, exportUrl }: {
  ws: WS; rpt: RPT; filter: any; setFilter: (f: any) => void; ledger: any;
  onDrill: (a: string) => void; exportUrl: string;
}) {
  const [tab, setTab] = useState("IS");
  const tabs = [["IS", "Profit or Loss"], ["BS", "Financial Position"], ["CF", "Cash Flows"],
    ["EQ", "Changes in Equity"], ["TB", "Trial Balance"], ["AR", "Receivables Ageing"],
    ["AP", "Payables Ageing"], ["VAT", "VAT Schedule"], ["WHT", "WHT Schedule"],
    ["GL", "Account Ledger"], ["INV", "Inventory"], ["PAY", "Payroll"]];
  const periods = ws?.periods ?? [];
  const bs = rpt?.balanceSheet;

  return (
    <div className="space-y-5">
      <SectionTitle hint="All statements follow the IFRS presentation requirements of IAS 1 and IAS 7. Filter by fiscal period, cost centre or project.">
        Financial Reporting
      </SectionTitle>

      <Card title="Report filters">
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Period from"><Select value={filter.from ?? ""} onChange={(e) => setFilter({ ...filter, from: e.target.value })} className="w-36">
            <option value="">Opening</option>{periods.map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select></Field>
          <Field label="Period to"><Select value={filter.to ?? ""} onChange={(e) => setFilter({ ...filter, to: e.target.value })} className="w-36">
            <option value="">Latest</option>{periods.map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select></Field>
          <Field label="Cost centre"><Select value={filter.costCenter ?? ""} onChange={(e) => setFilter({ ...filter, costCenter: e.target.value })} className="w-44">
            <option value="">All</option>{(ws?.costCenters ?? []).map((c: any) => <option key={c.ccCode} value={c.ccCode}>{c.ccCode} · {c.ccName}</option>)}</Select></Field>
          <Field label="Project"><Select value={filter.project ?? ""} onChange={(e) => setFilter({ ...filter, project: e.target.value })} className="w-40">
            <option value="">All</option>{(ws?.projects ?? []).map((p: any) => <option key={p.projectNo} value={p.projectNo}>{p.projectNo}</option>)}</Select></Field>
          <Button variant="ghost" onClick={() => setFilter({})}>Clear</Button>
          <a href={exportUrl} className="ml-auto inline-flex items-center gap-1.5 rounded-lg bg-[var(--gold-500)] px-3 py-1.5 text-[15px] font-semibold text-[var(--bpz-900)] hover:bg-[var(--gold-400)]">
            ⬇ Export full workbook (.xlsx)
          </a>
          <Button variant="ghost" onClick={() => window.print()}>🖨 Print</Button>
        </div>
      </Card>

      <div className="flex flex-wrap gap-1.5">
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`rounded-lg px-3 py-1.5 text-[16px] font-medium transition ${tab === k ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-600 hover:bg-slate-50"}`}>
            {l}
          </button>
        ))}
      </div>

      {tab === "IS" && <Card title="Statement of Profit or Loss and Other Comprehensive Income"
        subtitle={`For the period ${filter.from ?? "opening"} to ${filter.to ?? "latest"} · ${ws?.client?.currency ?? "GHS"}`}>
        <StatementTable lines={rpt?.incomeStatement?.lines ?? []} />
      </Card>}

      {tab === "BS" && <Card title="Statement of Financial Position"
        subtitle={bs?.totals?.balanced ? "✓ The statement balances" : `✕ Out of balance by ${money(bs?.totals?.difference)}`}>
        <StatementTable lines={[
          { label: "ASSETS", header: true },
          { label: "Non-current assets", header: true },
          ...(bs?.nonCurrentAssets ?? []).map((r: any) => ({ label: `   ${r.accountNo} · ${r.description}`, amount: r.closing })),
          { label: "Total non-current assets", amount: bs?.totals?.totalNCA, bold: true, rule: true },
          { label: "Current assets", header: true },
          ...(bs?.currentAssets ?? []).map((r: any) => ({ label: `   ${r.accountNo} · ${r.description}`, amount: r.closing })),
          { label: "Total current assets", amount: bs?.totals?.totalCA, bold: true, rule: true },
          { label: "TOTAL ASSETS", amount: bs?.totals?.totalAssets, bold: true, rule: true },
          { label: "EQUITY AND LIABILITIES", header: true },
          { label: "Equity", header: true },
          ...(bs?.equity ?? []).map((r: any) => ({ label: `   ${r.accountNo} · ${r.description}`, amount: -r.closing })),
          { label: "   Profit for the period", amount: bs?.totals?.retainedProfit },
          { label: "Total equity", amount: bs?.totals?.totalEquity, bold: true, rule: true },
          { label: "Non-current liabilities", header: true },
          ...(bs?.nonCurrentLiabilities ?? []).map((r: any) => ({ label: `   ${r.accountNo} · ${r.description}`, amount: -r.closing })),
          { label: "Current liabilities", header: true },
          ...(bs?.currentLiabilities ?? []).map((r: any) => ({ label: `   ${r.accountNo} · ${r.description}`, amount: -r.closing })),
          { label: "Total liabilities", amount: bs?.totals?.totalLiabilities, bold: true, rule: true },
          { label: "TOTAL EQUITY AND LIABILITIES", amount: bs?.totals?.equityAndLiabilities, bold: true, rule: true },
        ]} />
      </Card>}

      {tab === "CF" && <Card title="Statement of Cash Flows" subtitle="Indirect method (IAS 7)">
        <StatementTable lines={rpt?.cashFlow?.lines ?? []} />
        <p className="mt-2 text-[14px] text-slate-600">
          Reconciliation check: indirect total {money(rpt?.cashFlow?.reconciliation?.indirectTotal)} versus actual
          cash movement {money(rpt?.cashFlow?.reconciliation?.actualCashMovement)} — variance {money(rpt?.cashFlow?.reconciliation?.variance)}.
        </p>
      </Card>}

      {tab === "EQ" && <Card title="Statement of Changes in Equity" subtitle="IAS 1">
        <Table cols={["", { h: "Stated capital", align: "right" }, { h: "Retained earnings", align: "right" },
          { h: "OCI reserves", align: "right" }, { h: "Other reserves", align: "right" }, { h: "Total", align: "right" }]}
          rows={(rpt?.changesInEquity?.rows ?? []).map((r: any) => [
            r.bold ? <b key="l">{r.label}</b> : r.label, money(r.capital), money(r.retained), money(r.oci), money(r.other),
            r.bold ? <b key="t">{money(r.total)}</b> : money(r.total)])} />
      </Card>}

      {tab === "TB" && <Card title="Trial Balance" subtitle="Opening, movement and closing by account">
        <Table cols={["Account", "Description", "Type", { h: "Opening Dr", align: "right" }, { h: "Opening Cr", align: "right" },
          { h: "Period Dr", align: "right" }, { h: "Period Cr", align: "right" }, { h: "Closing", align: "right" }, ""]}
          rows={(rpt?.trialBalance ?? []).map((r: any) => [
            r.accountNo, r.description, r.type, money(r.openingDr), money(r.openingCr),
            money(r.periodDr), money(r.periodCr), money(r.closing),
            <Button key="d" size="sm" variant="ghost" onClick={() => onDrill(r.accountNo)}>Ledger</Button>])} />
      </Card>}

      {(tab === "AR" || tab === "AP") && (() => {
        const a = tab === "AR" ? rpt?.arAgeing : rpt?.apAgeing;
        return <Card title={`${tab === "AR" ? "Accounts Receivable" : "Accounts Payable"} Ageing`} subtitle={`As at ${a?.asAt ?? todayStr()} — click Statement for a printable PDF.`}>
          <Table cols={["Partner", "Name", { h: "Current", align: "right" }, { h: "1–30", align: "right" }, { h: "31–60", align: "right" },
            { h: "61–90", align: "right" }, { h: "90+", align: "right" }, { h: "Total", align: "right" }, ""]}
            rows={[...(a?.rows ?? []).map((r: any) => [r.bp, r.name, money(r.current), money(r.d30), money(r.d60), money(r.d90), money(r.d120), money(r.total),
              <a key="pdf" href={`/api/pdf?kind=statement&bp=${encodeURIComponent(r.bp)}`} target="_blank" rel="noreferrer"
                className="inline-flex items-center rounded-lg border border-slate-300 bg-white px-2 py-1 text-[14px] font-medium text-slate-700 hover:bg-slate-50">
                Statement ↗
              </a>]),
            ["", <b key="t">TOTAL</b>, <b key="1">{money(a?.totals?.current)}</b>, <b key="2">{money(a?.totals?.d30)}</b>,
              <b key="3">{money(a?.totals?.d60)}</b>, <b key="4">{money(a?.totals?.d90)}</b>, <b key="5">{money(a?.totals?.d120)}</b>,
              <b key="6">{money(a?.totals?.total)}</b>, ""]]}
            empty="No outstanding balances" />
        </Card>;
      })()}

      {tab === "VAT" && (() => {
        const v = rpt?.vatSchedule;
        return <div className="space-y-4">
          <Card tone="tint" title="Filing guidance" subtitle="Value Added Tax Act 2013 (Act 870), as amended">
            <div className="grid gap-3 text-[16px] text-slate-600 sm:grid-cols-3">
              <div><p className="font-bold text-[var(--bpz-900)]">Standard rate</p><p>20% — no cascading. Levies (tourism, CST, etc.) are computed on the net value, never on top of VAT.</p></div>
              <div><p className="font-bold text-[var(--bpz-900)]">Filing deadline</p><p>The last working day of the month following the tax period.</p></div>
              <div><p className="font-bold text-[var(--bpz-900)]">Who files</p><p>Every VAT-registered person, even where output and input VAT net to a recoverable position.</p></div>
            </div>
          </Card>
          <Card title="Output VAT — Sales" subtitle={`${v?.periodFrom ?? "opening"} to ${v?.periodTo ?? "latest"} — amounts to declare as sales on the VAT return`}>
            <Table cols={["Code", "Description", { h: "Rate", align: "right" }, { h: "Levy", align: "right" }, { h: "Docs", align: "right" }, { h: "Net", align: "right" }, { h: "VAT", align: "right" }, { h: "Levy", align: "right" }, { h: "Gross", align: "right" }]}
              rows={[...(v?.sales ?? []).map((r: any) => [r.code, r.name, `${r.rate}%`, `${r.levyRate}%`, r.docCount, money(r.net), money(r.vat), money(r.levy), money(r.gross)]),
                ["", <b key="t">TOTAL OUTPUT VAT</b>, "", "", "", <b key="n">{money(v?.totals?.salesNet)}</b>, <b key="v">{money(v?.totals?.outputVat)}</b>, "", ""]]}
              empty="No sales documents in this period" />
          </Card>
          <Card title="Input VAT — Purchases" subtitle="Amounts to declare as purchases/input tax on the VAT return">
            <Table cols={["Code", "Description", { h: "Rate", align: "right" }, { h: "Levy", align: "right" }, { h: "Docs", align: "right" }, { h: "Net", align: "right" }, { h: "VAT", align: "right" }, { h: "Levy", align: "right" }, { h: "Gross", align: "right" }]}
              rows={[...(v?.purchases ?? []).map((r: any) => [r.code, r.name, `${r.rate}%`, `${r.levyRate}%`, r.docCount, money(r.net), money(r.vat), money(r.levy), money(r.gross)]),
                ["", <b key="t">TOTAL INPUT VAT</b>, "", "", "", <b key="n">{money(v?.totals?.purchasesNet)}</b>, <b key="v">{money(v?.totals?.inputVat)}</b>, "", ""]]}
              empty="No purchase documents in this period" />
          </Card>
          <Card title="Net position to file">
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Output VAT" value={money(v?.totals?.outputVat)} tone="blue" />
              <Stat label="Input VAT (recoverable)" value={money(v?.totals?.inputVat)} tone="green" />
              <Stat label={(v?.totals?.netPayable ?? 0) >= 0 ? "Net VAT payable to GRA" : "Net VAT recoverable"} value={money(Math.abs(v?.totals?.netPayable ?? 0))} tone={(v?.totals?.netPayable ?? 0) >= 0 ? "red" : "green"} />
            </div>
          </Card>
        </div>;
      })()}

      {tab === "WHT" && (() => {
        const w = rpt?.whtSchedule;
        return <div className="space-y-4">
          <Card tone="tint" title="Filing guidance" subtitle="Income Tax Act 2015 (Act 896), sections 116–124">
            <div className="grid gap-3 text-[16px] text-slate-600 sm:grid-cols-3">
              <div><p className="font-bold text-[var(--bpz-900)]">Filing deadline</p><p>The 15th day of the month following the month of deduction.</p></div>
              <div><p className="font-bold text-[var(--bpz-900)]">Basis</p><p>Withheld on the VAT-exclusive (net) value of the qualifying payment.</p></div>
              <div><p className="font-bold text-[var(--bpz-900)]">Certificates</p><p>Issue a WHT credit certificate to each supplier for every amount withheld.</p></div>
            </div>
          </Card>
          <Card title="Withholding tax by rate code" subtitle={`${w?.periodFrom ?? "opening"} to ${w?.periodTo ?? "latest"} — the figures to complete the GRA WHT schedule`}>
            <Table cols={["Code", "Description", "Residency", "Category", { h: "Rate", align: "right" }, { h: "Payments", align: "right" }, { h: "Taxable base", align: "right" }, { h: "WHT withheld", align: "right" }]}
              rows={[...(w?.rows ?? []).map((r: any) => [r.code, r.name, <Badge key="r" tone={r.residency === "RESIDENT" ? "blue" : "amber"}>{r.residency.replace("_", "-")}</Badge>, r.category, `${r.rate}%`, r.count, money(r.base), money(r.amount)]),
                ["", <b key="t">TOTAL</b>, "", "", "", "", <b key="b">{money(w?.totals?.base)}</b>, <b key="a">{money(w?.totals?.amount)}</b>]]}
              empty="No withholding tax deducted in this period" />
          </Card>
          <Card title="Withholding detail by supplier">
            <Table cols={["Payment", "Date", "Supplier", "Code", { h: "Base", align: "right" }, { h: "WHT", align: "right" }]}
              rows={(w?.byPartner ?? []).map((r: any) => [r.payNo, r.payDate, `${r.bp} · ${r.name}`, r.code, money(r.base), money(r.amount)])}
              empty="No withholding tax deducted in this period" />
          </Card>
        </div>;
      })()}

      {tab === "GL" && <Card title={`Account ledger ${ledger?.account ? `— ${ledger.account} ${ledger.description}` : ""}`}
        subtitle={ledger?.account ? `Opening ${money(ledger.opening)} · Closing ${money(ledger.closing)}` : "Select an account from the trial balance or chart of accounts."}>
        {!ledger?.account ? <Empty icon="📒" title="No account selected" hint="Click 'Ledger' beside any account to see every transaction behind its balance." /> : (
          <Table cols={["Doc", "Date", "Period", "Module", "Type", "Description", "Partner", "Cost ctr", { h: "Debit", align: "right" }, { h: "Credit", align: "right" }, { h: "Balance", align: "right" }, "User"]}
            rows={(ledger.lines ?? []).map((l: any) => [
              l.reversed ? <s key="d">{l.docNo}</s> : l.docNo, l.postDate, l.periodCode, l.module, l.docType,
              <span key="x" className="block max-w-[260px] truncate" title={l.description}>{l.description}</span>,
              l.bp, l.costCenter, money(l.debit), money(l.credit), money(l.balance), l.createdBy])}
            empty="No transactions in this account for the selected period" />
        )}
      </Card>}

      {tab === "INV" && <Card title="Inventory Valuation" subtitle="Weighted average cost, tested against net realisable value (IAS 2)">
        <Table cols={["Item", "Description", "UoM", { h: "Quantity", align: "right" }, { h: "Unit cost", align: "right" },
          { h: "Cost value", align: "right" }, { h: "NRV value", align: "right" }, { h: "Carrying", align: "right" }, { h: "Write-down", align: "right" }]}
          rows={(rpt?.inventory ?? []).map((m: any) => [
            m.materialNo, m.description, m.uom, money(m.qty), money(m.unitCost), money(m.cost),
            money(m.nrvTotal), money(m.carrying), m.writedown > 0 ? <b key="w" className="text-rose-600">{money(m.writedown)}</b> : "—"])}
          empty="No inventory items" />
      </Card>}

      {tab === "PAY" && <Card title="Payroll Register">
        <Table cols={["Run", "Employee", { h: "Basic", align: "right" }, { h: "Allowances", align: "right" }, { h: "Gross", align: "right" },
          { h: "SSNIT EE", align: "right" }, { h: "Reliefs", align: "right" }, { h: "Chargeable", align: "right" },
          { h: "PAYE", align: "right" }, { h: "Net pay", align: "right" }]}
          rows={(rpt?.payroll ?? []).map((p: any) => [p.runNo, p.empNo, money(p.basic), money(p.allowances), money(p.gross),
            money(p.ssnitEe), money(p.reliefs), money(p.taxable), money(p.paye), money(p.net)])}
          empty="No payroll posted" />
      </Card>}
    </div>
  );
}

/* ==================== TAX CENTRE ==================== */
export function TaxCentre({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [scope, setScope] = useState("WHT");
  const rows = (ws?.taxRates ?? []).filter((t: any) => t.scope === scope);
  const sector = (ws?.reference?.sectors ?? []).find((s: any) => s.key === ws?.client?.sector);

  return (
    <div className="space-y-5">
      <SectionTitle hint="Every rate is data-driven and date-effective. Amend a rate here and the whole platform follows, while historic periods keep their original rate.">
        Tax Centre
      </SectionTitle>

      {sector && (
        <Card title={`Sector tax profile — ${sector.name}`} tone="tint">
          <div className="grid gap-3 md:grid-cols-3">
            <div><p className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Regulator</p><p className="text-[15px]">{sector.regulator}</p></div>
            <div><p className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Accounting focus</p><p className="text-[15px]">{sector.notes}</p></div>
            <div><p className="text-[13px] font-bold uppercase tracking-wider text-slate-600">Special tax regime</p>
              <div className="mt-0.5 flex flex-wrap gap-1">{sector.specialTax.map((t: string) => <Badge key={t} tone="gold">{t}</Badge>)}</div></div>
          </div>
        </Card>
      )}

      <div className="flex flex-wrap gap-1.5">
        {[["WHT", "Withholding Tax"], ["PAYE", "PAYE & Reliefs"], ["VAT", "VAT & Levies"], ["CIT", "Corporate & Sector Taxes"]].map(([k, l]) => (
          <button key={k} onClick={() => setScope(k)}
            className={`rounded-lg px-3 py-1.5 text-[16px] font-medium ${scope === k ? "bg-[var(--bpz-800)] text-white" : "border border-slate-300 bg-white text-slate-600"}`}>{l}</button>
        ))}
      </div>

      <Card title={`${scope} rates`} subtitle="Click Edit to amend a rate and set the date it takes effect.">
        <Table cols={["Code", "Description", { h: "Rate %", align: "right" }, "Residency", "Category", "Effective from", "Effective to", ""]}
          rows={rows.map((t: any) => [
            t.code, t.name, Number(t.rate).toFixed(2),
            t.residency === "ANY" ? "—" : <Badge key="r" tone={t.residency === "RESIDENT" ? "blue" : "amber"}>{t.residency.replace("_", "-")}</Badge>,
            t.basis || t.sector, t.effectiveFrom, t.effectiveTo || "Current",
            <TaxEditor key="e" row={t} post={post} busy={busy} />])}
          empty="No rates in this category" />
      </Card>

      <Card title="Add a tax rate" subtitle="Use this when the GRA introduces a new levy or withholding category.">
        <form className="flex flex-wrap items-end gap-2" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          post("tax.create", Object.fromEntries(f)); (e.target as HTMLFormElement).reset(); }}>
          <Field label="Scope"><Select name="scope" defaultValue="WHT" className="w-28">{["WHT", "VAT", "PAYE", "CIT", "LEVY"].map((s) => <option key={s}>{s}</option>)}</Select></Field>
          <Field label="Code"><Input name="code" required className="w-36" placeholder="R_NEWLEVY" /></Field>
          <Field label="Description"><Input name="name" required className="w-72" /></Field>
          <Field label="Rate %"><Input name="rate" type="number" step="0.01" required className="w-24" /></Field>
          <Field label="Residency"><Select name="residency" defaultValue="ANY" className="w-36">
            <option value="ANY">Any</option><option value="RESIDENT">Resident</option><option value="NON_RESIDENT">Non-resident</option></Select></Field>
          <Field label="Effective from"><Input name="effectiveFrom" type="date" defaultValue={todayStr()} /></Field>
          <Button type="submit" variant="gold" disabled={busy}>Add rate</Button>
        </form>
      </Card>
    </div>
  );
}

function TaxEditor({ row, post, busy }: { row: any; post: Post; busy: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button size="sm" variant="ghost" onClick={() => setOpen(true)}>Edit</Button>
      <Modal open={open} title={`Amend ${row.scope} · ${row.code}`} onClose={() => setOpen(false)}>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
          post("tax.update", { id: row.id, ...Object.fromEntries(f) }).then(() => setOpen(false)); }}>
          <Field label="Description"><Input name="name" defaultValue={row.name} /></Field>
          <Grid cols={2}>
            <Field label="Rate (%)"><Input name="rate" type="number" step="0.01" defaultValue={row.rate} /></Field>
            <Field label="Effective from"><Input name="effectiveFrom" type="date" defaultValue={row.effectiveFrom} /></Field>
            <Field label="Effective to" hint="Leave blank if still current"><Input name="effectiveTo" type="date" defaultValue={row.effectiveTo ?? ""} /></Field>
          </Grid>
          <Field label="Note / legal reference"><Input name="note" defaultValue={row.note} /></Field>
          <Button type="submit" variant="gold" disabled={busy}>Save amendment</Button>
        </form>
      </Modal>
    </>
  );
}

/* ==================== PRACTICE / ADVISORY ==================== */
export function Practice({ ws, post, busy }: { ws: WS; post: Post; busy: boolean }) {
  const [line, setLine] = useState("");
  const [open, setOpen] = useState<any>(null);
  const templates = (ws?.reference?.templates ?? []).filter((t: any) =>
    (!line || t.serviceLine === line) && (t.sectors.includes("*") || t.sectors.includes(ws?.client?.sector)));
  const lines = ws?.reference?.serviceLines ?? [];

  return (
    <div className="space-y-5">
      <SectionTitle hint="Professional work programmes with quantitative schedules, qualitative commentary and sign-off checklists — linked to the client ledger.">
        Service Delivery &amp; Work Templates
      </SectionTitle>

      <Card title="Engagements" right={<Button size="sm" variant="gold" onClick={() => setOpen({ create: true })}>+ Open engagement</Button>}>
        <Table cols={["Ref", "Service line", "Title", "Period", "Assigned to", { h: "Fee", align: "right" }, "Charge to", "Status", ""]}
          rows={(ws?.engagements ?? []).map((e: any) => [
            e.engNo, <Badge key="s" tone="violet">{e.serviceLine}</Badge>, e.title, e.periodCode || "—",
            e.assignedTo, money(e.feeAmount), <Badge key="c" tone={e.chargeTo === "CLIENT" ? "blue" : "gold"}>{e.chargeTo}</Badge>,
            <Badge key="t" tone={tone(e.status)}>{e.status}</Badge>,
            <Button key="o" size="sm" variant="ghost" onClick={() => setOpen(e)}>Open file</Button>])}
          empty="No engagements opened yet" />
      </Card>

      <Card title="Work template library" subtitle={`${templates.length} templates available for ${ws?.client?.sector ?? "this sector"}`}
        right={<Select value={line} onChange={(e) => setLine(e.target.value)} className="w-56">
          <option value="">All service lines</option>
          {lines.map((l: any) => <option key={l.key} value={l.key}>{l.name}</option>)}</Select>}>
        <div className="grid gap-3 lg:grid-cols-2 xl:grid-cols-3">
          {templates.map((t: any) => (
            <div key={t.key} className="rounded-xl border border-slate-200 bg-white p-3.5 shadow-sm">
              <div className="flex items-start justify-between gap-2">
                <h4 className="font-display text-[15px] font-bold text-[var(--bpz-900)]">{t.title}</h4>
                <Badge tone="violet">{t.serviceLine}</Badge>
              </div>
              <p className="mt-1.5 text-[16px] leading-relaxed text-slate-600">{t.objective}</p>
              <div className="mt-2 flex flex-wrap gap-1">{t.standards.map((s: string) => <Badge key={s} tone="gold">{s}</Badge>)}</div>
              <p className="mt-2 text-[14px] text-slate-600">
                {t.quantitative.length} quantitative measures · {t.qualitative.length} commentary sections · {t.checklist.length} checklist items
              </p>
              <p className="mt-1.5 text-[14px] italic text-slate-600">Deliverable: {t.deliverable}</p>
              <Button size="sm" variant="ghost" className="mt-2" onClick={() => setOpen({ create: true, templateKey: t.key })}>Use this template</Button>
            </div>
          ))}
        </div>
      </Card>

      <Modal open={!!open} wide title={open?.create ? "Open a new engagement" : `Engagement file — ${open?.engNo ?? ""}`} onClose={() => setOpen(null)}>
        {open?.create ? (
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget);
            post("eng.create", Object.fromEntries(f)).then(() => setOpen(null)); }}>
            <Field label="Work template"><Select name="templateKey" defaultValue={open.templateKey ?? ""} required>
              <option value="">— select a template —</option>
              {(ws?.reference?.templates ?? []).map((t: any) => <option key={t.key} value={t.key}>{t.serviceLine} · {t.title}</option>)}</Select></Field>
            <Grid cols={2}>
              <Field label="Engagement title"><Input name="title" placeholder="Defaults to the template title" /></Field>
              <Field label="Period"><Select name="periodCode" defaultValue={curPeriod()}>
                {(ws?.periods ?? []).map((p: any) => <option key={p.code} value={p.code}>{p.code}</option>)}</Select></Field>
              <Field label="Assigned to"><Input name="assignedTo" placeholder="staff@bpz.com.gh" /></Field>
              <Field label="Fee amount"><Input name="feeAmount" type="number" step="0.01" defaultValue={0} /></Field>
              <Field label="Charge to"><Select name="chargeTo" defaultValue="CLIENT">
                <option value="CLIENT">Chargeable to the client</option>
                <option value="FIRM">Absorbed by the firm (internal)</option></Select></Field>
              <Field label="Due date"><Input name="dueDate" type="date" /></Field>
            </Grid>
            <Button type="submit" variant="gold" disabled={busy}>Open engagement</Button>
          </form>
        ) : open ? <EngagementFile eng={open} ws={ws} post={post} busy={busy} onDone={() => setOpen(null)} /> : null}
      </Modal>
    </div>
  );
}

function EngagementFile({ eng, ws, post, busy, onDone }: { eng: any; ws: WS; post: Post; busy: boolean; onDone: () => void }) {
  const tpl = (ws?.reference?.templates ?? []).find((t: any) => t.key === eng.templateKey);
  const [quant, setQuant] = useState<Record<string, number>>(eng.quantitative ?? {});
  const [qual, setQual] = useState<Record<string, string>>(eng.qualitative ?? {});
  const [list, setList] = useState(eng.checklist ?? []);
  const [concl, setConcl] = useState(eng.conclusion ?? "");
  const [status, setStatus] = useState(eng.status);
  const done = list.filter((c: any) => c.done).length;

  return (
    <div className="space-y-4">
      <div className="rounded-lg bg-[var(--bpz-50)] p-3 text-[16px]">
        <b>{tpl?.title ?? eng.title}</b>
        <p className="mt-1 text-slate-600">{tpl?.objective}</p>
        <div className="mt-1.5 flex flex-wrap gap-1">{(tpl?.standards ?? []).map((s: string) => <Badge key={s} tone="gold">{s}</Badge>)}</div>
      </div>

      {tpl?.quantitative?.length > 0 && (
        <div>
          <p className="mb-1.5 text-[14px] font-bold uppercase tracking-wider text-slate-600">Quantitative schedule</p>
          <Grid cols={3}>{tpl.quantitative.map((q: any) => (
            <Field key={q.key} label={`${q.label} (${q.unit})`}>
              <Input type="number" step="0.01" value={quant[q.key] ?? ""} onChange={(e) => setQuant({ ...quant, [q.key]: Number(e.target.value) })} />
            </Field>))}</Grid>
        </div>
      )}

      {tpl?.qualitative?.length > 0 && (
        <div>
          <p className="mb-1.5 text-[14px] font-bold uppercase tracking-wider text-slate-600">Qualitative commentary</p>
          <div className="space-y-2">{tpl.qualitative.map((q: any) => (
            <Field key={q.key} label={q.label} hint={q.prompt}>
              <TextArea value={qual[q.key] ?? ""} onChange={(e) => setQual({ ...qual, [q.key]: e.target.value })} />
            </Field>))}</div>
        </div>
      )}

      <div>
        <p className="mb-1.5 text-[14px] font-bold uppercase tracking-wider text-slate-600">Completion checklist — {done}/{list.length} complete</p>
        <div className="scroll-thin max-h-72 space-y-1 overflow-y-auto rounded-lg border border-slate-200 p-2">
          {list.map((c: any, i: number) => (
            <label key={i} className="flex items-start gap-2 rounded px-1.5 py-1 text-[16px] hover:bg-slate-50">
              <input type="checkbox" className="mt-0.5" checked={c.done}
                onChange={(e) => setList(list.map((x: any, j: number) => (j === i ? { ...x, done: e.target.checked } : x)))} />
              <span className={c.done ? "text-slate-600 line-through" : ""}>{c.item}</span>
            </label>
          ))}
        </div>
      </div>

      <Field label="Overall conclusion"><TextArea value={concl} onChange={(e) => setConcl(e.target.value)} placeholder="Summarise the outcome, the opinion reached and the actions agreed with the client." /></Field>

      <div className="flex flex-wrap items-end gap-2">
        <Field label="Status"><Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-44">
          {["PLANNED", "IN_PROGRESS", "REVIEW", "COMPLETED", "ISSUED"].map((s) => <option key={s}>{s}</option>)}</Select></Field>
        <Button variant="gold" disabled={busy}
          onClick={() => post("eng.update", { engNo: eng.engNo, status, quantitative: quant, qualitative: qual, checklist: list, conclusion: concl }).then(onDone)}>
          Save working paper
        </Button>
        {eng.chargeTo === "CLIENT" && Number(eng.feeAmount) > 0 && (
          <Button variant="ghost" disabled={busy}
            onClick={() => post("eng.bill", { bp: (ws?.partners ?? []).find((p: any) => p.type === "Customer")?.bpNo, description: eng.title, amount: Number(eng.feeAmount) })}>
            Raise fee invoice
          </Button>
        )}
      </div>
    </div>
  );
}
