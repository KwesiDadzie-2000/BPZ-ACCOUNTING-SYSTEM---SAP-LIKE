import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
import { loadEnv } from "vite";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    test: {
      include: ["tests/**/*.test.ts"],
      environment: "node",
      env: {
        // Pure-logic tests must not need a live database. A placeholder keeps
        // the pool from throwing at import time; DB-touching tests are skipped
        // when the URL is a placeholder.
        DATABASE_URL: env.DATABASE_URL || "postgresql://placeholder:placeholder@localhost:5432/placeholder",
      },
    },
    resolve: {
      alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
    },
  };
});
