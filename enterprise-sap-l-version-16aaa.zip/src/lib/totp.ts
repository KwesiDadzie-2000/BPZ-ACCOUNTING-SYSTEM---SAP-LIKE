import { createHmac, randomBytes, createHash } from "crypto";

/**
 * RFC 6238 TOTP (time-based one-time password) — the standard behind Google
 * Authenticator, Microsoft Authenticator, Authy and 1Password.
 * Implemented with Node's built-in crypto only, so there is no third-party
 * dependency in the authentication path.
 */

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export function generateSecret(bytes = 20): string {
  const buf = randomBytes(bytes);
  let bits = "";
  for (const b of buf) bits += b.toString(2).padStart(8, "0");
  let out = "";
  for (let i = 0; i + 5 <= bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}

function base32Decode(secret: string): Buffer {
  const clean = secret.toUpperCase().replace(/=+$/, "").replace(/\s/g, "");
  let bits = "";
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx === -1) continue;
    bits += idx.toString(2).padStart(5, "0");
  }
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

function hotp(secret: string, counter: number): string {
  const key = base32Decode(secret);
  const buf = Buffer.alloc(8);
  buf.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
  buf.writeUInt32BE(counter % 0x100000000, 4);
  const hmac = createHmac("sha1", key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return String(code % 1_000_000).padStart(6, "0");
}

/** Current 6-digit code for a secret (used by the enrolment confirmation UI). */
export function totpNow(secret: string): string {
  return hotp(secret, Math.floor(Date.now() / 30_000));
}

/** Verify a 6-digit code, allowing ±1 time step for clock drift. */
export function verifyTotp(secret: string, token: string): boolean {
  const clean = (token ?? "").replace(/\D/g, "");
  if (clean.length !== 6 || !secret) return false;
  const counter = Math.floor(Date.now() / 30_000);
  for (let w = -1; w <= 1; w++) {
    if (hotp(secret, counter + w) === clean) return true;
  }
  return false;
}

/** otpauth:// URI for authenticator apps. */
export function otpauthUri(secret: string, account: string, issuer = "BPZ CONSULT"): string {
  const label = encodeURIComponent(`${issuer}:${account}`);
  return `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}

// ------------------------------------------------------------
// Password policy
// ------------------------------------------------------------

export const PASSWORD_RULES = {
  minLength: 10,
  requireUpper: true,
  requireLower: true,
  requireDigit: true,
  description: "At least 10 characters, with an uppercase letter, a lowercase letter and a digit.",
};

export function passwordProblem(pw: string): string | null {
  if (!pw || pw.length < PASSWORD_RULES.minLength) return `Password must be at least ${PASSWORD_RULES.minLength} characters.`;
  if (PASSWORD_RULES.requireUpper && !/[A-Z]/.test(pw)) return "Password must contain an uppercase letter.";
  if (PASSWORD_RULES.requireLower && !/[a-z]/.test(pw)) return "Password must contain a lowercase letter.";
  if (PASSWORD_RULES.requireDigit && !/[0-9]/.test(pw)) return "Password must contain a digit.";
  const weak = ["password", "12345678", "qwerty", "bpz12345", "ledgercore", "letmein"];
  if (weak.some((w) => pw.toLowerCase().includes(w))) return "Password is too predictable — choose something unique.";
  return null;
}

/** Deterministic fingerprint of a secret for the enrolment confirmation UI. */
export function secretFingerprint(secret: string): string {
  return createHash("sha256").update(secret).digest("hex").slice(0, 8).toUpperCase();
}
