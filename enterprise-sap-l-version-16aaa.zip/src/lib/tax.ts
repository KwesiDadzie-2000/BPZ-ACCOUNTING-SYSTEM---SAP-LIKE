import { db } from "@/db";
import { taxRates, taxBands, payComponents } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { PostingError } from "./posting";

const r2 = (n: number) => Math.round(n * 100) / 100;

export async function listRates(category?: string) {
  const rows = category
    ? await db.select().from(taxRates).where(eq(taxRates.category, category)).orderBy(asc(taxRates.name))
    : await db.select().from(taxRates).orderBy(asc(taxRates.category), asc(taxRates.name));
  return rows.map((r) => ({ ...r, rate: Number(r.rate) }));
}

export async function rateValue(category: string, name: string, fallback: number): Promise<number> {
  const rows = await db
    .select()
    .from(taxRates)
    .where(eq(taxRates.category, category))
    .orderBy(desc2(taxRates.effectiveFrom));
  const hit = rows.find((r) => r.name.toLowerCase() === name.toLowerCase());
  return hit ? Number(hit.rate) : fallback;
}

import { desc as desc2 } from "drizzle-orm";

export async function upsertRate(input: { category: string; name: string; rate: number; effectiveFrom?: string; notes?: string }) {
  if (!input.category || !input.name) throw new PostingError("Category and name are required.");
  if (!Number.isFinite(input.rate) || input.rate < 0) throw new PostingError("Rate must be ≥ 0.");
  const existing = await db
    .select()
    .from(taxRates)
    .where(eq(taxRates.category, input.category));
  const hit = existing.find((r) => r.name.toLowerCase() === input.name.toLowerCase());
  if (hit) {
    await db
      .update(taxRates)
      .set({ rate: String(input.rate), effectiveFrom: input.effectiveFrom ?? hit.effectiveFrom, notes: input.notes ?? hit.notes })
      .where(eq(taxRates.id, hit.id));
  } else {
    await db.insert(taxRates).values({
      category: input.category,
      name: input.name,
      rate: String(input.rate),
      effectiveFrom: input.effectiveFrom ?? new Date().toISOString().slice(0, 10),
      notes: input.notes ?? "",
    });
  }
}

// ------------------------------------------------------------
// PAYE bands (GRA schedule — owner-editable, effective 2026-09-01)
// ------------------------------------------------------------

export type PayeBand = { lower: number; upper: number | null; rate: number; effectiveFrom: string };

export async function listPayeBands(taxCode = "PAYE"): Promise<PayeBand[]> {
  const rows = await db
    .select()
    .from(taxBands)
    .where(eq(taxBands.tax, taxCode))
    .orderBy(asc(taxBands.lower));
  return rows.map((b) => ({
    lower: Number(b.lower),
    upper: b.upper ? Number(b.upper) : null,
    rate: Number(b.rate),
    effectiveFrom: b.effectiveFrom,
  }));
}

export async function setPayeBands(bands: { lower: number; upper: number | null; rate: number }[], effectiveFrom = "2026-09-01") {
  for (const b of bands) {
    if (!Number.isFinite(b.lower) || b.lower < 0) throw new PostingError("Band lower bound must be ≥ 0.");
    if (b.upper !== null && (!Number.isFinite(b.upper) || b.upper <= b.lower))
      throw new PostingError("Band upper bound must exceed its lower bound.");
    if (!Number.isFinite(b.rate) || b.rate < 0 || b.rate > 100) throw new PostingError("Band rate must be 0–100%.");
  }
  await db.delete(taxBands).where(eq(taxBands.tax, "PAYE"));
  await db.insert(taxBands).values(
    bands.map((b) => ({
      tax: "PAYE",
      lower: String(b.lower),
      upper: b.upper === null ? null : String(b.upper),
      rate: String(b.rate),
      effectiveFrom,
    }))
  );
}

/** Progressive PAYE on the taxable base (gross − statutory reliefs). */
export function computePaye(taxable: number, bands: PayeBand[], relief = 0): number {
  const base = Math.max(0, taxable - relief);
  let tax = 0;
  for (const b of [...bands].sort((x, y) => x.lower - y.lower)) {
    if (base <= b.lower) break;
    const cap = Math.min(base, b.upper === null ? base : b.upper);
    tax += (cap - b.lower) * (b.rate / 100);
  }
  return r2(tax);
}

export async function computePayeLive(taxable: number): Promise<{ paye: number; bands: PayeBand[] }> {
  const bands = await listPayeBands();
  return { paye: computePaye(taxable, bands), bands };
}

// ------------------------------------------------------------
// Payroll components (editable statutory schedule)
// ------------------------------------------------------------

export type PayComponent = {
  id: number;
  name: string;
  base: "gross" | "basic" | "net";
  rate: number | null;
  fixedAmount: number;
  side: "deduction" | "income" | "employer";
  ordinal: number;
  active: boolean;
};

export async function listPayComponents(): Promise<PayComponent[]> {
  const rows = await db.select().from(payComponents).orderBy(asc(payComponents.ordinal));
  return rows.map((c) => ({
    id: c.id,
    name: c.name,
    base: c.base as PayComponent["base"],
    rate: c.rate === null ? null : Number(c.rate),
    fixedAmount: Number(c.fixedAmount),
    side: c.side as PayComponent["side"],
    ordinal: c.ordinal,
    active: c.active,
  }));
}

export async function upsertPayComponent(input: {
  id?: number;
  name: string;
  base: string;
  rate: number | null;
  fixedAmount: number;
  side: string;
  ordinal: number;
  active: boolean;
}) {
  if (!input.name) throw new PostingError("Component name is required.");
  if (input.id) {
    await db
      .update(payComponents)
      .set({
        name: input.name,
        base: input.base,
        rate: input.rate === null ? null : String(input.rate),
        fixedAmount: String(input.fixedAmount ?? 0),
        side: input.side,
        ordinal: input.ordinal,
        active: input.active,
      })
      .where(eq(payComponents.id, input.id));
  } else {
    await db.insert(payComponents).values({
      name: input.name,
      base: input.base,
      rate: input.rate === null ? null : String(input.rate),
      fixedAmount: String(input.fixedAmount ?? 0),
      side: input.side,
      ordinal: input.ordinal,
      active: input.active,
    });
  }
}
