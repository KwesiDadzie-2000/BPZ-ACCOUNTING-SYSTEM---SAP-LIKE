import { db } from "@/db";
import {
  accounts,
  journalLines,
  purchaseOrders,
  salesOrders,
  partners,
  materials,
  costCenters,
  meta,
} from "@/db/schema";
import { and, eq, inArray, sql } from "drizzle-orm";
import { ensureSeed } from "./init";
import { today, num } from "./format";

// Any query runner: the db client or a transaction handle.
type Q = Pick<typeof db, "select" | "insert" | "update" | "delete">;

export class PostingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PostingError";
  }
}

const r2 = (n: number) => Math.round(n * 100) / 100;

// ------------------------------------------------------------
// Document numbering (SAP-style counters, per client)
// ------------------------------------------------------------

async function nextNo(kind: "uj" | "po" | "so", clientId: number, q: Q): Promise<string> {
  const rows = await q
    .update(meta)
    .set({ value: sql`${meta.value} + 1` })
    .where(and(eq(meta.key, kind), eq(meta.clientId, clientId)))
    .returning({ value: meta.value });
  if (!rows.length) throw new PostingError("Document counter is missing for this workspace.");
  return String(rows[0].value);
}

// ------------------------------------------------------------
// Master-data guards
// ------------------------------------------------------------

async function mustPartner(bp: string, type?: string, q: Q = db as Q, clientId = 1) {
  const rows = await q
    .select()
    .from(partners)
    .where(and(eq(partners.bpNo, bp), eq(partners.clientId, clientId)));
  const row = rows[0];
  if (!row)
    throw new PostingError(
      `Business partner "${bp}" is not in this workspace's master data. Add it under Master Data first.`
    );
  if (type && row.type !== type)
    throw new PostingError(
      `"${row.name}" is a ${row.type.toLowerCase()}, not a ${type.toLowerCase()}.`
    );
  return row;
}

/** Create-or-return a business partner scoped to one workspace. */
export async function upsertPartner(
  clientId: number,
  bpNo: string,
  name: string,
  type: string
): Promise<void> {
  const existing = await db
    .select({ bpNo: partners.bpNo })
    .from(partners)
    .where(and(eq(partners.bpNo, bpNo), eq(partners.clientId, clientId)));
  if (existing.length) return;
  await db
    .insert(partners)
    .values({ bpNo, clientId, name, type })
    .onConflictDoNothing({ target: [partners.bpNo, partners.clientId] });
}

async function mustMaterial(m: string, q: Q = db as Q) {
  const rows = await q.select().from(materials).where(eq(materials.materialNo, m));
  const row = rows[0];
  if (!row) throw new PostingError(`Material "${m}" not found.`);
  return row;
}

async function checkCC(cc: string | null | undefined, q: Q = db as Q) {
  if (!cc) return;
  const rows = await q.select().from(costCenters).where(eq(costCenters.ccCode, cc));
  if (!rows.length) throw new PostingError(`Cost center "${cc}" not found.`);
}

// ------------------------------------------------------------
// UNIVERSAL POSTING — every module funnels through here
// ------------------------------------------------------------

export type JLine = {
  account: string;
  bp?: string;
  cc?: string;
  material?: string;
  desc?: string;
  dr?: number;
  cr?: number;
};

export async function post(
  q: Q,
  p: {
    clientId: number;
    date: string;
    period?: string;
    module: string;
    docType: string;
    lines: JLine[];
    user?: string;
    reference?: string;
  }
): Promise<string> {
  const dr = r2(p.lines.reduce((s, l) => s + (l.dr ?? 0), 0));
  const cr = r2(p.lines.reduce((s, l) => s + (l.cr ?? 0), 0));
  if (Math.abs(dr - cr) >= 0.005)
    throw new PostingError(
      `Document rejected — not balanced. Debit ${num(dr)} ≠ Credit ${num(cr)}.`
    );

  const accs = [...new Set(p.lines.map((l) => l.account))];
  const found = await q
    .select({ accountNo: accounts.accountNo })
    .from(accounts)
    .where(inArray(accounts.accountNo, accs));
  const missing = accs.filter((a) => !found.some((f) => f.accountNo === a));
  if (missing.length)
    throw new PostingError(`Unknown account${missing.length > 1 ? "s" : ""}: ${missing.join(", ")}.`);

  const docNo = await nextNo("uj", p.clientId, q);
  await q.insert(journalLines).values(
    p.lines.map((l) => ({
      clientId: p.clientId,
      period: p.period ?? p.date.slice(0, 7),
      docNo,
      postDate: p.date,
      module: p.module,
      docType: p.docType,
      account: l.account,
      bp: l.bp ?? "",
      costCenter: l.cc ?? "",
      material: l.material ?? "",
      description: l.desc ?? "",
      debit: String(l.dr ?? 0),
      credit: String(l.cr ?? 0),
      createdBy: p.user ?? "SYSTEM",
      reference: p.reference ?? "",
    }))
  );
  return docNo;
}

// ------------------------------------------------------------
// MM — PROCUREMENT
// ------------------------------------------------------------

export async function createPO(input: {
  clientId: number;
  vendor: string;
  material: string;
  qty: number;
  price: number;
  cc?: string;
  user?: string;
}) {
  const { clientId, vendor, material, qty, price, cc } = input;
  if (!vendor || !material) throw new PostingError("Vendor and material are required.");
  if (!Number.isFinite(qty) || qty <= 0) throw new PostingError("Quantity must be a positive number.");
  if (!Number.isFinite(price) || price <= 0) throw new PostingError("Unit price must be positive.");
  await mustPartner(vendor, "Vendor", db as Q, clientId);
  await mustMaterial(material);
  await checkCC(cc);

  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const poNo = await nextNo("po", clientId, q);
    const total = r2(qty * price);
    await q.insert(purchaseOrders).values({
      clientId,
      poNo,
      vendor,
      material,
      qty: Math.round(qty),
      price: price.toFixed(2),
      total: total.toFixed(2),
      cc: cc ?? "",
      status: "Open",
    });
    return { doc: poNo, message: `PO ${poNo} created by ${input.user ?? "SYSTEM"}.` };
  });
}

export async function receiveGoods(input: { clientId: number; poNo: string; user?: string }) {
  const { clientId, poNo, user } = input;
  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const rows = await q
      .select()
      .from(purchaseOrders)
      .where(and(eq(purchaseOrders.clientId, clientId), eq(purchaseOrders.poNo, poNo)));
    const po = rows[0];
    if (!po) throw new PostingError(`PO ${poNo} not found in this workspace.`);
    if (po.status !== "Open")
      throw new PostingError(
        `PO ${poNo} is already ${po.status.toLowerCase()} — goods receipt already posted.`
      );

    const mat = await mustMaterial(po.material, q);
    const invAcc = mat.type === "Raw Material" ? "120000" : "121000";
    const total = r2(Number(po.total));

    const doc = await post(q, {
      clientId,
      date: today(),
      module: "MM",
      docType: "WE",
      user,
      reference: poNo,
      lines: [
        { account: invAcc, material: po.material, cc: po.cc, desc: `GR for PO ${poNo}`, dr: total },
        { account: "210000", bp: po.vendor, desc: `GR/IR clearing – PO ${poNo}`, cr: total },
      ],
    });
    await q
      .update(purchaseOrders)
      .set({ status: "Goods Received" })
      .where(eq(purchaseOrders.poNo, poNo));
    return { doc, message: `Goods received for PO ${poNo} → journal doc ${doc}.` };
  });
}

export async function postVendorInvoice(input: { clientId: number; poNo: string; user?: string }) {
  const { clientId, poNo, user } = input;
  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const rows = await q
      .select()
      .from(purchaseOrders)
      .where(and(eq(purchaseOrders.clientId, clientId), eq(purchaseOrders.poNo, poNo)));
    const po = rows[0];
    if (!po) throw new PostingError(`PO ${poNo} not found in this workspace.`);
    if (po.status !== "Goods Received")
      throw new PostingError(`PO ${poNo} must have a goods receipt before invoice posting.`);

    const total = r2(Number(po.total));
    const doc = await post(q, {
      clientId,
      date: today(),
      module: "MM",
      docType: "RE",
      user,
      reference: poNo,
      lines: [
        { account: "210000", bp: po.vendor, desc: `Vendor invoice – PO ${poNo}`, dr: total },
        { account: "200000", bp: po.vendor, desc: `Accounts payable – ${po.vendor}`, cr: total },
      ],
    });
    await q
      .update(purchaseOrders)
      .set({ status: "Invoiced" })
      .where(eq(purchaseOrders.poNo, poNo));
    return { doc, message: `Vendor invoice posted for PO ${poNo} → journal doc ${doc}.` };
  });
}

// ------------------------------------------------------------
// SD — SALES
// ------------------------------------------------------------

export async function createSO(input: {
  clientId: number;
  customer: string;
  material: string;
  qty: number;
  price: number;
  user?: string;
}) {
  const { clientId, customer, material, qty, price } = input;
  if (!customer || !material) throw new PostingError("Customer and material are required.");
  if (!Number.isFinite(qty) || qty <= 0) throw new PostingError("Quantity must be a positive number.");
  if (!Number.isFinite(price) || price <= 0) throw new PostingError("Unit price must be positive.");
  await mustPartner(customer, "Customer", db as Q, clientId);
  await mustMaterial(material);

  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const soNo = await nextNo("so", clientId, q);
    const total = r2(qty * price);
    await q.insert(salesOrders).values({
      clientId,
      soNo,
      customer,
      material,
      qty: Math.round(qty),
      price: price.toFixed(2),
      total: total.toFixed(2),
      status: "Open",
    });
    return { doc: soNo, message: `SO ${soNo} created by ${input.user ?? "SYSTEM"}.` };
  });
}

export async function postSalesInvoice(input: { clientId: number; soNo: string; user?: string }) {
  const { clientId, soNo, user } = input;
  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const rows = await q
      .select()
      .from(salesOrders)
      .where(and(eq(salesOrders.clientId, clientId), eq(salesOrders.soNo, soNo)));
    const so = rows[0];
    if (!so) throw new PostingError(`SO ${soNo} not found in this workspace.`);
    if (so.status !== "Open")
      throw new PostingError(
        `SO ${soNo} is already ${so.status.toLowerCase()} — invoice already posted.`
      );

    const total = r2(Number(so.total));
    const doc = await post(q, {
      clientId,
      date: today(),
      module: "SD",
      docType: "RV",
      user,
      reference: soNo,
      lines: [
        { account: "110000", bp: so.customer, desc: `Receivable – ${so.customer}`, dr: total },
        { account: "400000", bp: so.customer, desc: `Sales revenue – SO ${soNo}`, cr: total },
      ],
    });
    await q
      .update(salesOrders)
      .set({ status: "Invoiced" })
      .where(eq(salesOrders.soNo, soNo));
    return { doc, message: `Customer invoice posted for SO ${soNo} → journal doc ${doc}.` };
  });
}

export async function receivePayment(input: { clientId: number; soNo: string; user?: string }) {
  const { clientId, soNo, user } = input;
  return db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    const rows = await q
      .select()
      .from(salesOrders)
      .where(and(eq(salesOrders.clientId, clientId), eq(salesOrders.soNo, soNo)));
    const so = rows[0];
    if (!so) throw new PostingError(`SO ${soNo} not found in this workspace.`);
    if (so.status !== "Invoiced")
      throw new PostingError(`SO ${soNo} must be invoiced before payment receipt.`);

    const total = r2(Number(so.total));
    const doc = await post(q, {
      clientId,
      date: today(),
      module: "SD",
      docType: "DZ",
      user,
      reference: soNo,
      lines: [
        { account: "101000", desc: `Bank receipt – SO ${soNo}`, dr: total },
        { account: "110000", bp: so.customer, desc: `Payment – SO ${soNo}`, cr: total },
      ],
    });
    await q
      .update(salesOrders)
      .set({ status: "Paid" })
      .where(eq(salesOrders.soNo, soNo));
    return { doc, message: `Payment received for SO ${soNo} → journal doc ${doc}.` };
  });
}

// ------------------------------------------------------------
// HR — PAYROLL
// ------------------------------------------------------------

export async function runPayroll(input: {
  clientId: number;
  employee: string;
  gross: number;
  cc?: string;
  user?: string;
}) {
  const { clientId, employee, gross, cc } = input;
  if (!employee) throw new PostingError("Employee is required.");
  if (!Number.isFinite(gross) || gross <= 0) throw new PostingError("Gross salary must be positive.");
  await mustPartner(employee, "Employee", db as Q, clientId);
  await checkCC(cc);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "HR",
    docType: "PY",
    user: input.user,
    lines: [
      { account: "510000", bp: employee, cc, desc: `Salary expense – ${employee}`, dr: gross },
      { account: "220000", bp: employee, desc: `Salaries payable – ${employee}`, cr: gross },
    ],
  });
  return { doc, message: `Payroll posted for ${employee} → journal doc ${doc}.` };
}

export async function paySalary(input: {
  clientId: number;
  employee: string;
  amount: number;
  user?: string;
}) {
  const { clientId, employee, amount } = input;
  if (!employee) throw new PostingError("Employee is required.");
  if (!Number.isFinite(amount) || amount <= 0) throw new PostingError("Amount must be positive.");
  await mustPartner(employee, "Employee", db as Q, clientId);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "HR",
    docType: "PY",
    user: input.user,
    lines: [
      { account: "220000", bp: employee, desc: `Salary paid – ${employee}`, dr: amount },
      { account: "101000", desc: `Bank payment – ${employee}`, cr: amount },
    ],
  });
  return { doc, message: `Salary paid to ${employee} → journal doc ${doc}.` };
}

// ------------------------------------------------------------
// FI-AA — FIXED ASSETS
// ------------------------------------------------------------

export async function acquireAsset(input: {
  clientId: number;
  name: string;
  cost: number;
  cc?: string;
  user?: string;
}) {
  const { clientId, name, cost, cc } = input;
  if (!name) throw new PostingError("Asset name is required.");
  if (!Number.isFinite(cost) || cost <= 0) throw new PostingError("Asset cost must be positive.");
  await checkCC(cc);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "FI-AA",
    docType: "AA",
    user: input.user,
    lines: [
      { account: "130000", cc, desc: `Asset acquisition – ${name}`, dr: cost },
      { account: "101000", desc: `Bank payment – ${name}`, cr: cost },
    ],
  });
  return { doc, message: `Asset "${name}" acquired at cost → journal doc ${doc}.` };
}

export async function runDepreciation(input: {
  clientId: number;
  amount: number;
  cc?: string;
  user?: string;
}) {
  const { clientId, amount, cc } = input;
  if (!Number.isFinite(amount) || amount <= 0)
    throw new PostingError("Depreciation amount must be positive.");
  await checkCC(cc);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "FI-AA",
    docType: "AF",
    user: input.user,
    lines: [
      { account: "550000", cc, desc: "Depreciation – periodic run", dr: amount },
      { account: "139000", desc: "Accumulated depreciation", cr: amount },
    ],
  });
  return { doc, message: `Depreciation run posted → journal doc ${doc}.` };
}

// ------------------------------------------------------------
// ADMIN — INSURANCE & CLAIMS
// ------------------------------------------------------------

export async function claimReceived(input: {
  clientId: number;
  insurer: string;
  amount: number;
  offsetAccount: string;
  user?: string;
}) {
  const { clientId, insurer, amount, offsetAccount } = input;
  if (!insurer) throw new PostingError("Insurer is required.");
  if (!Number.isFinite(amount) || amount <= 0) throw new PostingError("Claim amount must be positive.");
  if (!offsetAccount) throw new PostingError("Offset account is required.");
  await mustPartner(insurer, "Vendor", db as Q, clientId);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "ADMIN",
    docType: "KG",
    user: input.user,
    lines: [
      { account: "110000", bp: insurer, desc: `Claim receivable – ${insurer}`, dr: amount },
      { account: offsetAccount, cc: "CC-OPS", desc: "Insurance recovery", cr: amount },
    ],
  });
  return { doc, message: `Insurance claim registered (${insurer}) → journal doc ${doc}.` };
}

export async function receiveSettlement(input: {
  clientId: number;
  insurer: string;
  amount: number;
  user?: string;
}) {
  const { clientId, insurer, amount } = input;
  if (!insurer) throw new PostingError("Insurer is required.");
  if (!Number.isFinite(amount) || amount <= 0)
    throw new PostingError("Settlement amount must be positive.");
  await mustPartner(insurer, "Vendor", db as Q, clientId);
  const doc = await post(db as Q, {
    clientId,
    date: today(),
    module: "ADMIN",
    docType: "KZ",
    user: input.user,
    lines: [
      { account: "101000", desc: `Insurance settlement – ${insurer}`, dr: amount },
      { account: "110000", bp: insurer, desc: `Settlement received – ${insurer}`, cr: amount },
    ],
  });
  return { doc, message: `Settlement received from ${insurer} → journal doc ${doc}.` };
}

// ------------------------------------------------------------
// FI — MANUAL JOURNAL
// ------------------------------------------------------------

export async function manualJournal(input: {
  clientId: number;
  lines: JLine[];
  user?: string;
  reference?: string;
}) {
  const lines = (input.lines ?? []).map((l) => ({
    ...l,
    dr: l.dr ? Number(l.dr) : 0,
    cr: l.cr ? Number(l.cr) : 0,
  }));
  if (lines.length < 2) throw new PostingError("A journal needs at least two lines.");
  for (const l of lines) {
    if (!l.account) throw new PostingError("Every journal line needs an account.");
    if (l.dr > 0 && l.cr > 0)
      throw new PostingError(`Line on account ${l.account} cannot be both debit and credit.`);
    if (l.dr <= 0 && l.cr <= 0)
      throw new PostingError(`Line on account ${l.account} has no amount.`);
  }
  const doc = await post(db as Q, {
    clientId: input.clientId,
    date: today(),
    module: "FI",
    docType: "SA",
    user: input.user,
    reference: input.reference,
    lines,
  });
  return { doc, message: `Manual journal posted → doc ${doc}.` };
}

// ------------------------------------------------------------
// SIMULATION — one full business day across the organisation
// ------------------------------------------------------------

export type SimStep = { module: string; label: string; detail: string };

export async function simulateDay(clientId: number) {
  await ensureSeed();
  const steps: SimStep[] = [];
  const log = (module: string, label: string, detail: string) =>
    steps.push({ module, label, detail });

  const summary = await db.transaction(async (tx) => {
    const q = tx as unknown as Q;

    // 1. PROCUREMENT
    const poNo = await nextNo("po", clientId, q);
    await q.insert(purchaseOrders).values({
      clientId, poNo, vendor: "V004", material: "MAT-001", qty: 100,
      price: "50.00", total: "5000.00", cc: "CC-OPS", status: "Open",
    });
    log("MM", `PO ${poNo} created`, "100 × MAT-001 Steel Rods @ 50.00 · CC-OPS");

    let doc = await post(q, {
      clientId, date: today(), module: "MM", docType: "WE", user: "procurement_user", reference: poNo,
      lines: [
        { account: "120000", material: "MAT-001", cc: "CC-OPS", desc: `GR for PO ${poNo}`, dr: 5000 },
        { account: "210000", bp: "V004", desc: `GR/IR clearing – PO ${poNo}`, cr: 5000 },
      ],
    });
    await q.update(purchaseOrders).set({ status: "Goods Received" }).where(eq(purchaseOrders.poNo, poNo));
    log("MM", "Goods receipt posted", "Inventory Dr / GR-IR Cr · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "MM", docType: "RE", user: "procurement_user", reference: poNo,
      lines: [
        { account: "210000", bp: "V004", desc: `Vendor invoice – PO ${poNo}`, dr: 5000 },
        { account: "200000", bp: "V004", desc: "Accounts payable – V004", cr: 5000 },
      ],
    });
    await q.update(purchaseOrders).set({ status: "Invoiced" }).where(eq(purchaseOrders.poNo, poNo));
    log("MM", "Vendor invoice posted", "GR-IR Dr / AP Cr · doc " + doc);

    // 2. SALES
    const soNo = await nextNo("so", clientId, q);
    await q.insert(salesOrders).values({
      clientId, soNo, customer: "C001", material: "MAT-003", qty: 20,
      price: "500.00", total: "10000.00", status: "Open",
    });
    log("SD", `SO ${soNo} created`, "20 × MAT-003 Finished Widget @ 500.00 · C001");

    doc = await post(q, {
      clientId, date: today(), module: "SD", docType: "RV", user: "sales_user", reference: soNo,
      lines: [
        { account: "110000", bp: "C001", desc: "Receivable – C001", dr: 10000 },
        { account: "400000", bp: "C001", desc: `Sales revenue – SO ${soNo}`, cr: 10000 },
      ],
    });
    await q.update(salesOrders).set({ status: "Invoiced" }).where(eq(salesOrders.soNo, soNo));
    log("SD", "Customer invoice posted", "AR Dr / Revenue Cr · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "SD", docType: "DZ", user: "sales_user", reference: soNo,
      lines: [
        { account: "101000", desc: `Bank receipt – SO ${soNo}`, dr: 10000 },
        { account: "110000", bp: "C001", desc: `Payment – SO ${soNo}`, cr: 10000 },
      ],
    });
    await q.update(salesOrders).set({ status: "Paid" }).where(eq(salesOrders.soNo, soNo));
    log("SD", "Payment received", "Bank Dr / AR Cr · doc " + doc);

    // 3. HR / PAYROLL
    doc = await post(q, {
      clientId, date: today(), module: "HR", docType: "PY", user: "hr_user",
      lines: [
        { account: "510000", bp: "E001", cc: "CC-ADM", desc: "Salary expense – E001", dr: 8000 },
        { account: "220000", bp: "E001", desc: "Salaries payable – E001", cr: 8000 },
      ],
    });
    log("HR", "Payroll run – E001 John Mensah", "Gross 8,000.00 · CC-ADM · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "HR", docType: "PY", user: "hr_user",
      lines: [
        { account: "510000", bp: "E002", cc: "CC-SLS", desc: "Salary expense – E002", dr: 6000 },
        { account: "220000", bp: "E002", desc: "Salaries payable – E002", cr: 6000 },
      ],
    });
    log("HR", "Payroll run – E002 Ama Owusu", "Gross 6,000.00 · CC-SLS · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "HR", docType: "PY", user: "hr_user",
      lines: [
        { account: "220000", bp: "E001", desc: "Salary paid – E001", dr: 8000 },
        { account: "101000", desc: "Bank payment – E001", cr: 8000 },
      ],
    });
    log("HR", "Salary paid – E001", "8,000.00 out of Bank · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "HR", docType: "PY", user: "hr_user",
      lines: [
        { account: "220000", bp: "E002", desc: "Salary paid – E002", dr: 6000 },
        { account: "101000", desc: "Bank payment – E002", cr: 6000 },
      ],
    });
    log("HR", "Salary paid – E002", "6,000.00 out of Bank · doc " + doc);

    // 4. FIXED ASSETS
    doc = await post(q, {
      clientId, date: today(), module: "FI-AA", docType: "AA", user: "ops_user",
      lines: [
        { account: "130000", cc: "CC-OPS", desc: "Asset acquisition – Toyota Hilux", dr: 250000 },
        { account: "101000", desc: "Bank payment – Toyota Hilux", cr: 250000 },
      ],
    });
    log("FI-AA", "Vehicle acquired – Toyota Hilux", "Cost 250,000.00 · CC-OPS · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "FI-AA", docType: "AF", user: "ops_user",
      lines: [
        { account: "550000", cc: "CC-OPS", desc: "Depreciation – periodic run", dr: 4166.67 },
        { account: "139000", desc: "Accumulated depreciation", cr: 4166.67 },
      ],
    });
    log("FI-AA", "Depreciation run", "4,166.67 · CC-OPS · doc " + doc);

    // 5. INSURANCE
    doc = await post(q, {
      clientId, date: today(), module: "ADMIN", docType: "KG", user: "admin_user",
      lines: [
        { account: "110000", bp: "V001", desc: "Claim receivable – V001", dr: 8000 },
        { account: "530000", cc: "CC-OPS", desc: "Insurance recovery", cr: 8000 },
      ],
    });
    log("ADMIN", "Insurance claim registered", "8,000.00 from V001 · doc " + doc);

    doc = await post(q, {
      clientId, date: today(), module: "ADMIN", docType: "KZ", user: "admin_user",
      lines: [
        { account: "101000", desc: "Insurance settlement – V001", dr: 8000 },
        { account: "110000", bp: "V001", desc: "Settlement received – V001", cr: 8000 },
      ],
    });
    log("ADMIN", "Settlement received", "8,000.00 into Bank · doc " + doc);

    // 6. FI — MONTH-END ACCRUAL
    doc = await post(q, {
      clientId, date: today(), module: "FI", docType: "SA", user: "accountant",
      reference: "Month-end accrual",
      lines: [
        { account: "540000", cc: "CC-ADM", desc: "Accrue utilities", dr: 1200 },
        { account: "210000", desc: "Utilities payable", cr: 1200 },
      ],
    });
    log("FI", "Manual journal – utilities accrual", "1,200.00 · CC-ADM · doc " + doc);

    return steps;
  });

  return { steps: summary, message: "Business day simulated — 13 journal documents posted." };
}

// ------------------------------------------------------------
// RESET — wipe a workspace's transactional data
// ------------------------------------------------------------

export async function resetData(clientId: number) {
  await ensureSeed();
  await db.transaction(async (tx) => {
    const q = tx as unknown as Q;
    await q.delete(journalLines).where(eq(journalLines.clientId, clientId));
    await q.delete(purchaseOrders).where(eq(purchaseOrders.clientId, clientId));
    await q.delete(salesOrders).where(eq(salesOrders.clientId, clientId));
    await q.update(meta).set({ value: 5_000_000_000 }).where(and(eq(meta.key, "uj"), eq(meta.clientId, clientId)));
    await q.update(meta).set({ value: 4_500_000_000 }).where(and(eq(meta.key, "po"), eq(meta.clientId, clientId)));
    await q.update(meta).set({ value: 3_000_000_000 }).where(and(eq(meta.key, "so"), eq(meta.clientId, clientId)));
  });
  return { message: "Workspace cleared — journal, order books and counters reset." };
}
