import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { clients, sessions, users } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import { ensureSeed, HQ_CLIENT_ID } from "./init";
import { SESSION_COOKIE, WORKSPACE_COOKIE } from "./cookie-names";

const SESSION_MAX_AGE = 7 * 24 * 60 * 60; // seconds

export { SESSION_COOKIE, WORKSPACE_COOKIE };

export type SessionUser = {
  id: number;
  username: string;
  name: string;
  role: "owner" | "admin" | "accountant" | "client" | "viewer";
  clientId: number | null;
  mustChangePassword: boolean;
  totpEnabled: boolean;
  pending2fa: boolean;
  termsAccepted: boolean;
};

const ROLE_MAP: Record<string, SessionUser["role"]> = {
  owner: "owner",
  admin: "admin",
  accountant: "accountant",
  viewer: "viewer",
  client: "client",
};

export type WorkspaceClient = { id: number; code: string; name: string; sector?: string };

export type Workspace = { user: SessionUser; client: WorkspaceClient };

/** Current user from the session cookie, or null. */
export async function getSessionUser(): Promise<SessionUser | null> {
  await ensureSeed();
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      name: users.name,
      role: users.role,
      clientId: users.clientId,
      active: users.active,
      mustChangePassword: users.mustChangePassword,
      totpEnabled: users.totpEnabled,
      acceptedTermsAt: users.acceptedTermsAt,
      pending: sessions.pending,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.id, token), gt(sessions.expiresAt, new Date())));
  const r = rows[0];
  if (!r || !r.active) return null;
  return {
    id: r.id,
    username: r.username,
    name: r.name,
    role: ROLE_MAP[r.role] ?? "client",
    clientId: r.clientId,
    mustChangePassword: r.mustChangePassword,
    totpEnabled: r.totpEnabled,
    pending2fa: r.pending,
    termsAccepted: !!r.acceptedTermsAt,
  };
}

/**
 * Resolve {user, client} for the current request without redirecting.
 * Owners may switch workspaces via the lc_ws cookie (validated server-side);
 * client users are pinned to their own workspace.
 */
export async function apiWorkspace(): Promise<Workspace | null> {
  const user = await getSessionUser();
  if (!user) return null;
  // A session awaiting its second factor must never reach client data.
  if (user.pending2fa) return null;
  // Terms of engagement must be accepted before any client data is served.
  if (!user.termsAccepted) return null;
  const jar = await cookies();
  let client: WorkspaceClient | undefined;

  if (user.role === "owner") {
    const wsId = Number(jar.get(WORKSPACE_COOKIE)?.value);
    if (wsId && Number.isFinite(wsId)) {
      const c = (await db.select().from(clients).where(eq(clients.id, wsId)))[0];
      if (c && c.active) client = { id: c.id, code: c.code, name: c.name, sector: c.sector };
    }
    if (!client && user.clientId) {
      const home = (await db.select().from(clients).where(eq(clients.id, user.clientId)))[0];
      if (home && home.active) client = { id: home.id, code: home.code, name: home.name, sector: home.sector };
    }
    if (!client) {
      const hq = (await db.select().from(clients).where(eq(clients.id, HQ_CLIENT_ID)))[0];
      if (hq && hq.active) client = { id: hq.id, code: hq.code, name: hq.name, sector: hq.sector };
    }
  } else {
    // Client users are pinned to their own workspace; firm staff work the firm (HQ) workspace.
    const cid = user.clientId ?? HQ_CLIENT_ID;
    const c = (await db.select().from(clients).where(eq(clients.id, cid)))[0];
    if (!c || !c.active) return null;
    client = { id: c.id, code: c.code, name: c.name, sector: c.sector };
  }
  return client ? { user, client } : null;
}

/** Server-component gate: auth → 2FA → terms → password change, in that order. */
export async function requireWorkspace(): Promise<Workspace> {
  const ws = await apiWorkspace();
  if (!ws) redirect("/login");
  if (ws.user.pending2fa) redirect("/login?step=2fa");
  if (ws.user.mustChangePassword) redirect("/login?reset=1");
  if (!ws.user.termsAccepted) redirect("/accept-terms");
  return ws;
}

/** Unauthenticated is fine — used by the login / acceptance screens themselves. */
export async function optionalUser(): Promise<SessionUser | null> {
  const u = await getSessionUser();
  return u;
}

/** For owner-only server components. */
export async function requireOwnerWorkspace(): Promise<Workspace> {
  const ws = await requireWorkspace();
  if (ws.user.role !== "owner") redirect("/");
  return ws;
}

/**
 * Session-level guard for onboarding routes (set password, accept terms).
 * Unlike requireApiWorkspace this does NOT require terms acceptance or a
 * completed password reset — those are exactly the steps being performed.
 */
export async function requireSessionUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user)
    throw Object.assign(new Error("Not authenticated — please sign in."), { status: 401 });
  return user;
}

/** For API routes: throws a user-friendly error when unauthenticated. */
export async function requireApiWorkspace(): Promise<Workspace> {
  const ws = await apiWorkspace();
  if (!ws) throw new Error("Not authenticated — please sign in.");
  return ws;
}
