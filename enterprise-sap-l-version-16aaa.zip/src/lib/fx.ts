import { db } from "@/db";
import { currencies } from "@/db/schema";
import { eq } from "drizzle-orm";
import { PostingError } from "./posting";

export type FxRate = { code: string; name: string; rateGhs: number; source: string; updatedAt: string };

export async function getRates(): Promise<FxRate[]> {
  const rows = await db.select().from(currencies).orderBy(currencies.code);
  return rows.map((r) => ({
    code: r.code,
    name: r.name,
    rateGhs: Number(r.rateGhs),
    source: r.source,
    updatedAt: r.updatedAt ? r.updatedAt.toISOString() : "",
  }));
}

export async function getRate(code: string): Promise<number> {
  if (code === "GHS" || !code) return 1;
  const r = (await db.select().from(currencies).where(eq(currencies.code, code)))[0];
  return r ? Number(r.rateGhs) : 1;
}

export async function setRate(code: string, rateGhs: number, source: string) {
  if (code === "GHS") throw new PostingError("GHS is the base currency.");
  if (!Number.isFinite(rateGhs) || rateGhs <= 0) throw new PostingError("Rate must be a positive number.");
  await db
    .insert(currencies)
    .values({ code, name: code, rateGhs: rateGhs.toFixed(6), source })
    .onConflictDoUpdate({ target: currencies.code, set: { rateGhs: rateGhs.toFixed(6), source, updatedAt: new Date() } });
  // Keep the evidence trail: every rate change is retained for revaluation audit.
  const { recordFxHistory } = await import("./security");
  await recordFxHistory(code, rateGhs, source);
}

/**
 * Live mid-market rates. Primary: open.er-api.com (BOG mid-rate proxy for GHS).
 * Falls back to the last stored rates so posting never blocks.
 */
export async function refreshLiveRates(): Promise<{ ok: boolean; source?: string; rates?: FxRate[]; error?: string }> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch("https://open.er-api.com/v6/latest/GHS", { signal: ctrl.signal, cache: "no-store" });
    clearTimeout(t);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    if (data?.result !== "success" || !data.rates) throw new Error("bad payload");
    const known = (await db.select().from(currencies)).map((c) => c.code);
    for (const code of known) {
      if (code === "GHS") continue;
      const v = data.rates[code];
      if (v && Number.isFinite(v) && v > 0) {
        // The API is GHS-based (1 GHS = v units). Store GHS-per-unit.
        const ghsPerUnit = v < 1 ? 1 / v : v;
        await setRate(code, ghsPerUnit, "Live mid-market (BOG mid proxy)");
      }
    }
    return { ok: true, source: String(data.time_last_update_utc ?? ""), rates: await getRates() };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "fetch failed" };
  }
}
