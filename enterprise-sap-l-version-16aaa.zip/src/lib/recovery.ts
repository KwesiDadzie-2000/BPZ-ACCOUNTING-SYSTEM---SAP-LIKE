import { createHash, randomBytes, scryptSync, timingSafeEqual } from "crypto";

/**
 * One-time 2FA recovery codes. A hash is stored so the code is never readable
 * from the database; it is shown to the user exactly once.
 */

export function generateRecoveryCode() {
  // Format: BPZ-XXXX-XXXX — readable over the phone, hard to guess.
  const raw = randomBytes(8).toString("hex").toUpperCase();
  const plain = `BPZ-${raw.slice(0, 4)}-${raw.slice(4, 8)}`;
  const hash = hashRecovery(plain);
  return { plain, hash };
}

export function hashRecovery(code: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(code.trim().toUpperCase(), salt, 32).toString("hex");
  return `rcv:${salt}:${hash}`;
}

/** Verifies and returns true if valid (single-use enforcement is done by the caller clearing the hash). */
export function consumeRecoveryCode(stored: string, provided: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split(":");
    if (scheme !== "rcv" || !salt || !hash) return false;
    const test = scryptSync(provided.trim().toUpperCase(), salt, 32);
    const expected = Buffer.from(hash, "hex");
    return expected.length === test.length && timingSafeEqual(test, expected);
  } catch {
    return false;
  }
}

export function recoveryCodeFingerprint(code: string): string {
  return createHash("sha256").update(code.trim().toUpperCase()).digest("hex").slice(0, 8);
}
