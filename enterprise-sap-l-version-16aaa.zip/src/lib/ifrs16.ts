import { db } from "@/db";
import { leases } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { postChecked, type JLine } from "./engine";
import { assertPeriodOpen, thisPeriod } from "./periods";
import {
  initialLeaseLiability,
  initialRouAsset,
  rouDepreciation,
  isExemptLease,
  leaseAmortisationSchedule,
  leaseCurrentSplit,
  totalPayments,
  type LeaseInput,
} from "./standards";

const r2 = (n: number) => Math.round(n * 100) / 100;
const num = (v: unknown) => Number(v ?? 0);

export type LeaseRow = typeof leases.$inferSelect;

export async function listLeases(clientId: number, status?: string) {
  const where = status
    ? and(eq(leases.clientId, clientId), eq(leases.status, status))
    : eq(leases.clientId, clientId);
  return db.select().from(leases).where(where).orderBy(desc(leases.id));
}

function toLeaseInput(row: LeaseRow): LeaseInput {
  return {
    payment: Number(row.payment),
    termMonths: row.termMonths,
    annualRate: Number(row.discountRate),
    frequency: row.frequency as LeaseInput["frequency"],
    timing: row.timing as LeaseInput["timing"],
    initialDirectCosts: Number(row.initialDirectCosts),
    incentives: Number(row.incentives),
    restorationCost: Number(row.restorationCost),
  };
}

/**
 * Recognise a new lease: Dr right-of-use asset / Cr lease liability, plus
 * initial direct costs paid, incentives received and any restoration provision.
 */
export async function addLease(
  clientId: number,
  input: {
    code: string;
    description: string;
    lessor?: string;
    leaseType?: string;
    startDate: string;
    termMonths: number;
    payment: number;
    frequency: "monthly" | "quarterly" | "annually";
    timing: "arrears" | "advance";
    discountRate: number;
    initialDirectCosts?: number;
    incentives?: number;
    restorationCost?: number;
    cc?: string;
    lowValueExemption?: boolean;
    period: string;
    user?: string;
  }
) {
  if (!input.code.trim()) throw new Error("A lease reference code is required.");
  if (input.termMonths <= 0) throw new Error("Lease term must be at least one month.");
  if (input.payment <= 0) throw new Error("The periodic lease payment must be positive.");
  if (input.discountRate <= 0) throw new Error("A discount rate is required — use the rate implicit in the lease or your incremental borrowing rate.");
  await assertPeriodOpen(clientId, input.period);

  const lease: LeaseInput = {
    payment: input.payment,
    termMonths: input.termMonths,
    annualRate: input.discountRate,
    frequency: input.frequency,
    timing: input.timing,
    initialDirectCosts: input.initialDirectCosts ?? 0,
    incentives: input.incentives ?? 0,
    restorationCost: input.restorationCost ?? 0,
  };

  const exemption = isExemptLease({
    termMonths: input.termMonths,
    assetValue: input.lowValueExemption ? 5000 : 0,
  });

  const measurement = initialRouAsset(lease);
  const depreciation = rouDepreciation(measurement.rouAsset, input.termMonths);

  const lines: JLine[] = [
    { account: "115000", cc: input.cc, desc: `Right-of-use asset – ${input.code} ${input.description}`, dr: measurement.rouAsset },
  ];
  if (input.initialDirectCosts && input.initialDirectCosts > 0)
    lines.push({ account: "101000", desc: `Initial direct costs paid – ${input.code}`, cr: input.initialDirectCosts });
  if (input.incentives && input.incentives > 0)
    lines.push({ account: "101000", desc: `Lease incentive received – ${input.code}`, dr: input.incentives });
  if (input.restorationCost && input.restorationCost > 0)
    lines.push({ account: "293000", desc: `Restoration provision – ${input.code}`, cr: input.restorationCost });
  lines.push({ account: "294000", desc: `Lease liability – ${input.code}`, cr: measurement.leaseLiability });

  // Balancing the document is the control: any residual proves a mis-typed cost.
  const dr = r2(lines.reduce((s, l) => s + (l.dr ?? 0), 0));
  const cr = r2(lines.reduce((s, l) => s + (l.cr ?? 0), 0));
  if (Math.abs(dr - cr) > 0.005)
    throw new Error(
      `Lease entry does not balance (Dr ₵${dr.toFixed(2)} vs Cr ₵${cr.toFixed(2)}). Check initial costs, incentives and the restoration provision.`
    );

  const doc = await postChecked(clientId, {
    period: input.period,
    module: "FI",
    docType: "LSE",
    user: input.user,
    reference: `${input.code} commencement`,
    lines,
  });

  await db.insert(leases).values({
    clientId,
    code: input.code.trim(),
    description: input.description,
    lessor: input.lessor ?? "",
    leaseType: input.leaseType ?? "property",
    startDate: input.startDate,
    termMonths: input.termMonths,
    payment: String(input.payment),
    frequency: input.frequency,
    timing: input.timing,
    discountRate: String(input.discountRate),
    initialDirectCosts: String(input.initialDirectCosts ?? 0),
    incentives: String(input.incentives ?? 0),
    restorationCost: String(input.restorationCost ?? 0),
    rouAsset: String(measurement.rouAsset),
    leaseLiability: String(measurement.leaseLiability),
    lowValueExemption: !!input.lowValueExemption,
    cc: input.cc ?? "",
    lastDepPeriod: input.period,
    lastInterestPeriod: input.period,
  });

  return {
    doc,
    rouAsset: measurement.rouAsset,
    leaseLiability: measurement.leaseLiability,
    monthlyDepreciation: depreciation,
    totalPayments: totalPayments(lease),
    interestOverTerm: r2(totalPayments(lease) - measurement.leaseLiability),
    exemption,
    message: `Lease ${input.code} capitalised: ROU asset ₵${measurement.rouAsset.toFixed(2)}, lease liability ₵${measurement.leaseLiability.toFixed(2)}, monthly depreciation ₵${depreciation.toFixed(2)} → doc ${doc}.`,
  };
}

/**
 * Monthly double entry: depreciation of the ROU asset, interest unwinding the
 * liability, and the cash payment settling part of that liability.
 */
export async function runLeaseMonth(
  clientId: number,
  input: { period: string; leaseId?: number; user?: string }
) {
  await assertPeriodOpen(clientId, input.period);
  const rows = input.leaseId
    ? await db.select().from(leases).where(and(eq(leases.clientId, clientId), eq(leases.id, input.leaseId)))
    : await db.select().from(leases).where(and(eq(leases.clientId, clientId), eq(leases.status, "active")));

  const results: { code: string; depreciation: number; interest: number; payment: number; closingLiability: number }[] = [];
  const summary: { depTotal: number; interestTotal: number; cashTotal: number } = { depTotal: 0, interestTotal: 0, cashTotal: 0 };
  const skipped: string[] = [];

  for (const row of rows) {
    if (row.lastDepPeriod >= input.period) continue;
    const lease = toLeaseInput(row);
    const exempt = isExemptLease({ termMonths: row.termMonths, assetValue: row.lowValueExemption ? 5000 : 0 });
    if (exempt.exempt) {
      skipped.push(`${row.code}: ${exempt.reason}`);
      continue;
    }

    const openingLiability = Number(row.leaseLiability);
    if (openingLiability <= 0.009) continue;

    const schedule = leaseAmortisationSchedule(lease);
    const step = schedule.find((s) => s.openingLiability === r2(openingLiability)) ?? {
      interest: r2(openingLiability * (Number(row.discountRate) / 100 / (row.frequency === "monthly" ? 12 : row.frequency === "quarterly" ? 4 : 1))),
      payment: Number(row.payment),
      closingLiability: r2(openingLiability),
    };

    const totalRou = Number(row.rouAsset);
    const alreadyDep = Number(row.accumulatedDepreciation);
    const remainingMonths = Math.max(1, row.termMonths - Math.round(alreadyDep / Math.max(1, totalRou) * row.termMonths));
    const depreciation = rouDepreciation(totalRou, remainingMonths);
    const interest = step.interest;
    const principalReduction = r2(step.payment - interest);
    const closingLiability = Math.max(0, r2(openingLiability - principalReduction));

    const lines = [
      { account: "534000", cc: row.cc, desc: `ROU depreciation – ${row.code}`, dr: depreciation },
      { account: "115500", desc: `Accumulated ROU depreciation – ${row.code}`, cr: depreciation },
      { account: "536000", cc: row.cc, desc: `Lease interest – ${row.code}`, dr: interest },
      { account: "294000", desc: `Lease liability settled – ${row.code}`, dr: principalReduction },
      { account: "101000", desc: `Lease payment – ${row.code}`, cr: step.payment },
    ];
    const doc = await postChecked(clientId, {
      period: input.period,
      module: "FI",
      docType: "LSE",
      user: input.user,
      reference: `${row.code} lease charge ${input.period}`,
      lines,
    });

    await db
      .update(leases)
      .set({
        accumulatedDepreciation: String(r2(alreadyDep + depreciation)),
        leaseLiability: String(closingLiability),
        lastDepPeriod: input.period,
        lastInterestPeriod: input.period,
      })
      .where(and(eq(leases.id, row.id), eq(leases.clientId, clientId)));

    results.push({
      code: row.code,
      depreciation,
      interest,
      payment: step.payment,
      closingLiability,
    });
    summary.depTotal = r2(summary.depTotal + depreciation);
    summary.interestTotal = r2(summary.interestTotal + interest);
    summary.cashTotal = r2(summary.cashTotal + step.payment);
    void doc;
  }

  return {
    processed: results.length,
    skipped,
    results,
    summary,
    message: results.length
      ? `${results.length} lease(s) charged — depreciation ₵${summary.depTotal.toFixed(2)}, interest ₵${summary.interestTotal.toFixed(2)}, cash ₵${summary.cashTotal.toFixed(2)}.`
      : skipped.length
        ? `Nothing to charge. ${skipped.length} lease(s) are exempt.`
        : "No active leases required charging this period.",
  };
}

/** IFRS 16.53 disclosure schedule for every active lease. */
export async function leasePortfolio(clientId: number) {
  const all = await listLeases(clientId, "active");
  let rouTotal = 0;
  let liabilityTotal = 0;
  let accumDep = 0;
  const rows = all.map((row) => {
    const lease = toLeaseInput(row);
    const split = leaseCurrentSplit(lease);
    const carrying = r2(Number(row.rouAsset) - Number(row.accumulatedDepreciation));
    rouTotal = r2(rouTotal + carrying);
    liabilityTotal = r2(liabilityTotal + Number(row.leaseLiability));
    accumDep = r2(accumDep + Number(row.accumulatedDepreciation));
    return {
      id: row.id,
      code: row.code,
      description: row.description,
      lessor: row.lessor,
      termMonths: row.termMonths,
      payment: Number(row.payment),
      discountRate: Number(row.discountRate),
      rouCarrying: carrying,
      leaseLiability: Number(row.leaseLiability),
      currentPortion: split.currentPortion,
      nonCurrentPortion: split.nonCurrentPortion,
    };
  });
  return {
    rows,
    totals: {
      rouCarrying: rouTotal,
      accumulatedDepreciation: accumDep,
      leaseLiability: liabilityTotal,
      interestCost: r2(
        all.reduce((s, row) => {
          const lease = toLeaseInput(row);
          const opening = Number(row.leaseLiability);
          return s + opening * (Number(row.discountRate) / 100 / 12);
        }, 0)
      ),
    },
  };
}

export async function getLease(clientId: number, id: number) {
  return (
    await db.select().from(leases).where(and(eq(leases.clientId, clientId), eq(leases.id, id)))
  )[0];
}

export { initialLeaseLiability, initialRouAsset, thisPeriod };
