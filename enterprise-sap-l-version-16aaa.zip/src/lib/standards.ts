/**
 * Pure computation rules for the financial-reporting standards desks.
 * No database access — every function here is covered by regression tests.
 *
 *   IFRS 9  — classification, effective interest, ECL staging & measurement
 *   IFRS 16 — lease liability, right-of-use asset, subsequent measurement
 *   IAS 36  — value in use, recoverable amount, impairment, CGU allocation
 *   IFRS 5  — held-for-sale measurement and de-recognition readiness
 */

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export const round4 = (n: number) => Math.round((n + Number.EPSILON) * 10000) / 10000;

/** Present value of a single future amount. */
export function pv(amount: number, rateAnnual: number, years: number): number {
  if (years <= 0) return round2(amount);
  const r = rateAnnual / 100;
  return round2(amount / Math.pow(1 + r, years));
}

/** Present value of an ordinary annuity (payments at end of each period). */
export function pvAnnuity(
  payment: number,
  rateAnnual: number,
  periods: number,
  timing: "arrears" | "advance" = "arrears"
): number {
  if (periods <= 0) return 0;
  const r = rateAnnual / 100;
  // Sum of discounted payments is computed explicitly so irregular cases stay exact.
  let total = 0;
  for (let t = 1; t <= periods; t++) {
    total += payment / Math.pow(1 + r, t);
  }
  if (timing === "advance") {
    // Annuity due: every payment moves one period earlier.
    total *= 1 + r;
  }
  return round2(total);
}

/* =====================================================================
   IFRS 9 — FINANCIAL INSTRUMENTS
   ===================================================================== */

export type Ifrs9Category = "amortised_cost" | "fvoci" | "fvtpl";
export type EclStage = 1 | 2 | 3;

/**
 * Expected credit losses. ECL = EAD × PD × LGD, discounted to the reporting
 * date. LGD is net of collateral recovery, and the discount rate is the
 * original effective interest rate (IFRS 9.5.5.10), never a current rate.
 */
export function computeEcl(input: {
  exposure: number;
  pd: number; // % probability of default
  lgd: number; // % loss given default, net of collateral
  discountRate: number; // % original effective interest rate
  horizonMonths: number;
}): { ecl: number; undiscounted: number; survivalFactor: number; discountedLoss: number } {
  const exposure = Math.max(0, input.exposure);
  const pd = Math.min(100, Math.max(0, input.pd)) / 100;
  const lgd = Math.min(100, Math.max(0, input.lgd)) / 100;
  const r = input.discountRate / 100;
  const years = Math.max(0, input.horizonMonths) / 12;

  const survivalFactor = years > 0 ? 1 / Math.pow(1 + r, years) : 1;
  const lossGivenDefault = round2(exposure * pd * lgd);
  const ecl = round2(lossGivenDefault * survivalFactor);
  return {
    ecl,
    undiscounted: round2(exposure * pd * lgd),
    survivalFactor: round4(survivalFactor),
    discountedLoss: ecl,
  };
}

/** Loss given default net of collateral recovery (IFRS 9.B5.5.55). */
export function lgdNetOfCollateral(input: {
  lgdGross: number;
  exposure: number;
  collateralValue: number;
}): number {
  const exposure = Math.max(0, input.exposure);
  if (exposure <= 0) return 0;
  const recoveryPct = Math.min(100, (Math.max(0, input.collateralValue) / exposure) * 100);
  const net = Math.max(0, input.lgdGross - recoveryPct);
  return round2(net);
}

/**
 * Stage determination. A significant increase in credit risk since initial
 * recognition moves the instrument from Stage 1 to Stage 2 (lifetime ECL);
 * objective evidence of impairment moves it to Stage 3.
 */
export function determineStage(input: {
  daysPastDue: number;
  pdNow: number;
  pdAtOrigination: number;
  undrawnRestructure?: boolean;
}): { stage: EclStage; reason: string; lifetime: boolean } {
  const spt = Math.abs(input.pdAtOrigination) > 0
    ? ((input.pdNow - input.pdAtOrigination) / input.pdAtOrigination) * 100
    : 0;
  if (input.daysPastDue > 90) {
    return { stage: 3, reason: "More than 90 days past due — rebuttable presumption of credit impairment", lifetime: true };
  }
  if (input.undrawnRestructure) {
    return { stage: 3, reason: "Concessionary restructuring indicating distress", lifetime: true };
  }
  // 30 DPD is a backstop and a doubling of lifetime PD is the primary SICR test.
  if (input.daysPastDue > 30 || spt >= 100) {
    return {
      stage: 2,
      reason: input.daysPastDue > 30
        ? "More than 30 days past due — backstop for significant increase in credit risk"
        : `Lifetime PD rose ${spt.toFixed(0)}% since origination — significant increase in credit risk`,
      lifetime: true,
    };
  }
  return { stage: 1, reason: "Performing — no significant increase in credit risk since origination", lifetime: false };
}

/** Interest revenue basis: gross for Stages 1–2, net of allowance for Stage 3. */
export function interestRevenueBase(input: {
  stage: EclStage;
  grossCarryingAmount: number;
  eclAllowance: number;
  effectiveRate: number;
}): number {
  const base =
    input.stage === 3
      ? Math.max(0, input.grossCarryingAmount - input.eclAllowance)
      : input.grossCarryingAmount;
  return round2(base * (input.effectiveRate / 100));
}

/** Provision-matrix ECL for trade receivables (simplified / lifetime approach). */
export function provisionMatrixEcl(
  buckets: { bucket: string; amount: number; pd: number }[]
): { rows: { bucket: string; amount: number; pd: number; provision: number }[]; total: number } {
  const rows = buckets.map((b) => ({
    bucket: b.bucket,
    amount: round2(Math.max(0, b.amount)),
    pd: Math.min(100, Math.max(0, b.pd)),
    provision: round2(Math.max(0, b.amount) * (Math.min(100, Math.max(0, b.pd)) / 100)),
  }));
  return { rows, total: round2(rows.reduce((s, r) => s + r.provision, 0)) };
}

/** Movement schedule required by IFRS 9.35H disclosure. */
export function eclMovement(
  opening: number,
  charges: number,
  releases: number,
  writeOffs: number,
  modelChanges: number
): { closing: number; netCharge: number } {
  const closing = round2(opening + charges - releases - writeOffs + modelChanges);
  return { closing, netCharge: round2(charges - releases) };
}

/* =====================================================================
   IFRS 16 — LEASES
   ===================================================================== */

export type LeaseInput = {
  payment: number;
  termMonths: number;
  annualRate: number;
  frequency: "monthly" | "quarterly" | "annually";
  timing: "arrears" | "advance";
  initialDirectCosts: number;
  incentives: number;
  restorationCost: number;
};

export function paymentsPerYear(frequency: LeaseInput["frequency"]): number {
  return frequency === "monthly" ? 12 : frequency === "quarterly" ? 4 : 1;
}

/** Rate per payment period, derived from the annual incremental borrowing rate. */
export function periodicRate(annualRate: number, frequency: LeaseInput["frequency"]): number {
  return annualRate / 100 / paymentsPerYear(frequency);
}

export function totalPayments(input: LeaseInput): number {
  return round2(input.payment * leasePeriods(input));
}

export function leasePeriods(input: LeaseInput): number {
  if (input.frequency === "monthly") return input.termMonths;
  if (input.frequency === "quarterly") return Math.ceil(input.termMonths / 3);
  return Math.ceil(input.termMonths / 12);
}

/**
 * Initial lease liability = present value of unpaid lease payments discounted
 * at the rate implicit in the lease, or the incremental borrowing rate if the
 * implicit rate cannot be readily determined (IFRS 16.26).
 */
export function initialLeaseLiability(input: LeaseInput): number {
  const periods = leasePeriods(input);
  const r = periodicRate(input.annualRate, input.frequency);
  let pvTotal = 0;
  for (let t = 1; t <= periods; t++) {
    pvTotal += input.payment / Math.pow(1 + r, t);
  }
  if (input.timing === "advance") pvTotal *= 1 + r;
  return round2(Math.max(0, pvTotal));
}

/** Initial right-of-use asset (IFRS 16.24). */
export function initialRouAsset(input: LeaseInput): {
  rouAsset: number;
  leaseLiability: number;
  buildUp: { liability: number; initialDirectCosts: number; restoration: number; incentives: number };
} {
  const liability = initialLeaseLiability(input);
  const rouAsset = round2(
    Math.max(
      0,
      liability +
        Math.max(0, input.initialDirectCosts) +
        Math.max(0, input.restorationCost) -
        Math.max(0, input.incentives)
    )
  );
  return {
    rouAsset,
    leaseLiability: liability,
    buildUp: {
      liability,
      initialDirectCosts: round2(Math.max(0, input.initialDirectCosts)),
      restoration: round2(Math.max(0, input.restorationCost)),
      incentives: round2(Math.max(0, input.incentives)),
    },
  };
}

/** Straight-line ROU depreciation over the shorter of lease term and useful life. */
export function rouDepreciation(rouAsset: number, termMonths: number, usefulLifeMonths?: number): number {
  const months = Math.max(1, Math.min(termMonths, usefulLifeMonths ?? termMonths));
  return round2(rouAsset / months);
}

/**
 * One period of subsequent measurement: interest unwinds the liability, the
 * payment reduces the principal, and the ROU asset depreciates.
 */
export function leasePeriodSchedule(
  openingLiability: number,
  input: LeaseInput
): {
  openingLiability: number;
  interest: number;
  payment: number;
  closingLiability: number;
  openingRou: number;
  depreciation: number;
  closingRou: number;
} {
  const r = periodicRate(input.annualRate, input.frequency);
  const interest = round2(openingLiability * r);
  const closingLiability = round2(openingLiability + interest - input.payment);
  const depreciation = rouDepreciation(initialRouAsset(input).rouAsset, input.termMonths);
  return {
    openingLiability: round2(openingLiability),
    interest,
    payment: round2(input.payment),
    closingLiability,
    openingRou: initialRouAsset(input).rouAsset,
    depreciation,
    closingRou: round2(initialRouAsset(input).rouAsset - depreciation),
  };
}

/** Full amortisation schedule, capped at the number of lease periods. */
export function leaseAmortisationSchedule(input: LeaseInput): {
  period: number;
  openingLiability: number;
  interest: number;
  payment: number;
  closingLiability: number;
}[] {
  const rows: {
    period: number;
    openingLiability: number;
    interest: number;
    payment: number;
    closingLiability: number;
  }[] = [];
  let liability = initialLeaseLiability(input);
  const r = periodicRate(input.annualRate, input.frequency);
  const periods = leasePeriods(input);
  for (let p = 1; p <= periods; p++) {
    const interest = round2(liability * r);
    const closing = round2(liability + interest - input.payment);
    rows.push({
      period: p,
      openingLiability: round2(liability),
      interest,
      payment: round2(input.payment),
      closingLiability: round2(closing),
    });
    liability = closing;
    if (Math.abs(liability) < 0.01) break;
  }
  return rows;
}

/** Current / non-current split of the lease liability for the balance sheet. */
export function leaseCurrentSplit(
  input: LeaseInput
): { currentPortion: number; nonCurrentPortion: number } {
  const schedule = leaseAmortisationSchedule(input);
  const perYear = paymentsPerYear(input.frequency);
  const firstTwelve = schedule.slice(0, perYear);
  const currentPortion = round2(
    firstTwelve.reduce((s, row) => s + (row.payment - row.interest), 0)
  );
  const total = initialLeaseLiability(input);
  return {
    currentPortion: round2(Math.min(total, currentPortion)),
    nonCurrentPortion: round2(Math.max(0, total - currentPortion)),
  };
}

/** IFRS 5.8 / IFRS 16.5 exemptions — expense straight line instead. */
export function isExemptLease(input: { termMonths: number; assetValue: number }): {
  exempt: boolean;
  reason: string;
} {
  if (input.termMonths <= 12)
    return { exempt: true, reason: "Short-term lease — term of 12 months or less (IFRS 16.5(a))" };
  if (input.assetValue > 0 && input.assetValue <= 5000)
    return { exempt: true, reason: "Low-value asset of USD 5,000 or less when new (IFRS 16.5(b) / B3-B8)" };
  return { exempt: false, reason: "Recognise a right-of-use asset and lease liability" };
}

/* =====================================================================
   IAS 36 — IMPAIRMENT OF ASSETS
   ===================================================================== */

/** Value in use = present value of expected future cash flows plus disposal. */
export function valueInUse(input: {
  cashFlows: number[];
  discountRate: number;
  terminalValue: number;
}): { valueInUse: number; rows: { year: number; cashFlow: number; discountFactor: number; presentValue: number }[] } {
  const r = input.discountRate / 100;
  const rows = input.cashFlows.map((cf, i) => {
    const year = i + 1;
    const discountFactor = round4(1 / Math.pow(1 + r, year));
    return { year, cashFlow: round2(cf), discountFactor, presentValue: round2(cf * discountFactor) };
  });
  const terminalYear = input.cashFlows.length;
  const terminalPv =
    terminalYear > 0 && input.terminalValue
      ? round2(input.terminalValue / Math.pow(1 + r, terminalYear))
      : 0;
  const valueInUse = round2(rows.reduce((s, x) => s + x.presentValue, 0) + terminalPv);
  return { valueInUse, rows };
}

/** Recoverable amount is the HIGHER of fair value less costs of disposal and value in use. */
export function recoverableAmount(
  fairValueLessCosts: number,
  viu: number
): { recoverableAmount: number; basis: string } {
  const fv = round2(Math.max(0, fairValueLessCosts));
  const v = round2(Math.max(0, viu));
  return fv >= v
    ? { recoverableAmount: fv, basis: "Fair value less costs of disposal" }
    : { recoverableAmount: v, basis: "Value in use" };
}

/** Impairment loss where carrying amount exceeds recoverable amount. */
export function impairmentLoss(carryingAmount: number, recoverable: number): number {
  return round2(Math.max(0, round2(carryingAmount) - recoverable));
}

/** Reversal is capped at the carrying amount had no prior impairment existed. */
export function impairmentReversal(input: {
  currentCarryingAmount: number;
  priorImpairmentCharges: number;
  recoverable: number;
}): { reversal: number; newCarryingAmount: number } {
  const notional = round2(input.currentCarryingAmount + input.priorImpairmentCharges);
  const target = round2(Math.min(notional, input.recoverable));
  const reversal = round2(Math.max(0, target - input.currentCarryingAmount));
  return { reversal, newCarryingAmount: round2(input.currentCarryingAmount + reversal) };
}

/**
 * Allocate a CGU impairment loss across assets pro-rata on carrying amounts,
 * never reducing any asset below the highest of its fair value less costs of
 * disposal, its value in use (if determinable) and zero (IAS 36.104).
 */
export function allocateCguImpairment(
  assets: { name: string; carryingAmount: number; floor: number }[],
  totalLoss: number
): { name: string; carryingAmount: number; allocated: number; closing: number }[] {
  const loss = round2(Math.max(0, totalLoss));
  const totalCarrying = round2(assets.reduce((s, a) => s + Math.max(0, a.carryingAmount), 0));
  let remaining = loss;
  const rows = assets.map((a, index) => {
    const carrying = round2(Math.max(0, a.carryingAmount));
    let share = totalCarrying > 0 ? round2((loss * carrying) / totalCarrying) : 0;
    if (index === assets.length - 1) share = round2(remaining); // absorb rounding
    const floor = round2(Math.max(0, a.floor));
    const maxAbsorbable = round2(Math.max(0, carrying - floor));
    const allocated = round2(Math.min(share, maxAbsorbable));
    remaining = round2(Math.max(0, remaining - allocated));
    return { name: a.name, carryingAmount: carrying, allocated, closing: round2(carrying - allocated) };
  });
  // Any unallocated loss because of floors goes to the last asset with headroom.
  if (remaining > 0) {
    for (let i = rows.length - 1; i >= 0 && remaining > 0; i--) {
      const headroom = round2(rows[i].carryingAmount - rows[i].allocated);
      if (headroom <= 0) continue;
      const extra = round2(Math.min(headroom, remaining));
      rows[i].allocated = round2(rows[i].allocated + extra);
      rows[i].closing = round2(rows[i].carryingAmount - rows[i].allocated);
      remaining = round2(remaining - extra);
    }
  }
  return rows;
}

/* =====================================================================
   IFRS 5 — NON-CURRENT ASSETS HELD FOR SALE
   ===================================================================== */

export type HeldForSaleAssessment = {
  qualifies: boolean;
  reasons: string[];
  measuredAmount: number;
  writeDown: number;
  presentation: string;
};

/**
 * Classification test (IFRS 5.7–8): the asset must be available for immediate
 * sale and the sale highly probable within 12 months. Measurement is the LOWER
 * of carrying amount and fair value less costs to sell (IFRS 5.15), and
 * depreciation ceases on classification (IFRS 5.20).
 */
export function assessHeldForSale(input: {
  carryingAmount: number;
  fairValue: number;
  costsToSell: number;
  committedToPlan: boolean;
  activeMarketing: boolean;
  expectedSaleMonths: number;
  discontinuedOperation: boolean;
}): HeldForSaleAssessment {
  const reasons: string[] = [];
  if (!input.committedToPlan)
    reasons.push("Management must be committed to a plan to sell (IFRS 5.8(a))");
  if (!input.activeMarketing)
    reasons.push("The asset must be actively marketed at a reasonable price (IFRS 5.8(b))");
  if (input.expectedSaleMonths > 12)
    reasons.push("Sale is not expected within 12 months — highly probable test fails (IFRS 5.8(c))");

  const qualifies = reasons.length === 0;
  const fvLessCosts = round2(Math.max(0, input.fairValue - Math.max(0, input.costsToSell)));
  const carrying = round2(Math.max(0, input.carryingAmount));
  const measuredAmount = round2(Math.min(carrying, fvLessCosts));
  const writeDown = round2(Math.max(0, carrying - measuredAmount));

  return {
    qualifies,
    reasons: qualifies
      ? [
          "Committed to the plan, actively marketed, and sale expected within 12 months",
          writeDown > 0
            ? `Measured at fair value less costs to sell — write-down of ${writeDown.toFixed(2)}`
            : "Carrying amount is recoverable through sale — no write-down",
          "Depreciation ceases on classification (IFRS 5.20)",
        ]
      : reasons,
    measuredAmount,
    writeDown,
    presentation: input.discontinuedOperation
      ? "Discontinued operation — single line for post-tax profit and gain/loss (IFRS 5.32)"
      : "Held for sale — separate current-asset line (IFRS 5.38)",
  };
}

/** Gain or loss on completing the sale of an asset previously held for sale. */
export function disposalGainLoss(input: {
  proceeds: number;
  costsToSell: number;
  heldForSaleCarryingAmount: number;
}): { gain: number; loss: number; net: number } {
  const netProceeds = round2(Math.max(0, input.proceeds) - Math.max(0, input.costsToSell));
  const net = round2(netProceeds - input.heldForSaleCarryingAmount);
  return { gain: net > 0 ? net : 0, loss: net < 0 ? Math.abs(net) : 0, net };
}
