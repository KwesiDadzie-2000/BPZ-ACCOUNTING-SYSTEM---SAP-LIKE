const nf = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const cf = new Intl.NumberFormat("en-GH", {
  style: "currency",
  currency: "GHS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const fixZero = (n: number): number => (n === 0 ? 0 : n); // normalises -0

/** Plain number, 2dp — for dense table cells. */
export const num = (n: number | null | undefined): string => nf.format(fixZero(n ?? 0));

/** Currency-formatted amount — for KPIs and totals. */
export const money = (n: number | null | undefined): string => cf.format(fixZero(n ?? 0));

/** Compact currency for tight spaces. */
export const moneyK = (n: number | null | undefined): string => {
  const v = n ?? 0;
  const abs = Math.abs(v);
  const sign = v < 0 ? "-" : "";
  if (abs >= 1_000_000) return `${sign}₵${(abs / 1_000_000).toFixed(2)}M`;
  if (abs >= 10_000) return `${sign}₵${(abs / 1_000).toFixed(1)}k`;
  return cf.format(v);
};

export const today = (): string => new Date().toISOString().slice(0, 10);

export const fmtDate = (d: string): string => {
  const [y, m, day] = d.split("-");
  if (!y || !m || !day) return d;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${day} ${months[Number(m) - 1] ?? m} ${y}`;
};
