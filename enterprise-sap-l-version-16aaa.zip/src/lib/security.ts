import { db } from "@/db";
import { activityLog, fxHistory, loginAttempts } from "@/db/schema";
import { and, desc, eq, gte, sql } from "drizzle-orm";

// ------------------------------------------------------------
// Immutable activity log — every mutating request is recorded
// ------------------------------------------------------------

export async function logActivity(e: {
  clientId?: number | null; workspace?: string; username: string; role?: string;
  action: string; ok: boolean; detail?: string; ip?: string;
}) {
  try {
    await db.insert(activityLog).values({
      clientId: e.clientId ?? null,
      workspace: e.workspace ?? "",
      username: e.username,
      role: e.role ?? "",
      action: e.action.slice(0, 80),
      ok: e.ok,
      detail: (e.detail ?? "").slice(0, 500),
      ip: e.ip ?? "",
    });
  } catch (err) {
    // Never block a business action because logging failed, but surface it.
    console.error("[audit] activity_log insert failed:", err instanceof Error ? err.message : err);
  }
}

export async function listActivity(clientId: number | null, limit = 200) {
  const rows = clientId === null
    ? await db.select().from(activityLog).orderBy(desc(activityLog.id)).limit(limit)
    : await db.select().from(activityLog).where(eq(activityLog.clientId, clientId)).orderBy(desc(activityLog.id)).limit(limit);
  return rows.map((r) => ({
    id: r.id, clientId: r.clientId, workspace: r.workspace, username: r.username, role: r.role,
    action: r.action, ok: r.ok, detail: r.detail, ip: r.ip, at: r.at.toISOString(),
  }));
}

// ------------------------------------------------------------
// FX rate history — evidences the rate behind each revaluation
// ------------------------------------------------------------

export async function recordFxHistory(code: string, rate: number, source: string) {
  try {
    await db.insert(fxHistory).values({ code, rate: rate.toFixed(6), source });
  } catch (err) {
    console.error("[audit] fx_history insert failed:", err instanceof Error ? err.message : err);
  }
}

export async function fxRateHistory(code: string, limit = 50) {
  const rows = await db
    .select()
    .from(fxHistory)
    .where(eq(fxHistory.code, code))
    .orderBy(desc(fxHistory.id))
    .limit(limit);
  return rows.map((r) => ({ rate: Number(r.rate), source: r.source, capturedAt: r.capturedAt.toISOString() }));
}

// ------------------------------------------------------------
// Login throttling — 8 failures per username per 15 minutes
// ------------------------------------------------------------

const MAX_FAILURES = 8;
const WINDOW_MINUTES = 15;

export async function loginAllowed(
  username: string,
  ip = ""
): Promise<{ allowed: boolean; remaining: number }> {
  const since = new Date(Date.now() - WINDOW_MINUTES * 60_000);
  const rows = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(loginAttempts)
    .where(
      and(
        gte(loginAttempts.at, since),
        // Throttle the account AND the source. Without the IP leg an attacker
        // could rotate usernames indefinitely from one machine.
        sql`(${loginAttempts.username} = ${username} OR (${ip} <> '' AND ${loginAttempts.ip} = ${ip}))`,
        eq(loginAttempts.ok, false)
      )
    );
  const fails = rows[0]?.n ?? 0;
  return { allowed: fails < MAX_FAILURES, remaining: Math.max(0, MAX_FAILURES - fails) };
}

export async function recordLoginAttempt(username: string, ok: boolean, ip: string) {
  try {
    await db.insert(loginAttempts).values({ username, ok, ip });
  } catch (err) {
    console.error("[security] login_attempts insert failed:", err instanceof Error ? err.message : err);
  }
}

export async function clearLoginFailures(username: string) {
  try {
    const since = new Date(Date.now() - WINDOW_MINUTES * 60_000);
    await db
      .delete(loginAttempts)
      .where(and(eq(loginAttempts.username, username), eq(loginAttempts.ok, false), gte(loginAttempts.at, since)));
  } catch {
    /* non-fatal */
  }
}

/** CSRF defence: mutating requests must come from our own origin. */
export function sameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true; // non-browser clients (curl / server-to-server)
  try {
    const host = req.headers.get("host");
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export function clientIp(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("x-real-ip") ??
    ""
  );
}
