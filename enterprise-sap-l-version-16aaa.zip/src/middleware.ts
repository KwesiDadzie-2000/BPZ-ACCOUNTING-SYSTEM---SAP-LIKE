import { NextResponse, type NextRequest } from "next/server";

/**
 * Exposes the request pathname to server components. The root layout needs to
 * know whether it is rendering an auth screen (plain frame) or the workspace
 * shell, without guessing from headers the runtime may not provide.
 */
export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  res.headers.set("x-bpz-pathname", req.nextUrl.pathname);
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
