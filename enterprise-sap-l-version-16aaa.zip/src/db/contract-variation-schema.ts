import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

/** Approved variations and estimate-at-completion revisions (IFRS 15). */
export const contractVariations = pgTable(
  "contract_variations",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    contractId: integer("contract_id").notNull(),
    period: text("period").notNull(),
    kind: text("kind").notNull().default("variation"),
    oldValue: numeric("old_value", { precision: 14, scale: 2 }).notNull().default("0"),
    newValue: numeric("new_value", { precision: 14, scale: 2 }).notNull().default("0"),
    oldEstimatedCost: numeric("old_estimated_cost", { precision: 14, scale: 2 })
      .notNull()
      .default("0"),
    newEstimatedCost: numeric("new_estimated_cost", { precision: 14, scale: 2 })
      .notNull()
      .default("0"),
    description: text("description").notNull().default(""),
    approvedBy: text("approved_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_cv_contract").on(t.clientId, t.contractId)]
);
