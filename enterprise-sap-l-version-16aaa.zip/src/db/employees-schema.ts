import { pgTable, serial, integer, text, numeric, uniqueIndex, index } from "drizzle-orm/pg-core";

/** Employee master — the payroll source of truth, per workspace. */
export const employees = pgTable(
  "employees",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    position: text("position").notNull().default(""),
    department: text("department").notNull().default(""),
    email: text("email").notNull().default(""),
    phone: text("phone").notNull().default(""),
    tin: text("tin").notNull().default(""),
    ssnitNo: text("ssnit_no").notNull().default(""),
    bankAccount: text("bank_account").notNull().default(""),
    employmentType: text("employment_type").notNull().default("permanent"),
    jurisdiction: text("jurisdiction").notNull().default("GH"),
    currency: text("currency").notNull().default("GHS"),
    basicSalary: numeric("basic_salary", { precision: 14, scale: 2 }).notNull().default("0"),
    allowances: numeric("allowances", { precision: 14, scale: 2 }).notNull().default("0"),
    hireDate: text("hire_date").notNull().default(""),
    endDate: text("end_date").notNull().default(""),
    status: text("status").notNull().default("active"), // active | suspended | left
  },
  (t) => [
    uniqueIndex("uq_emp_client_code").on(t.clientId, t.code),
    index("idx_emp_client").on(t.clientId, t.status),
  ]
);

/** Tax jurisdictions — makes the platform usable in any economy. */
export const jurisdictions = pgTable("jurisdictions", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  currency: text("currency").notNull().default("USD"),
  vatName: text("vat_name").notNull().default("VAT"),
  vatRate: numeric("vat_rate", { precision: 7, scale: 3 }).notNull().default("0"),
  citRate: numeric("cit_rate", { precision: 7, scale: 3 }).notNull().default("0"),
  payrollScheme: text("payroll_scheme").notNull().default("generic"),
  notes: text("notes").notNull().default(""),
});
