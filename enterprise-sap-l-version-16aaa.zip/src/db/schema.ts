import {
  pgTable,
  text,
  serial,
  integer,
  numeric,
  bigint,
  boolean,
  timestamp,
  index,
  uniqueIndex,
  primaryKey,
} from "drizzle-orm/pg-core";

// ============================================================
// IDENTITY & MULTI-TENANCY
// ============================================================

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  active: boolean("active").notNull().default(true),
  sector: text("sector").notNull().default("services"),
  serviceLines: text("service_lines").notNull().default(""),
  feeModel: text("fee_model").notNull().default(""),
  baseCurrency: text("base_currency").notNull().default("GHS"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("client"), // owner | admin | accountant | viewer
  clientId: integer("client_id"),
  active: boolean("active").notNull().default(true),
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  totpSecret: text("totp_secret").notNull().default(""),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  /** Hashed one-time 2FA recovery code — the only way back in if the phone is lost. */
  recoveryHash: text("recovery_hash").notNull().default(""),
  /** True while the documented bootstrap password is still in force. */
  usesBootstrapPassword: boolean("uses_bootstrap_password").notNull().default(false),
  passwordChangedAt: timestamp("password_changed_at"),
  acceptedTermsAt: timestamp("accepted_terms_at"),
  tempLoginLink: text("temp_login_link").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  /** True until the second factor (TOTP) is verified. Pending sessions see no data. */
  pending: boolean("pending").notNull().default(false),
  ip: text("ip").notNull().default(""),
});

// ============================================================
// MASTER DATA (shared reference)
// ============================================================

export const accounts = pgTable("accounts", {
  accountNo: text("account_no").primaryKey(),
  description: text("description").notNull(),
  type: text("type").notNull(),
});

export const partners = pgTable(
  "partners",
  {
    bpNo: text("bp_no").notNull(),
    clientId: integer("client_id").notNull().default(1),
    name: text("name").notNull(),
    type: text("type").notNull(), // Vendor | Customer | Employee
    tin: text("tin").notNull().default(""),
    phone: text("phone").notNull().default(""),
    email: text("email").notNull().default(""),
    defaultExpenseAccount: text("default_expense_account").notNull().default(""),
  },
  (t) => [primaryKey({ columns: [t.bpNo, t.clientId] }), index("idx_bp_client").on(t.clientId)]
);

export const costCenters = pgTable("cost_centers", {
  ccCode: text("cc_code").primaryKey(),
  ccName: text("cc_name").notNull(),
});

export const materials = pgTable("materials", {
  materialNo: text("material_no").primaryKey(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  stdPrice: numeric("std_price", { precision: 12, scale: 2 }).notNull(),
});

// ============================================================
// UNIVERSAL JOURNAL (ACDOCA) — per client, fiscal period
// ============================================================

export const journalLines = pgTable(
  "journal_lines",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    period: text("period").notNull().default("2026-02"), // YYYY-MM
    docNo: text("doc_no").notNull(),
    postDate: text("post_date").notNull(),
    module: text("module").notNull(),
    docType: text("doc_type").notNull(), // WE RE RV DZ PY AA AF KG KZ SA OPEN PREPAY REV ADJ FX
    account: text("account").notNull(),
    bp: text("bp").notNull().default(""),
    costCenter: text("cost_center").notNull().default(""),
    material: text("material").notNull().default(""),
    description: text("description").notNull().default(""),
    debit: numeric("debit", { precision: 16, scale: 2 }).notNull().default("0"),
    credit: numeric("credit", { precision: 16, scale: 2 }).notNull().default("0"),
    createdBy: text("created_by").notNull().default("SYSTEM"),
    reference: text("reference").notNull().default(""),
  },
  (t) => [
    index("idx_jl_client_doc").on(t.clientId, t.docNo),
    index("idx_jl_client_period").on(t.clientId, t.period),
    index("idx_jl_client_account").on(t.clientId, t.account),
    index("idx_jl_client_module").on(t.clientId, t.module),
    index("idx_jl_client_bp").on(t.clientId, t.bp),
  ]
);

export const fiscalPeriods = pgTable(
  "fiscal_periods",
  {
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    status: text("status").notNull().default("open"), // open | closed
    closedBy: text("closed_by").notNull().default(""),
    closedAt: timestamp("closed_at"),
  },
  (t) => [primaryKey({ columns: [t.clientId, t.period] })]
);

// ============================================================
// MODULE DOCUMENTS
// ============================================================

export const purchaseOrders = pgTable(
  "purchase_orders",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    poNo: text("po_no").notNull(),
    vendor: text("vendor").notNull(),
    material: text("material").notNull(),
    qty: integer("qty").notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    cc: text("cc").notNull().default(""),
    status: text("status").notNull().default("Open"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_po_client").on(t.clientId), uniqueIndex("uq_po_client_po_no").on(t.clientId, t.poNo)]
);

export const salesOrders = pgTable(
  "sales_orders",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull().default(1),
    soNo: text("so_no").notNull(),
    customer: text("customer").notNull(),
    material: text("material").notNull(),
    qty: integer("qty").notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("Open"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_so_client").on(t.clientId), uniqueIndex("uq_so_client_so_no").on(t.clientId, t.soNo)]
);

// Quotes / Invoices / Credit & Debit notes (sales + purchase)
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    direction: text("direction").notNull(), // sales | purchase
    docType: text("doc_type").notNull(), // quote | invoice | credit | debit
    no: text("no").notNull(),
    bp: text("bp").notNull(),
    currency: text("currency").notNull().default("GHS"),
    rate: numeric("rate", { precision: 14, scale: 6 }).notNull().default("1"),
    subtotal: numeric("subtotal", { precision: 14, scale: 2 }).notNull(),
    vat: numeric("vat", { precision: 14, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("open"),
    period: text("period").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    note: text("note").notNull().default(""),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    /** goods | service | statutory — statutory items never enter the procurement cycle */
    recurrence: text("recurrence").notNull().default("none"),
    recurrenceNext: text("recurrence_next").notNull().default(""),
    /** goods | service | utilities | tax | payroll | insurance | regulatory | penalty | finance */
    expenseCategory: text("expense_category").notNull().default("goods"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_inv_client").on(t.clientId, t.direction)]
);

// ============================================================
// MULTICURRENCY & TAX
// ============================================================

export const currencies = pgTable("currencies", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  rateGhs: numeric("rate_ghs", { precision: 14, scale: 6 }).notNull().default("1"),
  source: text("source").notNull().default("manual"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const taxRates = pgTable("tax_rates", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // VAT | WHT_RES | WHT_NR | CIT | ...
  name: text("name").notNull(),
  rate: numeric("rate", { precision: 12, scale: 3 }).notNull(),
  effectiveFrom: text("effective_from").notNull().default("2026-01-01"),
  notes: text("notes").notNull().default(""),
});

export const taxBands = pgTable("tax_bands", {
  id: serial("id").primaryKey(),
  tax: text("tax").notNull().default("PAYE"),
  lower: numeric("lower", { precision: 14, scale: 2 }).notNull(),
  upper: numeric("upper", { precision: 14, scale: 2 }),
  rate: numeric("rate", { precision: 7, scale: 3 }).notNull(),
  effectiveFrom: text("effective_from").notNull().default("2026-09-01"),
});

// ============================================================
// PAYROLL
// ============================================================

export const payComponents = pgTable("pay_components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  base: text("base").notNull().default("basic"), // gross | basic | net
  rate: numeric("rate", { precision: 7, scale: 3 }),
  fixedAmount: numeric("fixed_amount", { precision: 14, scale: 2 }).notNull().default("0"),
  side: text("side").notNull().default("deduction"), // deduction | income | employer
  ordinal: integer("ordinal").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const payOverrides = pgTable(
  "pay_overrides",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    bpNo: text("bp_no").notNull(),
    period: text("period").notNull(),
    basic: numeric("basic", { precision: 14, scale: 2 }).notNull(),
    allowance: numeric("allowance", { precision: 14, scale: 2 }).notNull().default("0"),
    note: text("note").notNull().default(""),
  },
  (t) => [uniqueIndex("uq_pay_override").on(t.clientId, t.bpNo, t.period)]
);

export const payrollRuns = pgTable("payroll_runs", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  period: text("period").notNull(),
  bpNo: text("bp_no").notNull(),
  basic: numeric("basic", { precision: 14, scale: 2 }).notNull(),
  allowance: numeric("allowance", { precision: 14, scale: 2 }).notNull().default("0"),
  gross: numeric("gross", { precision: 14, scale: 2 }).notNull(),
  paye: numeric("paye", { precision: 14, scale: 2 }).notNull().default("0"),
  ssnitT1: numeric("ssnit_t1", { precision: 14, scale: 2 }).notNull().default("0"),
  ssnitT2: numeric("ssnit_t2", { precision: 14, scale: 2 }).notNull().default("0"),
  nhil: numeric("nhil", { precision: 14, scale: 2 }).notNull().default("0"),
  housing: numeric("housing", { precision: 14, scale: 2 }).notNull().default("0"),
  otherDed: numeric("other_ded", { precision: 14, scale: 2 }).notNull().default("0"),
  net: numeric("net", { precision: 14, scale: 2 }).notNull(),
  employerCost: numeric("employer_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  docNo: text("doc_no").notNull().default(""),
  paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
});

// ============================================================
// BANKING & RECONCILIATION
// ============================================================

export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  bank: text("bank").notNull(),
  accountCode: text("account_code").notNull().default("101000"),
  currency: text("currency").notNull().default("GHS"),
  opening: numeric("opening", { precision: 14, scale: 2 }).notNull().default("0"),
  active: boolean("active").notNull().default(true),
});

export const bankLines = pgTable(
  "bank_lines",
  {
    id: serial("id").primaryKey(),
    accountId: integer("account_id").notNull(),
    ref: text("ref").notNull().default(""),
    txnDate: text("txn_date").notNull(),
    description: text("description").notNull().default(""),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    status: text("status").notNull().default("unmatched"),
    journalLineId: integer("journal_line_id"),
    note: text("note").notNull().default(""),
  },
  (t) => [index("idx_banklines_acc").on(t.accountId, t.status)]
);

// ============================================================
// FIXED ASSETS
// ============================================================

export const assetClasses = pgTable("asset_classes", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  scope: text("scope").notNull().default("general"),
  method: text("method").notNull().default("sl"),
  rate: numeric("rate", { precision: 6, scale: 3 }).notNull(),
  lifeYears: integer("life_years").notNull().default(5),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  classCode: text("class_code").notNull(),
  cost: numeric("cost", { precision: 14, scale: 2 }).notNull(),
  accumDep: numeric("accum_dep", { precision: 14, scale: 2 }).notNull().default("0"),
  nbv: numeric("nbv", { precision: 14, scale: 2 }).notNull(),
  inService: text("in_service").notNull(),
  cc: text("cc").notNull().default(""),
  active: boolean("active").notNull().default(true),
  docNo: text("doc_no").notNull().default(""),
});

// ============================================================
// INVENTORY / PRODUCTION / CONTRACTS
// ============================================================

export const stockMoves = pgTable("stock_moves", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  material: text("material").notNull(),
  moveDate: text("move_date").notNull(),
  period: text("period").notNull().default(""),
  qtyIn: numeric("qty_in", { precision: 14, scale: 2 }).notNull().default("0"),
  qtyOut: numeric("qty_out", { precision: 14, scale: 2 }).notNull().default("0"),
  amountIn: numeric("amount_in", { precision: 14, scale: 2 }).notNull().default("0"),
  amountOut: numeric("amount_out", { precision: 14, scale: 2 }).notNull().default("0"),
  docNo: text("doc_no").notNull().default(""),
  ref: text("ref").notNull().default(""),
});

export const productionOrders = pgTable("production_orders", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  no: text("no").notNull(),
  material: text("material").notNull(),
  rawMaterial: text("raw_material").notNull().default(""),
  rawQty: numeric("raw_qty", { precision: 14, scale: 2 }).notNull().default("0"),
  qty: integer("qty").notNull(),
  status: text("status").notNull().default("open"),
  period: text("period").notNull().default(""),
  docs: text("docs").notNull().default(""),
});

export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  no: text("no").notNull(),
  title: text("title").notNull().default(""),
  counterparty: text("counterparty").notNull(),
  sector: text("sector").notNull().default("construction"),
  startDate: text("start_date").notNull().default(""),
  endDate: text("end_date").notNull().default(""),
  /** cost_to_cost | input_survey | output_milestone | straight_line */
  method: text("method").notNull().default("cost_to_cost"),
  totalValue: numeric("total_value", { precision: 14, scale: 2 }).notNull(),
  estimatedCost: numeric("estimated_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  pctComplete: numeric("pct_complete", { precision: 5, scale: 1 }).notNull().default("0"),
  costToDate: numeric("cost_to_date", { precision: 14, scale: 2 }).notNull().default("0"),
  recognisedRevenue: numeric("recognised_revenue", { precision: 14, scale: 2 }).notNull().default("0"),
  recognisedCost: numeric("recognised_cost", { precision: 14, scale: 2 }).notNull().default("0"),
  billed: numeric("billed", { precision: 14, scale: 2 }).notNull().default("0"),
  retentionPct: numeric("retention_pct", { precision: 5, scale: 2 }).notNull().default("0"),
  retentionHeld: numeric("retention_held", { precision: 14, scale: 2 }).notNull().default("0"),
  retentionReleased: numeric("retention_released", { precision: 14, scale: 2 }).notNull().default("0"),
  advances: numeric("advances", { precision: 14, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("GHS"),
  cc: text("cc").notNull().default(""),
  lossProvision: numeric("loss_provision", { precision: 14, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("active"),
}, (t) => [uniqueIndex("uq_contract_no_client").on(t.clientId, t.no)]);

// ============================================================
// BUDGET & SCENARIOS
// ============================================================

export const budgetScenarios = pgTable("budget_scenarios", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  name: text("name").notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
});

export const budgetLines = pgTable("budget_lines", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  scenarioId: integer("scenario_id").notNull(),
  account: text("account").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  note: text("note").notNull().default(""),
});

// ============================================================
// BPZ SERVICES — advisory, engagements, fee billing
// ============================================================

export const workTemplates = pgTable("work_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  serviceLine: text("service_line").notNull(),
  checklist: text("checklist").notNull().default("[]"),
});

export const engagements = pgTable("engagements", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  serviceLine: text("service_line").notNull(),
  template: text("template").notNull().default(""),
  period: text("period").notNull().default(""),
  status: text("status").notNull().default("in_progress"),
  quant: text("quant").notNull().default("{}"),
  qual: text("qual").notNull().default(""),
  updatedBy: text("updated_by").notNull().default(""),
});

export const feeInvoices = pgTable("fee_invoices", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  serviceLine: text("service_line").notNull(),
  period: text("period").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  status: text("status").notNull().default("open"),
  docNo: text("doc_no").notNull().default(""),
});

// ============================================================
// COUNTERS & SETTINGS
// ============================================================

export const meta = pgTable(
  "meta",
  {
    key: text("key").notNull(),
    clientId: integer("client_id").notNull().default(1),
    value: bigint("value", { mode: "number" }).notNull(),
  },
  (t) => [primaryKey({ columns: [t.key, t.clientId] })]
);

export const systemSettings = pgTable("system_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

// ============================================================
// SECURITY, AUDIT & EVIDENCE
// ============================================================

/** Immutable user activity log — who did what, when, in which workspace. */
export const activityLog = pgTable(
  "activity_log",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    workspace: text("workspace").notNull().default(""),
    username: text("username").notNull(),
    role: text("role").notNull().default(""),
    action: text("action").notNull(),
    ok: boolean("ok").notNull().default(true),
    detail: text("detail").notNull().default(""),
    ip: text("ip").notNull().default(""),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_al_client").on(t.clientId, t.at)]
);

/** FX rate history — evidences the rate used for each IAS 21 revaluation. */
export const fxHistory = pgTable(
  "fx_history",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull(),
    rate: numeric("rate", { precision: 14, scale: 6 }).notNull(),
    source: text("source").notNull().default(""),
    capturedAt: timestamp("captured_at").notNull().defaultNow(),
  },
  (t) => [index("idx_fxh_code").on(t.code, t.capturedAt)]
);

/** Login attempts — brute-force lockout evidence. */
export const loginAttempts = pgTable(
  "login_attempts",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    ip: text("ip").notNull().default(""),
    ok: boolean("ok").notNull().default(false),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_la_user").on(t.username, t.at)]
);

// ============================================================
// PRODUCTION HARDENING
// ============================================================

export const backupRuns = pgTable(
  "backup_runs",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    scope: text("scope").notNull().default("workspace"),
    kind: text("kind").notNull().default("manual"),
    sizeBytes: integer("size_bytes").notNull().default(0),
    docs: integer("docs").notNull().default(0),
    takenBy: text("taken_by").notNull().default(""),
    takenAt: timestamp("taken_at").notNull().defaultNow(),
  },
  (t) => [index("idx_br_client").on(t.clientId, t.takenAt)]
);

/** Retained server errors — visible in Diagnostics instead of lost to a console. */
export const errorLog = pgTable(
  "error_log",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id"),
    workspace: text("workspace").notNull().default(""),
    username: text("username").notNull().default(""),
    action: text("action").notNull().default(""),
    route: text("route").notNull().default(""),
    message: text("message").notNull().default(""),
    stack: text("stack").notNull().default(""),
    at: timestamp("at").notNull().defaultNow(),
  },
  (t) => [index("idx_el_at").on(t.at)]
);

// ============================================================
// IFRS 15 — LONG-TERM CONTRACTS & OVER-TIME REVENUE RECOGNITION
// ============================================================

export const contractCertificates = pgTable(
  "contract_certificates",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    contractId: integer("contract_id").notNull(),
    certNo: text("cert_no").notNull(),
    period: text("period").notNull(),
    certDate: text("cert_date").notNull().default(""),
    grossValue: numeric("gross_value", { precision: 14, scale: 2 }).notNull().default("0"),
    retention: numeric("retention", { precision: 14, scale: 2 }).notNull().default("0"),
    netPayable: numeric("net_payable", { precision: 14, scale: 2 }).notNull().default("0"),
    cumulativePct: numeric("cumulative_pct", { precision: 5, scale: 1 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    paid: numeric("paid", { precision: 14, scale: 2 }).notNull().default("0"),
    status: text("status").notNull().default("open"),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("idx_cc_contract").on(t.clientId, t.contractId),
    uniqueIndex("uq_certificate_no_client").on(t.clientId, t.certNo),
  ]
);

export const contractCosts = pgTable(
  "contract_costs",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    contractId: integer("contract_id").notNull(),
    period: text("period").notNull(),
    account: text("account").notNull().default("505000"),
    description: text("description").notNull().default(""),
    vendor: text("vendor").notNull().default(""),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_cst_contract").on(t.clientId, t.contractId)]
);

// ============================================================
// IFRS 9 — FINANCIAL INSTRUMENTS & EXPECTED CREDIT LOSSES
// ============================================================

export const financialInstruments = pgTable(
  "financial_instruments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull().default("amortised_cost"),
    instrumentType: text("instrument_type").notNull().default("loan_receivable"),
    counterparty: text("counterparty").notNull().default(""),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    effectiveRate: numeric("effective_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    issueDate: text("issue_date").notNull().default(""),
    maturityDate: text("maturity_date").notNull().default(""),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    eclAllowance: numeric("ecl_allowance", { precision: 16, scale: 2 }).notNull().default("0"),
    stage: integer("stage").notNull().default(1),
    stage2Since: text("stage2_since").notNull().default(""),
    collateralValue: numeric("collateral_value", { precision: 16, scale: 2 }).notNull().default("0"),
    creditGrade: text("credit_grade").notNull().default(""),
    currency: text("currency").notNull().default("GHS"),
    lastEclPeriod: text("last_ecl_period").notNull().default(""),
    notes: text("notes").notNull().default(""),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_fi_client").on(t.clientId, t.status)]
);

export const eclAssessments = pgTable(
  "ecl_assessments",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    instrumentId: integer("instrument_id").notNull(),
    stage: integer("stage").notNull().default(1),
    exposure: numeric("exposure", { precision: 16, scale: 2 }).notNull().default("0"),
    pd: numeric("pd", { precision: 7, scale: 4 }).notNull().default("0"),
    lgd: numeric("lgd", { precision: 7, scale: 4 }).notNull().default("0"),
    ecl: numeric("ecl", { precision: 16, scale: 2 }).notNull().default("0"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    horizonMonths: integer("horizon_months").notNull().default(12),
    movement: numeric("movement", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_ecl_client").on(t.clientId, t.period)]
);

export const eclProvisionMatrix = pgTable(
  "ecl_provision_matrix",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    bucket: text("bucket").notNull(),
    label: text("label").notNull().default(""),
    pd: numeric("pd", { precision: 7, scale: 4 }).notNull().default("0"),
  },
  (t) => [uniqueIndex("uq_matrix_bucket").on(t.clientId, t.bucket)]
);

// ============================================================
// IFRS 16 — LEASES
// ============================================================

export const leases = pgTable(
  "leases",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    description: text("description").notNull().default(""),
    lessor: text("lessor").notNull().default(""),
    leaseType: text("lease_type").notNull().default("property"),
    startDate: text("start_date").notNull().default(""),
    termMonths: integer("term_months").notNull().default(12),
    payment: numeric("payment", { precision: 16, scale: 2 }).notNull().default("0"),
    frequency: text("frequency").notNull().default("monthly"),
    timing: text("timing").notNull().default("arrears"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    initialDirectCosts: numeric("initial_direct_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    incentives: numeric("incentives", { precision: 16, scale: 2 }).notNull().default("0"),
    restorationCost: numeric("restoration_cost", { precision: 16, scale: 2 }).notNull().default("0"),
    rouAsset: numeric("rou_asset", { precision: 16, scale: 2 }).notNull().default("0"),
    leaseLiability: numeric("lease_liability", { precision: 16, scale: 2 }).notNull().default("0"),
    accumulatedDepreciation: numeric("accumulated_depreciation", { precision: 16, scale: 2 }).notNull().default("0"),
    lowValueExemption: boolean("low_value_exemption").notNull().default(false),
    cc: text("cc").notNull().default(""),
    lastDepPeriod: text("last_dep_period").notNull().default(""),
    lastInterestPeriod: text("last_interest_period").notNull().default(""),
    status: text("status").notNull().default("active"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_lease_client").on(t.clientId, t.status)]
);

// ============================================================
// IAS 36 — IMPAIRMENT OF ASSETS
// ============================================================

export const impairmentTests = pgTable(
  "impairment_tests",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    unitName: text("unit_name").notNull(),
    unitType: text("unit_type").notNull().default("cgu"),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    fairValueLessCosts: numeric("fair_value_less_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    cashFlows: numeric("cash_flows", { precision: 16, scale: 2 }).notNull().default("0"),
    terminalValue: numeric("terminal_value", { precision: 16, scale: 2 }).notNull().default("0"),
    discountRate: numeric("discount_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    horizonYears: integer("horizon_years").notNull().default(5),
    valueInUse: numeric("value_in_use", { precision: 16, scale: 2 }).notNull().default("0"),
    recoverableAmount: numeric("recoverable_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    impairmentLoss: numeric("impairment_loss", { precision: 16, scale: 2 }).notNull().default("0"),
    reversalAvailable: numeric("reversal_available", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    notes: text("notes").notNull().default(""),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_imp_client").on(t.clientId, t.period)]
);

// ============================================================
// IFRS 5 — NON-CURRENT ASSETS HELD FOR SALE
// ============================================================

export const heldForSale = pgTable(
  "held_for_sale",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    period: text("period").notNull(),
    assetCode: text("asset_code").notNull().default(""),
    description: text("description").notNull().default(""),
    originalCost: numeric("original_cost", { precision: 16, scale: 2 }).notNull().default("0"),
    accumulatedDepreciation: numeric("accumulated_depreciation", { precision: 16, scale: 2 }).notNull().default("0"),
    carryingAmount: numeric("carrying_amount", { precision: 16, scale: 2 }).notNull().default("0"),
    fairValueLessCosts: numeric("fair_value_less_costs", { precision: 16, scale: 2 }).notNull().default("0"),
    writeDown: numeric("write_down", { precision: 16, scale: 2 }).notNull().default("0"),
    discontinuedOperation: boolean("discontinued_operation").notNull().default(false),
    expectedSaleDate: text("expected_sale_date").notNull().default(""),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("held_for_sale"),
    createdBy: text("created_by").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_hfs_client").on(t.clientId, t.period)]
);

// ============================================================
// LOANS & BORROWINGS — amortised cost with full schedules
// ============================================================

export const loans = pgTable(
  "loans",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    code: text("code").notNull(),
    lender: text("lender").notNull().default(""),
    facilityType: text("facility_type").notNull().default("amortising"),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    annualRate: numeric("annual_rate", { precision: 7, scale: 4 }).notNull().default("0"),
    termMonths: integer("term_months").notNull().default(12),
    startDate: text("start_date").notNull().default(""),
    frequency: text("frequency").notNull().default("monthly"),
    timing: text("timing").notNull().default("arrears"),
    moratoriumMonths: integer("moratorium_months").notNull().default(0),
    arrangementFee: numeric("arrangement_fee", { precision: 16, scale: 2 }).notNull().default("0"),
    feeMonths: integer("fee_months").notNull().default(0),
    drawdownAccount: text("drawdown_account").notNull().default("101000"),
    loanAccount: text("loan_account").notNull().default("290000"),
    interestAccount: text("interest_account").notNull().default("575000"),
    feeAccount: text("fee_account").notNull().default("576000"),
    currency: text("currency").notNull().default("GHS"),
    cc: text("cc").notNull().default(""),
    outstanding: numeric("outstanding", { precision: 16, scale: 2 }).notNull().default("0"),
    interestPaidTo: text("interest_paid_to").notNull().default(""),
    lastPeriod: text("last_period").notNull().default(""),
    status: text("status").notNull().default("active"),
    notes: text("notes").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_loan_client").on(t.clientId, t.status)]
);

export const loanSchedules = pgTable(
  "loan_schedules",
  {
    id: serial("id").primaryKey(),
    clientId: integer("client_id").notNull(),
    loanId: integer("loan_id").notNull(),
    seq: integer("seq").notNull(),
    period: text("period").notNull(),
    paymentDate: text("payment_date").notNull().default(""),
    opening: numeric("opening", { precision: 16, scale: 2 }).notNull().default("0"),
    interest: numeric("interest", { precision: 16, scale: 2 }).notNull().default("0"),
    fee: numeric("fee", { precision: 16, scale: 2 }).notNull().default("0"),
    principal: numeric("principal", { precision: 16, scale: 2 }).notNull().default("0"),
    payment: numeric("payment", { precision: 16, scale: 2 }).notNull().default("0"),
    closing: numeric("closing", { precision: 16, scale: 2 }).notNull().default("0"),
    docNo: text("doc_no").notNull().default(""),
    status: text("status").notNull().default("scheduled"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("idx_ls_loan").on(t.clientId, t.loanId)]
);
