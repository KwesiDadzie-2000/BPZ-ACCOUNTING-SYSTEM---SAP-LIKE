/**
 * BPZ Ghana sector knowledge base — sectors, their tax positions (Income Tax
 * Act 896 as amended, GRA practice, sector regulations) and workflows.
 * All rates live in the DB (tax_rates / tax_bands) and are owner-editable;
 * these notes guide workspaces and advisory templates.
 */

export type Sector = {
  code: string;
  name: string;
  description: string;
  corpTaxNote: string;
  sectorTaxNotes: string[];
  keyAccounts: string[];
  workflow: "standard" | "manufacturing" | "construction" | "extraction" | "financial";
  advisoryFocus: string;
};

export const SECTORS: Sector[] = [
  {
    code: "manufacturing",
    name: "Manufacturing",
    description: "Local production of goods — food, beverages, textiles, metals, assembly.",
    corpTaxNote: "Standard 25% CIT; 40% on tobacco & 40% on liquor; ECG levy 2.5% on large companies.",
    sectorTaxNotes: [
      "VAT 20% on sales; import duty/VAT on raw materials recoverable as input tax (no cascading on VAT)",
      "ECG Levy 2.5% of assessable profit (companies with turnover > GHS 30m)",
      "Manufacturing losses carry-forward subject to IAA 896 s.45 tests (sale of 75%/30% share rules)",
      "Inventory: raw material, WIP, finished goods costing (standard or moving average) — IAS 2",
    ],
    keyAccounts: ["120000", "122000", "121000", "500000", "501000", "132000"],
    workflow: "manufacturing",
    advisoryFocus: "Production costing, inventory valuation (IAS 2), capacity & margin analysis, ECG levy compliance.",
  },
  {
    code: "construction",
    name: "Construction",
    description: "Building, civil engineering and infrastructure contracts.",
    corpTaxNote: "25% CIT; contract revenue recognised under IFRS 15 (cost-to-cost); VAT on billings.",
    sectorTaxNotes: [
      "IFRS 15 / IAS 11-style contract accounting — WIP asset for costs + profit in excess of billings",
      "VAT 20% on monthly billings (certificates); input VAT on materials, plant hire",
      "Withholding tax applies on payments to sub-contractors (services 5% / goods 7.5%)",
      "Retentions receivable tracked as contract assets (IFRS 15)",
    ],
    keyAccounts: ["143000", "440000", "505000", "110000", "222000"],
    workflow: "construction",
    advisoryFocus: "Contract revenue & WIP reviews, retention tracking, project margin reporting, cash flow planning.",
  },
  {
    code: "oil_gas",
    name: "Oil & Gas",
    description: "Upstream petroleum production, services and midstream.",
    corpTaxNote: "Petroleum Production Tax (PPT) 35% of PPT income (50% special cases); corporate tax 25% on residual.",
    sectorTaxNotes: [
      "Petroleum Production Tax Act 2015 (Act 894): PPT 35% of PPT income (revenue minus deductions)",
      "8% rent / 15% concession rent on produced oil (Petroleum Act 2011)",
      "10% non-refundable VAT on imported equipment & services used in oil operations",
      "Capital cost deductions 50% (development) / 25% (exploration) annually — no loss carry-back",
      "Ring-fenced: petroleum profits cannot offset other income; WHT on payments 5–15% per schedule",
      "Gas: gas levy and gas transportation charges apply",
    ],
    keyAccounts: ["138000", "138500", "218000", "217000", "582000", "583000", "584000"],
    workflow: "extraction",
    advisoryFocus: "PPT computation, capital cost deduction schedules, cost recovery, joint venture & unitisation support.",
  },
  {
    code: "mining",
    name: "Mining",
    description: "Gold, diamonds, bauxite, manganese — exploration through production.",
    corpTaxNote: "35% CIT (mining rate); royalty 5% of gross value of production.",
    sectorTaxNotes: [
      "Minerals and Mining Act 2006 (Act 729): royalty 5% of gross value of minerals produced (4% bauxite)",
      "Corporate income tax 35% on mining profits",
      "Withholding tax on payments to vendors: 3% on goods & services? — apply current GRA schedule (7.5% goods / 5% services)",
      "Exploration & evaluation assets capitalised until technical feasibility (IAS 37/IFRIC 6)",
      "Dismantling / closure provision required at mine closure (IAS 37)",
      "Local content & 10% equity for Ghanaian participation (Act 1036 amendments)",
    ],
    keyAccounts: ["137000", "140500", "138500", "217000", "581000", "583000", "584000"],
    workflow: "extraction",
    advisoryFocus: "Royalty & PPT-style tax modelling, ore reserve disclosure support, IAS 37 closure provisions.",
  },
  {
    code: "energy",
    name: "Energy & Utilities",
    description: "Power generation, distribution, renewables, fuel & coking.",
    corpTaxNote: "25% CIT; renewables enjoy concessions under various Acts — verify per project.",
    sectorTaxNotes: [
      "Power Act 2001 (Act 632): EPC contract tax treatment — VAT on power sales; PPA pricing in $/cedis",
      "VAT 20% on electricity sales; import duty concessions on generation equipment (verify)",
      "Fuel & coking: fuel levy and excise duties on petroleum products",
      "Multi-currency PPA revenue — FX revaluation each period (IAS 21)",
    ],
    keyAccounts: ["450000", "138000", "491000", "580000", "506000"],
    workflow: "extraction",
    advisoryFocus: "FX exposure management, tariff & PPA compliance, fuel cost pass-through analysis.",
  },
  {
    code: "agriculture",
    name: "Agriculture & Agro-processing",
    description: "Farming, livestock, cocoa, agro-processing and inputs.",
    corpTaxNote: "5% tax on 80% of taxable income for qualifying agricultural income (IAA 896 s.10(4)).",
    sectorTaxNotes: [
      "Agricultural incentive: 5% CIT on 80% of assessable income (first 5 years for some)",
      "VAT 20% on agro-processing sales; some inputs (seed, fertiliser) zero-rated or exempt — verify current list",
      "Farm inventory (biological assets) IAS 41 fair value where applicable",
    ],
    keyAccounts: ["120000", "400000", "500000", "132000"],
    workflow: "standard",
    advisoryFocus: "Agricultural CIT computation, input VAT position, crop cycle budgeting.",
  },
  {
    code: "trade_retail",
    name: "Trade & Retail",
    description: "Wholesale, retail, supermarkets, e-commerce.",
    corpTaxNote: "25% CIT; 20% VAT on retail sales; property rate on premises.",
    sectorTaxNotes: [
      "VAT 20% output on retail; full input credit on stock purchases (no cascading)",
      "Property rate 1–3% of annual value (local assembly schedules) — accrue monthly",
      "E-commerce: 20% VAT on digital goods; 3% withholding on payments to non-resident e-platforms (verify)",
    ],
    keyAccounts: ["121000", "400000", "500000", "520000", "215000"],
    workflow: "standard",
    advisoryFocus: "Stock valuation & shrinkage, margin by product line, VAT control account reconciliation.",
  },
  {
    code: "import_distribution",
    name: "Import & Distribution",
    description: "Importers, freight forwarders, distributors.",
    corpTaxNote: "25% CIT; import duty + VAT at border; VAT refundable with proper import documentation.",
    sectorTaxNotes: [
      "Import duty 0–20% by HS code; VAT 20% on CIF + duty at import (ICUMS)",
      "Import VAT recoverable as input tax — maintain ICUMS documentation for VAT control account",
      "Freight forwarder WHT on commission; non-resident carriers WHT 15% (verify)",
      "Multi-currency: USD/EUR imports — IAS 21 initial measurement at transaction date, revaluation at period end",
    ],
    keyAccounts: ["121000", "400000", "491000", "580000", "570000"],
    workflow: "standard",
    advisoryFocus: "Import VAT recovery, FX exposure hedging advice, duty classification support.",
  },
  {
    code: "services",
    name: "Professional & General Services",
    description: "Consulting, agencies, facilities, BPOs, SaaS.",
    corpTaxNote: "25% CIT; WHT applies to service payments (5% resident / 15% non-resident).",
    sectorTaxNotes: [
      "WHT on service fees: 5% resident, 15% non-resident services; 15% professional fees (resident professionals)",
      "Export of services — VAT zero-rated where services wholly enjoyed outside Ghana (verify facts)",
      "Permanent establishment risk for non-resident clients — advisory note",
    ],
    keyAccounts: ["410000", "510000", "514000", "561000"],
    workflow: "standard",
    advisoryFocus: "WHT optimisation in vendor selection, zero-rated export VAT positions, project-based P&L.",
  },
  {
    code: "banking_finance",
    name: "Banking & Financial Services",
    description: "Commercial banks, MFI, insurance, leasing, fintech.",
    corpTaxNote: "25% CIT on banking income; loan-loss provisions per BOG guidelines; investment income taxed per schedule.",
    sectorTaxNotes: [
      "Banking Act 2016 (Act 874) — prudential loan-loss provisioning (specific/general)",
      "Interest on government securities & specific instruments — verify WHT/tax treatment",
      "Dividend income 8% WHT; intercompany interest 15% WHT",
      "IFRS 9 expected credit loss impairment modelling — advisory support",
    ],
    keyAccounts: ["110000", "111000", "420000", "590000", "293000"],
    workflow: "financial",
    advisoryFocus: "IFRS 9 ECL reviews, regulatory reporting support, loan portfolio tax treatment.",
  },
  {
    code: "real_estate",
    name: "Real Estate & Property",
    description: "Developers, landlords, property management.",
    corpTaxNote: "25% CIT; 8% WHT on improved property rent; 15% on unimproved land rent.",
    sectorTaxNotes: [
      "Property rate 1–3% of annual rateable value",
      "WHT on rent: 8% improved property, 15% unimproved land",
      "VAT 20% on commercial rent & sales; residential sales to individuals — VAT-exempt (verify)",
      "Development costs capitalised until completion (IAS 2 / IAS 16)",
    ],
    keyAccounts: ["130000", "131000", "430000", "520000", "215000"],
    workflow: "standard",
    advisoryFocus: "Property rate appeals, rental WHT compliance, development stage reporting.",
  },
  {
    code: "education",
    name: "Education",
    description: "Schools, universities, training institutions.",
    corpTaxNote: "25% CIT; some education income exempt/excluded per IAA 896 s.10 — verify entity status.",
    sectorTaxNotes: [
      "Tuition income — verify exempt vs taxable per Act 896 (private institutions)",
      "VAT 20% on fees where not exempt; supplies to staff canteens",
      "Depreciation of buildings 2–2.5%, equipment 25%",
    ],
    keyAccounts: ["410000", "131000", "510000"],
    workflow: "standard",
    advisoryFocus: "Tuition VAT/exemption position, fee collection controls, grant accounting.",
  },
  {
    code: "health",
    name: "Health & Pharmaceuticals",
    description: "Hospitals, clinics, pharma distribution, diagnostics.",
    corpTaxNote: "25% CIT; certain medical supplies zero-rated/exempt — verify current VAT list.",
    sectorTaxNotes: [
      "NHIF receivables tracked separately — aging critical",
      "Pharma imports: duty/VAT at import; excise on some products",
      "Equipment: 25% depreciation on medical machines",
    ],
    keyAccounts: ["110000", "121000", "410000", "134000"],
    workflow: "standard",
    advisoryFocus: "NHIF recovery tracking, drug inventory (expiry) valuation, capital project planning.",
  },
  {
    code: "transport_logistics",
    name: "Transport & Logistics",
    description: "Freight, haulage, warehousing, port services.",
    corpTaxNote: "25% CIT; 15% WHT on non-resident shipping/air transport services.",
    sectorTaxNotes: [
      "Vehicle & fleet depreciation 25%; leasing income 20% VAT",
      "Non-resident carriers: WHT 15% (verify current schedule)",
      "Fuel cost dominates P&L — budget & variance critical",
    ],
    keyAccounts: ["133000", "410000", "506000", "530000", "531000"],
    workflow: "standard",
    advisoryFocus: "Fleet cost management, route margin analysis, WHT on foreign carriers.",
  },
  {
    code: "it_telecom",
    name: "IT & Telecoms",
    description: "Software, SaaS, data centres, telecoms, hardware.",
    corpTaxNote: "25% CIT; e-services VAT on digital supplies; 15% WHT on non-resident technical/management fees.",
    sectorTaxNotes: [
      "SaaS/digital services: 20% VAT on e-services supplied to Ghanaian customers",
      "Non-resident technical & management fees: 15% WHT",
      "Software intangibles amortised 10% (verify useful life); hardware 25%",
    ],
    keyAccounts: ["410000", "140000", "595000", "491000"],
    workflow: "standard",
    advisoryFocus: "Digital VAT registration, intangible amortisation policy, USD-denominated SaaS revenue FX.",
  },
  {
    code: "tourism",
    name: "Tourism & Hospitality",
    description: "Hotels, tour operators, event management.",
    corpTaxNote: "25% CIT; 20% VAT on room/food services; property rate on premises.",
    sectorTaxNotes: [
      "VAT 20% on accommodation, F&B, events",
      "Tour operator: WHT on foreign service providers 15%",
      "Occupancy-related budgets & seasonality modelling",
    ],
    keyAccounts: ["410000", "121000", "520000", "131000"],
    workflow: "standard",
    advisoryFocus: "Seasonal cash budgeting, occupancy-based forecasting, F&B cost control.",
  },
  {
    code: "ngo_gov",
    name: "NGOs, Trusts & Public Sector",
    description: "NGOs, donor-funded projects, public entities, cooperatives.",
    corpTaxNote: "Exempt organisations (charitable) — verify GRA exemption letter; projects may be taxable.",
    sectorTaxNotes: [
      "Exemption applies to qualifying activities only — project income may be taxable",
      "Donor funds: fund accounting (restricted vs unrestricted) — IFRS for SMEs/GAAP hybrid",
      "Grant compliance reporting per donor (UN, USAID, DFID-style templates)",
    ],
    keyAccounts: ["330000", "410000", "510000", "222000"],
    workflow: "standard",
    advisoryFocus: "Grant compliance, restricted fund tracking, donor reporting packs.",
  },
];

export const sectorByCode = (code: string): Sector =>
  SECTORS.find((s) => s.code === code) ?? SECTORS[8];

/** BPZ service lines with default monthly fees (GHS) — editable in admin. */
export const SERVICE_LINES: { code: string; name: string; defaultFee: number; blurb: string }[] = [
  { code: "bookkeeping", name: "Bookkeeping & Daily Accounting", defaultFee: 3500, blurb: "Transaction capture, journal, ledger upkeep" },
  { code: "payroll", name: "Payroll & Statutory Filing", defaultFee: 2500, blurb: "Ghana PAYE, SSNIT, NHIL, WHT filings" },
  { code: "tax_compliance", name: "Tax Compliance & Returns", defaultFee: 3000, blurb: "VAT, CIT, withholding, property rate returns" },
  { code: "tax_planning", name: "Tax Planning & Advisory", defaultFee: 4500, blurb: "Structure, incentives, transfer pricing advice" },
  { code: "ifrs_reporting", name: "IFRS Financial Reporting", defaultFee: 4000, blurb: "Monthly close + IFRS statements & analysis" },
  { code: "audit_support", name: "Audit Support & Controls", defaultFee: 3000, blurb: "Audit packs, reconciliations, internal controls" },
  { code: "business_advisory", name: "Business Advisory & Planning", defaultFee: 3500, blurb: "Budgets, scenarios, KPI dashboards" },
  { code: "sector_specialist", name: "Sector Specialist (O&G / Mining / Energy)", defaultFee: 8000, blurb: "PPT, royalties, capital cost deductions, IAS 37" },
];

export const SERVICE_LINE_NAMES: Record<string, string> = Object.fromEntries(
  SERVICE_LINES.map((s) => [s.code, s.name])
);

/** Comprehensive Ghana/IFRS chart of accounts (sector-tailored, all sectors covered). */
export const CHART_OF_ACCOUNTS: [string, string, string][] = [
  // Assets — current
  ["100000", "Cash", "Asset"],
  ["101000", "Bank - SCB", "Asset"],
  ["102000", "Bank - GCB", "Asset"],
  ["103000", "Bank - Fidelity", "Asset"],
  ["104000", "Bank - Stanbic", "Asset"],
  ["105000", "Petty Cash", "Asset"],
  ["110000", "Accounts Receivable", "Asset"],
  ["111000", "Loans Receivable", "Asset"],
  ["112000", "VAT Receivable (Input Tax)", "Asset"],
  ["113000", "WHT Receivable", "Asset"],
  ["116000", "Other Receivables", "Asset"],
  ["120000", "Inventory - Raw Materials", "Asset"],
  ["121000", "Inventory - Finished Goods", "Asset"],
  ["122000", "Inventory - Work in Progress", "Asset"],
  ["123000", "Inventory - Packaging", "Asset"],
  ["124000", "Inventory - Spares & Consumables", "Asset"],
  // Assets — non-current
  ["130000", "Land", "Asset"],
  ["131000", "Buildings", "Asset"],
  ["132000", "Plant & Machinery", "Asset"],
  ["133000", "Vehicles & Fleet", "Asset"],
  ["134000", "IT & Office Equipment", "Asset"],
  ["135000", "Furniture & Fittings", "Asset"],
  ["136000", "Construction in Progress", "Asset"],
  ["137000", "Mining Assets", "Asset"],
  ["138000", "Oil & Gas / Wells Assets", "Asset"],
  ["138500", "Exploration & Evaluation Assets", "Asset"],
  ["139000", "Accumulated Depreciation", "Asset"],
  ["140000", "Intangible Assets", "Asset"],
  ["140500", "Mining Rights & Concessions", "Asset"],
  ["141000", "Prepaid Expenses", "Asset"],
  ["142000", "Deferred Tax Asset", "Asset"],
  ["143000", "Contract Asset - Unbilled Work (IFRS 15)", "Asset"],
  ["149000", "Other Non-Current Assets", "Asset"],
  // Liabilities — current
  ["200000", "Accounts Payable", "Liability"],
  ["201000", "Payable - Goods & Materials", "Liability"],
  ["202000", "Payable - Service Providers", "Liability"],
  ["205000", "Salaries & Wages Payable", "Liability"],
  ["206000", "SSNIT Payable", "Liability"],
  ["207000", "PAYE Payable", "Liability"],
  ["208000", "NHIL Payable", "Liability"],
  ["209000", "Withholding Tax Payable", "Liability"],
  ["210000", "GR/IR Clearing", "Liability"],
  ["211000", "VAT Payable (Output)", "Liability"],
  ["215000", "Property Rate Payable", "Liability"],
  ["216000", "Rent Payable", "Liability"],
  ["217000", "Royalties Payable", "Liability"],
  ["218000", "Petroleum Production Tax Payable", "Liability"],
  ["219000", "Accrued Expenses", "Liability"],
  ["220000", "Bank Loans - Current", "Liability"],
  ["222000", "Customer Advances (Unearned)", "Liability"],
  ["229000", "Other Current Liabilities", "Liability"],
  // Liabilities — non-current
  ["290000", "Bank Loans - Non-Current", "Liability"],
  ["291000", "Debentures & Long-Term Borrowings", "Liability"],
  ["292000", "Deferred Tax Liability", "Liability"],
  ["293000", "Provisions (Legal, Dismantling)", "Liability"],
  ["295000", "Contract Liabilities (Non-Current)", "Liability"],
  ["299000", "Other Non-Current Liabilities", "Liability"],
  // Equity
  ["300000", "Share Capital", "Equity"],
  ["310000", "Share Premium", "Equity"],
  ["320000", "Retained Earnings", "Equity"],
  ["330000", "Other Reserves", "Equity"],
  ["340000", "OCI - FX Translation Reserve", "Equity"],
  ["350000", "Revaluation Reserve", "Equity"],
  // Income
  ["400000", "Sales Revenue", "Revenue"],
  ["410000", "Service Revenue", "Revenue"],
  ["420000", "Interest Income", "Revenue"],
  ["421000", "Dividend Income", "Revenue"],
  ["430000", "Rental Income", "Revenue"],
  ["440000", "Contract Revenue (Construction)", "Revenue"],
  ["450000", "Power / Energy Sales Revenue", "Revenue"],
  ["490000", "Other Income", "Revenue"],
  ["491000", "Foreign Exchange Gain", "Revenue"],
  ["492000", "Gain on Disposal of Assets", "Revenue"],
  ["493000", "Reversal of Provisions", "Revenue"],
  // Expenses
  ["500000", "Cost of Goods Sold", "Expense"],
  ["501000", "Production Overhead", "Expense"],
  ["505000", "Contract Costs (Construction)", "Expense"],
  ["508000", "Onerous Contract Loss (IAS 37)", "Expense"],
  ["506000", "Fuel, Power & Utilities (Production)", "Expense"],
  ["510000", "Salaries & Wages", "Expense"],
  ["511000", "SSNIT - Employer Contribution", "Expense"],
  ["512000", "Benefits & Bonuses", "Expense"],
  ["513000", "Recruitment & Training", "Expense"],
  ["514000", "Professional Fees (Audit, Legal)", "Expense"],
  ["520000", "Rent Expense", "Expense"],
  ["521000", "Property Rate Expense", "Expense"],
  ["526304", "Insurance", "Expense"],
  ["530000", "Repairs & Maintenance", "Expense"],
  ["531000", "Vehicle & Fleet Expenses", "Expense"],
  ["540000", "Utilities - Office", "Expense"],
  ["550000", "Depreciation Expense", "Expense"],
  ["560000", "Office Supplies & Stationery", "Expense"],
  ["561000", "Travel, Transport & Hospitality", "Expense"],
  ["562000", "Marketing & Advertising", "Expense"],
  ["563000", "Commission & Agent Fees", "Expense"],
  ["564000", "Telephone, Internet & Data", "Expense"],
  ["570000", "Bank Charges & Interest Expense", "Expense"],
  ["580000", "Foreign Exchange Loss", "Expense"],
  ["581000", "Royalties - Mining", "Expense"],
  ["582000", "Petroleum Production Tax", "Expense"],
  ["583000", "Exploration & Evaluation Expense", "Expense"],
  ["584000", "Dismantling & Closure Provision", "Expense"],
  ["590000", "Bad Debt Expense", "Expense"],
  ["591000", "Loss on Disposal of Assets", "Expense"],
  ["592000", "Impairment & Write-Downs", "Expense"],
  ["595000", "Amortization of Intangibles", "Expense"],
  ["599000", "General & Administrative", "Expense"],
  // Legacy aliases (pre-BPZ migration postings)
  ["220000", "Salaries Payable (legacy – use 205000)", "Liability"],
  ["230000", "Tax Payable VAT (legacy – use 211000)", "Liability"],
  ["526304", "Insurance - Vehicles (legacy alias)", "Expense"],
];

/** Asset classes — general across all sectors + sector-specific. */
export const ASSET_CLASSES: {
  code: string;
  name: string;
  scope: string;
  method: "sl" | "db";
  rate: number;
  lifeYears: number;
}[] = [
  { code: "GEN-LAND", name: "Land", scope: "general", method: "sl", rate: 0, lifeYears: 999 },
  { code: "GEN-BLDG", name: "Buildings", scope: "general", method: "sl", rate: 2.5, lifeYears: 40 },
  { code: "GEN-PLANT", name: "Plant & Machinery", scope: "general", method: "sl", rate: 25, lifeYears: 4 },
  { code: "GEN-VEH", name: "Vehicles & Fleet", scope: "general", method: "sl", rate: 25, lifeYears: 4 },
  { code: "GEN-IT", name: "IT & Office Equipment", scope: "general", method: "sl", rate: 25, lifeYears: 4 },
  { code: "GEN-FURN", name: "Furniture & Fittings", scope: "general", method: "sl", rate: 25, lifeYears: 4 },
  { code: "GEN-INTANG", name: "Intangibles (Software, Licences)", scope: "general", method: "sl", rate: 10, lifeYears: 10 },
  { code: "GEN-CIP", name: "Construction in Progress", scope: "general", method: "sl", rate: 0, lifeYears: 999 },
  { code: "MIN-EQ", name: "Mining Equipment & Crushers", scope: "mining", method: "sl", rate: 25, lifeYears: 4 },
  { code: "MIN-RIGHTS", name: "Mining Rights & Concessions", scope: "mining", method: "sl", rate: 10, lifeYears: 10 },
  { code: "OIL-WELL", name: "Wells & Production Equipment", scope: "oil_gas", method: "sl", rate: 15, lifeYears: 7 },
  { code: "OIL-EXPLO", name: "Exploration Assets (Capitalised)", scope: "oil_gas", method: "sl", rate: 25, lifeYears: 4 },
  { code: "CON-PLANT", name: "Contract Plant & Temporary Works", scope: "construction", method: "sl", rate: 25, lifeYears: 4 },
  { code: "FIN-LOAN", name: "Loan Portfolio (Financial Sector)", scope: "banking_finance", method: "sl", rate: 0, lifeYears: 999 },
  { code: "ENE-GEN", name: "Generation Plant & Turbines", scope: "energy", method: "sl", rate: 10, lifeYears: 10 },
];

/** Work templates for BPZ service delivery (quantitative + qualitative). */
export const WORK_TEMPLATES: {
  name: string;
  serviceLine: string;
  checklist: { type: "quant" | "qual"; label: string }[];
}[] = [
  {
    name: "Corporate Income Tax Computation",
    serviceLine: "tax_planning",
    checklist: [
      { type: "quant", label: "Revenue per audited/management accounts" },
      { type: "quant", label: "Deductible expenses (per IAA 896)" },
      { type: "quant", label: "Disallowed / non-deductible adjustments" },
      { type: "quant", label: "Taxable income" },
      { type: "quant", label: "Sector rate applied (25% / 35% mining / 5% agri / PPT)" },
      { type: "quant", label: "Tax payable / credit (loss carry-forward applied)" },
      { type: "qual", label: "Transfer pricing & related-party review" },
      { type: "qual", label: "Permanent establishment / branch risk notes" },
      { type: "qual", label: "Incentives claimed & basis (Act references)" },
    ],
  },
  {
    name: "VAT Return Pack",
    serviceLine: "tax_compliance",
    checklist: [
      { type: "quant", label: "Output VAT @ 20% (sales + imports)" },
      { type: "quant", label: "Input VAT claimed" },
      { type: "quant", label: "Net VAT payable / refund" },
      { type: "quant", label: "VAT control account reconciliation (journal vs return)" },
      { type: "qual", label: "Zero-rated / exempt transactions review" },
      { type: "qual", label: "Blocked-credit risk (entertainment, vehicles) — no cascading check" },
      { type: "qual", label: "E-filing evidence & due date confirmation" },
    ],
  },
  {
    name: "PAYE & SSNIT Compliance Pack",
    serviceLine: "payroll",
    checklist: [
      { type: "quant", label: "Gross payroll by employee" },
      { type: "quant", label: "PAYE per GRA bands (effective schedule)" },
      { type: "quant", label: "SSNIT Tier 1 (5.5%) + Tier 2 (5%) employee / 13% employer" },
      { type: "quant", label: "NHIL 2.5% & housing component" },
      { type: "quant", label: "Total remitted vs payable (GRA/SSNIT/NHIL statements)" },
      { type: "qual", label: "New joiners / leavers in period" },
      { type: "qual", label: "Contractor vs employee classification review" },
    ],
  },
  {
    name: "IFRS Monthly Close Pack",
    serviceLine: "ifrs_reporting",
    checklist: [
      { type: "quant", label: "Trial balance review (all accounts moved)" },
      { type: "quant", label: "Bank reconciliations completed" },
      { type: "quant", label: "Accruals, prepayments & amortisations posted" },
      { type: "quant", label: "FX revaluation (IAS 21) & depreciation (IAS 16)" },
      { type: "quant", label: "Inventory valuation (IAS 2) & receivables ECL (IFRS 9)" },
      { type: "qual", label: "Judgement & estimate notes (impairment, provisions)" },
      { type: "qual", label: "Related-party disclosures" },
    ],
  },
  {
    name: "Budget, Forecast & Scenario Pack",
    serviceLine: "business_advisory",
    checklist: [
      { type: "quant", label: "Revenue model (volume × price by line)" },
      { type: "quant", label: "Cost structure & fixed/variable split" },
      { type: "quant", label: "3-year P&L / cash / balance sheet projection" },
      { type: "quant", label: "Base / upside / downside scenarios vs actual" },
      { type: "qual", label: "Market & demand assumptions" },
      { type: "qual", label: "Key risks & mitigants" },
      { type: "qual", label: "Funding & covenants review" },
    ],
  },
  {
    name: "Audit Support & Controls Pack",
    serviceLine: "audit_support",
    checklist: [
      { type: "quant", label: "Reconciliations pack (bank, VAT, debtors, creditors)" },
      { type: "quant", label: "Fixed asset register & physical verification" },
      { type: "quant", label: "Aging analyses (AR/AP) & provisions" },
      { type: "qual", label: "SoP walkthrough & control gap notes" },
      { type: "qual", label: "Recommendations & management response" },
    ],
  },
  {
    name: "Sector Tax & Regulatory Pack (O&G / Mining / Energy)",
    serviceLine: "sector_specialist",
    checklist: [
      { type: "quant", label: "Production & revenue by month (boe / t / MWh)" },
      { type: "quant", label: "Royalty (5% mining) / rent & PPT (35% O&G) computation" },
      { type: "quant", label: "Capital cost deduction schedule (50% dev / 25% expl)" },
      { type: "quant", label: "Dismantling provision roll-forward (IAS 37)" },
      { type: "qual", label: "Regulatory filings (PDC / MMA / ECGA) status" },
      { type: "qual", label: "JV / unitisation allocation review" },
      { type: "qual", label: "Local content compliance notes" },
    ],
  },
];
