/**
 * Expense classification — determines which purchases belong in the
 * procurement cycle (goods and services you contract for) and which are
 * statutory or regulatory obligations that must never pass through it.
 *
 * The distinction matters for control, not just for the ledger:
 *   Procurement  → PO, goods receipt, three-way match, vendor approval
 *   Statutory    → the amount is fixed by law; a PO would be meaningless
 */

export type ExpenseCategory = {
  code: string;
  label: string;
  /** true = never goes through procurement (no PO / goods receipt) */
  nonProcurement: boolean;
  /** typical GL accounts, most natural first */
  accounts: { accountNo: string; label: string }[];
  guidance: string;
};

export const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  {
    code: "goods",
    label: "Goods & materials",
    nonProcurement: false,
    accounts: [
      { accountNo: "120000", label: "120000 · Inventory – Raw Materials" },
      { accountNo: "121000", label: "121000 · Inventory – Finished Goods" },
      { accountNo: "124000", label: "124000 · Inventory – Spares & Consumables" },
      { accountNo: "500000", label: "500000 · Cost of Goods Sold" },
      { accountNo: "560000", label: "560000 · Office Supplies & Stationery" },
    ],
    guidance:
      "Full procurement cycle applies: raise a PO, receive goods, then invoice. Use the PO route when the items enter stock.",
  },
  {
    code: "service",
    label: "Services & professional fees",
    nonProcurement: false,
    accounts: [
      { accountNo: "514000", label: "514000 · Professional Fees (Audit, Legal)" },
      { accountNo: "563000", label: "563000 · Commission & Agent Fees" },
      { accountNo: "561000", label: "561000 · Travel, Transport & Hospitality" },
      { accountNo: "564000", label: "564000 · Telephone, Internet & Data" },
      { accountNo: "562000", label: "562000 · Marketing & Advertising" },
      { accountNo: "599000", label: "599000 · General & Administrative" },
    ],
    guidance:
      "Procurement applies where you select and contract a provider. No goods receipt — post the supplier invoice directly and choose the expense account.",
  },
  {
    code: "utilities",
    label: "Utilities & telecommunications",
    nonProcurement: true,
    accounts: [
      { accountNo: "540000", label: "540000 · Utilities – Office" },
      { accountNo: "506000", label: "506000 · Fuel, Power & Utilities (Production)" },
      { accountNo: "564000", label: "564000 · Telephone, Internet & Data" },
    ],
    guidance:
      "Statutory tariffs from a regulated utility. Never raise a PO — the amount and the supplier are not negotiable. Post the bill directly.",
  },
  {
    code: "tax",
    label: "Taxes — VAT, CIT, property rate, levies",
    nonProcurement: true,
    accounts: [
      { accountNo: "521000", label: "521000 · Property Rate Expense" },
      { accountNo: "581000", label: "581000 · Royalties – Mining" },
      { accountNo: "582000", label: "582000 · Petroleum Production Tax" },
      { accountNo: "599000", label: "599000 · General & Administrative (other levies)" },
    ],
    guidance:
      "A statutory liability owed to GRA or a local authority. There is no supplier to approve and no price to negotiate — never enters procurement. Pay directly to the authority.",
  },
  {
    code: "payroll",
    label: "Payroll, pensions & social security",
    nonProcurement: true,
    accounts: [
      { accountNo: "510000", label: "510000 · Salaries & Wages" },
      { accountNo: "511000", label: "511000 · SSNIT – Employer Contribution" },
      { accountNo: "512000", label: "512000 · Benefits & Bonuses" },
      { accountNo: "513000", label: "513000 · Recruitment & Training" },
    ],
    guidance:
      "Run it from the Payroll Desk, which computes PAYE, SSNIT and NHIL and posts the whole entry. Never raise a PO for salaries or pension contributions.",
  },
  {
    code: "insurance",
    label: "Insurance premiums",
    nonProcurement: true,
    accounts: [
      { accountNo: "526304", label: "526304 · Insurance" },
    ],
    guidance:
      "A regulated contract with a licensed insurer. Post the premium directly; claim settlement is handled separately under Insurance & Claims.",
  },
  {
    code: "regulatory",
    label: "Regulatory, licences, permits & renewals",
    nonProcurement: true,
    accounts: [
      { accountNo: "599000", label: "599000 · General & Administrative" },
      { accountNo: "140000", label: "140000 · Intangible Assets (capitalise a licence)" },
    ],
    guidance:
      "Fees to a regulator for a licence, permit, annual renewal or filing. Fixed by the regulator — post directly. Capitalise only where the licence creates a lasting right.",
  },
  {
    code: "penalty",
    label: "Penalties, fines & interest on late payment",
    nonProcurement: true,
    accounts: [
      { accountNo: "599000", label: "599000 · General & Administrative (penalties)" },
    ],
    guidance:
      "Never a procurement item. Post directly. These are usually non-deductible for tax — flag them for the tax computation so they are added back.",
  },
  {
    code: "finance",
    label: "Finance costs, bank charges & interest",
    nonProcurement: true,
    accounts: [
      { accountNo: "570000", label: "570000 · Bank Charges & Interest Expense" },
    ],
    guidance:
      "Charged by your bank or lender under the facility agreement. Post directly from the statement — this is where bank reconciliation feeds the ledger.",
  },
];

export const categoryByCode = (code: string): ExpenseCategory =>
  EXPENSE_CATEGORIES.find((c) => c.code === code) ?? EXPENSE_CATEGORIES[0];

/** Categories that must never enter the procurement cycle. */
export const NON_PROCUREMENT = EXPENSE_CATEGORIES.filter((c) => c.nonProcurement).map((c) => c.code);
