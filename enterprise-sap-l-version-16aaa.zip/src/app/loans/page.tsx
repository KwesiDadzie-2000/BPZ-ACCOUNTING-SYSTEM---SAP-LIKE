import { requireWorkspace } from "@/lib/auth";
import { masterData } from "@/lib/reports";
import { listLoans, loanPortfolio } from "@/lib/loans-service";
import { thisPeriod } from "@/lib/periods";
import { PageHeader, Card } from "@/components/ui";
import { LoansDesk } from "@/components/LoansDesk";

export const dynamic = "force-dynamic";

export default async function LoansPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = thisPeriod();

  const [{ ccs }, all, portfolio] = await Promise.all([
    masterData(clientId),
    listLoans(clientId),
    loanPortfolio(clientId),
  ]);

  return (
    <>
      <PageHeader
        kicker={`Treasury · Borrowings · ${ws.client.code} · ${period}`}
        title="Loan Facilities"
        desc="Amortising, interest-only and bullet facilities with full amortisation schedules. Drawdown posts principal and spreads the arrangement fee; each instalment repays interest, fee and principal and posts a balanced journal. The current and non-current liability split follows the contractual repayment profile, and the effective interest rate including fees is disclosed per facility."
      />

      <div className="grid items-start gap-4 xl:grid-cols-[1fr_320px]">
        <LoansDesk
          loans={all.map((l) => {
            const p = portfolio.rows.find((r) => r.id === l.id);
            return {
              id: l.id,
              code: l.code,
              lender: l.lender,
              facilityType: l.facilityType,
              principal: Number(l.principal),
              annualRate: Number(l.annualRate),
              termMonths: l.termMonths,
              outstanding: p?.outstanding ?? Number(l.outstanding),
              currentPortion: p?.currentPortion ?? 0,
              nonCurrentPortion: p?.nonCurrentPortion ?? 0,
              nextPayment: p?.nextPayment ?? 0,
              debtService12m: p?.debtService12m ?? 0,
              effectiveRate: p?.effectiveRate ?? Number(l.annualRate),
              status: l.status,
            };
          })}
          portfolio={portfolio.totals}
          ccOptions={ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }))}
          period={period}
        />

        <div className="space-y-4">
          <Card title="How borrowings are measured">
            <div className="space-y-2.5 text-[12px] leading-relaxed text-mist-400">
              <p>
                <span className="font-bold text-gold-300">Drawdown.</span> Principal is credited to borrowings; the
                arrangement fee is expensed or spread over the period it benefits, never netted silently against the
                proceeds.
              </p>
              <p>
                <span className="font-bold text-gold-300">Each instalment.</span> Interest is charged on the opening
                balance for the period, the fee is recognised, and the residual reduces principal — so the closing
                balance always agrees to the schedule.
              </p>
              <p>
                <span className="font-bold text-gold-300">Moratorium.</span> Deferring principal is not forgiving it:
                interest continues to accrue and is payable during the moratorium period.
              </p>
              <p>
                <span className="font-bold text-gold-300">Effective interest.</span> The rate including fees is shown
                per facility so the true cost of borrowing is visible, not just the coupon.
              </p>
              <p>
                <span className="font-bold text-gold-300">Balance sheet.</span> The portion of each facility
                repayable within twelve months is presented in current liabilities; the remainder in borrowings.
              </p>
            </div>
          </Card>

          <Card title="Lender review questions">
            <ul className="space-y-1.5 text-[12px] leading-relaxed text-mist-500">
              <li>• What is the total debt service due in the next twelve months?</li>
              <li>• How much of the facility is now current rather than non-current?</li>
              <li>• What is the effective cost including arrangement fees?</li>
              <li>• Which facilities still have a moratorium running?</li>
              <li>• Does the schedule agree to the lender&apos;s own statement?</li>
            </ul>
            <p className="mt-2 text-[11.5px] leading-relaxed text-mist-600">
              Every one of these is answered directly from the portfolio table and the per-facility schedule.
            </p>
          </Card>
        </div>
      </div>
    </>
  );
}
