import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { users, taxRates, taxBands, payComponents } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { PageHeader, Card, Stat } from "@/components/ui";
import { UsersPanel, RatesPanel } from "@/components/adminforms";
import { ProfileForm } from "@/components/ProfileForm";
import { SystemReset } from "@/components/SystemReset";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const ws = await requireWorkspace();
  const isOwner = ws.user.role === "owner";
  const isFirmStaff = isOwner || ws.user.clientId === null;

  const allUsers = await db.select().from(users);
  const rates = (await db.select().from(taxRates).orderBy(asc(taxRates.category), asc(taxRates.name))).map((r) => ({
    category: r.category,
    name: r.name,
    rate: Number(r.rate),
    notes: r.notes,
  }));
  const bands = (await db.select().from(taxBands).where(eq(taxBands.tax, "PAYE")).orderBy(asc(taxBands.lower))).map((b) => ({
    lower: Number(b.lower),
    upper: b.upper === null ? null : Number(b.upper),
    rate: Number(b.rate),
  }));
  const components = (await db.select().from(payComponents).orderBy(asc(payComponents.ordinal))).map((c) => ({
    id: c.id,
    name: c.name,
    base: c.base,
    rate: c.rate === null ? null : Number(c.rate),
    side: c.side,
    active: c.active,
  }));

  return (
    <>
      <PageHeader
        kicker={`ADM · Admin & Compliance · ${ws.client.code}`}
        title="Administration"
        desc="Profile, logins & roles for the firm and clients, the Ghana tax schedule (VAT 20% no-cascade, PAYE effective 1 Sep 2026, WHT resident & non-resident, SSNIT, NHIL — all owner-editable), and the system reset."
      />

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Signed in as" value={ws.user.name} sub={`${ws.user.username} · ${ws.user.role}`} />
        <Stat label="Workspaces" value={ws.client.code} sub={ws.client.name} />
        <Stat label="Logins" value={allUsers.length} sub="Firm + client accounts" />
        <Stat label="PAYE schedule" value="1 Sep 2026" sub="6 bands — editable below" />
      </div>

      <Card className="mb-4" title="My Profile" sub="Edit your display name — password changes use the same secure flow">
        <ProfileForm name={ws.user.name} />
      </Card>

      {isFirmStaff && (
        <div className="mb-4">
          <UsersPanel
            initial={allUsers.map((u) => ({
              id: u.id,
              username: u.username,
              name: u.name,
              role: u.role,
              clientId: u.clientId,
              active: u.active,
              mustChangePassword: u.mustChangePassword,
            }))}
          />
        </div>
      )}

      {isOwner && (
        <div className="mb-4">
          <RatesPanel rates={rates} bands={bands} components={components} />
        </div>
      )}

      {isOwner && <SystemReset />}
    </>
  );
}
