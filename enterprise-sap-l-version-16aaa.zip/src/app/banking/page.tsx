import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { bankAccounts, bankLines, journalLines } from "@/db/schema";
import { and, eq, desc, sql } from "drizzle-orm";
import { num } from "@/lib/format";
import { PageHeader, Card, EmptyState, tdCls, thCls, numCls, rowCls, Badge, Stat, ExportLink } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { BankImportForm, BankLineRow } from "@/components/bpforms";

export const dynamic = "force-dynamic";

export default async function BankingPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const accId = sp.acc ? Number(sp.acc) : undefined;

  const accounts = await db.select().from(bankAccounts).where(eq(bankAccounts.clientId, clientId));
  const active = accounts.find((a) => a.id === accId) ?? accounts[0];

  const lines = active
    ? await db.select().from(bankLines).where(eq(bankLines.accountId, active.id)).orderBy(desc(bankLines.id)).limit(60)
    : [];
  const bankTotal = lines.reduce((s, l) => s + Number(l.amount), 0);
  const matched = lines.filter((l) => l.status === "matched").length;

  const journal = active
    ? await db
        .select({
          id: journalLines.id,
          docNo: journalLines.docNo,
          description: journalLines.description,
          period: journalLines.period,
          debit: sql<number>`(${journalLines.debit})::float8`,
          credit: sql<number>`(${journalLines.credit})::float8`,
        })
        .from(journalLines)
        .where(and(eq(journalLines.clientId, clientId), eq(journalLines.account, active.accountCode)))
        .orderBy(desc(journalLines.id))
        .limit(60)
    : [];
  const bookNet = journal.reduce((s, l) => s + l.debit - l.credit, 0);

  return (
    <>
      <PageHeader
        kicker={`BANK · Banking & Reconciliation · ${ws.client.code}`}
        title="Banking"
        desc="Multiple bank accounts in any currency. Import bank statements (CSV), match them to journal lines, edit anything — the reconciliation stays fully auditable."
      >
        <ExportLink sheet="bank" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Bank Accounts" value={accounts.length} sub="This workspace" />
        <Stat label="Statement Lines" value={lines.length} sub={active ? active.name : "—"} />
        <Stat label="Matched" value={`${matched} / ${lines.length}`} sub="Reconciled to the journal" />
        <Stat label="Book Balance (GL)" value={num(bookNet)} sub={`Account ${active?.accountCode ?? "—"} debit − credit`} />
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {accounts.map((a) => (
          <a
            key={a.id}
            href={`/banking?acc=${a.id}`}
            className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
              (active?.id ?? 0) === a.id ? "border-gold-400/60 bg-gold-400/10 text-gold-300" : "border-ink-600 text-mist-400 hover:text-mist-200"
            }`}
          >
            {a.name} <span className="ml-1 font-mono text-[12px] opacity-70">{a.accountCode} · {a.currency}</span>
          </a>
        ))}
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <div className="space-y-4">
          <ActionForm
            action="add_bank_account"
            title="New Bank Account"
            sub="Link the account to its GL code (100000 cash, 101000–104000 banks, 105000 petty)"
            submitLabel="Add account"
            userDefault="bpz"
            fields={[
              { name: "name", label: "Account name", type: "text", placeholder: "e.g. GCB Savings", defaultValue: "" },
              { name: "bank", label: "Bank", type: "text", placeholder: "e.g. GCB Bank Ghana", defaultValue: "" },
              {
                name: "accountCode", label: "GL account", type: "select",
                options: [
                  { value: "100000", label: "100000 · Cash" },
                  { value: "101000", label: "101000 · Bank SCB" },
                  { value: "102000", label: "102000 · Bank GCB" },
                  { value: "103000", label: "103000 · Bank Fidelity" },
                  { value: "104000", label: "104000 · Bank Stanbic" },
                  { value: "105000", label: "105000 · Petty Cash" },
                ],
                defaultValue: "101000",
              },
              {
                name: "currency", label: "Currency", type: "select",
                options: [
                  { value: "GHS", label: "GHS — Cedi" },
                  { value: "USD", label: "USD — Dollar" },
                  { value: "EUR", label: "EUR — Euro" },
                  { value: "GBP", label: "GBP — Pound" },
                ],
                defaultValue: "GHS",
              },
              { name: "opening", label: "Opening balance", type: "number", defaultValue: "0", required: false },
            ]}
          />
          {active && <BankImportForm accounts={accounts.map((a) => ({ value: String(a.id), label: `${a.name} (${a.accountCode})` }))} />}
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Bank Statement" sub={active ? `${active.name} — import or add lines, then match` : "Select an account"} pad={false}>
            {!active ? (
              <div className="p-4"><EmptyState icon="building" title="No bank accounts" body="Add your first bank account to start reconciling." /></div>
            ) : lines.length === 0 ? (
              <div className="p-4"><EmptyState icon="card" title="No statement lines" body="Import a CSV statement (date, description, amount) or add lines manually." /></div>
            ) : (
              <div className="max-h-[560px] space-y-2 overflow-y-auto p-3">
                {lines.map((l) => (
                  <BankLineRow
                    key={l.id}
                    line={l}
                    journalOptions={journal.map((j) => ({ value: String(j.id), label: `${j.docNo} · ${j.description.slice(0, 34)} · ${num(j.debit - j.credit)}` }))}
                  />
                ))}
              </div>
            )}
          </Card>

          <Card title="Journal Side" sub={`Lines posted to GL ${active?.accountCode ?? ""} — the matching target`} pad={false}>
            {journal.length === 0 ? (
              <div className="p-4"><EmptyState icon="journal" title="No journal lines" body="Payments, receipts and fees post here automatically." /></div>
            ) : (
              <div className="max-h-[560px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Doc</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls}>Description</th>
                      <th className={thCls + " text-right"}>Net</th>
                    </tr>
                  </thead>
                  <tbody>
                    {journal.map((j) => (
                      <tr key={j.id} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-gold-300">#{j.id}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{j.period}</span></td>
                        <td className={tdCls}><span className="block max-w-[160px] truncate text-[12px]">{j.description}</span></td>
                        <td className={numCls + (j.debit - j.credit >= 0 ? " text-pos" : " text-neg")}>{num(j.debit - j.credit)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>

      <Card className="mt-4" title="Reconciliation Status" sub="Statement vs books for the selected account">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className="rounded-lg border border-ink-700 bg-ink-900/50 p-3">
            <div className="text-[12px] font-bold uppercase tracking-wider text-mist-600">Statement total</div>
            <div className="font-mono text-lg tabular-nums text-mist-100">{num(bankTotal)}</div>
          </div>
          <div className="rounded-lg border border-ink-700 bg-ink-900/50 p-3">
            <div className="text-[12px] font-bold uppercase tracking-wider text-mist-600">Book net (GL)</div>
            <div className="font-mono text-lg tabular-nums text-mist-100">{num(bookNet)}</div>
          </div>
          <div className="rounded-lg border border-ink-700 bg-ink-900/50 p-3">
            <div className="text-[12px] font-bold uppercase tracking-wider text-mist-600">Difference</div>
            <div className={`font-mono text-lg tabular-nums ${Math.abs(bankTotal - bookNet) < 0.01 ? "text-pos" : "text-neg"}`}>{num(bankTotal - bookNet)}</div>
          </div>
          <div className="flex items-center">
            <Badge tone={Math.abs(bankTotal - bookNet) < 0.01 ? "green" : "amber"}>
              {Math.abs(bankTotal - bookNet) < 0.01 ? "In balance" : "Investigate / match remaining"}
            </Badge>
          </div>
        </div>
      </Card>
    </>
  );
}
