import Link from "next/link";
import { requireWorkspace } from "@/lib/auth";
import { masterData, journalRows, documentLines, journalTotals } from "@/lib/reports";
import { num, fmtDate } from "@/lib/format";
import {
  PageHeader, Card, ModuleTag, Badge, ExportLink, EmptyState, Icon, btn, inputCls, Field, tdCls, thCls, numCls, rowCls,
} from "@/components/ui";

export const dynamic = "force-dynamic";

const MODULES = ["MM", "SD", "HR", "FI-AA", "ADMIN", "FI", "INV"];

export default async function JournalPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const doc = typeof sp.doc === "string" && sp.doc ? sp.doc : undefined;
  const mod = typeof sp.module === "string" && sp.module ? sp.module : undefined;
  const q = typeof sp.q === "string" && sp.q.trim() ? sp.q.trim() : undefined;
  const acc = typeof sp.account === "string" && sp.account ? sp.account : undefined;
  const from = typeof sp.from === "string" && sp.from ? sp.from : undefined;
  const to = typeof sp.to === "string" && sp.to ? sp.to : undefined;

  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { accs } = await masterData(clientId);

  if (doc) {
    const d = await documentLines(clientId, doc);
    return (
      <>
        <PageHeader kicker={`ACDOCA · ${ws.client.code}`} title={`Document ${doc}`}>
          <Link href="/universal-journal" className={btn.ghost}>
            <Icon name="back" size={15} />
            Back to journal
          </Link>
        </PageHeader>
        {d.lines.length === 0 ? (
          <EmptyState icon="doc" title="Document not found" body={`No lines for document ${doc} in this workspace.`} />
        ) : (
          <Card
            pad={false}
            title={
              <span className="flex flex-wrap items-center gap-2.5">
                <span className="font-mono text-base font-semibold">{doc}</span>
                <ModuleTag m={d.lines[0].module} />
                <Badge tone="slate">Type {d.lines[0].docType}</Badge>
                <Badge tone="slate">{d.lines[0].period}</Badge>
                <span className="text-xs font-normal text-mist-500">Posted {fmtDate(d.lines[0].postDate)} by {d.lines[0].createdBy}</span>
                {d.lines[0].reference && <span className="max-w-[280px] truncate text-xs font-normal text-mist-500">ref {d.lines[0].reference}</span>}
                <Badge tone={d.balanced ? "green" : "red"}>
                  <Icon name={d.balanced ? "check" : "x"} size={11} />
                  {d.balanced ? "Balanced" : "Out of balance"}
                </Badge>
              </span>
            }
          >
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px]">
                <thead>
                  <tr className="border-b border-ink-700/70">
                    <th className={thCls}>Account</th>
                    <th className={thCls}>Description</th>
                    <th className={thCls}>BP</th>
                    <th className={thCls}>CC</th>
                    <th className={thCls}>Material</th>
                    <th className={thCls + " text-right"}>Debit</th>
                    <th className={thCls + " text-right"}>Credit</th>
                  </tr>
                </thead>
                <tbody>
                  {d.lines.map((l) => (
                    <tr key={l.id} className={rowCls}>
                      <td className={tdCls}>
                        <span className="font-mono text-[13px] font-semibold text-mist-100">{l.account}</span>
                        <div className="mt-0.5 text-[12.5px] text-mist-600">{l.accDesc}</div>
                      </td>
                      <td className={tdCls}>
                        <span className="block max-w-[280px] truncate text-[13px]">{l.description}</span>
                      </td>
                      <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{l.bp || "—"}</span></td>
                      <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{l.costCenter || "—"}</span></td>
                      <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{l.material || "—"}</span></td>
                      <td className={numCls + " text-aa"}>{l.debit ? num(l.debit) : ""}</td>
                      <td className={numCls + " text-pos"}>{l.credit ? num(l.credit) : ""}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t border-ink-600 bg-ink-900/60">
                    <td className={tdCls + " font-semibold text-mist-100"} colSpan={5}>Document totals</td>
                    <td className={numCls + " font-semibold text-aa"}>{num(d.dr)}</td>
                    <td className={numCls + " font-semibold text-pos"}>{num(d.cr)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </Card>
        )}
      </>
    );
  }

  const rows = await journalRows({ clientId, search: q, module: mod, account: acc, from, to, limit: 500 });
  const totals = await journalTotals(clientId, from, to);
  const shownDr = rows.reduce((s, r) => s + r.debit, 0);
  const shownCr = rows.reduce((s, r) => s + r.credit, 0);

  return (
    <>
      <PageHeader
        kicker={`ACDOCA · Universal Journal · ${ws.client.code}`}
        title="Universal Journal"
        desc="The single source of truth for this workspace. Filter by fiscal period, module, account or text — click any document to see its balanced lines."
      >
        <ExportLink sheet="journal" label="Export .xlsx" />
      </PageHeader>

      <Card className="mb-4" title="Filters" sub="Fiscal period (unlimited), module, account, free text">
        <form method="GET" action="/universal-journal" className="grid gap-3 md:grid-cols-4 lg:grid-cols-6">
          <Field label="From period">
            <input type="month" name="from" defaultValue={from ?? ""} className={inputCls + " font-mono text-xs"} />
          </Field>
          <Field label="To period">
            <input type="month" name="to" defaultValue={to ?? ""} className={inputCls + " font-mono text-xs"} />
          </Field>
          <Field label="Module">
            <select name="module" defaultValue={mod ?? ""} className={inputCls}>
              <option value="">All modules</option>
              {MODULES.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </Field>
          <Field label="Account">
            <select name="account" defaultValue={acc ?? ""} className={inputCls}>
              <option value="">All accounts</option>
              {accs.map((a) => (
                <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.description}</option>
              ))}
            </select>
          </Field>
          <Field label="Search" className="md:col-span-4 lg:col-span-1">
            <input type="text" name="q" defaultValue={q ?? ""} placeholder="Doc, account, BP, desc…" className={inputCls} />
          </Field>
          <div className="flex items-end gap-2">
            <button type="submit" className={btn.gold}><Icon name="search" size={15} /> Filter</button>
            {(q || mod || acc || from || to) && (
              <Link href="/universal-journal" className={btn.ghost}>Clear</Link>
            )}
          </div>
        </form>
      </Card>

      <Card
        title="Journal Lines"
        sub={`${totals.lineCount.toLocaleString()} lines across ${totals.docCount.toLocaleString()} documents`}
        pad={false}
      >
        {rows.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon="journal"
              title={totals.lineCount === 0 ? "The Universal Journal is empty" : "No lines match the filters"}
              body={totals.lineCount === 0 ? "Run the business-day simulation from the dashboard, or post from any department." : "Widen the period range or clear the filters."}
            >
              {totals.lineCount === 0 && (
                <Link href="/" className={btn.gold}><Icon name="bolt" size={15} /> Go to dashboard</Link>
              )}
            </EmptyState>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1020px]">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>Doc No.</th>
                  <th className={thCls}>Period</th>
                  <th className={thCls}>Date</th>
                  <th className={thCls}>Module</th>
                  <th className={thCls}>Type</th>
                  <th className={thCls}>Account</th>
                  <th className={thCls}>BP</th>
                  <th className={thCls}>CC</th>
                  <th className={thCls}>Description</th>
                  <th className={thCls + " text-right"}>Debit</th>
                  <th className={thCls + " text-right"}>Credit</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className={rowCls}>
                    <td className={tdCls}>
                      <Link href={`/universal-journal?doc=${r.docNo}`} className="font-mono text-[12.5px] font-semibold text-gold-300 hover:underline">
                        {r.docNo}
                      </Link>
                    </td>
                    <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{r.period}</span></td>
                    <td className={tdCls + " whitespace-nowrap text-[12.5px] text-mist-500"}>{fmtDate(r.postDate)}</td>
                    <td className={tdCls}><ModuleTag m={r.module} /></td>
                    <td className={tdCls}><span className="font-mono text-[12.5px] text-mist-500">{r.docType}</span></td>
                    <td className={tdCls}>
                      <span className="font-mono text-[12.5px] font-semibold text-mist-100">{r.account}</span>
                      <div className="mt-0.5 max-w-[150px] truncate text-[12.5px] text-mist-600">{r.accDesc}</div>
                    </td>
                    <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{r.bp || "—"}</span></td>
                    <td className={tdCls}><span className="font-mono text-[12px] text-mist-400">{r.costCenter || "—"}</span></td>
                    <td className={tdCls}><span className="block max-w-[220px] truncate text-[13px]">{r.description}</span></td>
                    <td className={numCls + " text-aa"}>{r.debit ? num(r.debit) : ""}</td>
                    <td className={numCls + " text-pos"}>{r.credit ? num(r.credit) : ""}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-ink-600 bg-ink-900/60">
                  <td className={tdCls + " font-semibold text-mist-100"} colSpan={9}>
                    Shown in view {rows.length === 500 ? "(latest 500 lines)" : `(${rows.length} lines)`}
                  </td>
                  <td className={numCls + " font-semibold text-aa"}>{num(shownDr)}</td>
                  <td className={numCls + " font-semibold text-pos"}>{num(shownCr)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
