import { requireWorkspace } from "@/lib/auth";
import { masterData, orderBooks } from "@/lib/reports";
import { db } from "@/db";
import { invoices } from "@/db/schema";
import { and, eq, desc, inArray } from "drizzle-orm";
import { getRates } from "@/lib/fx";
import { num, fmtDate } from "@/lib/format";
import { PageHeader, Card, ExportLink, EmptyState, StatusBadge, tdCls, thCls, numCls, rowCls } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { RowAction } from "@/components/RowAction";
import { InvoiceForm } from "@/components/bpforms";

export const dynamic = "force-dynamic";

export default async function SalesPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { bps, mats } = await masterData(clientId);
  const { sos } = await orderBooks(clientId);
  const customers = bps.filter((b) => b.type === "Customer");
  const rates = await getRates();
  const currencyOptions = rates.map((r) => ({ value: r.code, label: r.code === "GHS" ? "GHS — Cedi (base)" : `${r.code} — ${num(r.rateGhs)}/GHS live` }));

  const { ccs } = await masterData(clientId);
  const ccOptions = ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }));

  const docList = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.clientId, clientId), eq(invoices.direction, "sales")))
    .orderBy(desc(invoices.id))
    .limit(25);

  return (
    <>
      <PageHeader
        kicker={`SD · Sales · ${ws.client.code}`}
        title="Sales"
        desc="Quotes, invoices, credit and debit notes with 20% VAT (no cascading), multi-currency at live mid-rates, and payment receipts (full or partial) through the Payment Desk."
      >
        <ExportLink sheet="invoices" label="Export .xlsx" />
      </PageHeader>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <div className="space-y-4">
          <InvoiceForm
              direction="sales"
              bpOptions={customers.map((c) => ({ value: c.bpNo, label: `${c.bpNo} · ${c.name}` }))}
              currencies={currencyOptions}
              ccOptions={ccOptions}
            />
          <ActionForm
            action="create_so"
            title="Sales Order"
            sub="Order capture — revenue is recognised at invoice"
            submitLabel="Create SO"
            userDefault="sales_user"
            totalFrom={["qty", "price"]}
            fields={[
              { name: "customer", label: "Customer", type: "select", options: customers.map((c) => ({ value: c.bpNo, label: `${c.bpNo} · ${c.name}` })) },
              { name: "material", label: "Material", type: "select", options: mats.map((m) => ({ value: m.materialNo, label: `${m.materialNo} · ${m.description}` })) },
              { name: "qty", label: "Quantity", type: "number", step: "1", min: 1, defaultValue: "20" },
              { name: "price", label: "Unit price", type: "number", step: "0.01", min: 0.01, defaultValue: "500.00" },
            ]}
          />
        </div>

        <div className="space-y-4">
          <Card title="Customer Documents" sub="Quotes → accept to invoice · credit notes reverse · payments via Payment Desk" pad={false}>
            {docList.length === 0 ? (
              <div className="p-4"><EmptyState icon="tag" title="No sales documents" body="Raise a quote or invoice on the left — documents appear here with VAT and FX applied." /></div>
            ) : (
              <div className="max-h-[420px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>No</th>
                      <th className={thCls}>Type</th>
                      <th className={thCls}>BP</th>
                      <th className={thCls + " text-right"}>VAT 20%</th>
                      <th className={thCls + " text-right"}>Total</th>
                      <th className={thCls}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {docList.map((d) => (
                      <tr key={d.id} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12px] font-semibold text-mist-100">{d.no}</span></td>
                        <td className={tdCls}><span className="text-[12px] capitalize text-mist-400">{d.docType === "credit" ? "Credit note" : d.docType === "debit" ? "Debit note" : d.docType}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12.5px]">{d.bp}</span> <span className="font-mono text-[12px] text-mm">{d.currency}</span></td>
                        <td className={numCls}>{num(Number(d.vat))}</td>
                        <td className={numCls + " font-semibold"}>{num(Number(d.total))}</td>
                        <td className={tdCls}>
                          {d.docType === "quote" ? <StatusBadge status="Open" /> : <StatusBadge status={d.status === "paid" ? "Paid" : d.status === "partial" ? "Invoiced" : "Invoiced"} />}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          <Card title="Sales Orders" sub="Open → invoiced → paid" pad={false}>
            {sos.length === 0 ? (
              <div className="p-4"><EmptyState icon="tag" title="No sales orders" body="Create an order on the left, then invoice and receive payment." /></div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[560px]">
                  <thead>
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>SO</th>
                      <th className={thCls}>Customer</th>
                      <th className={thCls + " text-right"}>Total</th>
                      <th className={thCls}>Status</th>
                      <th className={thCls + " text-right"}>Next step</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sos.map((so) => (
                      <tr key={so.soNo} className={rowCls}>
                        <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{so.soNo}</span></td>
                        <td className={tdCls}><span className="font-mono text-[12px]">{so.customer}</span></td>
                        <td className={numCls + " font-semibold"}>{num(Number(so.total))}</td>
                        <td className={tdCls}><StatusBadge status={so.status} /></td>
                        <td className={tdCls}>
                          <div className="flex justify-end">
                            {so.status === "Open" && (
                              <RowAction action="post_sales_invoice" payload={{ soNo: so.soNo }} label="Post invoice" tone="gold" user="sales_user" />
                            )}
                            {so.status === "Invoiced" && (
                              <span className="text-[12.5px] text-mist-500">Collect at Payment Desk</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
