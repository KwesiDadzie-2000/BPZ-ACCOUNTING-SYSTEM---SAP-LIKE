import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { invoices, taxRates } from "@/db/schema";
import { and, eq, desc, inArray } from "drizzle-orm";
import { getRates } from "@/lib/fx";
import { thisPeriod } from "@/lib/periods";
import { num } from "@/lib/format";
import { PageHeader, Card, ExportLink, EmptyState, Badge, Stat } from "@/components/ui";
import { PaymentRow } from "@/components/PaymentRow";

export const dynamic = "force-dynamic";

export default async function PaymentDeskPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = thisPeriod();

  const open = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.clientId, clientId), inArray(invoices.status, ["open", "partial"]), eq(invoices.docType, "invoice")))
    .orderBy(desc(invoices.id))
    .limit(40);

  const [whtRes, whtNr] = await Promise.all([
    db.select().from(taxRates).where(eq(taxRates.category, "WHT_RES")),
    db.select().from(taxRates).where(eq(taxRates.category, "WHT_NR")),
  ]);
  const whtOptions = [...whtRes, ...whtNr].map((r) => ({
    value: r.name,
    label: `${r.name} — ${Number(r.rate)}%${r.category === "WHT_NR" ? " (non-resident)" : ""}`,
    rate: Number(r.rate),
  }));

  const rates = await getRates();
  const rateOf = (c: string) => rates.find((r) => r.code === c)?.rateGhs ?? 1;

  const apOpen = open.filter((i) => i.direction === "purchase" && i.docType === "invoice").reduce((s, i) => s + (Number(i.total) - Number(i.paid)), 0);
  const arOpen = open.filter((i) => i.direction === "sales").reduce((s, i) => s + (Number(i.total) - Number(i.paid)), 0);

  return (
    <>
      <PageHeader
        kicker={`PMT · Payment Desk · ${ws.client.code}`}
        title="Payment Desk"
        desc="All supplier and customer settlements run through here — full or partial payments, resident & non-resident withholding tax on supplier payments, and automatic FX gain/loss when the cedi moves between invoice date and payment date."
      >
        <ExportLink sheet="invoices" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Supplier Invoices Open" value={num(Math.abs(apOpen))} sub="Purchase and statutory bills awaiting (partial) payment" />
        <Stat label="Customer Invoices Open" value={num(arOpen)} sub="Sales invoices awaiting receipt" />
        <Stat label="WHT Schedule" value={`${whtOptions.length} types`} sub="Resident & non-resident — editable in Admin" />
        <Stat label="VAT Position" value="20% (no cascading)" sub="Full input credit claimed on purchases" />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Pay Suppliers (AP)" sub="Bank 101000 out · WHT to 209000 · FX gain/loss on non-GHS invoices">
          {open.filter((i) => i.direction === "purchase").length === 0 ? (
            <EmptyState icon="card" title="No open supplier invoices" body="Raise supplier invoices (or accept quotes) in Procurement — they appear here for payment." />
          ) : (
            <div className="space-y-3">
              {open
                .filter((i) => i.direction === "purchase")
                .sort((a, b) => (a.expenseCategory === "goods" ? 1 : 0) - (b.expenseCategory === "goods" ? 1 : 0))
                .map((i) => (
                <div key={i.id}>
                  {i.expenseCategory && i.expenseCategory !== "goods" && (
                    <div className="mb-1 ml-1 text-[12px] font-semibold text-gold-300">
                      {i.note?.split("·")[0]?.trim() || "Statutory"} — not a procurement item
                    </div>
                  )}
                  <PaymentRow invoice={i} isSales={false} whtOptions={whtOptions} rateNow={rateOf(i.currency)} period={period} />
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card title="Receive from Customers (AR)" sub="Bank 101000 in · FX gain/loss on non-GHS invoices">
          {open.filter((i) => i.direction === "sales").length === 0 ? (
            <EmptyState icon="tag" title="No open customer invoices" body="Invoice your customers in Sales — receipts land here." />
          ) : (
            <div className="space-y-3">
              {open.filter((i) => i.direction === "sales").map((i) => (
                <PaymentRow key={i.id} invoice={i} isSales whtOptions={[]} rateNow={rateOf(i.currency)} period={period} />
              ))}
            </div>
          )}
        </Card>
      </div>

      <Card className="mt-4" title="How settlements post" sub="Balanced entries, automatically">
        <div className="grid gap-4 text-[13px] leading-relaxed text-mist-500 md:grid-cols-2">
          <div>
            <div className="mb-1 font-bold text-mist-300">Supplier payment (with WHT)</div>
            Dr 200000 Accounts payable (gross) · Dr 580000 FX loss if cedi weakened · Cr 101000 Bank (net of WHT) · Cr 209000 WHT payable (resident / non-resident schedule) · Cr 491000 FX gain if cedi strengthened
          </div>
          <div>
            <div className="mb-1 font-bold text-mist-300">Customer receipt</div>
            Dr 101000 Bank (amount received) · Dr 580000 FX loss on revaluation · Cr 110000 Receivables · Cr 491000 FX gain. Partial payments update the invoice to “partial” until settled.
          </div>
        </div>
      </Card>
    </>
  );
}
