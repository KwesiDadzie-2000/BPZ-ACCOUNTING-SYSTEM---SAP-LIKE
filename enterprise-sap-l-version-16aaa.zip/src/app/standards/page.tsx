import { requireWorkspace } from "@/lib/auth";
import { masterData, trialBalance } from "@/lib/reports";
import { listInstruments, ensureProvisionMatrix, eclPortfolio } from "@/lib/ifrs9";
import { listLeases } from "@/lib/ifrs16";
import { listImpairmentTests, listHeldForSale, standardsBalances } from "@/lib/impairment";
import { thisPeriod } from "@/lib/periods";
import { PageHeader, Card, Stat } from "@/components/ui";
import { money } from "@/lib/format";
import { StandardsDesk, type DeskTab } from "@/components/StandardsDesk";

export const dynamic = "force-dynamic";

export default async function StandardsPage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = typeof sp.period === "string" && sp.period ? sp.period : thisPeriod();
  const tab = (typeof sp.tab === "string" ? sp.tab : "ifrs9") as DeskTab;

  // Each standards data source loads independently so a failure in one desk
  // degrades that desk only — the page never becomes unreachable.
  const safe = async <T,>(label: string, fn: () => Promise<T>, fallback: T): Promise<{ data: T; error: string | null }> => {
    try {
      return { data: await fn(), error: null };
    } catch (e) {
      return { data: fallback, error: `${label}: ${e instanceof Error ? e.message : "failed"}` };
    }
  };

  const [
    { data: md, error: eMd },
    { data: instruments, error: eInst },
    { data: matrix, error: eMat },
    { data: leases, error: eLse },
    { data: impairments, error: eImp },
    { data: held, error: eHfs },
    { data: balances, error: eBal },
    { data: ecl, error: eEcl },
    { data: tbRes, error: eTb },
  ] = await Promise.all([
    safe("Master data", () => masterData(clientId), { accs: [], bps: [], ccs: [], mats: [] } as never),
    safe("Instruments", () => listInstruments(clientId), []),
    safe("Provision matrix", () => ensureProvisionMatrix(clientId), []),
    safe("Leases", () => listLeases(clientId), []),
    safe("Impairment tests", () => listImpairmentTests(clientId), []),
    safe("Held for sale", () => listHeldForSale(clientId), []),
    safe("Standards balances", () => standardsBalances(clientId), {
      eclAllowance: 0, eclCharge: 0, eclReversal: 0, rouAssets: 0,
      rouAccumulatedDep: 0, leaseLiability: 0, rouDepreciation: 0,
      leaseInterest: 0, impairmentLoss: 0, impairmentReversal: 0,
      heldForSale: 0, onerousProvision: 0,
    }),
    safe("ECL portfolio", () => eclPortfolio(clientId), {
      instruments: [],
      totals: { grossAmortisedCost: 0, grossFvoci: 0, grossFvtpl: 0, allowance: 0, stage1: 0, stage2: 0, stage3: 0, netCarrying: 0 },
    }),
    safe("Trial balance", () => trialBalance(clientId), { rows: [], totalDr: 0, totalCr: 0, balanced: true }),
  ]);
  const ccs = md.ccs;
  const loadErrors = [eMd, eInst, eMat, eLse, eImp, eHfs, eBal, eEcl, eTb].filter(Boolean) as string[];

  const balanced = tbRes.rows.reduce((s, r) => s + r.bal, 0);

  return (
    <>
      <PageHeader
        kicker={`Standards desk · ${ws.client.code} · ${period}`}
        title="Financial Reporting Standards"
        desc="IFRS 9 financial instruments and expected credit losses, IFRS 16 leases, IAS 36 impairment of assets, and IFRS 5 non-current assets held for sale. Every assessment posts a balanced journal into the same Universal Journal as the transactional modules, so the disclosures below tie to the ledger."
      />

      {loadErrors.length > 0 && (
        <div className="mb-4 rounded-xl border border-aa/40 bg-aa/10 px-4 py-3">
          <div className="text-[12.5px] font-bold text-aa">Some standards data could not be loaded</div>
          <ul className="mt-1 space-y-0.5 text-[12px] text-mist-400">
            {loadErrors.map((e) => (
              <li key={e}>• {e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat
          label="ECL allowance"
          value={money(balances.eclAllowance)}
          sub={`Stages 1/2/3 gross ${money(ecl.totals.stage1)} · ${money(ecl.totals.stage2)} · ${money(ecl.totals.stage3)}`}
          tone={balances.eclAllowance > 0 ? "text-neg" : undefined}
        />
        <Stat
          label="Right-of-use assets"
          value={money(balances.rouAssets)}
          sub={`Lease liability ${money(balances.leaseLiability)}`}
          tone="text-fi"
        />
        <Stat
          label="Impairment losses"
          value={money(balances.impairmentLoss)}
          sub={`Reversals ${money(balances.impairmentReversal)}`}
          tone={balances.impairmentLoss > 0 ? "text-neg" : undefined}
        />
        <Stat
          label="Assets held for sale"
          value={money(balances.heldForSale)}
          sub={`Onerous provision ${money(balances.onerousProvision)}`}
          tone="text-aa"
        />
      </div>

      {Math.abs(balanced) > 0.05 && (
        <div className="mb-4 rounded-xl border border-neg/30 bg-neg/10 px-4 py-3">
          <div className="text-[12.5px] text-neg">
            The trial balance is out by {money(Math.abs(balanced))}. Correct that before relying on any standard&apos;s
            disclosure figures — they are all derived from the same journal.
          </div>
        </div>
      )}

      <StandardsDesk
        initialTab={tab}
        instruments={instruments.map((i) => ({
          id: i.id,
          code: i.code,
          name: i.name,
          category: i.category,
          instrumentType: i.instrumentType,
          carryingAmount: i.carryingAmount,
          eclAllowance: i.eclAllowance,
          stage: i.stage,
          effectiveRate: i.effectiveRate,
          collateralValue: i.collateralValue,
          status: i.status,
        }))}
        leases={leases.map((l) => ({
          id: l.id,
          code: l.code,
          description: l.description,
          lessor: l.lessor,
          termMonths: l.termMonths,
          payment: l.payment,
          discountRate: l.discountRate,
          rouAsset: l.rouAsset,
          leaseLiability: l.leaseLiability,
          accumulatedDepreciation: l.accumulatedDepreciation,
          status: l.status,
        }))}
        impairments={impairments.map((t) => ({
          id: t.id,
          period: t.period,
          unitName: t.unitName,
          carryingAmount: t.carryingAmount,
          valueInUse: t.valueInUse,
          fairValueLessCosts: t.fairValueLessCosts,
          recoverableAmount: t.recoverableAmount,
          impairmentLoss: t.impairmentLoss,
          docNo: t.docNo,
        }))}
        heldForSale={held.map((h) => ({
          id: h.id,
          assetCode: h.assetCode,
          description: h.description,
          carryingAmount: h.carryingAmount,
          fairValueLessCosts: h.fairValueLessCosts,
          writeDown: h.writeDown,
          discontinuedOperation: h.discontinuedOperation,
          status: h.status,
        }))}
        matrix={matrix.map((m) => ({ bucket: m.bucket, label: m.label, pd: Number(m.pd) }))}
        balances={balances}
        ccOptions={ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }))}
        period={period}
      />

      <Card className="mt-4" title="Where each standard is applied in this workspace" sub="Links between the standards desks and the rest of the platform">
        <div className="grid gap-3 md:grid-cols-2">
          {[
            [
              "IFRS 9 → Accounts receivable",
              "Trade receivables use the simplified lifetime approach. The ECL run reads the same AR ageing shown in Reports, applies the provision matrix, and posts the movement against 114000.",
            ],
            [
              "IFRS 9 → Banking",
              "Interest revenue accrues on gross carrying amount for Stages 1 and 2, and on net carrying amount for Stage 3, using each instrument's effective interest rate.",
            ],
            [
              "IFRS 16 → Fixed assets & cash",
              "The right-of-use asset is depreciated and the liability unwinds each month; the payment posts through the same bank account used by the Payment Desk.",
            ],
            [
              "IAS 36 → Fixed asset register",
              "Impairment charges and reversals post against accumulated depreciation (139000), so the register and the impairment schedule always agree.",
            ],
            [
              "IFRS 5 → Fixed asset register",
              "Classification transfers cost and accumulated depreciation out of PPE into 295500, and depreciation ceases immediately.",
            ],
            [
              "IAS 37 → Projects & contracts",
              "Onerous long-term contracts are provisioned from the Projects desk using the same 293000 provision account that impairment reversals release.",
            ],
          ].map(([title, body]) => (
            <div key={title} className="rounded-lg border border-ink-700 bg-ink-900/40 p-3">
              <div className="text-[12.5px] font-bold text-gold-300">{title}</div>
              <div className="mt-1 text-[12px] leading-relaxed text-mist-400">{body}</div>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}
