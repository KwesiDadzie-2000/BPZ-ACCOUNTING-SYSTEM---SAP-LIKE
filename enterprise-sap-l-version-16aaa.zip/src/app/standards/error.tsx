"use client";

import { btn } from "@/components/ui";

export default function StandardsError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="rounded-xl border border-neg/30 bg-neg/10 p-5">
      <h2 className="font-display text-base font-bold text-neg">Standards desk could not render</h2>
      <p className="mt-2 font-mono text-[12.5px] leading-relaxed text-mist-300">{error.message}</p>
      {error.digest && <p className="mt-1 text-[11.5px] text-mist-600">digest {error.digest}</p>}
      <button className={btn.gold + " mt-3"} onClick={reset}>
        Try again
      </button>
    </div>
  );
}
