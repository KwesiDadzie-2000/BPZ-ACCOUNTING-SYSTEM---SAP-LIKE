import { notFound } from "next/navigation";
import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import {
  contractCertificates,
  contracts,
  clients,
  partners,
} from "@/db/schema";
import { and, asc, eq, lt, sql } from "drizzle-orm";
import { num, fmtDate } from "@/lib/format";
import { PrintButton } from "@/components/PrintButton";

export const dynamic = "force-dynamic";

export default async function CertificatePrintPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const cert = (
    await db
      .select()
      .from(contractCertificates)
      .where(
        and(
          eq(contractCertificates.id, Number(id)),
          eq(contractCertificates.clientId, clientId)
        )
      )
  )[0];
  if (!cert) notFound();

  const contract = (
    await db
      .select()
      .from(contracts)
      .where(
        and(
          eq(contracts.id, cert.contractId),
          eq(contracts.clientId, clientId)
        )
      )
  )[0];
  if (!contract) notFound();

  const customer = (
    await db
      .select()
      .from(partners)
      .where(
        and(
          eq(partners.clientId, clientId),
          eq(partners.bpNo, contract.counterparty)
        )
      )
  )[0];
  const entity = (
    await db.select().from(clients).where(eq(clients.id, clientId))
  )[0];
  const prior = await db
    .select({
      gross: sql<number>`coalesce(sum(${contractCertificates.grossValue}),0)::float8`,
      retention: sql<number>`coalesce(sum(${contractCertificates.retention}),0)::float8`,
    })
    .from(contractCertificates)
    .where(
      and(
        eq(contractCertificates.clientId, clientId),
        eq(contractCertificates.contractId, contract.id),
        lt(contractCertificates.id, cert.id),
        sql`${contractCertificates.status} <> 'cancelled'`
      )
    );
  const priorGross = prior[0]?.gross ?? 0;
  const cumulativeGross = priorGross + Number(cert.grossValue);
  const certifiedRemaining = Math.max(0, Number(contract.totalValue) - cumulativeGross);

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 print:px-0 print:py-0">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <a href="/projects" className="text-xs font-semibold text-mist-400 hover:text-mist-100">
          ← Back to Projects &amp; Contracts
        </a>
        <PrintButton label="Print / Save certificate as PDF" />
      </div>

      <div className="rounded-xl border border-slate-300 bg-white p-8 text-slate-900 shadow-sm print:rounded-none print:border-0 print:shadow-none">
        <header className="flex items-start justify-between border-b-2 border-[#f3b600] pb-5">
          <div className="flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-[#082f4f] font-display text-[15px] font-extrabold text-[#f3b600]">
              BPZ
            </span>
            <div>
              <div className="font-display text-lg font-extrabold text-[#082f4f]">
                {entity?.name ?? ws.client.name}
              </div>
              <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#8a5d00]">
                Interim Payment Certificate
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-display text-xl font-extrabold text-[#082f4f]">
              {cert.certNo}
            </div>
            <div className="mt-1 text-xs font-semibold uppercase tracking-wider text-slate-500">
              {cert.status}
            </div>
          </div>
        </header>

        <section className="mt-6 grid grid-cols-2 gap-8 text-[13px]">
          <div>
            <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">
              Employer / customer
            </div>
            <div className="font-semibold text-slate-900">
              {customer?.name ?? contract.counterparty}
            </div>
            <div className="mt-1 font-mono text-xs text-slate-500">
              {contract.counterparty}{customer?.tin ? ` · TIN ${customer.tin}` : ""}
            </div>
          </div>
          <div className="text-right">
            <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">
              Certificate details
            </div>
            <div>Date: {fmtDate(cert.certDate)}</div>
            <div>Period: {cert.period}</div>
            <div>Progress: {Number(cert.cumulativePct).toFixed(1)}%</div>
            <div className="font-mono text-xs text-slate-500">Journal {cert.docNo}</div>
          </div>
        </section>

        <section className="mt-6 rounded-lg border border-slate-200 bg-slate-50 p-4">
          <div className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">
            Contract / project
          </div>
          <div className="mt-1 font-display text-lg font-bold text-[#082f4f]">
            {contract.title || contract.no}
          </div>
          <div className="mt-1 flex flex-wrap gap-x-6 gap-y-1 text-[12.5px] text-slate-600">
            <span>Contract: {contract.no}</span>
            <span>Start: {fmtDate(contract.startDate)}</span>
            <span>End: {fmtDate(contract.endDate)}</span>
            <span>Value: GHS {num(Number(contract.totalValue))}</span>
          </div>
        </section>

        <table className="mt-6 w-full border-collapse text-[13px]">
          <thead>
            <tr className="border-y border-slate-300 bg-slate-50">
              <th className="px-2 py-2 text-left font-bold uppercase tracking-wider text-slate-600">
                Valuation
              </th>
              <th className="px-2 py-2 text-right font-bold uppercase tracking-wider text-slate-600">
                GHS
              </th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-slate-200">
              <td className="px-2 py-2.5">Value certified before this certificate</td>
              <td className="px-2 py-2.5 text-right font-mono tabular-nums">{num(priorGross)}</td>
            </tr>
            <tr className="border-b border-slate-200">
              <td className="px-2 py-2.5 font-semibold">Gross value certified this period</td>
              <td className="px-2 py-2.5 text-right font-mono font-semibold tabular-nums">{num(Number(cert.grossValue))}</td>
            </tr>
            <tr className="border-b border-slate-200">
              <td className="px-2 py-2.5">Retention withheld</td>
              <td className="px-2 py-2.5 text-right font-mono tabular-nums">({num(Number(cert.retention))})</td>
            </tr>
            <tr className="border-t-2 border-[#082f4f]">
              <td className="px-2 py-3 font-display font-extrabold text-[#082f4f]">
                Net amount due on this certificate
              </td>
              <td className="px-2 py-3 text-right font-mono text-[16px] font-extrabold tabular-nums text-[#082f4f]">
                {num(Number(cert.netPayable))}
              </td>
            </tr>
          </tbody>
        </table>

        <div className="mt-4 grid grid-cols-2 gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 text-[12.5px]">
          <div>
            <span className="text-slate-500">Cumulative gross certified: </span>
            <span className="font-mono font-semibold">GHS {num(cumulativeGross)}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-500">Uncertified contract value: </span>
            <span className="font-mono font-semibold">GHS {num(certifiedRemaining)}</span>
          </div>
        </div>

        <section className="mt-10 grid grid-cols-2 gap-12 text-[12px] text-slate-600">
          <div className="border-t border-slate-400 pt-2">
            Prepared / certified by
            <div className="mt-1 font-semibold text-slate-900">Quantity Surveyor / Project Manager</div>
          </div>
          <div className="border-t border-slate-400 pt-2">
            Approved by
            <div className="mt-1 font-semibold text-slate-900">Employer / Client Representative</div>
          </div>
        </section>

        <footer className="mt-8 border-t border-slate-200 pt-4 text-[10.5px] leading-relaxed text-slate-500">
          This interim certificate records work certified under IFRS 15. Revenue recognition is based on the
          contract&apos;s approved measure of progress and is independent of billing. Retention is carried separately
          until it becomes due at practical completion or expiry of the defects-liability period.
        </footer>
      </div>
    </div>
  );
}
