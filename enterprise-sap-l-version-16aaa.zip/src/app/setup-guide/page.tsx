import { requireWorkspace } from "@/lib/auth";
import { PageHeader, Card, Icon } from "@/components/ui";

export const dynamic = "force-dynamic";

const STEPS: { title: string; body: string[] }[] = [
  {
    title: "1 · Sign in & set your password",
    body: [
      "Owner signs in with the credentials you were given. New client logins show a temporary password — they are required to set their own on first login, and afterwards only ever see their own workspace.",
      "Firm staff (admin / accountant / viewer) are added in Admin & Compliance → Logins & Roles. Viewers are read-only; postings are blocked at the engine level.",
    ],
  },
  {
    title: "2 · Create client workspaces",
    body: [
      "Clients → New Client Workspace: name, sector, login username, temporary password and the BPZ service lines to bill monthly.",
      "The sector drives everything sector-specific: tax context (CIT, royalties, PPT, levies), the sector operations workflows and the advisory focus shown in the workspace dashboard.",
      "Each workspace gets its own books, its own document numbering (docs 5000000001+, POs 4500000001+, SOs 3000000001+) — fully independent of the firm and other clients.",
    ],
  },
  {
    title: "3 · Run a client's business day",
    body: [
      "Procurement: PO → receive goods (inventory in, GR/IR) → supplier invoice (AP + 20% recoverable input VAT) → pay at the Payment Desk with resident/non-resident WHT and FX gain/loss.",
      "Sales: quote → accept to invoice (AR + output VAT) → receive payment, full or partial. Credit & debit notes reverse cleanly.",
      "Payroll Desk: editable basic salary per period, automatic PAYE (bands effective 1 Sep 2026), SSNIT T1/T2, NHIL, housing on basic — then release net pay from the bank.",
      "Sector Operations: production orders (raw → WIP → FG) for manufacturing, contract cost/billing for construction, royalty & PPT tax runs for mining, oil & gas and energy.",
    ],
  },
  {
    title: "4 · Banking & reconciliation",
    body: [
      "Add bank accounts (GHS or foreign currency, linked to a GL code). Import a CSV statement (date, description, amount) or add lines by hand.",
      "Match each statement line to its journal line — everything is editable: edit amounts, unmatch, note. The status card shows statement vs book difference live.",
    ],
  },
  {
    title: "5 · Month-end close",
    body: [
      "Month-End Close: run depreciation (per asset class), FX revaluation (IAS 21 at the live mid-rate), review the trial balance, then close the period.",
      "Closed periods reject postings — reopen only for correcting entries (reasons are mandatory on adjustments and reversals and sit in the audit trail).",
      "Fiscal periods are YYYY-MM strings with unlimited years — every module and every report filters by them.",
    ],
  },
  {
    title: "6 · Reports & Excel export",
    body: [
      "Reports: trial balance, IFRS profit or loss + OCI, statement of financial position, cash flow (IAS 7), changes in equity, AP/AR aging, module & cost-center views, stock valuation, BP ledgers, audit trail — all period-filterable.",
      "Every report exports to Excel (.xlsx); the dashboard offers the full multi-sheet workbook.",
    ],
  },
  {
    title: "7 · BPZ services & billing",
    body: [
      "Advisory & Tax: work templates (quantitative + qualitative) per service line, per client, per period — tax computation, VAT return, PAYE pack, IFRS close, business plan, audit support, sector specialist packs.",
      "Generate monthly fees per assigned service line and collect them (posts bank / service revenue). Any owner posting can be charged to the client with the “Charge to client” flag.",
    ],
  },
  {
    title: "8 · Compliance & administration",
    body: [
      "Admin & Compliance: profile, logins & roles (reissue temp passwords, restrict/restore, change roles), the full Ghana tax schedule (VAT 20% no cascade, PAYE bands, WHT resident & non-resident, SSNIT, NHIL) — owner-editable with effective dates — and the system reset.",
      "Live FX: the currency table fetches mid-market rates automatically; payments and month-end revaluation recognise FX gain/loss against it.",
    ],
  },
];

export default async function SetupGuidePage() {
  await requireWorkspace();
  return (
    <>
      <PageHeader
        kicker="Onboarding"
        title="BPZ Platform Setup Guide"
        desc="From first login to fully running client workspaces — the workflow BPZ uses to serve clients across every sector of the Ghanaian economy."
      />
      <div className="grid gap-4 xl:grid-cols-2">
        {STEPS.map((s) => (
          <Card key={s.title} title={s.title}>
            <div className="space-y-2">
              {s.body.map((b) => (
                <p key={b.slice(0, 24)} className="flex items-start gap-2 text-[13px] leading-relaxed text-mist-500">
                  <Icon name="check" size={14} className="mt-0.5 shrink-0 text-gold-400" />
                  {b}
                </p>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </>
  );
}
