import { requireWorkspace } from "@/lib/auth";
import { complianceCalendar } from "@/lib/reports";
import { listRates, listPayeBands } from "@/lib/tax";
import { thisPeriod, periodLabel } from "@/lib/periods";
import { money, num } from "@/lib/format";
import { PageHeader, Card, Badge, Stat, tdCls, thCls, numCls, rowCls, inputCls, Field, btn, Icon, ExportLink } from "@/components/ui";

export const dynamic = "force-dynamic";

const WHT_ROWS = [
  { cat: "Resident — payments to Ghanaian suppliers", rows: [
    ["Goods sold / supplies (other than listed)", "7.5%"],
    ["Services (general)", "5%"],
    ["Professional services (accounting, legal, audit, engineering)", "15%"],
    ["Management & technical services", "15%"],
    ["Commission / agency fees", "15%"],
    ["Royalties", "15%"],
    ["Interest", "15%"],
    ["Dividends (final tax)", "8%"],
    ["Rent — improved property (residential / commercial)", "8%"],
    ["Rent — unimproved land", "15%"],
    ["Winning from games / lottery (final)", "10%"],
  ]},
  { cat: "Non-resident — payments abroad", rows: [
    ["Services supplied in Ghana (any)", "15%"],
    ["Management & technical services", "15%"],
    ["Royalties", "15%"],
    ["Interest", "15%"],
    ["Dividends", "8%"],
    ["Rent", "15%"],
    ["Commission", "15%"],
    ["Entertainers / sportsmen performing in Ghana", "15%"],
    ["Shipping / carriage of goods into Ghana", "15% (on freight)"],
    ["Telecommunications", "15%"],
  ]},
  { cat: "Sector-specific", rows: [
    ["Payments to sub-contractors in construction", "7.5% goods / 5% services"],
    ["Petroleum operations — services & works", "5% – 15% per schedule"],
    ["Mining — payments to contractors", "7.5% goods / 5% services"],
    ["Non-resident e-commerce / digital services", "15%"],
  ]},
];

export default async function CompliancePage({
  searchParams,
}: {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = (await searchParams) ?? {};
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const period = typeof sp.period === "string" && sp.period ? sp.period : thisPeriod();

  const [cal, rates, bands] = await Promise.all([
    complianceCalendar(clientId, period),
    listRates(),
    listPayeBands(),
  ]);

  const vatRates = rates.filter((r) => r.category === "VAT");
  const citRates = rates.filter((r) => r.category === "CIT");
  const whtRes = rates.filter((r) => r.category === "WHT_RES");
  const whtNr = rates.filter((r) => r.category === "WHT_NR");

  return (
    <>
      <PageHeader
        kicker={`Compliance · ${ws.client.code}`}
        title="Tax Compliance & Filing Schedule"
        desc="What to file, when it is due, how much is payable, and the statutory rate behind every figure — computed live from this workspace's Universal Journal. Rates are owner-editable, so when GRA amends a schedule you update it once and every workspace follows."
      >
        <ExportLink sheet="vat" label="Export VAT .xlsx" />
      </PageHeader>

      <Card className="mb-4">
        <form method="GET" action="/compliance" className="flex flex-wrap items-end gap-3">
          <Field label="Filing period (month)">
            <input type="month" name="period" defaultValue={period} className={inputCls + " font-mono text-xs"} />
          </Field>
          <button className={btn.gold}><Icon name="search" size={15} /> Recompute</button>
          <span className="pb-2 text-xs text-mist-500">Showing {periodLabel(period)}</span>
        </form>
      </Card>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Net VAT payable" value={money(cal.vat.netPayable)} sub={`Output ${money(cal.vat.output)} − input ${money(cal.vat.input)}`} tone={cal.vat.netPayable > 0 ? "text-neg" : "text-pos"} />
        <Stat label="PAYE to remit" value={money(cal.paye)} sub="Deducted from employees" />
        <Stat label="WHT to remit" value={money(cal.wht.payable)} sub="Deducted from suppliers" />
        <Stat label="SSNIT + NHIL" value={money(cal.ssnit + cal.nhil)} sub="Statutory social contributions" />
      </div>

      <Card
        className="mb-4"
        title={`Filing checklist — ${periodLabel(period)}`}
        sub="Every statutory return this workspace owes, with its due date, basis of assessment and the authority to file with"
        pad={false}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-ink-700/70">
                <th className={thCls}>Tax</th>
                <th className={thCls}>What to file</th>
                <th className={thCls}>Due</th>
                <th className={thCls}>Amount / basis</th>
                <th className={thCls}>File with</th>
                <th className={thCls}>Status</th>
              </tr>
            </thead>
            <tbody>
              {cal.items.map((it) => (
                <tr key={it.tax} className={rowCls}>
                  <td className={tdCls}><Badge tone={it.tax === "VAT" ? "mm" : it.tax === "PAYE" ? "hr" : it.tax === "WHT" ? "amber" : "sd"}>{it.tax}</Badge></td>
                  <td className={tdCls}><span className="block max-w-[420px] text-[13px] text-mist-300">{it.what}</span></td>
                  <td className={tdCls}><span className="text-[12.5px] text-mist-400">{it.due}</span></td>
                  <td className={numCls + " font-semibold"}>{it.amount === null ? it.basis : money(it.amount)}</td>
                  <td className={tdCls}><span className="text-[12px] text-mist-500">{it.authority}</span></td>
                  <td className={tdCls}>
                    <Badge tone={it.status === "overdue" ? "red" : it.status === "due" ? "amber" : "slate"}>{it.status}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <Card title="VAT computation" sub="Output VAT on sales less recoverable input VAT on purchases — no cascading" pad={false}>
          <table className="w-full">
            <tbody>
              <tr className={rowCls}>
                <td className={tdCls}>Standard-rated sales (net of VAT)</td>
                <td className={numCls}>{num(cal.vat.salesBase)}</td>
              </tr>
              <tr className={rowCls}>
                <td className={tdCls}>Output VAT @ 20%</td>
                <td className={numCls + " text-neg"}>{num(cal.vat.output)}</td>
              </tr>
              <tr className={rowCls}>
                <td className={tdCls}>Purchases / expenses (net of VAT)</td>
                <td className={numCls}>{num(cal.vat.purchasesBase)}</td>
              </tr>
              <tr className={rowCls}>
                <td className={tdCls}>Input VAT recoverable</td>
                <td className={numCls + " text-pos"}>{num(cal.vat.input)}</td>
              </tr>
              <tr className="border-t-2 border-ink-600 bg-ink-900/60">
                <td className={tdCls + " font-display font-bold text-mist-100"}>Net VAT payable to GRA</td>
                <td className={numCls + " font-bold " + (cal.vat.netPayable >= 0 ? "text-neg" : "text-pos")}>{money(cal.vat.netPayable)}</td>
              </tr>
            </tbody>
          </table>
          <div className="px-4 py-3 text-[12.5px] leading-relaxed text-mist-500">
            A negative figure means input VAT exceeds output VAT — carry the credit forward to the next period
            or claim a refund from GRA. Input VAT is only recoverable with valid VAT invoices; entertainment
            expenditure and passenger vehicles carry blocked credits.
          </div>
        </Card>

        <Card title="Withholding tax deduction register" sub="WHT deducted this period, per supplier — the basis for remittance and certificates" pad={false}>
          {cal.wht.byPartner.length === 0 ? (
            <p className="p-4 text-sm text-mist-500">
              No withholding tax has been deducted in {periodLabel(period)}. WHT is applied automatically when you
              pay a supplier invoice at the Payment Desk and select the applicable WHT type.
            </p>
          ) : (
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>Supplier</th>
                  <th className={thCls}>WHT type</th>
                  <th className={thCls + " text-right"}>Deducted</th>
                </tr>
              </thead>
              <tbody>
                {cal.wht.byPartner.map((w, i) => (
                  <tr key={i} className={rowCls}>
                    <td className={tdCls}>
                      <span className="font-mono text-[12px] font-semibold text-mist-100">{w.bp}</span>
                      <div className="mt-0.5 text-[12.5px] text-mist-500">{w.name}</div>
                    </td>
                    <td className={tdCls}><span className="text-[12px] text-mist-400">{w.detail}</span></td>
                    <td className={numCls + " font-semibold text-aa"}>{num(w.deducted)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-ink-600 bg-ink-900/60">
                  <td className={tdCls + " font-semibold"} colSpan={2}>Total to remit by the 15th</td>
                  <td className={numCls + " font-bold text-gold-300"}>{money(cal.wht.payable)}</td>
                </tr>
              </tfoot>
            </table>
          )}
        </Card>
      </div>

      <Card className="mt-4" title="Statutory withholding tax schedule" sub="Apply the correct rate when paying a supplier — resident and non-resident" pad={false}>
        <div className="grid gap-4 p-4 md:grid-cols-2 xl:grid-cols-3">
          {WHT_ROWS.map((g) => (
            <div key={g.cat} className="rounded-lg border border-ink-700 bg-ink-900/40 p-3">
              <div className="mb-2 text-[12.5px] font-bold uppercase tracking-[0.12em] text-gold-400">{g.cat}</div>
              <table className="w-full">
                <tbody>
                  {g.rows.map(([what, rate]) => (
                    <tr key={what} className="border-b border-ink-800/60 last:border-0">
                      <td className="py-1.5 pr-2 text-[12px] leading-snug text-mist-400">{what}</td>
                      <td className="py-1.5 text-right font-mono text-[12px] font-semibold whitespace-nowrap text-mist-200">{rate}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
        <div className="border-t border-ink-700 px-4 py-3 text-[12.5px] leading-relaxed text-mist-500">
          <strong className="text-mist-300">Live rate table (owner-editable):</strong>{" "}
          {whtRes.map((r) => `${r.name} ${r.rate}%`).join(" · ")} | Non-resident: {whtNr.map((r) => `${r.name} ${r.rate}%`).join(" · ")}
          <div className="mt-1.5">
            WHT is a credit for the supplier against their own income tax. You must issue a withholding tax
            certificate and remit by the 15th of the following month. Non-resident WHT is a final tax.
          </div>
        </div>
      </Card>

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <Card title="Other statutory rates in force" sub="Applied automatically to every computation" pad={false}>
          <table className="w-full">
            <tbody>
              {[...vatRates, ...citRates].map((r) => (
                <tr key={r.category + r.name} className={rowCls}>
                  <td className={tdCls}><Badge tone={r.category === "VAT" ? "mm" : "amber"}>{r.category}</Badge></td>
                  <td className={tdCls}><span className="text-[13px] text-mist-300">{r.name}</span></td>
                  <td className={numCls + " font-semibold"}>{num(r.rate)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t border-ink-700 px-4 py-2.5 text-[12.5px] text-mist-500">
            Amend these in <span className="text-mist-300">Admin &amp; Compliance → Tax rates</span>. Changes take
            effect immediately for all future computations across every workspace.
          </div>
        </Card>

        <Card title="PAYE schedule in force" sub={`Effective ${bands[0]?.effectiveFrom ?? "n/a"} — progressive, applied to gross less SSNIT`} pad={false}>
          <table className="w-full">
            <thead>
              <tr className="border-b border-ink-700/70">
                <th className={thCls}>Monthly income from</th>
                <th className={thCls}>To</th>
                <th className={thCls + " text-right"}>Rate</th>
              </tr>
            </thead>
            <tbody>
              {bands.map((b, i) => (
                <tr key={i} className={rowCls}>
                  <td className={numCls}>{num(b.lower)}</td>
                  <td className={numCls}>{b.upper === null ? "and above" : num(b.upper)}</td>
                  <td className={numCls + " font-semibold text-aa"}>{num(b.rate)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t border-ink-700 px-4 py-2.5 text-[12.5px] text-mist-500">
            Statutory reliefs (SSNIT Tier 1 and Tier 2 employee contributions) are deducted before the bands are
            applied, as required. Amend the bands in Admin &amp; Compliance when GRA revises them.
          </div>
        </Card>
      </div>
    </>
  );
}
