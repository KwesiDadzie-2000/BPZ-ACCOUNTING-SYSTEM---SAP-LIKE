import { requireWorkspace } from "@/lib/auth";
import { masterData, journalRows } from "@/lib/reports";
import { EXPENSE_CATEGORIES, NON_PROCUREMENT } from "@/data/expense-categories";
import { num, fmtDate } from "@/lib/format";
import { PageHeader, Card, Badge, ExportLink, EmptyState, tdCls, thCls, numCls, rowCls } from "@/components/ui";
import { ExpenseDesk } from "@/components/ExpenseDesk";

export const dynamic = "force-dynamic";

export default async function ExpensesPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const { bps, ccs } = await masterData(clientId);
  const statutory = EXPENSE_CATEGORIES.filter((c) => c.nonProcurement);
  const history = await journalRows({ clientId, module: "FI", limit: 300 });
  const statDocs = history.filter((r) => r.docType === "STAT");

  return (
    <>
      <PageHeader
        kicker={`FI · Non-procurement expenses · ${ws.client.code}`}
        title="Expense & Statutory Payments"
        desc="Utilities, taxes, pension and social security, insurance premiums, regulatory licences, penalties and finance costs. These are obligations fixed by law, regulation or contract — posting them here charges them straight to the right expense account. They are deliberately excluded from the procurement cycle, so no purchase order or goods receipt is raised for them."
      >
        <ExportLink sheet="journal" label="Export .xlsx" />
      </PageHeader>

      <div className="grid items-start gap-4 xl:grid-cols-[460px_1fr]">
        <ExpenseDesk
          categories={EXPENSE_CATEGORIES}
          partners={bps.map((b) => ({ bpNo: b.bpNo, name: b.name }))}
          ccOptions={ccs.map((c) => ({ value: c.ccCode, label: `${c.ccCode} · ${c.ccName}` }))}
          bankOptions={[]}
        />

        <div className="space-y-4">
          <Card title="What belongs here — and what does not" sub="The control that keeps procurement clean">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="rounded-lg border border-pos/25 bg-pos/5 p-3">
                <div className="mb-1.5 text-[12px] font-bold uppercase tracking-wider text-pos">Post here (no PO)</div>
                <ul className="space-y-1 text-[12.5px] leading-relaxed text-mist-400">
                  {statutory.map((c) => (
                    <li key={c.code}>• {c.label}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-lg border border-ink-700 bg-ink-900/40 p-3">
                <div className="mb-1.5 text-[12px] font-bold uppercase tracking-wider text-gold-300">Use Procurement instead</div>
                <ul className="space-y-1 text-[12.5px] leading-relaxed text-mist-400">
                  <li>• Goods &amp; materials entering stock</li>
                  <li>• Raw materials and production inputs</li>
                  <li>• Services you contract and select</li>
                  <li>• Capital equipment and plant</li>
                </ul>
                <p className="mt-2 text-[11.5px] leading-relaxed text-mist-500">
                  These need supplier approval, a purchase order and a goods receipt so the commitment is controlled
                  before the money is owed.
                </p>
              </div>
            </div>
            <p className="mt-3 text-[12px] leading-relaxed text-mist-500">
              <span className="font-semibold text-mist-300">Penalties and fines are usually non-deductible for tax.</span>{" "}
              Keep them in this category so they are easy to identify and add back in the tax computation.
            </p>
          </Card>

          <Card title="Statutory payment history" sub="Every non-procurement expense posted in this workspace" pad={false}>
            {statDocs.length === 0 ? (
              <div className="p-4">
                <EmptyState
                  icon="shield"
                  title="No statutory payments posted yet"
                  body="Post a utility bill, a GRA payment or an SSNIT remittance using the form on the left — it appears here with the journal document reference."
                />
              </div>
            ) : (
              <div className="max-h-[520px] overflow-y-auto">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-850">
                    <tr className="border-b border-ink-700/70">
                      <th className={thCls}>Doc</th>
                      <th className={thCls}>Period</th>
                      <th className={thCls}>Account</th>
                      <th className={thCls}>Description</th>
                      <th className={thCls + " text-right"}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statDocs.map((r) => (
                      <tr key={r.id} className={rowCls}>
                        <td className={tdCls}>
                          <span className="font-mono text-[12px] text-gold-300">{r.docNo}</span>
                          <div className="mt-0.5 text-[11.5px] text-mist-500">{fmtDate(r.postDate)}</div>
                        </td>
                        <td className={tdCls}><span className="font-mono text-[11.5px] text-mist-500">{r.period}</span></td>
                        <td className={tdCls}>
                          <span className="font-mono text-[12px] font-semibold text-mist-100">{r.account}</span>
                          <div className="mt-0.5 max-w-[150px] truncate text-[11px] text-mist-500">{r.accDesc}</div>
                        </td>
                        <td className={tdCls}><span className="block max-w-[220px] truncate text-[12.5px] text-mist-300">{r.description}</span></td>
                        <td className={numCls + " font-semibold"}>{num(r.debit)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
