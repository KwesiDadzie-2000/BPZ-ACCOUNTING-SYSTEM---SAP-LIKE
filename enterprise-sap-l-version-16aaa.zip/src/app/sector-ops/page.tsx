import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { productionOrders, contracts, clients } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { masterData, stockValuation } from "@/lib/reports";
import { sectorByCode } from "@/data/sectors";
import { num, money } from "@/lib/format";
import { PageHeader, Card, EmptyState, Stat, tdCls, thCls, numCls, rowCls, Badge } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { RowAction } from "@/components/RowAction";

export const dynamic = "force-dynamic";

export default async function SectorOpsPage() {
  const ws = await requireWorkspace();
  const clientId = ws.client.id;
  const client = (await db.select().from(clients).where(eq(clients.id, clientId)))[0];
  const sector = sectorByCode(client?.sector ?? "services");
  const { mats } = await masterData(clientId);
  const stock = await stockValuation(clientId);

  const fgs = mats.filter((m) => m.type === "Finished Good");
  const raws = mats.filter((m) => m.type === "Raw Material");

  const productions = await db.select().from(productionOrders).where(eq(productionOrders.clientId, clientId)).orderBy(desc(productionOrders.id)).limit(20);
  const contractList = await db.select().from(contracts).where(eq(contracts.clientId, clientId)).orderBy(desc(contracts.id)).limit(20);

  const wip = stock.find((s) => s.type === "Work in Progress")?.value ?? 0;
  const wipRaw = stock.filter((s) => s.type === "Raw Material").reduce((x, r) => x + r.value, 0);
  const fgVal = stock.filter((s) => s.type === "Finished Good").reduce((x, r) => x + r.value, 0);

  return (
    <>
      <PageHeader
        kicker={`SECT · Sector Operations · ${sector.name}`}
        title="Sector Operations"
        desc={sector.description + " " + sector.advisoryFocus}
      />

      <div className="mb-4 rounded-xl border border-ink-700 bg-ink-850/70 px-4 py-3 text-[13px] leading-relaxed text-mist-400">
        <span className="font-bold text-gold-300">Sector tax position: </span>
        {sector.corpTaxNote}. {sector.sectorTaxNotes[0]}
      </div>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Raw Material Stock" value={money(wipRaw)} sub="Account 120000" />
        <Stat label="WIP Cost Carried" value={money(wip)} sub="Account 122000 (manufacturing)" />
        <Stat label="Finished Goods" value={money(fgVal)} sub="Account 121000" />
        <Stat label="Active Contracts" value={contractList.filter((c) => c.status === "active").length} sub="Construction / project work" />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {sector.workflow === "manufacturing" && (
          <>
            <ActionForm
              action="start_production"
              title="Start Production Order"
              sub="Issues raw material into WIP — posts 122000 Dr / 120000 Cr at standard cost"
              submitLabel="Issue to WIP"
              userDefault="production"
              periodField
              fields={[
                { name: "material", label: "Finished good", type: "select", options: fgs.map((m) => ({ value: m.materialNo, label: `${m.materialNo} · ${m.description}` })) },
                { name: "rawMaterial", label: "Raw material", type: "select", options: raws.map((m) => ({ value: m.materialNo, label: `${m.materialNo} · ${m.description} @ ${num(Number(m.stdPrice))}` })) },
                { name: "qty", label: "Units to produce", type: "number", step: "1", min: 1, defaultValue: "10" },
                { name: "rawQty", label: "Raw qty to issue", type: "number", step: "0.01", min: 0.01, defaultValue: "100" },
              ]}
            />
            <Card title="Production Orders" sub="Start → complete moves cost from WIP to finished goods" pad={false}>
              {productions.length === 0 ? (
                <div className="p-4"><EmptyState icon="bolt" title="No production yet" body="Start a production order — raw materials issue to WIP at standard cost." /></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[560px]">
                    <thead>
                      <tr className="border-b border-ink-700/70">
                        <th className={thCls}>Order</th>
                        <th className={thCls}>FG</th>
                        <th className={thCls}>Raw</th>
                        <th className={thCls + " text-right"}>Qty</th>
                        <th className={thCls}>Status</th>
                        <th className={thCls + " text-right"}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {productions.map((p) => (
                        <tr key={p.id} className={rowCls}>
                          <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{p.no}</span></td>
                          <td className={tdCls}><span className="font-mono text-[12.5px]">{p.material}</span></td>
                          <td className={tdCls}><span className="font-mono text-[12.5px]">{p.rawMaterial} × {num(Number(p.rawQty))}</span></td>
                          <td className={numCls}>{p.qty}</td>
                          <td className={tdCls}><Badge tone={p.status === "completed" ? "green" : "amber"}>{p.status}</Badge></td>
                          <td className={tdCls}>
                            <div className="flex justify-end">
                              {p.status === "started" && (
                                <RowAction action="complete_production" payload={{ id: p.id }} label="Complete (WIP→FG)" tone="gold" user="production" />
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}

        {(sector.workflow === "construction" || sector.workflow === "standard") && (
          <>
            <ActionForm
              action="save_contract"
              title="Open Contract / Project"
              sub="Tracks value, cost-to-date, billings and % complete (IFRS 15 cost-to-cost)"
              submitLabel="Open contract"
              userDefault="projects"
              fields={[
                { name: "counterparty", label: "Counterparty", type: "text", placeholder: "e.g. GRA / private principal", defaultValue: "" },
                { name: "totalValue", label: "Contract value (GHS)", type: "number", step: "0.01", min: 0.01, defaultValue: "500000.00" },
                { name: "pctComplete", label: "% complete (initial)", type: "number", step: "1", min: 0, defaultValue: "0", required: false },
              ]}
            />
            <Card title="Contracts & Projects" sub="Progressing posts contract costs (505000) and billings (440000) automatically" pad={false}>
              {contractList.length === 0 ? (
                <div className="p-4"><EmptyState icon="building" title="No contracts yet" body="Open a contract to track cost-to-date, billings and % complete." /></div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[620px]">
                    <thead>
                      <tr className="border-b border-ink-700/70">
                        <th className={thCls}>Contract</th>
                        <th className={thCls}>Counterparty</th>
                        <th className={thCls + " text-right"}>Value</th>
                        <th className={thCls + " text-right"}>Cost to date</th>
                        <th className={thCls + " text-right"}>Billed</th>
                        <th className={thCls + " text-right"}>%</th>
                      </tr>
                    </thead>
                    <tbody>
                      {contractList.map((c) => (
                        <tr key={c.id} className={rowCls}>
                          <td className={tdCls}><span className="font-mono text-[12.5px] font-semibold text-mist-100">{c.no}</span></td>
                          <td className={tdCls}><span className="text-[13px]">{c.counterparty}</span></td>
                          <td className={numCls}>{num(Number(c.totalValue))}</td>
                          <td className={numCls + " text-neg"}>{num(Number(c.costToDate))}</td>
                          <td className={numCls + " text-pos"}>{num(Number(c.billed))}</td>
                          <td className={numCls}>{num(Number(c.pctComplete))}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}

        {(sector.workflow === "extraction" || sector.workflow === "financial") && (
          <ActionForm
            action="extraction_tax_run"
            title={sector.workflow === "financial" ? "Regulatory Levy Run" : "Sector Tax Run — Royalties & PPT"}
            sub={sector.workflow === "extraction"
              ? "Accrues royalty (mining 5% / oil rent) and Petroleum Production Tax (35%) on the period production value — posts to 581000/217000 and 582000/218000"
              : "Accrues regulatory levies on the period revenue value"}
            submitLabel="Post sector taxes"
            userDefault="compliance"
            periodField
            fields={[
              { name: "productionValue", label: "Period production / revenue value (GHS)", type: "number", step: "0.01", min: 0.01, defaultValue: "1000000.00" },
              { name: "royaltyRate", label: "Royalty / rent rate %", type: "number", step: "0.1", min: 0, defaultValue: sector.code === "mining" ? "5" : sector.code === "oil_gas" ? "8" : "0", required: false },
              { name: "pptRate", label: "PPT / levy rate %", type: "number", step: "0.1", min: 0, defaultValue: sector.code === "oil_gas" ? "35" : "0", required: false },
            ]}
          />
        )}

        {sector.workflow === "standard" && sector.code !== "construction" && (
          <Card title="Standard-sector workflow" sub="This sector runs on the core departments">
            <p className="text-[13px] leading-relaxed text-mist-500">
              Use Procurement, Sales, Payroll, Inventory, Payment Desk and Banking like every other workspace — the
              sector tailoring lives in the tax schedule, the chart of accounts and the advisory workpapers. BPZ
              advisory focus: {sector.advisoryFocus}
            </p>
          </Card>
        )}
      </div>
    </>
  );
}
