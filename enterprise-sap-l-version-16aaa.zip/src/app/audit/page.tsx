import { requireWorkspace } from "@/lib/auth";
import { listActivity } from "@/lib/security";
import { PageHeader, Card, Badge, Stat, tdCls, thCls, rowCls, ExportLink } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AuditPage() {
  const ws = await requireWorkspace();
  const isOwner = ws.user.role === "owner";
  // Owners see the whole firm's activity; clients see only their own workspace.
  const entries = await listActivity(isOwner ? null : ws.client.id, 300);
  const failures = entries.filter((e) => !e.ok).length;
  const users = new Set(entries.map((e) => e.username)).size;

  return (
    <>
      <PageHeader
        kicker="ADM · Evidence"
        title="System Audit Log"
        desc="Immutable record of every mutating action — who did it, in which workspace, when, and whether it succeeded. Retained for ISA 315 / ISQC 1 evidence and client assurance."
      >
        <ExportLink sheet="activity" label="Export .xlsx" />
      </PageHeader>

      <div className="mb-4 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Recorded events" value={entries.length} sub={isOwner ? "All workspaces (owner view)" : "This workspace"} />
        <Stat label="Distinct users" value={users} sub="Active in the visible window" />
        <Stat label="Failed / blocked" value={failures} tone={failures > 0 ? "text-neg" : "text-pos"} sub="Rejected postings, lockouts, denials" />
        <Stat label="Retention" value="Permanent" sub="Never overwritten or editable" />
      </div>

      <Card title="Activity Feed" sub="Newest first — every posting, login, approval and denial" pad={false}>
        {entries.length === 0 ? (
          <p className="p-6 text-center text-sm text-mist-500">
            No activity recorded yet. Every action you take from now on appears here.
          </p>
        ) : (
          <div className="max-h-[640px] overflow-auto">
            <table className="w-full min-w-[860px]">
              <thead className="sticky top-0 bg-ink-850">
                <tr className="border-b border-ink-700/70">
                  <th className={thCls}>When</th>
                  <th className={thCls}>User</th>
                  <th className={thCls}>Role</th>
                  <th className={thCls}>Workspace</th>
                  <th className={thCls}>Action</th>
                  <th className={thCls}>Outcome</th>
                  <th className={thCls}>Detail</th>
                  <th className={thCls}>IP</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.id} className={rowCls}>
                    <td className={tdCls}>
                      <span className="font-mono text-[12.5px] text-mist-400">
                        {new Date(e.at).toLocaleString("en-GB", { hour12: false })}
                      </span>
                    </td>
                    <td className={tdCls}>
                      <span className="font-mono text-[12px] font-semibold text-mist-100">{e.username}</span>
                    </td>
                    <td className={tdCls}><span className="text-[12.5px] text-mist-500">{e.role || "—"}</span></td>
                    <td className={tdCls}>
                      <Badge tone="slate">{e.workspace || "—"}</Badge>
                    </td>
                    <td className={tdCls}>
                      <span className="font-mono text-[12px] text-gold-300">{e.action}</span>
                    </td>
                    <td className={tdCls}>
                      <Badge tone={e.ok ? "green" : "red"}>{e.ok ? "success" : "blocked"}</Badge>
                    </td>
                    <td className={tdCls}>
                      <span className="block max-w-[320px] truncate text-[12px] text-mist-400">{e.detail || "—"}</span>
                    </td>
                    <td className={tdCls}>
                      <span className="font-mono text-[12px] text-mist-600">{e.ip || "—"}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
