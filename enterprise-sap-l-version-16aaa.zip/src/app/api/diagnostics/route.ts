import { NextResponse } from "next/server";
import { requireApiWorkspace } from "@/lib/auth";
import { clearErrors, recentErrors } from "@/lib/observability";
import { sameOrigin, logActivity, clientIp } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const ws = await requireApiWorkspace();
    const all = await recentErrors(60);
    const errors = ws.user.role === "owner" ? all : all.filter((e) => e.clientId === ws.client.id);
    return NextResponse.json({ ok: true, errors });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}

export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ ok: false, error: "Cross-origin request blocked." }, { status: 403 });
  try {
    const ws = await requireApiWorkspace();
    if (ws.user.role !== "owner") {
      return NextResponse.json({ ok: false, error: "Only the owner can clear the log." }, { status: 403 });
    }
    await clearErrors();
    await logActivity({
      clientId: ws.client.id, workspace: ws.client.code, username: ws.user.username, role: ws.user.role,
      action: "diagnostics_cleared", ok: true, detail: "Error log cleared", ip: clientIp(req),
    });
    return NextResponse.json({ ok: true, message: "Error log cleared." });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
