import { NextResponse } from "next/server";
import { db } from "@/db";
import { journalLines, invoices, partners, assets } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { requireApiWorkspace } from "@/lib/auth";
import { PostingError, post, type JLine } from "@/lib/posting";
import { assertPeriodOpen, thisPeriod } from "@/lib/periods";
import { logActivity, sameOrigin, clientIp } from "@/lib/security";
import { ensureSeed } from "@/lib/init";
import { addEmployee } from "@/lib/employees";

export const dynamic = "force-dynamic";

type AnyRec = Record<string, unknown>;

const s = (v: unknown) => (v === undefined || v === null ? "" : String(v).trim());
const n = (v: unknown) => {
  const x = Number(String(v ?? "").replace(/[, GHC₵\s]/g, ""));
  return Number.isFinite(x) ? x : 0;
};
const r2 = (x: number) => Math.round(x * 100) / 100;

/** Minimal CSV parser supporting quoted fields and embedded commas. */
export function parseCsv(text: string): { header: string[]; rows: AnyRec[] } {
  const lines = text.replace(/\r\n?/g, "\n").split("\n").filter((l) => l.trim().length > 0);
  if (lines.length < 2) return { header: [], rows: [] };

  const parseLine = (line: string): string[] => {
    const out: string[] = [];
    let cur = "";
    let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQ) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') inQ = false;
        else cur += ch;
      } else if (ch === '"') inQ = true;
      else if (ch === ",") { out.push(cur); cur = ""; }
      else cur += ch;
    }
    out.push(cur);
    return out.map((x) => x.trim());
  };

  const header = parseLine(lines[0]).map((h) => h.toLowerCase().replace(/[^a-z0-9]/g, ""));
  const rows: AnyRec[] = [];
  for (const line of lines.slice(1)) {
    const cells = parseLine(line);
    const rec: AnyRec = {};
    header.forEach((h, i) => (rec[h] = cells[i] ?? ""));
    rows.push(rec);
  }
  return { header, rows };
}

/** Maps a trial-balance CSV row onto a journal line. */
function tbRowToLine(row: AnyRec): JLine | null {
  const account = s(row.account || row.accountno || row.code);
  if (!account) return null;
  const dr = n(row.debit || row.dr);
  const cr = n(row.credit || row.cr);
  if (dr === 0 && cr === 0) return null;
  return {
    account,
    desc: s(row.description || row.desc) || "Opening balance",
    cc: s(row.costcenter || row.cc) || undefined,
    bp: s(row.bp || row.partner) || undefined,
    dr: dr || undefined,
    cr: cr || undefined,
  };
}

/**
 * POST /api/migrate
 *  kind = "opening_balances"  → one balanced opening journal
 *  kind = "partners"          → customer / supplier master
 *  kind = "employees"         → payroll master
 *  kind = "assets"            → fixed-asset register (capitalisation)
 */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return NextResponse.json({ ok: false, error: "Cross-origin request blocked." }, { status: 403 });
  try {
    await ensureSeed();
    const ws = await requireApiWorkspace();
    const user = ws.user.username;
    if (ws.user.role === "viewer") throw new PostingError("Viewers are read-only.");

    const ct = req.headers.get("content-type") ?? "";
    let kind = "";
    let period = thisPeriod();
    let csvText = "";
    const body: AnyRec = {};

    if (ct.includes("application/json")) {
      const b = (await req.json()) as AnyRec;
      Object.assign(body, b);
      kind = s(b.kind);
      period = s(b.period) || period;
      csvText = s(b.csv);
    } else {
      const form = await req.formData();
      for (const [k, v] of form.entries()) body[k] = typeof v === "string" ? v : "";
      kind = s(form.get("kind"));
      period = s(form.get("period")) || period;
      const file = form.get("file");
      if (file && typeof file !== "string") csvText = await file.text();
      else csvText = s(form.get("csv"));
    }

    if (!csvText) throw new PostingError("Paste CSV content or attach a .csv file.");

    // Owners migrate on behalf of a client: pass forClientId. Otherwise the
    // import lands in the workspace the owner has selected in the sidebar.
    const clientId =
      ws.user.role === "owner" && Number(body.forClientId) > 0
        ? Number(body.forClientId)
        : ws.client.id;
    if (ws.user.role !== "owner" && clientId !== ws.client.id) {
      throw new PostingError("You can only import into your own workspace.");
    }
    await assertPeriodOpen(clientId, period);

    const { header, rows } = parseCsv(csvText);
    if (!rows.length) throw new PostingError("No data rows found — check the header line is present.");

    const ip = clientIp(req);

    // ---------------- OPENING BALANCES ----------------
    if (kind === "opening_balances") {
      const lines: JLine[] = [];
      const skipped: string[] = [];
      for (const row of rows) {
        const line = tbRowToLine(row);
        if (!line) { skipped.push(s(row.account)); continue; }
        lines.push(line);
      }
      if (lines.length < 2) throw new PostingError("Need at least two non-zero rows to form a balanced entry.");

      const dr = r2(lines.reduce((t, l) => t + (l.dr ?? 0), 0));
      const cr = r2(lines.reduce((t, l) => t + (l.cr ?? 0), 0));
      const diff = r2(dr - cr);

      // Insert a balancing suspense line rather than rejecting, so a client can
      // be onboarded and the difference investigated visibly in the ledger.
      if (Math.abs(diff) >= 0.005) {
        lines.push({
          account: diff > 0 ? "310000" : "320000",
          desc: "Opening balance difference — review and clear",
          dr: diff < 0 ? Math.abs(diff) : undefined,
          cr: diff > 0 ? diff : undefined,
        });
      }

      const doc = await post(db as never, {
        clientId,
        date: new Date().toISOString().slice(0, 10),
        period,
        module: "FI",
        docType: "OPEN",
        user,
        reference: `Opening balances uploaded by ${user}`,
        lines,
      });

      await logActivity({ clientId, workspace: ws.client.code, username: user, role: ws.user.role, action: "migrate_opening", ok: true, detail: `${lines.length} lines, difference ${diff.toFixed(2)}`, ip });

      return NextResponse.json({
        ok: true,
        doc,
        lines: lines.length,
        dr: r2(dr),
        cr: r2(cr),
        balancingLine: Math.abs(diff) >= 0.005 ? r2(Math.abs(diff)) : 0,
        skipped,
        message: `Opening balances posted → doc ${doc}. ${lines.length} lines.${Math.abs(diff) >= 0.005 ? ` A balancing entry of ₵${Math.abs(diff).toFixed(2)} was created — review and clear it.` : ""}`,
      });
    }

    // ---------------- PARTNERS ----------------
    if (kind === "partners") {
      let created = 0;
      const errors: string[] = [];
      for (const row of rows) {
        const bpNo = s(row.code || row.bp || row.bpno || row.no).toUpperCase();
        const name = s(row.name || row.partnername);
        if (!bpNo || !name) { errors.push(`row missing code/name`); continue; }
        const typeRaw = s(row.type).toLowerCase();
        const type = typeRaw.startsWith("c") ? "Customer" : typeRaw.startsWith("v") || typeRaw.startsWith("s") ? "Vendor" : "Employee";
        try {
          const exists = (await db.select({ bpNo: partners.bpNo }).from(partners).where(and(eq(partners.bpNo, bpNo), eq(partners.clientId, clientId))))[0];
          if (exists) continue;
          await db.insert(partners).values({
            bpNo, clientId, name, type,
            tin: s(row.tin || row.taxno), phone: s(row.phone || row.telephone), email: s(row.email),
          });
          created++;
        } catch (e) {
          errors.push(`${bpNo}: ${e instanceof Error ? e.message : "failed"}`);
        }
      }
      await logActivity({ clientId, workspace: ws.client.code, username: user, role: ws.user.role, action: "migrate_partners", ok: true, detail: `${created} partners`, ip });
      return NextResponse.json({ ok: true, created, errors: errors.slice(0, 8), message: `${created} partner(s) imported${errors.length ? `, ${errors.length} row(s) skipped` : ""}.` });
    }

    // ---------------- EMPLOYEES ----------------
    if (kind === "employees") {
      let created = 0;
      const errors: string[] = [];
      for (const row of rows) {
        const name = s(row.name || row.employeename);
        const basic = n(row.basic || row.basicsalary || row.salary);
        if (!name || basic <= 0) { errors.push(`${name || "row"}: name and basic salary required`); continue; }
        try {
          await addEmployee(clientId, {
            name,
            position: s(row.position || row.jobtitle),
            department: s(row.department || row.cc),
            jurisdiction: s(row.jurisdiction) || "GH",
            employmentType: s(row.employmenttype) || "permanent",
            basicSalary: basic,
            allowances: n(row.allowances),
            tin: s(row.tin),
            ssnitNo: s(row.ssnitno || row.ssnit),
            bankAccount: s(row.bankaccount || row.bank),
            email: s(row.email),
            phone: s(row.phone),
            hireDate: s(row.hiredate) || new Date().toISOString().slice(0, 10),
          });
          created++;
        } catch (e) {
          errors.push(`${name}: ${e instanceof Error ? e.message : "failed"}`);
        }
      }
      await logActivity({ clientId, workspace: ws.client.code, username: user, role: ws.user.role, action: "migrate_employees", ok: true, detail: `${created} employees`, ip });
      return NextResponse.json({ ok: true, created, errors: errors.slice(0, 8), message: `${created} employee(s) imported${errors.length ? `, ${errors.length} row(s) skipped` : ""}.` });
    }

    // ---------------- FIXED ASSETS ----------------
    if (kind === "assets") {
      let created = 0;
      let totalCost = 0;
      const errors: string[] = [];
      const lines: JLine[] = [];
      for (const row of rows) {
        const name = s(row.name || row.asset || row.assetname);
        const cost = n(row.cost || row.costprice);
        const classCode = s(row.class || row.classcode || row.category) || "GEN-PLANT";
        if (!name || cost <= 0) { errors.push(`${name || "row"}: name and cost required`); continue; }
        try {
          const exists = (await db.select({ id: assets.id }).from(assets).where(and(eq(assets.clientId, clientId), eq(assets.name, name))))[0];
          if (exists) continue;
          const doc = await post(db as never, {
            clientId,
            date: new Date().toISOString().slice(0, 10),
            period,
            module: "FI-AA",
            docType: "AA",
            user,
            reference: classCode,
            lines: [
              { account: "130000", cc: s(row.cc), desc: `Asset migration – ${name}`, dr: cost },
              { account: "101000", desc: `Asset migration clearing – ${name}`, cr: cost },
            ],
          });
          await db.insert(assets).values({
            clientId, name, classCode, cost: String(cost), accumDep: String(n(row.accumulateddepreciation || row.accumdep)),
            nbv: String(r2(cost - n(row.accumulateddepreciation || row.accumdep))),
            inService: s(row.inservice || row.date) || new Date().toISOString().slice(0, 10),
            cc: s(row.cc) ?? "", active: true, docNo: doc,
          });
          created++;
          totalCost = r2(totalCost + cost);
        } catch (e) {
          errors.push(`${name}: ${e instanceof Error ? e.message : "failed"}`);
        }
      }
      await logActivity({ clientId, workspace: ws.client.code, username: user, role: ws.user.role, action: "migrate_assets", ok: true, detail: `${created} assets, ₵${totalCost}`, ip });
      return NextResponse.json({ ok: true, created, totalCost, errors: errors.slice(0, 8), message: `${created} asset(s) capitalised at ₵${totalCost.toFixed(2)}${errors.length ? `, ${errors.length} row(s) skipped` : ""}.` });
    }

    throw new PostingError('Unknown import kind. Use "opening_balances", "partners", "employees" or "assets".');
  } catch (e) {
    const msg = e instanceof PostingError ? e.message : e instanceof Error ? e.message : "Unexpected error.";
    return NextResponse.json({ ok: false, error: msg }, { status: 400 });
  }
}
