import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { verifyTotp } from "@/lib/totp";
import { generateRecoveryCode, consumeRecoveryCode } from "@/lib/recovery";
import { logActivity, clientIp } from "@/lib/security";
import { hashPassword } from "@/lib/password";
import { passwordProblem } from "@/lib/totp";

export const dynamic = "force-dynamic";

/**
 * 2FA lifecycle: enrolment codes, status, and a one-time recovery code so a
 * lost phone never means a locked-out accounting firm.
 */
export async function POST(req: Request) {
  try {
    const user = await getSessionUser();
    const ip = clientIp(req);
    const body = (await req.json()) as Record<string, unknown>;
    const op = String(body.op ?? "");

    // ---- Recover access when the authenticator is lost ----
    if (op === "recover") {
      const username = String(body.username ?? "").trim().toLowerCase();
      const recovery = String(body.recovery ?? "").trim().toUpperCase();
      const nextPw = String(body.nextPassword ?? "");

      const row = (await db.select().from(users).where(eq(users.username, username)))[0];
      if (!row || !row.active) {
        return NextResponse.json({ ok: false, error: "Invalid recovery details." }, { status: 401 });
      }
      if (!row.recoveryHash || !consumeRecoveryCode(row.recoveryHash, recovery)) {
        await logActivity({ clientId: row.clientId, username, action: "2fa_recovery_failed", ok: false, detail: "Invalid recovery code", ip });
        return NextResponse.json({ ok: false, error: "Invalid or already-used recovery code." }, { status: 401 });
      }
      const problem = passwordProblem(nextPw);
      if (problem) return NextResponse.json({ ok: false, error: problem }, { status: 400 });

      // Recovery consumes the 2FA enrolment so the user re-enrols on a new device.
      await db
        .update(users)
        .set({
          passwordHash: hashPassword(nextPw),
          totpEnabled: false,
          totpSecret: "",
          recoveryHash: "",
          mustChangePassword: false,
          passwordChangedAt: new Date(),
        })
        .where(eq(users.id, row.id));
      await logActivity({
        clientId: row.clientId, username, role: row.role,
        action: "2fa_recovered", ok: true,
        detail: "Access restored via one-time recovery code; 2FA reset for re-enrolment", ip,
      });
      return NextResponse.json({
        ok: true,
        message: "Access restored. Sign in with your new password, then set up two-factor authentication on your new device.",
      });
    }

    const session = await getSessionUser();
    if (!session) return NextResponse.json({ ok: false, error: "Not authenticated." }, { status: 401 });

    // ---- Generate (or regenerate) a recovery code ----
    if (op === "recovery_generate") {
      const row = (await db.select().from(users).where(eq(users.id, session.id)))[0];
      if (!row?.totpEnabled) {
        return NextResponse.json({ ok: false, error: "Enable two-factor authentication first." }, { status: 400 });
      }
      const code = generateRecoveryCode();
      await db.update(users).set({ recoveryHash: code.hash }).where(eq(users.id, session.id));
      await logActivity({
        clientId: session.clientId, username: session.username, role: session.role,
        action: "recovery_code_generated", ok: true, detail: "One-time recovery code issued", ip,
      });
      return NextResponse.json({
        ok: true,
        recoveryCode: code.plain,
        message: "Store this somewhere safe — it is the only way back in if you lose your phone. It is shown once and never again.",
      });
    }

    return NextResponse.json({ ok: false, error: "Unknown operation." }, { status: 400 });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
