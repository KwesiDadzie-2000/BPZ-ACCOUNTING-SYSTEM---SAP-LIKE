import { NextResponse } from "next/server";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";
import { verifyTotp } from "@/lib/totp";
import { SESSION_COOKIE } from "@/lib/cookie-names";
import { logActivity, clientIp } from "@/lib/security";

export const dynamic = "force-dynamic";

const MAX_AGE = 7 * 24 * 60 * 60;

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { ticket?: string; code?: string };
    const ticket = String(body.ticket ?? "");
    const code = String(body.code ?? "");
    if (!ticket || !code) {
      return NextResponse.json({ ok: false, error: "Enter the 6-digit code from your authenticator." }, { status: 400 });
    }

    const rows = await db
      .select({ sessionId: sessions.id, userId: users.id, username: users.username, name: users.name, role: users.role, clientId: users.clientId, secret: users.totpSecret })
      .from(sessions)
      .innerJoin(users, eq(sessions.userId, users.id))
      .where(and(eq(sessions.id, ticket), eq(sessions.pending, true), gt(sessions.expiresAt, new Date())));
    const r = rows[0];
    if (!r) {
      return NextResponse.json({ ok: false, error: "This sign-in attempt expired. Please sign in again." }, { status: 401 });
    }
    if (!verifyTotp(r.secret, code)) {
      await logActivity({ clientId: r.clientId, username: r.username, role: r.role, action: "2fa_failed", ok: false, detail: "Invalid authenticator code", ip: clientIp(req) });
      return NextResponse.json({ ok: false, error: "That code is not valid. Codes change every 30 seconds." }, { status: 401 });
    }

    await db.update(sessions).set({ pending: false, expiresAt: new Date(Date.now() + MAX_AGE * 1000) }).where(eq(sessions.id, ticket));
    await logActivity({ clientId: r.clientId, username: r.username, role: r.role, action: "2fa_success", ok: true, detail: `${r.name} passed second factor`, ip: clientIp(req) });

    const res = NextResponse.json({ ok: true, name: r.name, role: r.role });
    res.cookies.set(SESSION_COOKIE, ticket, {
      httpOnly: true, sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/", maxAge: MAX_AGE,
    });
    return res;
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
