import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSessionUser, requireSessionUser } from "@/lib/auth";
import { verifyPassword, hashPassword } from "@/lib/password";
import { passwordProblem } from "@/lib/totp";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const user = await requireSessionUser();
    const body = (await req.json()) as { current?: string; next?: string };
    if (!body.current || !body.next) return NextResponse.json({ ok: false, error: "Current and new password are required." }, { status: 400 });
    const problem = passwordProblem(body.next);
    if (problem) return NextResponse.json({ ok: false, error: problem }, { status: 400 });
    const row = (await db.select().from(users).where(eq(users.id, user.id)))[0];
    if (!row || !verifyPassword(body.current, row.passwordHash)) {
      return NextResponse.json({ ok: false, error: "Current password is incorrect." }, { status: 400 });
    }
    await db.update(users).set({ passwordHash: hashPassword(body.next), mustChangePassword: false }).where(eq(users.id, user.id));
    return NextResponse.json({ ok: true, message: "Password updated." });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Unexpected error." }, { status: 400 });
  }
}
