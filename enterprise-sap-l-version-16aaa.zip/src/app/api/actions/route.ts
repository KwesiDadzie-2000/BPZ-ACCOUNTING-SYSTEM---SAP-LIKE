import { ensureSeed } from "@/lib/init";
import { requireApiWorkspace } from "@/lib/auth";
import { logActivity, sameOrigin, clientIp } from "@/lib/security";
import {
  PostingError,
  createPO,
  receiveGoods,
  postVendorInvoice,
  createSO,
  postSalesInvoice,
  receivePayment,
  simulateDay,
  resetData,
} from "@/lib/posting";
import {
  postChecked,
  reverseDocument,
  addAsset,
  runDepreciation,
  runPayrollGhana,
  payInvoice,
  stockMovement,
  revaluateFx,
  chargeClientFee,
  collectFee,
  type JLine,
} from "@/lib/engine";
import { runPayroll, runBatchPayroll } from "@/lib/engine";
import { addEmployee, updateEmployee, terminateEmployee } from "@/lib/employees";
import { closePeriod, openPeriod, thisPeriod } from "@/lib/periods";
import {
  createContract,
  recordContractCost,
  recogniseRevenue,
  raiseCertificate,
  receiveCertificatePayment,
  getContract,
  reviseContract,
  releaseRetention,
} from "@/lib/contracts";
import { getRate, refreshLiveRates } from "@/lib/fx";
import { NON_PROCUREMENT, categoryByCode } from "@/data/expense-categories";
import { report } from "@/lib/observability";
import {
  addInstrument,
  assessInstrumentEcl,
  assessTradeReceivableEcl,
  updateProvisionMatrix,
  listInstruments,
  CATEGORIES,
} from "@/lib/ifrs9";
import { addLease, runLeaseMonth, listLeases } from "@/lib/ifrs16";
import {
  drawdownLoan,
  repayLoan,
  listLoans,
  listSchedule,
  loanPortfolio,
} from "@/lib/loans-service";
import {
  runImpairmentTest,
  allocateCguLoss,
  classifyHeldForSale,
  completeHeldForSaleDisposal,
} from "@/lib/impairment";
import { db } from "@/db";
import {
  invoices,
  bankAccounts,
  bankLines,
  productionOrders,
  contracts,
  budgetScenarios,
  budgetLines,
  engagements,
  feeInvoices,
  payrollRuns,
  journalLines,
  materials,
  clients,
  partners,
} from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

type AnyInput = Record<string, unknown>;
const str = (v: unknown) => (v === undefined || v === null ? undefined : String(v).trim() || undefined);
const num = (v: unknown) => (v === undefined || v === null || v === "" ? 0 : Number(v));
const r2 = (n: number) => Math.round(n * 100) / 100;

const DOC_PREFIX: Record<string, Record<string, string>> = {
  sales: { quote: "EST", invoice: "INV", credit: "CN", debit: "DN" },
  purchase: { quote: "PQT", invoice: "PIN", credit: "PCN", debit: "PDN" },
};

async function nextDocNo(clientId: number, direction: string, docType: string): Promise<string> {
  const rows = await db
    .select({ m: sql<number>`coalesce(max(${invoices.id})::int, 0)::int` })
    .from(invoices)
    .where(and(eq(invoices.clientId, clientId), eq(invoices.direction, direction)));
  const n = (rows[0]?.m ?? 0) + 1;
  return `${DOC_PREFIX[direction][docType]}-${String(n).padStart(4, "0")}`;
}

async function nextDocNoTx(q: { select: typeof db.select }, clientId: number, direction: string, docType: string): Promise<string> {
  const rows = await (q as unknown as typeof db)
    .select({ m: sql<number>`coalesce(max(${invoices.id})::int, 0)::int` })
    .from(invoices)
    .where(and(eq(invoices.clientId, clientId), eq(invoices.direction, direction)));
  const n = (rows[0]?.m ?? 0) + 1;
  return `${DOC_PREFIX[direction][docType]}-${String(n).padStart(4, "0")}`;
}

// Invoice posting inside a transaction (asserts the period is open first)
async function postInvoiceDocTx(
  q: unknown | null,
  clientId: number,
  p: { no: string; bp: string; direction: string; docType: string; subtotal: number; vat: number; period: string; user?: string; expenseAccount?: string; cc?: string; expenseCategory?: string }
): Promise<string> {
  const { assertPeriodOpen } = await import("@/lib/periods");
  await assertPeriodOpen(clientId, p.period);
  const credit = p.docType === "credit";
  const sales = p.direction === "sales";
  const s = credit ? -1 : 1;
  const lines: JLine[] = [];
  if (sales) {
    lines.push({ account: "110000", bp: p.bp, desc: `${p.no} – ${p.bp}`, dr: s * (p.subtotal + p.vat) });
    if (p.vat) lines.push({ account: "211000", bp: p.bp, desc: `${p.no} output VAT @ 20%`, cr: s * p.vat });
    lines.push({ account: "400000", bp: p.bp, cc: p.cc, desc: `${p.no} revenue`, cr: s * p.subtotal });
  } else {
    // Supplier invoice: recognise the cost, recover the input VAT, and CREDIT
    // the supplier (a liability). Debiting AP here made suppliers look like debtors.
    lines.push({ account: p.expenseAccount || "599000", bp: p.bp, cc: p.cc, desc: `${p.no} ${p.expenseCategory && p.expenseCategory !== "goods" ? p.expenseCategory + " – " : ""}purchase – ${p.bp}`, dr: s * p.subtotal });
    if (p.vat) lines.push({ account: "112000", bp: p.bp, desc: `${p.no} input VAT (recoverable)`, dr: s * p.vat });
    lines.push({ account: "200000", bp: p.bp, desc: `${p.no} payable – ${p.bp}`, cr: s * (p.subtotal + p.vat) });
  }
  const { post } = await import("@/lib/posting");
  return post((q ?? db) as never, {
    clientId,
    date: new Date().toISOString().slice(0, 10),
    period: p.period,
    module: sales ? "SD" : "MM",
    docType: credit ? "CN" : sales ? "RV" : "RE",
    user: p.user,
    reference: p.no,
    lines,
  });
}


export async function POST(req: Request) {
  // CSRF defence: cross-origin browser posts are rejected before any processing.
  if (!sameOrigin(req)) {
    return Response.json({ ok: false, error: "Cross-origin request blocked." }, { status: 403 });
  }
  let body: AnyInput;
  try {
    body = (await req.json()) as AnyInput;
  } catch {
    return Response.json({ ok: false, error: "Request body must be valid JSON." }, { status: 400 });
  }

  const ctx: AuditCtx = { clientId: null, workspace: "", username: "unauthenticated", role: "", detail: "" };
  const res = await handleAction(body, ctx);
  // Immutable evidence trail — every mutating call is logged with its outcome.
  await logActivity({
    clientId: ctx.clientId, workspace: ctx.workspace, username: ctx.username, role: ctx.role,
    action: String(body.action ?? "unknown"), ok: res.status < 400,
    detail: ctx.detail, ip: clientIp(req),
  });
  return res;
}

export type AuditCtx = { clientId: number | null; workspace: string; username: string; role: string; detail: string };

async function handleAction(body: AnyInput, ctx: AuditCtx): Promise<Response> {
  try {
    await ensureSeed();
    const ws = await requireApiWorkspace();
    const clientId = ws.client.id;
    const user = ws.user.username;
    const { action } = body;
    const i = body;

    // Populate the audit context for this request's evidence-trail entry.
    ctx.clientId = clientId;
    ctx.workspace = ws.client.code;
    ctx.username = ws.user.username;
    ctx.role = ws.user.role;

    if (ws.user.role === "viewer") {
      throw new PostingError("Viewers are read-only — this action is blocked by your role restriction.");
    }

    switch (action) {
      // ---- core MM / SD ----
      case "create_po":
        return Response.json({ ok: true, ...(await createPO({ clientId, vendor: str(i.vendor) ?? "", material: str(i.material) ?? "", qty: num(i.qty), price: num(i.price), cc: str(i.cc), user })) });
      case "receive_goods":
        return Response.json({ ok: true, ...(await receiveGoods({ clientId, poNo: str(i.poNo) ?? "", user })) });
      case "post_vendor_invoice":
        return Response.json({ ok: true, ...(await postVendorInvoice({ clientId, poNo: str(i.poNo) ?? "", user })) });
      case "create_so":
        return Response.json({ ok: true, ...(await createSO({ clientId, customer: str(i.customer) ?? "", material: str(i.material) ?? "", qty: num(i.qty), price: num(i.price), user })) });
      case "post_sales_invoice":
        return Response.json({ ok: true, ...(await postSalesInvoice({ clientId, soNo: str(i.soNo) ?? "", user })) });
      case "receive_payment":
        return Response.json({ ok: true, ...(await receivePayment({ clientId, soNo: str(i.soNo) ?? "", user })) });
      case "simulate":
        // Seeds 13 demonstration documents — must never run on a live client's books.
        if (ws.user.role !== "owner")
          throw new PostingError(
            "The demonstration simulation is restricted to BPZ owner accounts. It would post sample documents into live books."
          );
        return Response.json({ ok: true, ...(await simulateDay(clientId)) });
      case "reset":
        if (ws.user.role !== "owner")
          throw new PostingError("Only the owner can clear a workspace's books.");
        return Response.json({ ok: true, ...(await resetData(clientId)) });

      // ---- accounting: journal / openings / prepayments / adjustments / reversals ----
      case "manual_journal": {
        const raw = Array.isArray(i.lines) ? (i.lines as AnyInput[]) : [];
        const lines: JLine[] = raw.map((l) => ({
          account: str(l.account) ?? "", cc: str(l.cc), desc: str(l.desc) ?? "",
          dr: l.dr ? num(l.dr) : 0, cr: l.cr ? num(l.cr) : 0,
        }));
        const cat = str(i.docCategory) ?? "SA";
        if (!["SA", "OPEN", "PREPAY", "ADJ"].includes(cat)) throw new PostingError("Unknown document category.");
        const reason = str(i.reason) ?? "";
        if ((cat === "ADJ" || cat === "OPEN") && !reason) throw new PostingError("Opening balances and adjustments require a reason.");
        const doc = await postChecked(clientId, {
          period: str(i.period) ?? thisPeriod(), module: "FI", docType: cat, user,
          reference: str(i.reference) ?? reason, lines,
        });
        const label = cat === "SA" ? "Journal" : cat === "OPEN" ? "Opening balance" : cat === "PREPAY" ? "Prepayment" : "Adjustment";
        return Response.json({ ok: true, doc, message: `${label} posted → doc ${doc}.` });
      }
      case "reverse_document":
        return Response.json({ ok: true, ...(await reverseDocument(clientId, str(i.docNo) ?? "", str(i.reason) ?? "", str(i.period) ?? thisPeriod(), user)) });

      // ---- fixed assets ----
      case "add_asset":
        return Response.json({ ok: true, ...(await addAsset(clientId, { name: str(i.name) ?? "", classCode: str(i.classCode) ?? "", cost: num(i.cost), inService: str(i.inService) ?? new Date().toISOString().slice(0, 10), cc: str(i.cc), period: str(i.period), user })) });
      case "depreciation_run":
        return Response.json({ ok: true, ...(await runDepreciation(clientId, str(i.period) ?? thisPeriod(), user)) });

      // ---- payroll (Ghana statutory) ----
      // ---- business partner master (suppliers, customers, employees) ----
      case "create_partner": {
        const bpNo = (str(i.bpNo) ?? "").toUpperCase();
        const name = str(i.name) ?? "";
        const type = str(i.type) ?? "";
        if (!/^[A-Z0-9_-]{2,20}$/.test(bpNo))
          throw new PostingError("Partner code must be 2–20 characters (letters, numbers, dash, underscore).");
        if (name.length < 2) throw new PostingError("Partner name is required.");
        if (!["Vendor", "Customer", "Employee"].includes(type))
          throw new PostingError("Choose Vendor, Customer or Employee.");
        const exists = await db
          .select({ bpNo: partners.bpNo })
          .from(partners)
          .where(and(eq(partners.bpNo, bpNo), eq(partners.clientId, clientId)));
        if (exists.length) throw new PostingError(`Partner "${bpNo}" already exists in this workspace.`);
        await db.insert(partners).values({
          bpNo, clientId, name,
          tin: str(i.tin) ?? "", phone: str(i.phone) ?? "", email: str(i.email) ?? "",
          type,
        });
        return Response.json({ ok: true, message: `${type} "${name}" (${bpNo}) added to this workspace's master data.` });
      }
      case "update_partner": {
        const bpNo = (str(i.bpNo) ?? "").toUpperCase();
        const row = (
          await db.select().from(partners).where(and(eq(partners.bpNo, bpNo), eq(partners.clientId, clientId)))
        )[0];
        if (!row) throw new PostingError("Partner not found in this workspace.");
        await db
          .update(partners)
          .set({
            name: str(i.name) ?? row.name,
            tin: str(i.tin) ?? row.tin,
            phone: str(i.phone) ?? row.phone,
            email: str(i.email) ?? row.email,
            type: ["Vendor", "Customer", "Employee"].includes(str(i.type) ?? "") ? str(i.type)! : row.type,
          })
          .where(and(eq(partners.bpNo, bpNo), eq(partners.clientId, clientId)));
        return Response.json({ ok: true, message: `${bpNo} updated.` });
      }

      // ---- employee master (add at any time) ----
      case "add_employee": {
        const emp = await addEmployee(clientId, i);
        return Response.json({ ok: true, employee: emp, message: `${emp.name} (${emp.code}) added to the payroll master — basic ${emp.basicSalary.toLocaleString()} ${emp.currency}, ${emp.jurisdiction}.` });
      }
      case "update_employee": {
        const emp = await updateEmployee(clientId, num(i.employeeId), i);
        return Response.json({ ok: true, employee: emp, message: `${emp.name} updated — basic ${emp.basicSalary.toLocaleString()} ${emp.currency}, status ${emp.status}. Affects future runs only.` });
      }
      case "terminate_employee": {
        const emp = await terminateEmployee(clientId, num(i.employeeId), str(i.endDate) ?? "");
        return Response.json({ ok: true, employee: emp, message: `${emp.name} (${emp.code}) left on ${emp.endDate}. History preserved, future runs blocked.` });
      }
      case "run_payroll_gh":
        return Response.json({ ok: true, ...(await runPayrollGhana(clientId, { bpNo: str(i.bpNo) ?? "", period: str(i.period) ?? thisPeriod(), basic: num(i.basic), allowance: num(i.allowance), cc: str(i.cc), user })) });
      case "run_payroll": {
        const r = await runPayroll(clientId, { employeeId: num(i.employeeId) || undefined, code: str(i.code) ?? undefined, period: str(i.period) ?? thisPeriod(), basic: num(i.basic) || undefined, allowance: num(i.allowance) || undefined, cc: str(i.cc), user });
        return Response.json({
          ok: true, doc: r.doc, gross: r.gross, paye: r.incomeTax, pension: r.pension, net: r.net, employer: r.employerCost, breakdown: r.breakdown,
          message: `${r.employee.name} (${r.employee.jurisdiction}): gross ${r.gross.toFixed(2)} → net ${r.net.toFixed(2)} → doc ${r.doc}.`,
        });
      }
      case "run_batch_payroll":
        return Response.json({ ok: true, ...(await runBatchPayroll(clientId, { period: str(i.period) ?? thisPeriod(), user })) });
      case "pay_payroll": {
        const run = (await db.select().from(payrollRuns).where(eq(payrollRuns.id, num(i.runId))))[0];
        if (!run || run.clientId !== clientId) throw new PostingError("Payroll run not found.");
        const outstanding = r2(Number(run.net) - Number(run.paid));
        const amount = num(i.amount) || outstanding;
        if (amount <= 0) throw new PostingError("Nothing to pay.");
        if (amount > outstanding + 0.009) throw new PostingError(`Amount exceeds outstanding net pay (₵${outstanding.toFixed(2)}).`);
        const doc = await postChecked(clientId, {
          period: str(i.period) ?? thisPeriod(), module: "HR", docType: "PY", user,
          reference: `Salary payment ${run.bpNo} ${run.period}${amount < outstanding - 0.009 ? " (partial)" : ""}`,
          lines: [
            { account: "205000", bp: run.bpNo, desc: `Net pay released – ${run.bpNo}`, dr: amount },
            { account: "101000", desc: `Bank payment – ${run.bpNo}`, cr: amount },
          ],
        });
        await db.update(payrollRuns).set({ paid: String(r2(Number(run.paid) + amount)) }).where(eq(payrollRuns.id, run.id));
        return Response.json({ ok: true, doc, message: `₵${amount.toFixed(2)} paid to ${run.bpNo} → doc ${doc}.` });
      }

      // ---- invoices: quote / invoice / credit note / debit note ----
      case "save_invoice": {
        const direction = str(i.direction) === "purchase" ? "purchase" : "sales";
        const expenseAccount = str(i.expenseAccount) ?? "";
        const invoiceCC = str(i.cc) ?? "";
        // Classification drives the workflow: statutory expenses never enter the
        // procurement cycle, so they cannot be raised as purchase orders.
        const expenseCategory = str(i.expenseCategory) ?? "goods";
        if (!["goods","service","utilities","tax","payroll","insurance","regulatory","penalty","finance"].includes(expenseCategory))
          throw new PostingError("Unknown expense category.");
        const docType = ["quote", "invoice", "credit", "debit"].includes(str(i.docType) ?? "") ? (str(i.docType) as "quote" | "invoice" | "credit" | "debit") : "quote";
        const bp = str(i.bp) ?? "";
        if (!bp) throw new PostingError("Select a customer or supplier.");
        // Tenant isolation: the partner must exist in THIS workspace. Without this
        // check an invoice could silently book to another client's supplier.
        const partnerRow = (
          await db.select().from(partners).where(and(eq(partners.bpNo, bp), eq(partners.clientId, clientId)))
        )[0];
        if (!partnerRow)
          throw new PostingError(
            `"${bp}" is not in this workspace's master data. Add the customer or supplier before invoicing them.`
          );
        const currency = str(i.currency) ?? "GHS";
        const subtotal = num(i.subtotal);
        if (subtotal <= 0) throw new PostingError("Enter a positive amount.");
        const vatOn = i.vat !== false;
        const rate = await getRate(currency);
        const vat = r2(subtotal * 0.2);
        const totalSigned = docType === "credit" ? -r2(subtotal + (vatOn ? vat : 0)) : r2(subtotal + (vatOn ? vat : 0));
        const period = str(i.period) ?? thisPeriod();

        // Atomic: the invoice row and its journal entry commit together.
        const result = await db.transaction(async (tx) => {
          const no = await nextDocNoTx(tx as never, clientId, direction, docType);
          const created = await (tx as never as typeof db).insert(invoices).values({
            clientId, direction, docType, no, bp, currency, rate: String(rate),
            subtotal: String(subtotal), vat: String(vatOn ? vat : 0), total: String(totalSigned),
            status: "open", period, note: str(i.note) ?? "",
          }).returning({ id: invoices.id });
          const invId = created[0].id;
          let doc = "";
          if (docType !== "quote") {
            if (direction === "purchase" && docType === "invoice" && NON_PROCUREMENT.includes(expenseCategory)) {
              throw new PostingError(
                `${categoryByCode(expenseCategory).label} is a statutory obligation — it does not go through the procurement cycle. Post it under "Expense & statutory payments" instead, where it is charged straight to the expense account.`
              );
            }
            doc = await postInvoiceDocTx(tx as never, clientId, { no, bp, direction, docType, subtotal, vat: vatOn ? vat : 0, period, user, expenseAccount, cc: invoiceCC, expenseCategory });
            await (tx as never as typeof db).update(invoices).set({ docNo: doc }).where(eq(invoices.id, invId));
          }
          return { invId, no, doc };
        });
        return Response.json({ ok: true, id: result.invId, no: result.no, doc: result.doc, message: `${result.no} saved${result.doc ? ` → doc ${result.doc}` : " (quote – no accounting entry until accepted)"}.` });
      }
      case "accept_quote": {
        const inv = (await db.select().from(invoices).where(and(eq(invoices.id, num(i.id)), eq(invoices.clientId, clientId))))[0];
        if (!inv) throw new PostingError("Quote not found.");
        if (inv.docType !== "quote") throw new PostingError("Only quotes can be accepted.");
        const period = str(i.period) ?? thisPeriod();
        const newNo = inv.no.replace("EST-", "INV-").replace("PQT-", "PIN-");
        const doc = await db.transaction(async (tx) => {
          const d = await postInvoiceDocTx(tx as never, clientId, { no: inv.no, bp: inv.bp, direction: inv.direction, docType: "invoice", subtotal: Number(inv.subtotal), vat: Number(inv.vat), period, user });
          await (tx as never as typeof db).update(invoices).set({ status: "open", docNo: d, docType: "invoice", no: newNo }).where(eq(invoices.id, inv.id));
          return d;
        });
        return Response.json({ ok: true, doc, message: `Quote ${inv.no} accepted → invoice ${newNo} (doc ${doc}).` });
      }
      case "pay_invoice":
        return Response.json({ ok: true, ...(await payInvoice(clientId, { invoiceId: num(i.invoiceId), amount: num(i.amount), rateNow: num(i.rateNow) || (await getRate(str(i.currency) ?? "GHS")), whtName: str(i.whtName), period: str(i.period) ?? thisPeriod(), user })) });

      // ---- EXPENSE & STATUTORY PAYMENTS (utilities, taxes, pension, insurance,
      //      regulatory fees, penalties, finance costs) — never in procurement.
      //      The bill is raised as an invoice into Accounts Payable, then paid
      //      through the Payment Desk like any other bill. ----
      case "post_expense": {
        const category = str(i.expenseCategory) ?? "utilities";
        if (!NON_PROCUREMENT.includes(category))
          throw new PostingError(
            `${categoryByCode(category).label} is a trading cost. Raise it through Procurement so it gets a PO and a goods receipt.`
          );
        const amount = num(i.amount);
        if (amount <= 0) throw new PostingError("Enter a positive amount.");
        const account = str(i.expenseAccount) ?? categoryByCode(category).accounts[0].accountNo;
        const bpNo = str(i.bp) ?? "";
        const period = str(i.period) ?? thisPeriod();
        const meta = categoryByCode(category);
        const desc = str(i.description) ?? meta.label;
        const who = bpNo || meta.label;

        // The bill is recognised now: expense Dr / Accounts Payable Cr.
        // Payment is a separate step at the Payment Desk, so the liability is
        // visible, the aging is correct, and nothing bypasses the approval flow.
        const doc = await postChecked(clientId, {
          period,
          module: "FI",
          docType: "STAT",
          user,
          reference: `${category} · ${desc}`,
          lines: [
            { account, bp: bpNo, cc: str(i.cc), desc: `${meta.label} – ${desc}`, dr: amount },
            { account: "200000", bp: bpNo || "STATUTORY", desc: `Payable – ${desc}`, cr: amount },
          ],
        });

        const count = (await db.select({ m: sql<number>`count(*)::int` }).from(invoices).where(and(eq(invoices.clientId, clientId), eq(invoices.direction, "purchase"))))[0]?.m ?? 0;
        const no = `STAT-${String(count + 1).padStart(4, "0")}`;
        const created = await db
          .insert(invoices)
          .values({
            clientId, direction: "purchase", docType: "invoice", no, bp: bpNo || "STATUTORY",
            currency: str(i.currency) ?? "GHS", rate: String(await getRate(str(i.currency) ?? "GHS")),
            subtotal: String(amount), vat: "0", total: String(amount),
            status: "open", paid: "0",
            period, docNo: doc, note: `${meta.label} · ${desc}`, expenseCategory: category,
          })
          .returning({ id: invoices.id });

        return Response.json({
          ok: true, doc, no, invoiceId: created[0].id,
          message: `${meta.label} bill of ₵${amount.toFixed(2)} raised as ${no} → doc ${doc}. It is now in Accounts Payable — pay it from the Payment Desk.`,
        });
      }

      // ================= IFRS 9 — FINANCIAL INSTRUMENTS & ECL =================
      case "ifrs9.add_instrument": {
        const r = await addInstrument(clientId, {
          code: str(i.code) ?? "",
          name: str(i.name) ?? "",
          category: str(i.category) ?? "amortised_cost",
          instrumentType: str(i.instrumentType) ?? "loan_receivable",
          counterparty: str(i.counterparty),
          principal: num(i.principal),
          effectiveRate: num(i.effectiveRate),
          issueDate: str(i.issueDate),
          maturityDate: str(i.maturityDate),
          collateralValue: num(i.collateralValue),
          creditGrade: str(i.creditGrade),
          currency: str(i.currency) || "GHS",
          notes: str(i.notes),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs9.assess_instrument": {
        const r = await assessInstrumentEcl(clientId, {
          instrumentId: num(i.instrumentId),
          period: str(i.period) ?? thisPeriod(),
          daysPastDue: num(i.daysPastDue),
          pdNow: str(i.pdNow) !== "" ? num(i.pdNow) : undefined,
          forwardLookingAdjustment: num(i.forwardLookingAdjustment),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs9.assess_receivables": {
        const r = await assessTradeReceivableEcl(clientId, {
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs9.update_matrix": {
        const rows = (Array.isArray(i.rows) ? i.rows : []) as { bucket: string; pd: number }[];
        const r = await updateProvisionMatrix(clientId, rows);
        return Response.json({ ok: true, ...r });
      }

      // ======================= IFRS 16 — LEASES =======================
      case "ifrs16.add_lease": {
        const r = await addLease(clientId, {
          code: str(i.code) ?? "",
          description: str(i.description) ?? "",
          lessor: str(i.lessor),
          leaseType: str(i.leaseType) ?? "property",
          startDate: str(i.startDate) ?? "",
          termMonths: num(i.termMonths) || 12,
          payment: num(i.payment),
          frequency: (str(i.frequency) || "monthly") as "monthly" | "quarterly" | "annually",
          timing: (str(i.timing) || "arrears") as "arrears" | "advance",
          discountRate: num(i.discountRate),
          initialDirectCosts: num(i.initialDirectCosts),
          incentives: num(i.incentives),
          restorationCost: num(i.restorationCost),
          cc: str(i.cc),
          lowValueExemption: i.lowValueExemption === true,
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs16.run_month": {
        const r = await runLeaseMonth(clientId, {
          period: str(i.period) ?? thisPeriod(),
          leaseId: num(i.leaseId) || undefined,
          user,
        });
        return Response.json({ ok: true, ...r });
      }

      // ============== IAS 36 — IMPAIRMENT / IFRS 5 — HELD FOR SALE ==============
      case "ias36.impairment_test": {
        const r = await runImpairmentTest(clientId, {
          period: str(i.period) ?? thisPeriod(),
          unitName: str(i.unitName) ?? "",
          unitType: (str(i.unitType) || "cgu") as "cgu" | "asset",
          carryingAmount: num(i.carryingAmount),
          fairValueLessCosts: num(i.fairValueLessCosts),
          cashFlows: Array.isArray(i.cashFlows) ? (i.cashFlows as number[]).map((c) => num(c)) : [],
          terminalValue: num(i.terminalValue),
          discountRate: num(i.discountRate),
          notes: str(i.notes),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ias36.allocate_cgu": {
        const r = await allocateCguLoss(clientId, {
          period: str(i.period) ?? thisPeriod(),
          unitName: str(i.unitName) ?? "",
          assets: (Array.isArray(i.assets) ? i.assets : []) as {
            name: string;
            carryingAmount: number;
            floor: number;
          }[],
          totalLoss: num(i.totalLoss),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs5.classify": {
        const r = await classifyHeldForSale(clientId, {
          period: str(i.period) ?? thisPeriod(),
          assetCode: str(i.assetCode) ?? "",
          description: str(i.description) ?? "",
          originalCost: num(i.originalCost),
          accumulatedDepreciation: num(i.accumulatedDepreciation),
          fairValue: num(i.fairValue),
          costsToSell: num(i.costsToSell),
          committedToPlan: i.committedToPlan !== false,
          activeMarketing: i.activeMarketing !== false,
          expectedSaleMonths: num(i.expectedSaleMonths) || 12,
          discontinuedOperation: i.discontinuedOperation === true,
          expectedSaleDate: str(i.expectedSaleDate),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "ifrs5.dispose": {
        const r = await completeHeldForSaleDisposal(clientId, {
          id: num(i.id),
          proceeds: num(i.proceeds),
          costsToSell: num(i.costsToSell),
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }

      // ============== LOANS & BORROWINGS — amortised cost ==============
      case "loan.drawdown": {
        const r = await drawdownLoan(clientId, {
          code: str(i.code) ?? "",
          lender: str(i.lender) ?? "",
          facilityType: (str(i.facilityType) || "amortising") as never,
          principal: num(i.principal),
          annualRate: num(i.annualRate),
          termMonths: num(i.termMonths) || 12,
          startDate: str(i.startDate) ?? "",
          frequency: (str(i.frequency) || "monthly") as never,
          timing: (str(i.timing) || "arrears") as never,
          moratoriumMonths: num(i.moratoriumMonths),
          arrangementFee: num(i.arrangementFee),
          feeSpreadMonths: num(i.feeSpreadMonths),
          drawdownAccount: str(i.drawdownAccount) || undefined,
          loanAccount: str(i.loanAccount) || undefined,
          cc: str(i.cc),
          period: str(i.period) ?? thisPeriod(),
          user,
          notes: str(i.notes),
        });
        return Response.json({ ok: true, ...r });
      }
      case "loan.repay": {
        const r = await repayLoan(clientId, {
          loanId: num(i.loanId),
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "loan.schedule": {
        const rows = await listSchedule(clientId, num(i.loanId));
        return Response.json({ ok: true, rows });
      }

      // ---- banking & reconciliation ----
      case "add_bank_account": {
        if (!str(i.name) || !str(i.bank)) throw new PostingError("Account and bank names are required.");
        const created = await db.insert(bankAccounts).values({
          clientId, name: str(i.name)!, bank: str(i.bank)!, accountCode: str(i.accountCode) ?? "101000",
          currency: str(i.currency) ?? "GHS", opening: String(num(i.opening)), active: true,
        }).returning({ id: bankAccounts.id });
        return Response.json({ ok: true, id: created[0].id, message: `Bank account ${str(i.name)} added.` });
      }
      case "add_bank_line": {
        const acc = (await db.select().from(bankAccounts).where(and(eq(bankAccounts.id, num(i.accountId)), eq(bankAccounts.clientId, clientId))))[0];
        if (!acc) throw new PostingError("Bank account not found.");
        if (!num(i.amount)) throw new PostingError("Amount is required.");
        const created = await db.insert(bankLines).values({
          accountId: acc.id, ref: str(i.ref) ?? "", txnDate: str(i.txnDate) ?? new Date().toISOString().slice(0, 10),
          description: str(i.description) ?? "", amount: String(num(i.amount)), status: "unmatched",
        }).returning({ id: bankLines.id });
        return Response.json({ ok: true, id: created[0].id, message: "Bank line added." });
      }
      case "import_bank_lines": {
        const acc = (await db.select().from(bankAccounts).where(and(eq(bankAccounts.id, num(i.accountId)), eq(bankAccounts.clientId, clientId))))[0];
        if (!acc) throw new PostingError("Bank account not found.");
        const lines = Array.isArray(i.lines) ? (i.lines as AnyInput[]) : [];
        if (!lines.length) throw new PostingError("No lines parsed (expected CSV: date, description, amount).");
        let n = 0;
        for (const l of lines) {
          const amt = num(l.amount);
          if (!amt) continue;
          await db.insert(bankLines).values({
            accountId: acc.id, ref: str(l.ref) ?? "", txnDate: str(l.date) ?? new Date().toISOString().slice(0, 10),
            description: str(l.description) ?? "", amount: String(amt), status: "unmatched",
          });
          n++;
        }
        return Response.json({ ok: true, count: n, message: `${n} bank statement lines imported for matching.` });
      }
      case "add_bank_line": {
        const acc = (await db.select().from(bankAccounts).where(and(eq(bankAccounts.id, num(i.accountId)), eq(bankAccounts.clientId, clientId))))[0];
        if (!acc) throw new PostingError("Bank account not found.");
        if (!num(i.amount)) throw new PostingError("Amount is required.");
        const created = await db.insert(bankLines).values({
          accountId: acc.id, ref: str(i.ref) ?? "", txnDate: str(i.txnDate) ?? new Date().toISOString().slice(0, 10),
          description: str(i.description) ?? "", amount: String(num(i.amount)), status: "unmatched",
        }).returning({ id: bankLines.id });
        return Response.json({ ok: true, id: created[0].id, message: "Bank line added." });
      }
      case "edit_bank_line": {
        const row = (await db.select().from(bankLines).where(eq(bankLines.id, num(i.id))))[0];
        if (!row) throw new PostingError("Bank line not found.");
        await db.update(bankLines).set({
          description: str(i.description) ?? row.description,
          amount: str(i.amount) ?? row.amount,
          note: str(i.note) ?? row.note,
          txnDate: str(i.txnDate) ?? row.txnDate,
          ref: str(i.ref) ?? row.ref,
        }).where(eq(bankLines.id, row.id));
        return Response.json({ ok: true, message: "Bank line updated — reconciliation is fully editable." });
      }
      case "match_bank_line": {
        const row = (await db.select().from(bankLines).where(eq(bankLines.id, num(i.id))))[0];
        if (!row) throw new PostingError("Bank line not found.");
        await db.update(bankLines).set({ status: "matched", journalLineId: num(i.journalLineId) || null, note: str(i.note) ?? row.note }).where(eq(bankLines.id, row.id));
        return Response.json({ ok: true, message: "Matched." });
      }
      case "unmatch_bank_line":
        await db.update(bankLines).set({ status: "unmatched", journalLineId: null }).where(eq(bankLines.id, num(i.id)));
        return Response.json({ ok: true, message: "Unmatched." });

      // ---- inventory ----
      case "stock_move":
        return Response.json({ ok: true, ...(await stockMovement(clientId, { material: str(i.material) ?? "", qtyIn: num(i.qtyIn), qtyOut: num(i.qtyOut), amountIn: num(i.amountIn), amountOut: num(i.amountOut), period: str(i.period) ?? thisPeriod(), ref: str(i.ref), user })) });

      // ---- sector operations: manufacturing / construction / extraction ----
      case "start_production": {
        const fg = str(i.material) ?? "";
        const raw = str(i.rawMaterial) ?? "";
        const rawQty = num(i.rawQty);
        const qty = num(i.qty);
        if (!fg || !raw || qty <= 0 || rawQty <= 0) throw new PostingError("Fill in finished good, raw material and quantities.");
        const rawRow = (await db.select().from(materials).where(eq(materials.materialNo, raw)))[0];
        const cost = r2(rawQty * Number(rawRow?.stdPrice ?? 0));
        if (cost <= 0) throw new PostingError("Raw material cost is zero — check the material master price.");
        const count = (await db.select({ m: sql<number>`count(*)::int` }).from(productionOrders).where(eq(productionOrders.clientId, clientId)))[0]?.m ?? 0;
        const no = `PRD-${String(count + 1).padStart(4, "0")}`;
        const period = str(i.period) ?? thisPeriod();
        const doc = await postChecked(clientId, {
          period, module: "INV", docType: "PRD", user, reference: no,
          lines: [
            { account: "122000", material: fg, desc: `WIP issued – ${no}`, dr: cost },
            { account: "120000", material: raw, desc: `Raw material issue – ${no}`, cr: cost },
          ],
        });
        await db.insert(productionOrders).values({
          clientId, no, material: fg, rawMaterial: raw, rawQty: String(rawQty), qty: Math.round(qty),
          status: "started", period, docs: doc,
        });
        return Response.json({ ok: true, no, doc, message: `Production ${no} started (raw → WIP) → doc ${doc}.` });
      }
      case "complete_production": {
        const po = (await db.select().from(productionOrders).where(and(eq(productionOrders.id, num(i.id)), eq(productionOrders.clientId, clientId))))[0];
        if (!po) throw new PostingError("Production order not found.");
        if (po.status !== "started") throw new PostingError("Order is not in started state.");
        const drs = (await db.select({ v: sql<number>`coalesce(sum(${journalLines.debit}),0)::float8` }).from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.reference, po.no), eq(journalLines.account, "122000"))))[0]?.v ?? 0;
        const crs = (await db.select({ v: sql<number>`coalesce(sum(${journalLines.credit}),0)::float8` }).from(journalLines).where(and(eq(journalLines.clientId, clientId), eq(journalLines.reference, po.no), eq(journalLines.account, "122000"))))[0]?.v ?? 0;
        const wipVal = r2(drs - crs);
        if (wipVal <= 0) throw new PostingError("No WIP cost to transfer.");
        const doc = await postChecked(clientId, {
          period: str(i.period) ?? po.period, module: "INV", docType: "PRD", user, reference: po.no,
          lines: [
            { account: "121000", material: po.material, desc: `FG received – ${po.no}`, dr: wipVal },
            { account: "122000", material: po.material, desc: `WIP completed – ${po.no}`, cr: wipVal },
          ],
        });
        await db.update(productionOrders).set({ status: "completed", docs: po.docs + " " + doc }).where(eq(productionOrders.id, po.id));
        return Response.json({ ok: true, doc, message: `Production ${po.no} completed (WIP → FG) → doc ${doc}.` });
      }
      // ---- IFRS 15 long-term contracts ----
      case "save_contract": {
        const r = await createContract(clientId, {
          title: str(i.title) ?? "",
          counterparty: str(i.counterparty) ?? "",
          totalValue: num(i.totalValue),
          estimatedCost: num(i.estimatedCost),
          method: (str(i.method) ?? "cost_to_cost") as never,
          startDate: str(i.startDate) ?? "",
          endDate: str(i.endDate) ?? "",
          cc: str(i.cc),
          retentionPct: num(i.retentionPct),
          currency: str(i.currency) ?? "GHS",
          sector: str(i.sector) ?? "construction",
          advance: num(i.advance),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "record_contract_cost": {
        const r = await recordContractCost(clientId, {
          contractId: num(i.contractId),
          amount: num(i.amount),
          account: str(i.account) ?? "505000",
          vendor: str(i.vendor),
          vat: i.vat === true,
          description: str(i.description) ?? "",
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, doc: r.doc, pctComplete: r.pctComplete, message: r.message });
      }
      case "recognise_revenue": {
        const r = await recogniseRevenue(clientId, {
          contractId: num(i.contractId),
          period: str(i.period) ?? thisPeriod(),
          user,
          forcePct: i.surveyedPct !== undefined && str(i.surveyedPct) !== "" ? num(i.surveyedPct) : undefined,
        });
        return Response.json({
          ok: true, doc: r.doc, revenue: r.revenueThisPeriod, cost: r.costThisPeriod,
          profit: r.profit, pctComplete: r.pctComplete,
          contractAsset: r.contractAsset, contractLiability: r.contractLiability, message: r.message,
        });
      }
      case "raise_certificate": {
        const r = await raiseCertificate(clientId, {
          contractId: num(i.contractId),
          period: str(i.period) ?? thisPeriod(),
          grossValue: str(i.grossValue) !== "" ? num(i.grossValue) : undefined,
          surveyedPct: str(i.surveyedPct) !== "" ? num(i.surveyedPct) : undefined,
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "receive_certificate": {
        const r = await receiveCertificatePayment(clientId, {
          certificateId: num(i.certificateId),
          amount: num(i.amount),
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "revise_contract": {
        const r = await reviseContract(clientId, {
          contractId: num(i.contractId),
          newValue: num(i.newValue),
          newEstimatedCost: num(i.newEstimatedCost),
          period: str(i.period) ?? thisPeriod(),
          description: str(i.description) ?? "",
          approvedBy: str(i.approvedBy) ?? "",
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "release_retention": {
        const r = await releaseRetention(clientId, {
          contractId: num(i.contractId),
          amount: num(i.amount) || undefined,
          period: str(i.period) ?? thisPeriod(),
          user,
        });
        return Response.json({ ok: true, ...r });
      }
      case "close_contract": {
        const c = await getContract(clientId, num(i.contractId));
        if (!c) throw new PostingError("Contract not found.");
        if (c.status !== "active") throw new PostingError("Contract is not active.");
        await db
          .update(contracts)
          .set({ status: str(i.status) === "cancelled" ? "cancelled" : "completed" })
          .where(and(eq(contracts.clientId, clientId), eq(contracts.id, c.id)));
        return Response.json({ ok: true, message: `Contract ${c.no} ${str(i.status) === "cancelled" ? "cancelled" : "completed"}.` });
      }

      case "extraction_tax_run": {
        const revenue = num(i.productionValue);
        if (revenue <= 0) throw new PostingError("Enter the period production/revenue value.");
        const royaltyRate = num(i.royaltyRate);
        const pptRate = num(i.pptRate);
        const royalty = r2(revenue * (royaltyRate / 100));
        const ppt = r2(revenue * (pptRate / 100));
        const doc = await postChecked(clientId, {
          period: str(i.period) ?? thisPeriod(), module: "FI", docType: "TAX", user,
          reference: `Sector tax run ${str(i.period) ?? thisPeriod()}`,
          lines: [
            { account: "581000", desc: `Royalty @ ${royaltyRate}%`, dr: royalty },
            { account: "217000", desc: "Royalties payable", cr: royalty },
            { account: "582000", desc: `Petroleum production tax @ ${pptRate}%`, dr: ppt },
            { account: "218000", desc: "PPT payable", cr: ppt },
          ],
        });
        return Response.json({ ok: true, doc, royalty, ppt, message: `Sector taxes posted → doc ${doc}.` });
      }

      // ---- FX ----
      case "revalue_fx":
        return Response.json({ ok: true, ...(await revaluateFx(clientId, str(i.period) ?? thisPeriod(), user)) });
      case "refresh_fx": {
        const r = await refreshLiveRates();
        return r.ok
          ? Response.json({ ok: true, rates: r.rates, message: `Live mid-market rates updated (${r.source}).` })
          : Response.json({ ok: true, stale: true, message: `Live fetch unavailable (${r.error}) — stored mid-rates remain in force.` });
      }
      case "set_currency_rate": {
        if (ws.user.role !== "owner") throw new PostingError("Only the owner can override currency rates.");
        const { setRate } = await import("@/lib/fx");
        await setRate(str(i.code) ?? "", num(i.rate), "Owner override (BOG mid adjustment)");
        return Response.json({ ok: true, message: `Rate for ${str(i.code)} set to ${num(i.rate)} GHS.` });
      }

      // ---- budget & scenarios ----
      case "save_budget": {
        const fy = Math.round(num(i.fiscalYear));
        const name = str(i.scenarioName) ?? "Base";
        if (!fy) throw new PostingError("Fiscal year is required.");
        let sc = (await db.select().from(budgetScenarios).where(and(eq(budgetScenarios.clientId, clientId), eq(budgetScenarios.name, name), eq(budgetScenarios.fiscalYear, fy))))[0];
        if (!sc) {
          const c = await db.insert(budgetScenarios).values({ clientId, name, fiscalYear: fy }).returning();
          sc = c[0];
        }
        await db.delete(budgetLines).where(and(eq(budgetLines.clientId, clientId), eq(budgetLines.scenarioId, sc.id)));
        const lines = Array.isArray(i.lines) ? (i.lines as AnyInput[]) : [];
        for (const l of lines) {
          const amt = num(l.amount);
          if (!str(l.account) || amt === 0) continue;
          await db.insert(budgetLines).values({ clientId, scenarioId: sc.id, account: str(l.account)!, amount: String(amt), note: str(l.note) ?? "" });
        }
        return Response.json({ ok: true, message: `Budget "${name} ${fy}" saved (${lines.length} lines).` });
      }

      // ---- month-end close ----
      case "close_period": {
        const p = str(i.period) ?? thisPeriod();
        const r = await closePeriod(clientId, p, user);
        return Response.json({ ok: true, count: r.count, message: `Period ${p} closed (${r.count} lines frozen).` });
      }
      case "open_period": {
        const p = str(i.period) ?? thisPeriod();
        await openPeriod(clientId, p, user);
        return Response.json({ ok: true, message: `Period ${p} reopened for correcting entries.` });
      }

      // ---- BPZ fees ----
      case "charge_fee":
        return Response.json({ ok: true, ...(await chargeClientFee(clientId, { serviceLine: str(i.serviceLine) ?? "", amount: num(i.amount), period: str(i.period) ?? thisPeriod(), user })) });
      case "collect_fee": {
        const feeRow = (await db.select().from(feeInvoices).where(eq(feeInvoices.id, num(i.feeId))))[0];
        if (!feeRow) throw new PostingError("Fee invoice not found.");
        if (ws.user.role !== "owner" && feeRow.clientId !== clientId)
          throw new PostingError("You can only collect fees for your own workspace.");
        return Response.json({ ok: true, ...(await collectFee(feeRow.clientId, num(i.feeId), str(i.period) ?? thisPeriod(), user)) });
      }
      case "generate_monthly_fees": {
        const targetId =
          ws.user.role === "owner" && i.forClientId ? Number(i.forClientId) : clientId;
        const client = (await db.select().from(clients).where(eq(clients.id, targetId)))[0];
        const lines = (client?.serviceLines ?? "").split(",").map((s) => s.trim()).filter(Boolean);
        if (!lines.length) throw new PostingError("No service lines assigned to this client.");
        const period = str(i.period) ?? thisPeriod();
        const feeMap: Record<string, number> = typeof i.feeMap === "object" && i.feeMap ? (i.feeMap as Record<string, number>) : {};
        let n = 0;
        for (const sl of lines) {
          const exists = (await db.select({ id: feeInvoices.id }).from(feeInvoices).where(and(eq(feeInvoices.clientId, targetId), eq(feeInvoices.serviceLine, sl), eq(feeInvoices.period, period))))[0];
          if (exists) continue;
          const fee = num(feeMap[sl]);
          if (!fee) continue;
          await db.insert(feeInvoices).values({ clientId: targetId, serviceLine: sl, period, amount: String(fee), status: "open" });
          n++;
        }
        return Response.json({ ok: true, count: n, message: n ? `${n} monthly fee invoice(s) generated for ${period}.` : "No new fees to generate (already invoiced this period)." });
      }

      // ---- advisory / engagements ----
      case "save_engagement": {
        const clientIdE = num(i.engagementClientId) || clientId;
        const serviceLine = str(i.serviceLine) ?? "";
        const template = str(i.template) ?? "";
        const period = str(i.period) ?? thisPeriod();
        if (!serviceLine) throw new PostingError("Select a service line.");
        const quant = typeof i.quant === "string" ? i.quant : JSON.stringify(i.quant ?? {});
        const qual = str(i.qual) ?? "";
        const existing = (await db.select().from(engagements).where(and(eq(engagements.clientId, clientIdE), eq(engagements.serviceLine, serviceLine), eq(engagements.template, template), eq(engagements.period, period))))[0];
        if (existing) {
          await db.update(engagements).set({ quant, qual, status: str(i.status) ?? existing.status, updatedBy: user }).where(eq(engagements.id, existing.id));
        } else {
          await db.insert(engagements).values({ clientId: clientIdE, serviceLine, template, period, status: str(i.status) ?? "in_progress", quant, qual, updatedBy: user });
        }
        return Response.json({ ok: true, message: "Workpaper saved." });
      }

      // ---- recurring invoices (retainers, rent, subscriptions) ----
      case "make_recurring": {
        const inv = (await db.select().from(invoices).where(and(eq(invoices.id, num(i.invoiceId)), eq(invoices.clientId, clientId))))[0];
        if (!inv) throw new PostingError("Invoice not found in this workspace.");
        const freq = ["monthly", "quarterly"].includes(str(i.freq) ?? "") ? str(i.freq)! : "monthly";
        if (inv.docType !== "invoice") throw new PostingError("Only invoices can recur — quotes cannot.");
        const { shiftPeriod, thisPeriod: tp } = await import("@/lib/periods");
        const base = inv.period || tp();
        await db.update(invoices).set({ recurrence: freq, recurrenceNext: shiftPeriod(base, freq === "monthly" ? 1 : 3) }).where(eq(invoices.id, inv.id));
        return Response.json({ ok: true, message: `${inv.no} will now recur ${freq}ly — next run ${shiftPeriod(base, freq === "monthly" ? 1 : 3)}.` });
      }
      case "stop_recurring": {
        const inv = (await db.select().from(invoices).where(and(eq(invoices.id, num(i.invoiceId)), eq(invoices.clientId, clientId))))[0];
        if (!inv) throw new PostingError("Invoice not found.");
        await db.update(invoices).set({ recurrence: "none", recurrenceNext: "" }).where(eq(invoices.id, inv.id));
        return Response.json({ ok: true, message: `${inv.no} recurrence stopped.` });
      }
      case "run_recurrings": {
        const period = str(i.period) ?? thisPeriod();
        const due = (await db.select().from(invoices).where(and(eq(invoices.clientId, clientId), eq(invoices.docType, "invoice"), sql`${invoices.recurrenceNext} <= ${period}`, sql`${invoices.recurrence} <> 'none'`)));
        if (!due.length) return Response.json({ ok: true, count: 0, message: `No recurring invoices are due for ${period}.` });
        let made = 0;
        const notes: string[] = [];
        for (const inv of due) {
          const freqGap = inv.recurrence === "monthly" ? 1 : 3;
          const no = await nextDocNo(clientId, inv.direction, "invoice");
          const vat = r2(Number(inv.subtotal) * 0.2);
          const totalSigned = inv.direction === "sales" ? r2(Number(inv.subtotal) + vat) : r2(Number(inv.subtotal) + vat);
          const created = await db.insert(invoices).values({
            clientId, direction: inv.direction, docType: "invoice", no, bp: inv.bp,
            currency: inv.currency, rate: inv.rate, subtotal: inv.subtotal, vat: String(vat),
            total: String(totalSigned), status: "open", period, note: `Recurring from ${inv.no}`,
            recurrence: inv.recurrence,
            recurrenceNext: (await import("@/lib/periods")).shiftPeriod(inv.recurrenceNext || period, freqGap),
          }).returning({ id: invoices.id });
          const doc = await postInvoiceDocTx(null, clientId, { no, bp: inv.bp, direction: inv.direction, docType: "invoice", subtotal: Number(inv.subtotal), vat, period, user });
          await db.update(invoices).set({ docNo: doc }).where(eq(invoices.id, created[0].id));
          // stop the source from re-firing for this cycle
          await db.update(invoices).set({ recurrenceNext: (await import("@/lib/periods")).shiftPeriod(inv.recurrenceNext || period, freqGap) }).where(eq(invoices.id, inv.id));
          made++;
          notes.push(no);
        }
        return Response.json({ ok: true, count: made, message: `${made} recurring invoice(s) raised for ${period}: ${notes.join(", ")}.` });
      }

      default:
        throw new PostingError(`Unknown action "${String(action)}".`);
    }
  } catch (e) {
    const isPosting = e instanceof PostingError;
    const msg = isPosting ? e.message : e instanceof Error ? e.message : "Unexpected server error.";
    const status = msg.startsWith("Not authenticated") ? 401 : 400;
    ctx.detail = msg.slice(0, 300);
    // Validation failures are expected and readable. Anything else is a defect —
    // record it so it can be diagnosed rather than surfacing as a blank response.
    if (!isPosting) {
      await report(`Unhandled error in action "${String(body.action)}"`, {
        clientId: ctx.clientId, workspace: ctx.workspace, username: ctx.username,
        action: String(body.action ?? ""), route: "/api/actions",
      }, e);
    }
    return Response.json({ ok: false, error: msg }, { status });
  }
}
