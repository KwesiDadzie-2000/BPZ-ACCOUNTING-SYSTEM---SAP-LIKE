import { requireWorkspace } from "@/lib/auth";
import { db } from "@/db";
import { invoices, accounts } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getRate } from "@/lib/fx";
import { jurisdictionByCode } from "@/data/jurisdictions";
import { sectorByCode } from "@/data/sectors";
import { db as database } from "@/db";
import { clients } from "@/db/schema";
import { num, fmtDate } from "@/lib/format";
import { PrintButton } from "@/components/PrintButton";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function InvoicePrintPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ws = await requireWorkspace();
  const inv = (
    await db
      .select()
      .from(invoices)
      .where(and(eq(invoices.id, Number(id)), eq(invoices.clientId, ws.client.id)))
  )[0];
  if (!inv) notFound();

  const client = (await database.select().from(clients).where(eq(clients.id, ws.client.id)))[0];
  const jur = jurisdictionByCode(client?.baseCurrency === "GHS" ? "GH" : "EU");
  const sector = sectorByCode(client?.sector ?? "services");
  const rate = inv.currency === "GHS" ? 1 : await getRate(inv.currency);
  const coa = await db.select().from(accounts);
  const paid = Number(inv.paid);
  const balance = Number(inv.total) - paid;
  const isCredit = inv.docType === "credit";
  const label =
    inv.docType === "quote" ? "QUOTATION" : inv.docType === "credit" ? "CREDIT NOTE" : inv.docType === "debit" ? "DEBIT NOTE" : "INVOICE";

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 print:px-0 print:py-0">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <a href="/payment-desk" className="text-xs font-semibold text-mist-400 hover:text-mist-200">
          ← Back to desk
        </a>
        <PrintButton />
      </div>

      {/* Printable document */}
      <div className="rounded-xl border border-ink-700 bg-white p-8 text-slate-900 shadow-sm print:rounded-none print:border-0 print:shadow-none">
        {/* Letterhead */}
        <div className="flex items-start justify-between border-b-2 border-[#F5B719] pb-4">
          <div className="flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-[#0D2445] font-display text-[15px] font-extrabold text-[#F5B719]">
              BPZ
            </span>
            <span>
              <span className="block font-display text-lg font-extrabold tracking-tight text-[#0D2445]">BPZ CONSULT</span>
              <span className="block text-[12px] font-semibold uppercase tracking-[0.2em] text-[#B07F08]">Financial Experts</span>
            </span>
          </div>
          <div className="text-right">
            <div className="font-display text-xl font-extrabold text-[#0D2445]">{label}</div>
            <div className="mt-0.5 font-mono text-sm font-bold text-slate-600">{inv.no}</div>
          </div>
        </div>

        {/* Parties */}
        <div className="mt-6 grid grid-cols-2 gap-8 text-[13px]">
          <div>
            <div className="mb-1 text-[12px] font-bold uppercase tracking-[0.14em] text-slate-500">
              {inv.direction === "sales" ? "Billed to" : "Received from"}
            </div>
            <div className="font-semibold text-slate-900">{inv.bp}</div>
            <div className="mt-0.5 text-slate-600">{ws.client.name}</div>
          </div>
          <div className="text-right">
            <div className="mb-1 text-[12px] font-bold uppercase tracking-[0.14em] text-slate-500">Details</div>
            <div className="text-slate-700">Period: <span className="font-mono">{inv.period || "—"}</span></div>
            <div className="text-slate-700">Raised: <span className="font-mono">{fmtDate(inv.createdAt.toISOString().slice(0, 10))}</span></div>
            <div className="text-slate-700">
              Currency: <span className="font-mono">{inv.currency}</span>
              {inv.currency !== "GHS" && <span className="text-slate-500"> @ {num(rate)} GHS</span>}
            </div>
            <div className="text-slate-700">Status: <span className="font-semibold capitalize">{inv.status}</span></div>
          </div>
        </div>

        {/* Lines */}
        <table className="mt-6 w-full border-collapse text-[13px]">
          <thead>
            <tr className="border-y border-slate-300 bg-slate-50 text-left">
              <th className="py-2 pl-1 font-bold uppercase tracking-wider text-slate-600">Description</th>
              <th className="py-2 text-right font-bold uppercase tracking-wider text-slate-600">Amount ({inv.currency})</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-slate-200">
              <td className="py-2.5 pl-1 text-slate-800">
                {inv.note || `${label.toLowerCase()} — professional services`}
                <span className="ml-1 text-slate-400">({sector.name})</span>
              </td>
              <td className="py-2.5 text-right font-mono tabular-nums text-slate-800">{num(Number(inv.subtotal))}</td>
            </tr>
            <tr className="border-b border-slate-200">
              <td className="py-2.5 pl-1 text-slate-700">Indirect tax ({jur.vatName} @ {num(jur.vatRate)}%)</td>
              <td className="py-2.5 text-right font-mono tabular-nums text-slate-800">{num(Number(inv.vat))}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-[#0D2445]">
              <td className="py-2.5 pl-1 font-display font-extrabold text-[#0D2445]">Total</td>
              <td className="py-2.5 text-right font-mono text-[15px] font-extrabold tabular-nums text-[#0D2445]">
                {num(Number(inv.total))}
              </td>
            </tr>
            {paid > 0 && (
              <>
                <tr>
                  <td className="py-1.5 pl-1 text-slate-600">Settled to date</td>
                  <td className="py-1.5 text-right font-mono tabular-nums text-emerald-700">{num(paid)}</td>
                </tr>
                <tr>
                  <td className="py-1.5 pl-1 font-bold text-slate-800">Balance due</td>
                  <td className="py-1.5 text-right font-mono font-bold tabular-nums text-slate-900">{num(balance)}</td>
                </tr>
              </>
            )}
          </tfoot>
        </table>

        {/* GHS equivalent + footer */}
        {inv.currency !== "GHS" && (
          <div className="mt-3 rounded bg-slate-50 px-3 py-2 text-[12px] text-slate-600">
            GHS equivalent at transaction rate: <span className="font-mono font-semibold">₵{num(Number(inv.total) * rate)}</span> (IAS 21 initial measurement)
          </div>
        )}

        <div className="mt-8 border-t border-slate-200 pt-4 text-[12.5px] leading-relaxed text-slate-500">
          <div className="font-semibold text-slate-700">BPZ CONSULT · Financial Experts</div>
          <div>
            Email: bpzconsults@gmail.com · Call/WhatsApp: +233 53 898 1062, +233 54 717 9469, +233 24 341 8400
          </div>
          <div className="mt-1.5">
            This document is generated from the BPZ CONSULT enterprise accounting platform and corresponds to journal
            document <span className="font-mono">{inv.docNo || "pending posting"}</span>. Indirect tax is stated at the
            statutory rate applicable in {jur.name} ({num(jur.vatRate)}%) and is not subject to cascading.
          </div>
        </div>
      </div>
    </div>
  );
}
