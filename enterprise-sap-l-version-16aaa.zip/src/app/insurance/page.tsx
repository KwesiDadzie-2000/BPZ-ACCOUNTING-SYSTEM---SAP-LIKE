import { requireWorkspace } from "@/lib/auth";
import { masterData, journalRows } from "@/lib/reports";
import { money } from "@/lib/format";
import { PageHeader, Stat } from "@/components/ui";
import { ActionForm } from "@/components/ActionForm";
import { ModuleHistory } from "@/components/ModuleHistory";

export const dynamic = "force-dynamic";

export default async function InsurancePage() {
  const ws = await requireWorkspace();
  const { accs, bps } = await masterData(ws.client.id);
  const insurers = bps.filter((b) => b.type === "Vendor");
  const expenseAccounts = accs.filter((a) => a.type === "Expense");

  const adminLines = await journalRows({ clientId: ws.client.id, module: "ADMIN", limit: 100_000 });
  const claimed = adminLines.filter((l) => l.docType === "KG").reduce((s, l) => s + l.debit, 0);
  const settled = adminLines.filter((l) => l.docType === "KZ").reduce((s, l) => s + l.debit, 0);
  const openReceivable = adminLines
    .filter((l) => l.account === "110000")
    .reduce((s, l) => s + l.debit - l.credit, 0);

  return (
    <>
      <PageHeader
        kicker="ADMIN · Insurance"
        title="Insurance & Claims"
        desc="A claim registers a receivable from the insurer against the expense it offsets; the settlement clears the receivable into the bank."
      />

      <div className="mb-4 grid grid-cols-3 gap-3">
        <Stat label="Claims Registered" value={money(claimed)} sub="Receivables booked against expenses" />
        <Stat label="Settlements Received" value={money(settled)} sub="Paid into Bank 101000" tone="text-sd" />
        <Stat
          label="Open Claim Receivable"
          value={money(openReceivable)}
          sub="Awaiting insurer settlement"
          tone={openReceivable > 0 ? "text-aa" : undefined}
        />
      </div>

      <div className="grid items-start gap-4 xl:grid-cols-2">
        <ActionForm
          action="claim_received"
          title="Register Claim"
          sub="Posts 110000 Dr / offset expense Cr."
          submitLabel="Register claim"
          userDefault="admin_user"
          fields={[
            {
              name: "insurer",
              label: "Insurer",
              type: "select",
              options: insurers.map((v) => ({ value: v.bpNo, label: `${v.bpNo} · ${v.name}` })),
            },
            { name: "amount", label: "Claim amount", type: "number", step: "0.01", min: 0.01, defaultValue: "8000.00" },
            {
              name: "offsetAccount",
              label: "Offset expense account",
              type: "select",
              options: expenseAccounts.map((a) => ({ value: a.accountNo, label: `${a.accountNo} · ${a.description}` })),
            },
          ]}
        />
        <ActionForm
          action="receive_settlement"
          title="Receive Settlement"
          sub="Posts 101000 Dr / 110000 Cr."
          submitLabel="Record settlement"
          userDefault="admin_user"
          fields={[
            {
              name: "insurer",
              label: "Insurer",
              type: "select",
              options: insurers.map((v) => ({ value: v.bpNo, label: `${v.bpNo} · ${v.name}` })),
            },
            { name: "amount", label: "Amount received", type: "number", step: "0.01", min: 0.01, defaultValue: "8000.00" },
          ]}
        />
      </div>

      <div className="mt-4">
        <ModuleHistory clientId={ws.client.id} module="ADMIN" title="Claims History" sub="Claims and settlements in the Universal Journal" />
      </div>
    </>
  );
}
