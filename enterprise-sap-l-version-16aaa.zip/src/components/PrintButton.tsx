"use client";

import { btn, Icon } from "./ui";

export function PrintButton({ label = "Print / Save as PDF" }: { label?: string }) {
  return (
    <button className={btn.gold} onClick={() => window.print()}>
      <Icon name="doc" size={15} />
      {label}
    </button>
  );
}
