"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, cn, Badge, Stat, numCls, rowCls, tdCls, thCls } from "./ui";
import { num } from "@/lib/format";

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export type DeskTab = "ifrs9" | "ifrs16" | "ias36" | "ifrs5";

function SimpleTable({
  cols,
  rows,
  empty,
}: {
  cols: string[];
  rows: (string | number | React.ReactNode)[][];
  empty: string;
}) {
  return (
    <div className="max-h-[460px] overflow-auto">
      <table className="w-full min-w-[760px]">
        <thead className="sticky top-0 bg-ink-850">
          <tr className="border-b border-ink-700/70">
            {cols.map((c, i) => (
              <th
                key={i}
                className={
                  thCls + (c.startsWith("→") ? " text-right" : "")
                }
              >
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={cols.length} className="px-3 py-6 text-center text-sm text-mist-500">
                {empty}
              </td>
            </tr>
          ) : (
            rows.map((r, ri) => (
              <tr key={ri} className={rowCls}>
                {r.map((cell, ci) => (
                  <td key={ci} className={tdCls + (cols[ci]?.startsWith("→") ? " text-right font-mono tabular-nums" : "")}>
                    {cell}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

type Instrument = {
  id: number; code: string; name: string; category: string; instrumentType: string;
  carryingAmount: string; eclAllowance: string; stage: number; effectiveRate: string;
  collateralValue: string; status: string;
};
type Lease = {
  id: number; code: string; description: string; lessor: string; termMonths: number;
  payment: string; discountRate: string; rouAsset: string; leaseLiability: string;
  accumulatedDepreciation: string; status: string;
};
type Impairment = {
  id: number; period: string; unitName: string; carryingAmount: string;
  valueInUse: string; fairValueLessCosts: string; recoverableAmount: string;
  impairmentLoss: string; docNo: string;
};
type Hfs = {
  id: number; assetCode: string; description: string; carryingAmount: string;
  fairValueLessCosts: string; writeDown: string; discontinuedOperation: boolean; status: string;
};

const TABS: [DeskTab, string, string][] = [
  ["ifrs9", "IFRS 9", "Financial instruments & ECL"],
  ["ifrs16", "IFRS 16", "Leases"],
  ["ias36", "IAS 36", "Impairment"],
  ["ifrs5", "IFRS 5", "Held for sale"],
];

export function StandardsDesk({
  initialTab,
  instruments,
  leases,
  impairments,
  heldForSale,
  matrix,
  balances,
  ccOptions,
  period,
}: {
  initialTab: DeskTab;
  instruments: Instrument[];
  leases: Lease[];
  impairments: Impairment[];
  heldForSale: Hfs[];
  matrix: { bucket: string; label: string; pd: number }[];
  balances: Record<string, number>;
  ccOptions: { value: string; label: string }[];
  period: string;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [tab, setTab] = useState<DeskTab>(initialTab);

  // Keep the URL shareable without the server passing a function prop.
  useEffect(() => {
    const fromUrl = params.get("tab") as DeskTab | null;
    if (fromUrl && fromUrl !== tab) setTab(fromUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  function switchTab(next: DeskTab) {
    setTab(next);
    const url = new URL(window.location.href);
    url.searchParams.set("tab", next);
    window.history.replaceState({}, "", url.toString());
  }

  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run(payload: Record<string, unknown>) {
    setBusy(true);
    setError(null);
    setMsg(null);
    const d = await post(payload);
    setBusy(false);
    if (d.ok) {
      setMsg(d.message);
      router.refresh();
    } else setError(d.error);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1.5">
        {TABS.map(([id, label, note]) => (
          <button
            key={id}
            onClick={() => switchTab(id)}
            className={cn(
              "rounded-lg border px-3.5 py-2 text-left transition",
              tab === id
                ? "border-gold-400 bg-gold-400/15"
                : "border-ink-600 bg-ink-900/40 hover:border-gold-400/40"
            )}
          >
            <div className={cn("text-[13px] font-bold", tab === id ? "text-gold-300" : "text-mist-200")}>{label}</div>
            <div className="text-[11.5px] text-mist-500">{note}</div>
          </button>
        ))}
      </div>

      {msg && <div className="rounded-lg border border-pos/30 bg-pos/10 px-3 py-2.5 text-[12.5px] text-pos">{msg}</div>}
      {error && <div className="rounded-lg border border-neg/30 bg-neg/10 px-3 py-2.5 text-[12.5px] text-neg">{error}</div>}

      {tab === "ifrs9" && (
        <Ifrs9Desk
          instruments={instruments}
          matrix={matrix}
          balances={balances}
          period={period}
          busy={busy}
          run={run}
        />
      )}
      {tab === "ifrs16" && (
        <Ifrs16Desk leases={leases} balances={balances} ccOptions={ccOptions} period={period} busy={busy} run={run} />
      )}
      {tab === "ias36" && <Ias36Desk impairments={impairments} period={period} busy={busy} run={run} />}
      {tab === "ifrs5" && <Ifrs5Desk heldForSale={heldForSale} period={period} busy={busy} run={run} />}
    </div>
  );
}

/* ===================== IFRS 9 ===================== */

function Ifrs9Desk({
  instruments,
  matrix,
  balances,
  period,
  busy,
  run,
}: {
  instruments: Instrument[];
  matrix: { bucket: string; label: string; pd: number }[];
  balances: Record<string, number>;
  period: string;
  busy: boolean;
  run: (p: Record<string, unknown>) => Promise<void>;
}) {
  const [pd, setPd] = useState<Record<string, string>>(
    Object.fromEntries(matrix.map((m) => [m.bucket, String(m.pd)]))
  );
  const [assessId, setAssessId] = useState("");
  const [dpd, setDpd] = useState("0");
  const [pdNow, setPdNow] = useState("");

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Gross amortised cost" value={money(balances.grossAmortised ?? 0)} />
        <Stat label="ECL allowance" value={money(balances.eclAllowance ?? 0)} tone="text-neg" />
        <Stat label="ECL charge to date" value={money(balances.eclCharge ?? 0)} tone="text-neg" />
        <Stat label="ECL reversal to date" value={money(balances.eclReversal ?? 0)} tone="text-pos" />
      </div>

      <Card
        title="Simplified approach — trade receivables provision matrix"
        sub="Lifetime ECL using a provision matrix over the ageing buckets. One click posts the movement to the ledger."
        action={
          <button
            className={btn.gold}
            disabled={busy}
            onClick={() => run({ action: "ifrs9.assess_receivables", period })}
          >
            {busy ? "Computing…" : "Run ECL on receivables"}
          </button>
        }
      >
        <div className="mb-3 grid grid-cols-2 gap-3 md:grid-cols-5">
          {matrix.map((m) => (
            <Field key={m.bucket} label={m.label} hint="PD %">
              <input
                type="number"
                step="0.01"
                min={0}
                max={100}
                className={inputCls}
                value={pd[m.bucket] ?? ""}
                onChange={(e) => setPd({ ...pd, [m.bucket]: e.target.value })}
              />
            </Field>
          ))}
        </div>
        <button
          className={btn.ghost}
          disabled={busy}
          onClick={() =>
            run({
              action: "ifrs9.update_matrix",
              rows: matrix.map((m) => ({ bucket: m.bucket, pd: Number(pd[m.bucket]) || 0 })),
            })
          }
        >
          <Icon name="check" size={15} /> Save matrix
        </button>
        <p className="mt-2 text-[12px] leading-relaxed text-mist-500">
          PDs are forward-looking and must reflect reasonable and supportable information, not just historic loss
          experience. Updating the matrix affects all future runs but never rewrites a posted period.
        </p>
      </Card>

      <Card title="Financial instruments register" sub="Add an instrument, then run its staged ECL assessment" pad={false}>
        <div className="border-b border-ink-700 p-4">
          <form
            className="grid grid-cols-2 gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              run({
                action: "ifrs9.add_instrument",
                code: f.get("code"),
                name: f.get("name"),
                category: f.get("category"),
                instrumentType: f.get("instrumentType"),
                counterparty: f.get("counterparty"),
                principal: Number(f.get("principal")),
                effectiveRate: Number(f.get("effectiveRate")),
                issueDate: f.get("issueDate"),
                maturityDate: f.get("maturityDate"),
                collateralValue: Number(f.get("collateralValue") || 0),
                creditGrade: f.get("creditGrade"),
                notes: f.get("notes"),
              });
              e.currentTarget.reset();
            }}
          >
            <Field label="Code"><input name="code" className={inputCls} required placeholder="LN-001" /></Field>
            <Field label="Name"><input name="name" className={inputCls} required placeholder="Term loan – Omanye" /></Field>
            <Field label="Classification">
              <select name="category" className={inputCls} defaultValue="amortised_cost">
                <option value="amortised_cost">Amortised cost (hold to collect)</option>
                <option value="fvoci">Fair value through OCI (collect &amp; sell)</option>
                <option value="fvtpl">Fair value through profit or loss</option>
              </select>
            </Field>
            <Field label="Type">
              <select name="instrumentType" className={inputCls} defaultValue="loan_receivable">
                <option value="loan_receivable">Loan / advance receivable</option>
                <option value="trade_receivable">Trade receivable</option>
                <option value="investment">Debt investment</option>
                <option value="borrowing">Borrowing payable</option>
              </select>
            </Field>
            <Field label="Counterparty"><input name="counterparty" className={inputCls} placeholder="Customer or lender code" /></Field>
            <Field label="Principal / fair value"><input name="principal" type="number" step="0.01" className={inputCls} required /></Field>
            <Field label="Effective interest rate %"><input name="effectiveRate" type="number" step="0.0001" className={inputCls} required /></Field>
            <Field label="Collateral value"><input name="collateralValue" type="number" step="0.01" className={inputCls} /></Field>
            <Field label="Issue date"><input name="issueDate" type="date" className={inputCls} /></Field>
            <Field label="Maturity date"><input name="maturityDate" type="date" className={inputCls} /></Field>
            <Field label="Credit grade"><input name="creditGrade" className={inputCls} placeholder="Internal grade" /></Field>
            <Field label="Notes"><input name="notes" className={inputCls} /></Field>
            <div className="col-span-2 flex justify-end">
              <button className={btn.gold} disabled={busy}>Add instrument</button>
            </div>
          </form>
        </div>

        <div className="p-4">
          <Field label="Run a staged ECL assessment">
            <select className={inputCls} value={assessId} onChange={(e) => setAssessId(e.target.value)}>
              <option value="">— select an instrument —</option>
              {instruments.map((i) => (
                <option key={i.id} value={i.id}>{i.code} · {i.name} (Stage {i.stage})</option>
              ))}
            </select>
          </Field>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="Days past due" hint="30+ → Stage 2 backstop; 90+ → Stage 3">
              <input type="number" min={0} className={inputCls} value={dpd} onChange={(e) => setDpd(e.target.value)} />
            </Field>
            <Field label="Forward-looking lifetime PD %" hint="Blank = derive from days past due">
              <input type="number" step="0.01" min={0} max={100} className={inputCls} value={pdNow} onChange={(e) => setPdNow(e.target.value)} placeholder="auto" />
            </Field>
          </div>
          <button
            className={btn.gold + " mt-3"}
            disabled={busy || !assessId}
            onClick={() =>
              run({
                action: "ifrs9.assess_instrument",
                instrumentId: Number(assessId),
                period,
                daysPastDue: Number(dpd),
                pdNow: pdNow === "" ? undefined : Number(pdNow),
              })
            }
          >
            {busy ? "Assessing…" : "Assess ECL & post movement"}
          </button>
        </div>

        <div className="overflow-x-auto">
          <SimpleTable
            cols={["Code", "Name", "Category", "→ Carrying", "→ ECL", "Stage", "→ EIR %", "Status"]}
            rows={instruments.map((i) => [
              <span key="c" className="font-mono text-[12px] font-semibold text-gold-300">{i.code}</span>,
              i.name,
              <Badge key="k" tone={i.category === "fvtpl" ? "amber" : "mm"}>{i.category.replace("_", " ")}</Badge>,
              num(Number(i.carryingAmount)),
              num(Number(i.eclAllowance)),
              <Badge key="s" tone={i.stage === 3 ? "red" : i.stage === 2 ? "amber" : "green"}>Stage {i.stage}</Badge>,
              num(Number(i.effectiveRate)),
              <Badge key="st" tone={i.status === "active" ? "green" : "slate"}>{i.status}</Badge>,
            ])}
            empty="No financial instruments yet"
          />
        </div>
      </Card>
    </div>
  );
}

function money(n: number) {
  return num(n);
}

/* ===================== IFRS 16 ===================== */

function Ifrs16Desk({
  leases,
  balances,
  ccOptions,
  period,
  busy,
  run,
}: {
  leases: Lease[];
  balances: Record<string, number>;
  ccOptions: { value: string; label: string }[];
  period: string;
  busy: boolean;
  run: (p: Record<string, unknown>) => Promise<void>;
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        <Stat label="ROU carrying amount" value={money(balances.rouAssets ?? 0)} tone="text-fi" />
        <Stat label="ROU accumulated depreciation" value={money(balances.rouAccumulatedDep ?? 0)} tone="text-neg" />
        <Stat label="Lease liability" value={money(balances.leaseLiability ?? 0)} tone="text-aa" />
        <Stat label="ROU depreciation" value={money(balances.rouDepreciation ?? 0)} />
        <Stat label="Lease interest" value={money(balances.leaseInterest ?? 0)} />
      </div>

      <Card title="Run the monthly lease charge" sub="Depreciation, interest unwinding and the cash payment in one document"
        action={
          <button className={btn.gold} disabled={busy} onClick={() => run({ action: "ifrs16.run_month", period })}>
            {busy ? "Posting…" : "Run all leases"}
          </button>
        }
      >
        <p className="text-[12px] leading-relaxed text-mist-500">
          Each lease posts depreciation of the right-of-use asset, interest unwinding on the liability, and the cash
          payment — every period, idempotently. Short-term and low-value leases are skipped and expensed instead.
        </p>
      </Card>

      <Card title="Capitalise a new lease">
        <form
          className="grid grid-cols-2 gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            run({
              action: "ifrs16.add_lease",
              code: f.get("code"),
              description: f.get("description"),
              lessor: f.get("lessor"),
              leaseType: f.get("leaseType"),
              startDate: f.get("startDate"),
              termMonths: Number(f.get("termMonths")),
              payment: Number(f.get("payment")),
              frequency: f.get("frequency"),
              timing: f.get("timing"),
              discountRate: Number(f.get("discountRate")),
              initialDirectCosts: Number(f.get("initialDirectCosts") || 0),
              incentives: Number(f.get("incentives") || 0),
              restorationCost: Number(f.get("restorationCost") || 0),
              cc: f.get("cc"),
              period,
            });
            e.currentTarget.reset();
          }}
        >
          <Field label="Lease code"><input name="code" className={inputCls} required placeholder="LSE-001" /></Field>
          <Field label="Description"><input name="description" className={inputCls} required placeholder="Accra office – 5 years" /></Field>
          <Field label="Lessor"><input name="lessor" className={inputCls} /></Field>
          <Field label="Asset type">
            <select name="leaseType" className={inputCls} defaultValue="property">
              <option value="property">Property</option>
              <option value="vehicle">Vehicles</option>
              <option value="plant">Plant &amp; equipment</option>
              <option value="it">IT equipment</option>
            </select>
          </Field>
          <Field label="Commencement date"><input name="startDate" type="date" className={inputCls} required /></Field>
          <Field label="Term (months)"><input name="termMonths" type="number" min={1} className={inputCls} required defaultValue={60} /></Field>
          <Field label="Periodic payment"><input name="payment" type="number" step="0.01" className={inputCls} required /></Field>
          <Field label="Frequency">
            <select name="frequency" className={inputCls} defaultValue="monthly">
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
              <option value="annually">Annually</option>
            </select>
          </Field>
          <Field label="Payment timing">
            <select name="timing" className={inputCls} defaultValue="arrears">
              <option value="arrears">In arrears</option>
              <option value="advance">In advance</option>
            </select>
          </Field>
          <Field label="Discount rate % (IBR)"><input name="discountRate" type="number" step="0.0001" className={inputCls} required /></Field>
          <Field label="Initial direct costs"><input name="initialDirectCosts" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Lease incentives received"><input name="incentives" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Restoration provision"><input name="restorationCost" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Cost centre">
            <select name="cc" className={inputCls} defaultValue="">
              <option value="">— none —</option>
              {ccOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy}>Capitalise lease</button>
          </div>
        </form>
      </Card>

      <Card title="Lease portfolio" sub="Right-of-use carrying amount and liability split (IFRS 16.53)" pad={false}>
        <SimpleTable
          cols={["Code", "Description", "Lessor", "→ Term (mths)", "→ Payment", "→ Rate %", "→ ROU carrying", "→ Liability", "Status"]}
          rows={leases.map((l) => [
            <span key="c" className="font-mono text-[12px] font-semibold text-gold-300">{l.code}</span>,
            l.description,
            l.lessor || "—",
            l.termMonths,
            num(Number(l.payment)),
            num(Number(l.discountRate)),
            num(Number(l.rouAsset) - Number(l.accumulatedDepreciation)),
            num(Number(l.leaseLiability)),
            <Badge key="s" tone={l.status === "active" ? "green" : "slate"}>{l.status}</Badge>,
          ])}
          empty="No leases capitalised"
        />
      </Card>
    </div>
  );
}

/* ===================== IAS 36 ===================== */

function Ias36Desk({
  impairments,
  period,
  busy,
  run,
}: {
  impairments: Impairment[];
  period: string;
  busy: boolean;
  run: (p: Record<string, unknown>) => Promise<void>;
}) {
  const [cfs, setCfs] = useState<string[]>(["", "", "", "", ""]);
  return (
    <div className="space-y-4">
      <Card title="Impairment test" sub="Value in use is discounted; recoverable amount is the higher of the two measures">
        <form
          className="grid grid-cols-2 gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            run({
              action: "ias36.impairment_test",
              period,
              unitName: f.get("unitName"),
              unitType: f.get("unitType"),
              carryingAmount: Number(f.get("carryingAmount")),
              fairValueLessCosts: Number(f.get("fairValueLessCosts") || 0),
              cashFlows: cfs.map((c) => Number(c) || 0),
              terminalValue: Number(f.get("terminalValue") || 0),
              discountRate: Number(f.get("discountRate")),
              notes: f.get("notes"),
            });
          }}
        >
          <Field label="Asset or CGU name"><input name="unitName" className={inputCls} required placeholder="Transport fleet CGU" /></Field>
          <Field label="Level">
            <select name="unitType" className={inputCls} defaultValue="cgu">
              <option value="cgu">Cash-generating unit</option>
              <option value="asset">Individual asset</option>
            </select>
          </Field>
          <Field label="Carrying amount"><input name="carryingAmount" type="number" step="0.01" className={inputCls} required /></Field>
          <Field label="Fair value less costs of disposal"><input name="fairValueLessCosts" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Discount rate % (pre-tax)"><input name="discountRate" type="number" step="0.0001" className={inputCls} required /></Field>
          <Field label="Terminal / disposal value"><input name="terminalValue" type="number" step="0.01" className={inputCls} /></Field>
          <div className="col-span-2">
            <span className="mb-1.5 block text-xs font-semibold text-mist-400">Forecast pre-tax cash flows by year</span>
            <div className="flex flex-wrap gap-2">
              {cfs.map((c, i) => (
                <input
                  key={i}
                  type="number"
                  step="0.01"
                  className={inputCls + " w-28"}
                  placeholder={`Yr ${i + 1}`}
                  value={c}
                  onChange={(e) => setCfs(cfs.map((x, j) => (j === i ? e.target.value : x)))}
                />
              ))}
              <button type="button" className={btn.tiny} onClick={() => setCfs([...cfs, ""])}>+ Year</button>
            </div>
          </div>
          <Field label="Notes" className="col-span-2"><input name="notes" className={inputCls} placeholder="Basis of forecast and key assumptions" /></Field>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy}>Run impairment test</button>
          </div>
        </form>
      </Card>

      <Card title="Impairment test history" sub="Recoverable amount, basis selected, and losses posted" pad={false}>
        <SimpleTable
          cols={["Period", "Asset / CGU", "→ Carrying", "→ Value in use", "→ FV less costs", "→ Recoverable", "→ Loss", "Doc"]}
          rows={impairments.map((t) => [
            t.period,
            t.unitName,
            num(Number(t.carryingAmount)),
            num(Number(t.valueInUse)),
            num(Number(t.fairValueLessCosts)),
            num(Number(t.recoverableAmount)),
            num(Number(t.impairmentLoss)),
            t.docNo || "—",
          ])}
          empty="No impairment tests recorded"
        />
      </Card>
    </div>
  );
}

/* ===================== IFRS 5 ===================== */

function Ifrs5Desk({
  heldForSale,
  period,
  busy,
  run,
}: {
  heldForSale: Hfs[];
  period: string;
  busy: boolean;
  run: (p: Record<string, unknown>) => Promise<void>;
}) {
  return (
    <div className="space-y-4">
      <Card title="Classify as held for sale" sub="All IFRS 5.7 criteria must be met or the classification is refused">
        <form
          className="grid grid-cols-2 gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            run({
              action: "ifrs5.classify",
              period,
              assetCode: f.get("assetCode"),
              description: f.get("description"),
              originalCost: Number(f.get("originalCost")),
              accumulatedDepreciation: Number(f.get("accumulatedDepreciation") || 0),
              fairValue: Number(f.get("fairValue")),
              costsToSell: Number(f.get("costsToSell") || 0),
              committedToPlan: f.get("committedToPlan") === "on",
              activeMarketing: f.get("activeMarketing") === "on",
              expectedSaleMonths: Number(f.get("expectedSaleMonths") || 12),
              discontinuedOperation: f.get("discontinuedOperation") === "on",
              expectedSaleDate: f.get("expectedSaleDate"),
            });
            e.currentTarget.reset();
          }}
        >
          <Field label="Asset code"><input name="assetCode" className={inputCls} required placeholder="FA-0012" /></Field>
          <Field label="Description"><input name="description" className={inputCls} required placeholder="Ex-Accra warehouse" /></Field>
          <Field label="Original cost"><input name="originalCost" type="number" step="0.01" className={inputCls} required /></Field>
          <Field label="Accumulated depreciation"><input name="accumulatedDepreciation" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Fair value"><input name="fairValue" type="number" step="0.01" className={inputCls} required /></Field>
          <Field label="Costs to sell"><input name="costsToSell" type="number" step="0.01" className={inputCls} /></Field>
          <Field label="Sale expected within (months)"><input name="expectedSaleMonths" type="number" min={1} className={inputCls} defaultValue={9} /></Field>
          <Field label="Expected sale date"><input name="expectedSaleDate" type="date" className={inputCls} /></Field>
          <div className="col-span-2 space-y-2 rounded-lg border border-ink-700 bg-ink-900/40 p-3 text-[12.5px] text-mist-300">
            <label className="flex items-start gap-2">
              <input type="checkbox" name="committedToPlan" defaultChecked className="mt-0.5 h-4 w-4 accent-gold-400" />
              <span>Management is committed to a plan to sell, and the asset is available for immediate sale</span>
            </label>
            <label className="flex items-start gap-2">
              <input type="checkbox" name="activeMarketing" defaultChecked className="mt-0.5 h-4 w-4 accent-gold-400" />
              <span>An active programme to locate a buyer is under way at a reasonable price</span>
            </label>
            <label className="flex items-start gap-2">
              <input type="checkbox" name="discontinuedOperation" className="mt-0.5 h-4 w-4 accent-gold-400" />
              <span>This is a separate major line of business or geographical area (discontinued operation)</span>
            </label>
          </div>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy}>Classify as held for sale</button>
          </div>
        </form>
      </Card>

      <Card title="Assets held for sale" sub="Measured at the lower of carrying amount and fair value less costs to sell" pad={false}>
        <SimpleTable
          cols={["Asset", "Description", "→ Carrying", "→ FV less costs", "→ Write-down", "Type", "Status"]}
          rows={heldForSale.map((h) => [
            <span key="c" className="font-mono text-[12px] font-semibold text-gold-300">{h.assetCode}</span>,
            h.description,
            num(Number(h.carryingAmount)),
            num(Number(h.fairValueLessCosts)),
            num(Number(h.writeDown)),
            h.discontinuedOperation ? <Badge key="d" tone="ad">discontinued</Badge> : <Badge key="h" tone="mm">held for sale</Badge>,
            <Badge key="s" tone={h.status === "held_for_sale" ? "amber" : h.status === "disposed" ? "green" : "slate"}>{h.status.replace("_", " ")}</Badge>,
          ])}
          empty="No assets held for sale"
        />
      </Card>

      <Card title="Complete a disposal" sub="De-recognises the held-for-sale asset and records the gain or loss">
        <form
          className="grid grid-cols-3 gap-3 items-end"
          onSubmit={(e) => {
            e.preventDefault();
            const f = new FormData(e.currentTarget);
            run({
              action: "ifrs5.dispose",
              id: Number(f.get("id")),
              proceeds: Number(f.get("proceeds")),
              costsToSell: Number(f.get("costsToSell") || 0),
              period,
            });
          }}
        >
          <Field label="Held-for-sale record">
            <select name="id" className={inputCls} required>
              <option value="">— select —</option>
              {heldForSale
                .filter((h) => h.status === "held_for_sale")
                .map((h) => (
                  <option key={h.id} value={h.id}>{h.assetCode} · {h.description}</option>
                ))}
            </select>
          </Field>
          <Field label="Proceeds received"><input name="proceeds" type="number" step="0.01" className={inputCls} required /></Field>
          <Field label="Direct costs of sale"><input name="costsToSell" type="number" step="0.01" className={inputCls} /></Field>
          <div className="col-span-3 flex justify-end">
            <button className={btn.gold} disabled={busy}>Post disposal</button>
          </div>
        </form>
      </Card>
    </div>
  );
}
