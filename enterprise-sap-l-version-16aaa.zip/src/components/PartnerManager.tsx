"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, Badge, cn } from "./ui";

type Partner = {
  bpNo: string; name: string; type: string; tin: string; phone: string; email: string;
  defaultExpenseAccount: string;
};

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export function PartnerManager({ partners }: { partners: Partner[] }) {
  const router = useRouter();
  const [list, setList] = useState(partners);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ bpNo: "", name: "", type: "Vendor", tin: "", phone: "", email: "" });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const shown = list.filter(
    (p) =>
      (filter === "all" || p.type === filter) &&
      (!search || `${p.bpNo} ${p.name} ${p.tin}`.toLowerCase().includes(search.toLowerCase()))
  );

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setMsg(null);
    const d = await post({ action: "create_partner", ...form });
    setBusy(false);
    if (d.ok) {
      setList([...list, { ...form, bpNo: form.bpNo.toUpperCase(), email: form.email, defaultExpenseAccount: "" }]);
      setMsg(d.message);
      setForm({ bpNo: "", name: "", type: form.type, tin: "", phone: "", email: "" });
      setAdding(false);
      router.refresh();
    } else setError(d.error);
  }

  const tone = (t: string) => (t === "Vendor" ? "mm" : t === "Customer" ? "sd" : "hr");

  return (
    <Card
      title={`Business Partners (${list.length})`}
      sub="Customers, suppliers and employees — each workspace keeps its own list. These are the parties you select on every invoice, order and payroll run."
      action={
        <button className={btn.gold} onClick={() => setAdding(!adding)}>
          {adding ? "Close" : <><Icon name="plus" size={15} /> Add partner</>}
        </button>
      }
    >
      {msg && <div className="mb-3 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">{msg}</div>}
      {error && <div className="mb-3 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">{error}</div>}

      {adding && (
        <form onSubmit={save} className="mb-4 grid grid-cols-2 gap-3 rounded-lg border border-gold-400/25 bg-gold-400/5 p-3">
          <Field label="Type">
            <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="Vendor">Supplier (vendor)</option>
              <option value="Customer">Customer</option>
              <option value="Employee">Employee</option>
            </select>
          </Field>
          <Field label="Code" hint="Short reference, e.g. V010 or C007">
            <input className={inputCls + " font-mono text-xs uppercase"} value={form.bpNo} onChange={(e) => setForm({ ...form, bpNo: e.target.value.toUpperCase() })} required />
          </Field>
          <Field label="Name" className="col-span-2">
            <input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </Field>
          <Field label="TIN / tax number">
            <input className={inputCls + " font-mono text-xs"} value={form.tin} onChange={(e) => setForm({ ...form, tin: e.target.value })} />
          </Field>
          <Field label="Phone">
            <input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label="Email" className="col-span-2">
            <input type="email" className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <div className="col-span-2 flex justify-end gap-2">
            <button type="button" className={btn.ghost} onClick={() => setAdding(false)}>Cancel</button>
            <button type="submit" className={btn.gold} disabled={busy}>{busy ? "Saving…" : "Save partner"}</button>
          </div>
        </form>
      )}

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <input className={inputCls + " max-w-xs"} placeholder="Search code, name or TIN…" value={search} onChange={(e) => setSearch(e.target.value)} />
        {["all", "Vendor", "Customer", "Employee"].map((f) => (
          <button key={f} className={cn(btn.tiny, filter === f && "border-gold-400/50 text-gold-300")} onClick={() => setFilter(f)}>
            {f === "all" ? "All" : f + "s"}
          </button>
        ))}
      </div>

      <div className="max-h-[560px] overflow-y-auto rounded-lg border border-ink-700">
        <table className="w-full">
          <thead className="sticky top-0 bg-ink-850">
            <tr className="border-b border-ink-700">
              <th className="px-3 py-2 text-left text-[12.5px] font-bold uppercase tracking-wider text-mist-500">Code</th>
              <th className="px-3 py-2 text-left text-[12.5px] font-bold uppercase tracking-wider text-mist-500">Name</th>
              <th className="px-3 py-2 text-left text-[12.5px] font-bold uppercase tracking-wider text-mist-500">Type</th>
              <th className="px-3 py-2 text-left text-[12.5px] font-bold uppercase tracking-wider text-mist-500">TIN</th>
              <th className="px-3 py-2 text-left text-[12.5px] font-bold uppercase tracking-wider text-mist-500">Contact</th>
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && (
              <tr><td colSpan={5} className="px-3 py-6 text-center text-sm text-mist-500">No partners match. Add one above.</td></tr>
            )}
            {shown.map((p) => (
              <tr key={p.bpNo} className="border-b border-ink-800/60 last:border-0 hover:bg-ink-800/40">
                <td className="px-3 py-2 font-mono text-[12px] font-semibold text-gold-300">{p.bpNo}</td>
                <td className="px-3 py-2 text-[13px] text-mist-200">{p.name}</td>
                <td className="px-3 py-2"><Badge tone={tone(p.type)}>{p.type}</Badge></td>
                <td className="px-3 py-2 font-mono text-[12.5px] text-mist-500">{p.tin || "—"}</td>
                <td className="px-3 py-2 text-[12.5px] text-mist-500">{p.phone || p.email || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
