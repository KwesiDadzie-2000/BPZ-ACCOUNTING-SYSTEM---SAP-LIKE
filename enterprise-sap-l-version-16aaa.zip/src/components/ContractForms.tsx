"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, cn, Badge } from "./ui";
import { num } from "@/lib/format";

export type MethodOpt = { code: string; label: string; note: string };

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export function ContractForms({
  partnerOptions,
  ccOptions,
  methodOptions,
  sectorOptions,
  contractOptions,
  vendorOptions,
}: {
  partnerOptions: { value: string; label: string }[];
  ccOptions: { value: string; label: string }[];
  methodOptions: MethodOpt[];
  sectorOptions: { value: string; label: string }[];
  contractOptions: { value: string; label: string }[];
  vendorOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [tab, setTab] = useState<
    "create" | "cost" | "recognise" | "certificate" | "revise" | "retention"
  >("create");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [breakdown, setBreakdown] = useState<string | null>(null);

  // create
  const [c, setC] = useState({
    title: "", counterparty: "", totalValue: "", estimatedCost: "",
    method: "cost_to_cost", startDate: "", endDate: "", cc: "",
    retentionPct: "10", sector: "construction", advance: "",
  });

  // cost
  const [costContract, setCostContract] = useState("");
  const [costAmount, setCostAmount] = useState("");
  const [costAccount, setCostAccount] = useState("505000");
  const [costVendor, setCostVendor] = useState("");
  const [costVat, setCostVat] = useState(true);
  const [costDesc, setCostDesc] = useState("");
  const [costPeriod, setCostPeriod] = useState("");

  // recognise
  const [recContract, setRecContract] = useState("");
  const [recPeriod, setRecPeriod] = useState("");
  const [surveyedPct, setSurveyedPct] = useState("");

  // certificate
  const [certContract, setCertContract] = useState("");
  const [certPeriod, setCertPeriod] = useState("");
  const [certGross, setCertGross] = useState("");
  const [certPct, setCertPct] = useState("");

  // revise
  const [revContract, setRevContract] = useState("");
  const [revValue, setRevValue] = useState("");
  const [revCost, setRevCost] = useState("");
  const [revPeriod, setRevPeriod] = useState("");
  const [revDesc, setRevDesc] = useState("");
  const [revApprover, setRevApprover] = useState("");

  // retention
  const [retContract, setRetContract] = useState("");
  const [retAmount, setRetAmount] = useState("");
  const [retPeriod, setRetPeriod] = useState("");

  function reset() {
    setC({ ...c, title: "", totalValue: "", estimatedCost: "", advance: "" });
  }

  async function run(payload: Record<string, unknown>) {
    setBusy(true); setError(null); setMsg(null); setBreakdown(null);
    const d = await post(payload);
    setBusy(false);
    if (d.ok) {
      setMsg(d.message);
      if (d.revenue !== undefined)
        setBreakdown(
          `Revenue ₵${num(d.revenue)} · cost ₵${num(d.cost)} · profit ₵${num(d.profit)} · ${d.pctComplete}% complete · contract asset ₵${num(d.contractAsset)} · contract liability ₵${num(d.contractLiability)}`
        );
      router.refresh();
    } else setError(d.error);
  }

  return (
    <Card
      title="Contract Workbench"
      sub="Create the contract, record costs as incurred, recognise revenue at each period end, then raise certificates for certified work."
      action={
        <div className="flex flex-wrap gap-1.5">
          {([
            ["create", "New contract"],
            ["cost", "Record cost"],
            ["recognise", "Recognise revenue"],
            ["certificate", "Raise certificate"],
            ["revise", "Variation / estimate"],
            ["retention", "Release retention"],
          ] as const).map(
            ([id, label]) => (
              <button key={id} className={cn(btn.tiny, tab === id && "border-gold-400/50 text-gold-300")} onClick={() => setTab(id)}>
                {label}
              </button>
            )
          )}
        </div>
      }
    >
      {msg && (
        <div className="mb-3 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2.5 text-[12.5px] text-pos">
          <div className="font-semibold">{msg}</div>
          {breakdown && <div className="mt-1 font-mono text-[11.5px] text-mist-400">{breakdown}</div>}
        </div>
      )}
      {error && <div className="mb-3 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-[12.5px] text-neg">{error}</div>}

      {tab === "create" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({
              action: "save_contract", ...c,
              totalValue: Number(c.totalValue), estimatedCost: Number(c.estimatedCost),
              retentionPct: Number(c.retentionPct), advance: Number(c.advance) || 0,
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract / project title" className="col-span-2">
            <input className={inputCls} value={c.title} onChange={(e) => setC({ ...c, title: e.target.value })} placeholder="e.g. Kumasi Inner Ring Road – Phase 2" required />
          </Field>
          <Field label="Customer">
            <select className={inputCls} value={c.counterparty} onChange={(e) => setC({ ...c, counterparty: e.target.value })} required>
              <option value="">— select —</option>
              {partnerOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Sector">
            <select className={inputCls} value={c.sector} onChange={(e) => setC({ ...c, sector: e.target.value })}>
              {sectorOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Contract value (GHS)">
            <input type="number" step="0.01" min={0.01} className={inputCls} value={c.totalValue} onChange={(e) => setC({ ...c, totalValue: e.target.value })} required />
          </Field>
          <Field label="Estimated total cost (GHS)" hint="Drives cost-to-cost progress — required by IFRS 15">
            <input type="number" step="0.01" min={0.01} className={inputCls} value={c.estimatedCost} onChange={(e) => setC({ ...c, estimatedCost: e.target.value })} required />
          </Field>
          <Field label="Start date">
            <input type="date" className={inputCls} value={c.startDate} onChange={(e) => setC({ ...c, startDate: e.target.value })} />
          </Field>
          <Field label="End date" hint="Multi-year contracts are expected">
            <input type="date" className={inputCls} value={c.endDate} onChange={(e) => setC({ ...c, endDate: e.target.value })} />
          </Field>
          <Field label="Recognition method" className="col-span-2">
            <select className={inputCls} value={c.method} onChange={(e) => setC({ ...c, method: e.target.value })}>
              {methodOptions.map((m) => (
                <option key={m.code} value={m.code}>{m.label}</option>
              ))}
            </select>
          </Field>
          <div className="col-span-2 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] leading-relaxed text-mist-400">
            {methodOptions.find((m) => m.code === c.method)?.note}
          </div>
          <Field label="Retention %">
            <input type="number" step="0.5" min={0} max={50} className={inputCls} value={c.retentionPct} onChange={(e) => setC({ ...c, retentionPct: e.target.value })} />
          </Field>
          <Field label="Mobilisation advance (GHS)" hint="Received on signature — becomes a contract liability">
            <input type="number" step="0.01" min={0} className={inputCls} value={c.advance} onChange={(e) => setC({ ...c, advance: e.target.value })} />
          </Field>
          <Field label="Cost centre">
            <select className={inputCls} value={c.cc} onChange={(e) => setC({ ...c, cc: e.target.value })}>
              <option value="">— none —</option>
              {ccOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <div className="flex items-end">
            <button className={btn.gold} disabled={busy}>
              {busy ? "Creating…" : <><Icon name="plus" size={15} /> Open contract</>}
            </button>
          </div>
        </form>
      )}

      {tab === "cost" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({
              action: "record_contract_cost",
              contractId: Number(costContract),
              amount: Number(costAmount),
              account: costAccount,
              vendor: costVendor || undefined,
              vat: !!costVendor && costVat,
              description: costDesc,
              period: costPeriod,
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract" className="col-span-2">
            <select className={inputCls} value={costContract} onChange={(e) => setCostContract(e.target.value)} required>
              <option value="">— select a contract —</option>
              {contractOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Amount (GHS)">
            <input type="number" step="0.01" min={0.01} className={inputCls} value={costAmount} onChange={(e) => setCostAmount(e.target.value)} required />
          </Field>
          <Field label="Period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={costPeriod} onChange={(e) => setCostPeriod(e.target.value)} required />
          </Field>
          <Field label="Nature of cost">
            <select className={inputCls} value={costAccount} onChange={(e) => setCostAccount(e.target.value)}>
              <option value="505000">Contract costs (materials, labour, plant)</option>
              <option value="506000">Fuel, power & site utilities</option>
              <option value="530000">Site repairs & maintenance</option>
              <option value="561000">Site transport & logistics</option>
            </select>
          </Field>
          <Field
            label="Supplier (optional)"
            hint="Leave blank only for an accrual with no supplier invoice yet"
          >
            <select
              className={inputCls}
              value={costVendor}
              onChange={(e) => setCostVendor(e.target.value)}
            >
              <option value="">Accrue the cost (no supplier yet)</option>
              {vendorOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          {costVendor && (
            <label className="col-span-2 flex items-start gap-2 rounded-lg border border-ink-700 bg-ink-900/55 px-3 py-2.5 text-[12.5px] text-mist-300">
              <input
                type="checkbox"
                checked={costVat}
                onChange={(e) => setCostVat(e.target.checked)}
                className="mt-0.5 h-4 w-4 accent-gold-400"
              />
              <span>
                Supplier invoice includes 20% recoverable VAT. The net amount drives
                project progress; VAT is posted separately and the gross amount goes to AP.
              </span>
            </label>
          )}
          <Field label="Description" className="col-span-2">
            <input className={inputCls} value={costDesc} onChange={(e) => setCostDesc(e.target.value)} placeholder="e.g. Cement and reinforcement – week 14" required />
          </Field>
          <div className="col-span-2 flex items-center justify-between">
            <span className="text-[11.5px] text-mist-500">Costs incurred increase the cost-to-cost measure of progress.</span>
            <button className={btn.gold} disabled={busy || !costContract}>{busy ? "Posting…" : "Record cost"}</button>
          </div>
        </form>
      )}

      {tab === "recognise" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({ action: "recognise_revenue", contractId: Number(recContract), period: recPeriod, surveyedPct: surveyedPct || undefined });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract" className="col-span-2">
            <select className={inputCls} value={recContract} onChange={(e) => setRecContract(e.target.value)} required>
              <option value="">— select a contract —</option>
              {contractOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Recognition period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={recPeriod} onChange={(e) => setRecPeriod(e.target.value)} required />
          </Field>
          <Field label="Certified % complete (optional)" hint="Only for surveyor / input measurement">
            <input type="number" step="0.1" min={0} max={100} className={inputCls} value={surveyedPct} onChange={(e) => setSurveyedPct(e.target.value)} placeholder="auto" />
          </Field>
          <div className="col-span-2 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] leading-relaxed text-mist-400">
            Posts cumulative performance revenue less previously recognised. Contract costs are already expensed
            when incurred; the resulting margin therefore uses actual cost, not a manufactured estimate. Advances
            and billings offset performance to derive one net contract asset or liability.
          </div>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy || !recContract}>{busy ? "Posting…" : "Recognise revenue"}</button>
          </div>
        </form>
      )}

      {tab === "certificate" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({
              action: "raise_certificate",
              contractId: Number(certContract),
              period: certPeriod,
              grossValue: certGross || undefined,
              surveyedPct: certPct || undefined,
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract" className="col-span-2">
            <select className={inputCls} value={certContract} onChange={(e) => setCertContract(e.target.value)} required>
              <option value="">— select a contract —</option>
              {contractOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Certificate period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={certPeriod} onChange={(e) => setCertPeriod(e.target.value)} required />
          </Field>
          <Field label="Certified % complete" hint="Defaults to the contract's measured progress">
            <input type="number" step="0.1" min={0} max={100} className={inputCls} value={certPct} onChange={(e) => setCertPct(e.target.value)} placeholder="auto" />
          </Field>
          <Field label="Gross value certified (GHS)" className="col-span-2" hint="Leave blank to derive from % complete less already certified">
            <input type="number" step="0.01" min={0} className={inputCls} value={certGross} onChange={(e) => setCertGross(e.target.value)} placeholder="auto" />
          </Field>
          <div className="col-span-2 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] leading-relaxed text-mist-400">
            Raises an IPC, allocates billing against the contract asset first, records overbilling as a contract
            liability, deducts retention, and opens the net amount at the Payment Desk.
          </div>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy || !certContract}>{busy ? "Raising…" : "Raise certificate"}</button>
          </div>
        </form>
      )}

      {tab === "revise" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({
              action: "revise_contract",
              contractId: Number(revContract),
              newValue: Number(revValue),
              newEstimatedCost: Number(revCost),
              period: revPeriod,
              description: revDesc,
              approvedBy: revApprover,
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract" className="col-span-2">
            <select className={inputCls} value={revContract} onChange={(e) => setRevContract(e.target.value)} required>
              <option value="">— select a contract —</option>
              {contractOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Revised contract value (GHS)">
            <input type="number" min={0.01} step="0.01" className={inputCls} value={revValue} onChange={(e) => setRevValue(e.target.value)} required />
          </Field>
          <Field label="Revised estimated total cost (GHS)">
            <input type="number" min={0.01} step="0.01" className={inputCls} value={revCost} onChange={(e) => setRevCost(e.target.value)} required />
          </Field>
          <Field label="Effective period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={revPeriod} onChange={(e) => setRevPeriod(e.target.value)} required />
          </Field>
          <Field label="Approved by">
            <input className={inputCls} value={revApprover} onChange={(e) => setRevApprover(e.target.value)} placeholder="Client QS / Project Director" required />
          </Field>
          <Field label="Variation / revision reason" className="col-span-2">
            <input className={inputCls} value={revDesc} onChange={(e) => setRevDesc(e.target.value)} placeholder="Approved variation order, updated EAC, scope change…" required />
          </Field>
          <div className="col-span-2 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] leading-relaxed text-mist-400">
            The revision is retained in the contract audit schedule. If the revised estimated cost exceeds the
            transaction price, the provision increases immediately; if the risk reduces, the excess is released.
          </div>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy || !revContract}>Save approved revision</button>
          </div>
        </form>
      )}

      {tab === "retention" && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            run({
              action: "release_retention",
              contractId: Number(retContract),
              amount: retAmount || undefined,
              period: retPeriod,
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <Field label="Contract" className="col-span-2">
            <select className={inputCls} value={retContract} onChange={(e) => setRetContract(e.target.value)} required>
              <option value="">— select a contract —</option>
              {contractOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
          <Field label="Release period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={retPeriod} onChange={(e) => setRetPeriod(e.target.value)} required />
          </Field>
          <Field label="Amount (blank = all outstanding)">
            <input type="number" min={0} step="0.01" className={inputCls} value={retAmount} onChange={(e) => setRetAmount(e.target.value)} placeholder="all outstanding" />
          </Field>
          <div className="col-span-2 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12px] leading-relaxed text-mist-400">
            Use only when the certificate terms make retention due—normally practical completion or expiry of the
            defects-liability period. The released amount becomes an open receivable at the Payment Desk.
          </div>
          <div className="col-span-2 flex justify-end">
            <button className={btn.gold} disabled={busy || !retContract}>Release retention</button>
          </div>
        </form>
      )}
    </Card>
  );
}
