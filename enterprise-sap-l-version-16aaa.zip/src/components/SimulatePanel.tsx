"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Icon, btn, cn, ModuleTag } from "./ui";
import type { SimStep } from "@/lib/posting";

const DEPARTMENTS = [
  { m: "MM", text: "PO → Goods Receipt → Vendor Invoice" },
  { m: "SD", text: "SO → Customer Invoice → Payment" },
  { m: "HR", text: "Payroll runs + salary payments" },
  { m: "FI-AA", text: "Vehicle acquisition + depreciation" },
  { m: "ADMIN", text: "Insurance claim + settlement" },
  { m: "FI", text: "Manual month-end accrual" },
];

function StepLog({ steps }: { steps: SimStep[] }) {
  return (
    <div className="mt-4 max-h-80 overflow-y-auto rounded-lg border border-ink-700 bg-ink-950/70 p-3">
      <div className="mb-2 flex items-center gap-2 text-[12px] font-bold uppercase tracking-[0.16em] text-mist-600">
        <Icon name="journal" size={12} />
        Posting feed
      </div>
      <div className="space-y-1.5">
        {steps.map((s, i) => (
          <div key={i} className="log-row flex items-baseline gap-2.5 font-mono text-[12.5px] leading-relaxed" style={{ animationDelay: `${i * 60}ms` }}>
            <ModuleTag m={s.module} />
            <span className="text-mist-300">{s.label}</span>
            <span className="text-mist-600">— {s.detail}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function SimulatePanel({ variant = "bar" }: { variant?: "hero" | "bar" }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [steps, setSteps] = useState<SimStep[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function run() {
    setBusy(true);
    setError(null);
    setSteps(null);
    setNotice(null);
    try {
      const res = await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "simulate" }),
      });
      const data = await res.json();
      if (data.ok) {
        setSteps(data.steps ?? []);
        setNotice(data.message ?? "Simulation complete.");
        router.refresh();
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not reach the posting service.");
    }
    setBusy(false);
  }

  async function reset() {
    setResetting(true);
    setError(null);
    try {
      const res = await fetch("/api/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reset" }),
      });
      const data = await res.json();
      if (data.ok) {
        setSteps(null);
        setNotice(data.message ?? "Reset complete.");
        setConfirmReset(false);
        router.refresh();
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not reach the posting service.");
    }
    setResetting(false);
  }

  const statusBlock = (
    <div className="space-y-2">
      {steps && <StepLog steps={steps} />}
      {notice && !steps && (
        <div className="flex items-start gap-2 rounded-lg border border-sd/30 bg-sd/10 px-3 py-2 text-xs text-sd">
          <Icon name="check" size={14} className="mt-px shrink-0" />
          <span>{notice}</span>
        </div>
      )}
      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
          <Icon name="x" size={14} className="mt-px shrink-0" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );

  if (variant === "hero") {
    return (
      <Card className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-400/60 to-transparent" />
        <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-md border border-gold-400/30 bg-gold-400/10 px-2.5 py-1 text-[12.5px] font-bold uppercase tracking-[0.18em] text-gold-300">
              <Icon name="bolt" size={13} />
              One click · Six departments · One journal
            </div>
            <h2 className="font-display text-[26px] font-semibold leading-tight text-mist-100">
              The books are open.
            </h2>
            <p className="mt-2 max-w-lg text-sm leading-relaxed text-mist-500">
              No postings in the Universal Journal yet. Run a full business day across the
              organisation — procurement, sales, payroll, assets, insurance and finance all post
              into the same ACDOCA table, exactly like SAP&apos;s Universal Journal.
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <button className={btn.gold} onClick={run} disabled={busy}>
                {busy ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" />
                ) : (
                  <Icon name="play" size={15} />
                )}
                {busy ? "Posting 13 documents…" : "Simulate a full business day"}
              </button>
              <span className="text-xs text-mist-600">13 balanced journal documents, one transaction.</span>
            </div>
          </div>
          <div>
            <div className="mb-2 text-[12px] font-bold uppercase tracking-[0.16em] text-mist-600">
              What runs
            </div>
            <ul className="divide-y divide-ink-800 rounded-lg border border-ink-700 bg-ink-900/50">
              {DEPARTMENTS.map((d) => (
                <li key={d.m} className="flex items-center gap-3 px-3 py-2.5">
                  <ModuleTag m={d.m} />
                  <span className="text-xs text-mist-400">{d.text}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-5">{statusBlock}</div>
      </Card>
    );
  }

  return (
    <Card
      title="Run the organisation"
      sub="Simulate a full day of cross-department activity — or clear the books."
    >
      <div className="flex flex-wrap items-center gap-3">
        <button className={btn.gold} onClick={run} disabled={busy}>
          {busy ? (
            <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" />
          ) : (
            <Icon name="play" size={15} />
          )}
          {busy ? "Posting…" : "Simulate business day"}
        </button>
        {confirmReset ? (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-neg">Wipe journal & order books?</span>
            <button className={cn(btn.danger, "px-3 py-1.5 text-xs")} onClick={reset} disabled={resetting}>
              {resetting ? "Clearing…" : "Yes, reset"}
            </button>
            <button className={cn(btn.ghost, "px-3 py-1.5 text-xs")} onClick={() => setConfirmReset(false)}>
              Cancel
            </button>
          </div>
        ) : (
          <button className={btn.danger} onClick={() => setConfirmReset(true)} disabled={resetting}>
            <Icon name="reset" size={14} />
            Reset data
          </button>
        )}
      </div>
      {statusBlock}
    </Card>
  );
}
