"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btn, inputCls, cn } from "./ui";
import { num } from "@/lib/format";

export function PaymentRow({
  invoice,
  isSales,
  whtOptions,
  rateNow,
  period,
}: {
  invoice: { id: number; no: string; bp: string; total: string; paid: string; status: string; currency: string; period: string; docType: string };
  isSales: boolean;
  whtOptions: { value: string; label: string; rate: number }[];
  rateNow: number;
  period: string;
}) {
  const router = useRouter();
  const total = Number(invoice.total);
  const paid = Number(invoice.paid);
  const balance = Math.abs(total - paid);
  const [amount, setAmount] = useState(String(balance.toFixed(2)));
  const [wht, setWht] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pay() {
    setBusy(true);
    setError(null);
    const res = await fetch("/api/actions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "pay_invoice",
        invoiceId: invoice.id,
        amount: Number(amount) || 0,
        currency: invoice.currency,
        rateNow,
        whtName: wht || undefined,
        period,
      }),
    });
    const data = await res.json();
    setBusy(false);
    if (data.ok) {
      router.refresh();
    } else setError(data.error);
  }

  const whtRate = whtOptions.find((w) => w.value === wht)?.rate ?? 0;

  return (
    <div className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
      <div className="flex flex-wrap items-center gap-3">
        <a
          href={`/invoices/${invoice.id}/print`}
          className="font-mono text-[13px] font-semibold text-gold-300 underline-offset-2 hover:underline"
          target="_blank"
          rel="noreferrer"
        >
          {invoice.no}
        </a>
        <span className="font-mono text-[12px] text-mist-400">{invoice.bp}</span>
        <span className={cn("text-[12.5px] uppercase", invoice.currency !== "GHS" ? "text-mm" : "text-mist-600")}>
          {invoice.currency}
          {invoice.currency !== "GHS" && ` @ ${num(rateNow)}`}
        </span>
        <span className="ml-auto font-mono text-[13px] tabular-nums text-mist-300">
          Paid {num(paid)} / {num(Math.abs(total))}
        </span>
        <span className="font-mono text-[13px] font-bold tabular-nums text-gold-300">Due {num(balance)}</span>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        <input
          type="number"
          step="0.01"
          min={0.01}
          max={balance}
          className={inputCls + " w-32 text-right font-mono text-xs"}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        {!isSales && (
          <select className={inputCls + " w-56 text-xs"} value={wht} onChange={(e) => setWht(e.target.value)}>
            <option value="">No withholding tax</option>
            {whtOptions.map((w) => (
              <option key={w.value} value={w.value}>{w.label}</option>
            ))}
          </select>
        )}
        {wht && (
          <span className="text-[12.5px] text-mist-500">
            WHT ≈ <span className="font-mono text-aa">₵{num(((Number(amount) || 0) * whtRate) / 100)}</span>
          </span>
        )}
        <button className={btn.tiny} onClick={pay} disabled={busy}>
          {busy ? "Posting…" : `Pay ${Number(amount) >= balance - 0.009 ? "in full" : "partial"}`}
        </button>
        <span className="text-[12px] text-mist-600">Bank 101000 · FX gain/loss auto-recognised if cedi moved</span>
      </div>
      {error && <div className="mt-2 text-[12.5px] text-neg">{error}</div>}
    </div>
  );
}
