"use client";

import { useRouter } from "next/navigation";
import { btn, cn } from "./ui";
import { WORKSPACE_COOKIE } from "@/lib/cookie-names";

export function OpenWorkspace({ id, code }: { id: number; code: string }) {
  const router = useRouter();

  function open() {
    document.cookie = `${WORKSPACE_COOKIE}=${id}; path=/; max-age=31536000`;
    router.push("/");
    router.refresh();
  }

  return (
    <button className={cn(btn.tiny, "border-gold-400/40 text-gold-300 hover:border-gold-400/70")} onClick={open}>
      Open {code}
    </button>
  );
}
