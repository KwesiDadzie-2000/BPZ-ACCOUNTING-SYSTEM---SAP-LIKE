"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, btn, Icon, cn } from "./ui";

type Check = { id: string; area: string; name: string; status: "pass" | "fail" | "warn"; detail: string; evidence?: string };

export function AssuranceRunner({ initial }: { initial: Check[] }) {
  const router = useRouter();
  const [checks, setChecks] = useState<Check[]>(initial);
  const [busy, setBusy] = useState(false);
  const [ranAt, setRanAt] = useState<string>("");

  async function run() {
    setBusy(true);
    try {
      const res = await fetch("/api/assurance", { method: "POST" });
      const data = await res.json();
      if (data.ok) {
        setChecks(data.checks);
        setRanAt(new Date().toLocaleString("en-GB"));
        router.refresh();
      }
    } finally {
      setBusy(false);
    }
  }

  const passed = checks.filter((c) => c.status === "pass").length;
  const failed = checks.filter((c) => c.status === "fail").length;
  const warned = checks.filter((c) => c.status === "warn").length;
  const verdict = failed > 0 ? "fail" : warned > 0 ? "warn" : "pass";

  const areas = [...new Set(checks.map((c) => c.area))];

  return (
    <div className="space-y-4">
      <Card
        title="System Assurance Suite"
        sub="Fifteen automated control tests run live against the database — the same evidence an external auditor would ask for."
        action={
          <div className="flex items-center gap-2">
            <a className={btn.ghost} href="/api/assurance?mode=snapshot">
              <Icon name="download" size={15} /> Snapshot
            </a>
            <button className={btn.gold} onClick={run} disabled={busy}>
              {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="check" size={15} />}
              {busy ? "Running…" : "Run all tests"}
            </button>
          </div>
        }
      >
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className={cn("rounded-xl border px-4 py-3", verdict === "pass" ? "border-pos/40 bg-pos/10" : verdict === "warn" ? "border-aa/40 bg-aa/10" : "border-neg/40 bg-neg/10")}>
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">Overall verdict</div>
            <div className={cn("mt-1 font-display text-lg font-extrabold", verdict === "pass" ? "text-pos" : verdict === "warn" ? "text-aa" : "text-neg")}>
              {verdict === "pass" ? "ALL CONTROLS OK" : verdict === "warn" ? "ATTENTION" : "ACTION REQUIRED"}
            </div>
          </div>
          <div className="rounded-xl border border-ink-700 bg-ink-850/80 px-4 py-3">
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">Passed</div>
            <div className="mt-1 font-display text-lg font-extrabold text-pos">{passed}</div>
          </div>
          <div className="rounded-xl border border-ink-700 bg-ink-850/80 px-4 py-3">
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">Warnings</div>
            <div className="mt-1 font-display text-lg font-extrabold text-aa">{warned}</div>
          </div>
          <div className="rounded-xl border border-ink-700 bg-ink-850/80 px-4 py-3">
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-mist-500">Failed</div>
            <div className="mt-1 font-display text-lg font-extrabold text-neg">{failed}</div>
          </div>
        </div>
        {ranAt && <p className="mt-3 text-[12.5px] text-mist-600">Last run {ranAt} — every run is written to the immutable audit log.</p>}
      </Card>

      {areas.map((area) => (
        <Card key={area} title={area} pad={false}>
          <div className="divide-y divide-ink-800">
            {checks.filter((c) => c.area === area).map((c) => (
              <div key={c.id} className="flex items-start gap-3 px-4 py-3">
                <span
                  className={cn(
                    "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[12.5px] font-bold",
                    c.status === "pass" ? "bg-pos/20 text-pos" : c.status === "warn" ? "bg-aa/20 text-aa" : "bg-neg/20 text-neg"
                  )}
                >
                  {c.status === "pass" ? "✓" : c.status === "warn" ? "!" : "✕"}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-semibold text-mist-100">{c.name}</div>
                  <div className="mt-0.5 text-[12.5px] leading-relaxed text-mist-500">{c.detail}</div>
                  {c.evidence && <div className="mt-1 font-mono text-[12px] text-mist-600">{c.evidence}</div>}
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}
