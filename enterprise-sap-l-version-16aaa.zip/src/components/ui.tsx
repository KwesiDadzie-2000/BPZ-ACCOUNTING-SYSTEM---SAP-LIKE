import type { ReactNode } from "react";
import { money } from "@/lib/format";

export function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}

// ------------------------------------------------------------
// Icons (inline SVG only)
// ------------------------------------------------------------

const ICONS: Record<string, ReactNode> = {
  dashboard: (
    <>
      <rect x="3" y="3" width="7.5" height="7.5" rx="1.5" />
      <rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5" />
      <rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5" />
      <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5" />
    </>
  ),
  journal: (
    <>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4H6.5A2.5 2.5 0 0 0 4 6.5v13Z" />
      <path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5" />
      <path d="M9 8h7M9 12h5" />
    </>
  ),
  cart: (
    <>
      <circle cx="9.5" cy="20" r="1.4" />
      <circle cx="17.5" cy="20" r="1.4" />
      <path d="M3 4h2.2l2.5 11.6a1 1 0 0 0 1 .7h9a1 1 0 0 0 1-.8L20.5 8H6" />
    </>
  ),
  tag: (
    <>
      <path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8Z" />
      <circle cx="7.5" cy="7.5" r="1.1" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.4" />
      <path d="M2.8 20c.8-3.1 3.3-4.9 6.2-4.9s5.4 1.8 6.2 4.9" />
      <path d="M15.8 4.9a3.4 3.4 0 0 1 0 6.3M17.9 15.4c1.8.7 2.8 2.3 3.1 4.6" />
    </>
  ),
  truck: (
    <>
      <path d="M2 7h11.5v10.5H2z" />
      <path d="M13.5 10.5h3.9l2.9 3v4h-6.8" />
      <circle cx="6.2" cy="17.7" r="1.6" />
      <circle cx="17" cy="17.7" r="1.6" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2.5 4.5 5.4v6c0 4.6 3.2 8 7.5 10 4.3-2 7.5-5.4 7.5-10v-6L12 2.5Z" />
      <path d="m8.8 11.6 2.2 2.2 4.2-4.4" />
    </>
  ),
  pen: (
    <>
      <path d="M12.5 20.5H21" />
      <path d="M16.7 3.6a2.1 2.1 0 0 1 3 3L7.5 18.8 3 20l1.2-4.5L16.7 3.6Z" />
    </>
  ),
  chart: (
    <>
      <path d="M3.5 3.5v17h17" />
      <path d="M8 16.5v-5M12.5 16.5v-9M17 16.5v-3" />
    </>
  ),
  database: (
    <>
      <ellipse cx="12" cy="5.5" rx="7.5" ry="3" />
      <path d="M4.5 5.5V12c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V5.5" />
      <path d="M4.5 12v6.5c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V12" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  x: <path d="m6 6 12 12M18 6 6 18" />,
  check: <path d="m4.5 12.5 5 5 10-11" />,
  download: (
    <>
      <path d="M12 3.5v10.5m0 0 4-4m-4 4-4-4" />
      <path d="M4 17v2.3A1.7 1.7 0 0 0 5.7 21h12.6a1.7 1.7 0 0 0 1.7-1.7V17" />
    </>
  ),
  play: <path d="M7.5 4.8v14.4L19 12 7.5 4.8Z" />,
  reset: (
    <>
      <path d="M3 4.5v5h5" />
      <path d="M4.2 14.5a8.5 8.5 0 1 0 .6-7L3 9.5" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20.5 20.5-4-4" />
    </>
  ),
  back: <path d="M19 12H5.5m0 0 5.5-5.5M5.5 12 11 17.5" />,
  bolt: <path d="M13 2.5 4.8 13.5h6L9.5 21.5 18.7 10h-6l.3-7.5Z" />,
  doc: (
    <>
      <path d="M14 2.5H6.5A1.5 1.5 0 0 0 5 4v16a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 20V7.5L14 2.5Z" />
      <path d="M14 2.5V7.5H19M9 12.5h6M9 16h6" />
    </>
  ),
  building: (
    <>
      <rect x="4" y="3" width="16" height="18" rx="1.5" />
      <path d="M8 7.5h2M14 7.5h2M8 11.5h2M14 11.5h2M8 15.5h2M14 15.5h2M10.5 21v-3h3v3" />
    </>
  ),
  card: (
    <>
      <rect x="2.5" y="5.5" width="19" height="13" rx="2" />
      <path d="M2.5 10h19M6 14.5h4" />
    </>
  ),
  box: (
    <>
      <path d="M21 8.2 12 3.5 3 8.2v7.6l9 4.7 9-4.7V8.2Z" />
      <path d="M3 8.2 12 12.9l9-4.7M12 12.9v7.6" />
    </>
  ),
  scale: (
    <>
      <path d="M12 4v17M7 21h10M5 7l2.5-3M19 7l-2.5-3M5 7h14" />
      <path d="M5 7 2.5 12.5a3 3 0 0 0 5 0L5 7ZM19 7l-2.5 5.5a3 3 0 0 0 5 0L19 7Z" />
    </>
  ),
  book: (
    <>
      <path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v17.5H7.5A2.5 2.5 0 0 0 5 22V4.5Z" />
      <path d="M5 19.5A2.5 2.5 0 0 1 7.5 17H19M9 6.5h6M9 10h4" />
    </>
  ),
};

export function Icon({
  name,
  size = 16,
  className,
}: {
  name: string;
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {ICONS[name] ?? null}
    </svg>
  );
}

// ------------------------------------------------------------
// Badges & tags
// ------------------------------------------------------------

export type Tone = "slate" | "gold" | "mm" | "sd" | "hr" | "aa" | "ad" | "fi" | "green" | "red" | "amber";

const TONES: Record<Tone, string> = {
  slate: "border-mist-500/25 bg-mist-500/10 text-mist-300",
  gold: "border-gold-400/30 bg-gold-400/10 text-gold-300",
  mm: "border-mm/25 bg-mm/10 text-mm",
  sd: "border-sd/25 bg-sd/10 text-sd",
  hr: "border-hr/25 bg-hr/10 text-hr",
  aa: "border-aa/25 bg-aa/10 text-aa",
  ad: "border-ad/25 bg-ad/10 text-ad",
  fi: "border-fi/25 bg-fi/10 text-fi",
  green: "border-sd/25 bg-sd/10 text-sd",
  red: "border-neg/30 bg-neg/10 text-neg",
  amber: "border-aa/25 bg-aa/10 text-aa",
};

export function Badge({
  tone = "slate",
  children,
  className,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-md border px-1.5 py-0.5 font-mono text-[12.5px] font-semibold tracking-wide",
        TONES[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

const MODULES: Record<string, { label: string; tone: Tone }> = {
  MM: { label: "Procurement", tone: "mm" },
  SD: { label: "Sales", tone: "sd" },
  HR: { label: "Payroll", tone: "hr" },
  "FI-AA": { label: "Fixed Assets", tone: "aa" },
  ADMIN: { label: "Insurance", tone: "ad" },
  FI: { label: "Finance", tone: "fi" },
};

export function ModuleTag({ m }: { m: string }) {
  const meta = MODULES[m] ?? { label: m, tone: "slate" as Tone };
  return (
    <span title={meta.label} className="inline-flex items-center">
      <Badge tone={meta.tone}>{m}</Badge>
    </span>
  );
}

const STATUS_CLS: Record<string, Tone> = {
  Open: "slate",
  "Goods Received": "mm",
  Invoiced: "amber",
  Paid: "green",
};

export function StatusBadge({ status }: { status: string }) {
  return <Badge tone={STATUS_CLS[status] ?? "slate"}>{status}</Badge>;
}

// ------------------------------------------------------------
// Layout primitives
// ------------------------------------------------------------

export function Card({
  title,
  sub,
  action,
  children,
  className,
  pad = true,
}: {
  title?: ReactNode;
  sub?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  pad?: boolean;
}) {
  return (
    <section className={cn("rounded-xl border border-ink-700 bg-ink-850/80", className)}>
      {(title || action) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-700/70 px-4 py-3">
          <div className="min-w-0">
            <h3 className="font-display text-sm font-semibold tracking-wide text-mist-100">{title}</h3>
            {sub && <p className="mt-0.5 truncate text-xs text-mist-500">{sub}</p>}
          </div>
          {action && <div className="flex items-center gap-2">{action}</div>}
        </header>
      )}
      <div className={pad ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: string;
}) {
  return (
    <div className="rounded-xl border border-ink-700 bg-ink-850/80 px-4 py-3.5">
      <div className="text-[12.5px] font-semibold uppercase tracking-[0.14em] text-mist-500">{label}</div>
      <div className={cn("mt-1.5 font-display text-[22px] font-semibold leading-tight tabular-nums", tone ?? "text-mist-100")}>
        {value}
      </div>
      {sub && <div className="mt-1 text-xs text-mist-500">{sub}</div>}
    </div>
  );
}

export function PageHeader({
  kicker,
  title,
  desc,
  children,
}: {
  kicker?: ReactNode;
  title: string;
  desc?: string;
  children?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        {kicker && (
          <div className="mb-1.5 text-[12.5px] font-bold uppercase tracking-[0.2em] text-gold-400">{kicker}</div>
        )}
        <h1 className="font-display text-[26px] font-semibold leading-tight text-mist-100">{title}</h1>
        {desc && <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-mist-500">{desc}</p>}
      </div>
      {children && <div className="flex flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

export function EmptyState({
  icon = "database",
  title,
  body,
  children,
  className,
}: {
  icon?: string;
  title: string;
  body?: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-xl border border-dashed border-ink-600/80 bg-ink-850/40 px-6 py-12 text-center",
        className
      )}
    >
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-lg border border-ink-600 bg-ink-800 text-mist-500">
        <Icon name={icon} size={20} />
      </div>
      <h3 className="font-display text-base font-semibold text-mist-300">{title}</h3>
      {body && <p className="mt-1.5 max-w-md text-sm leading-relaxed text-mist-500">{body}</p>}
      {children && <div className="mt-4 flex flex-wrap items-center justify-center gap-2">{children}</div>}
    </div>
  );
}

export function Bar({ pct, cls }: { pct: number; cls?: string }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-800">
      <div
        className={cn("h-full rounded-full transition-all duration-500", cls ?? "bg-gold-400")}
        style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
      />
    </div>
  );
}

// ------------------------------------------------------------
// Forms
// ------------------------------------------------------------

export function Field({
  label,
  children,
  className,
  hint,
}: {
  label: string;
  children: ReactNode;
  className?: string;
  hint?: string;
}) {
  return (
    <label className={cn("block min-w-0", className)}>
      <span className="mb-1.5 block text-xs font-semibold text-mist-400">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[12.5px] text-mist-600">{hint}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-lg border border-ink-600 bg-ink-900/70 px-3 py-2 text-sm text-mist-100 placeholder:text-mist-600 outline-none transition focus:border-gold-400/60 focus:ring-2 focus:ring-gold-400/15";

export const btn = {
  gold: "inline-flex items-center justify-center gap-2 rounded-lg bg-gold-400 px-4 py-2 text-sm font-semibold text-brand-navy shadow-[0_0_18px_-6px_rgba(242,178,62,0.5)] transition hover:bg-gold-500 disabled:cursor-not-allowed disabled:opacity-40",
  ghost:
    "inline-flex items-center justify-center gap-2 rounded-lg border border-ink-600 bg-ink-800/60 px-3.5 py-2 text-sm font-medium text-mist-300 transition hover:border-mist-500/40 hover:text-mist-100 disabled:cursor-not-allowed disabled:opacity-40",
  danger:
    "inline-flex items-center justify-center gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3.5 py-2 text-sm font-medium text-neg transition hover:bg-neg/20 disabled:cursor-not-allowed disabled:opacity-40",
  tiny:
    "inline-flex items-center justify-center gap-1.5 rounded-md border border-ink-600 bg-ink-800/70 px-2.5 py-1.5 text-xs font-semibold text-mist-300 transition hover:border-mist-500/40 hover:text-mist-100 disabled:cursor-not-allowed disabled:opacity-35",
};

// ------------------------------------------------------------
// Table helpers
// ------------------------------------------------------------

export const thCls =
  "px-3 py-2.5 text-left text-[12.5px] font-bold uppercase tracking-[0.12em] text-mist-500";
export const tdCls = "px-3 py-2.5 align-middle text-sm text-mist-300";
export const numCls = "px-3 py-2.5 text-right font-mono text-[13px] tabular-nums";
export const rowCls = "border-b border-ink-800/70 transition-colors hover:bg-ink-800/40";

export function Money({
  value,
  className,
  signed,
}: {
  value: number;
  className?: string;
  signed?: boolean;
}) {
  return (
    <span className={cn("font-mono tabular-nums", className)}>
      {signed && value > 0 ? "+" : ""}
      {money(value)}
    </span>
  );
}

export function ExportLink({ sheet, label = "Export CSV" }: { sheet: string; label?: string }) {
  return (
    <a href={`/api/export?sheet=${sheet}`} className={btn.ghost} download>
      <Icon name="download" size={15} />
      {label}
    </a>
  );
}
