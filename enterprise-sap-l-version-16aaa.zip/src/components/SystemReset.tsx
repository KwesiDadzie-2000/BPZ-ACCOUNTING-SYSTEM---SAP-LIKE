"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, btn, inputCls, Icon } from "./ui";

export function SystemReset() {
  const router = useRouter();
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function reset() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reset_system", confirm }),
    });
    const data = await res.json();
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message);
      setConfirm("");
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="System Reset (owner only)" sub="Wipes every workspace's journal, order books, invoices, bank lines, assets, payroll, budgets, fees and workpapers. Logins, users and master data are preserved.">
      <div className="flex flex-wrap items-center gap-3">
        <input
          className={inputCls + " w-40 font-mono text-xs uppercase"}
          placeholder='Type RESET'
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
        />
        <button className={btn.danger} onClick={reset} disabled={busy || confirm !== "RESET"}>
          <Icon name="reset" size={14} />
          {busy ? "Resetting…" : "Reset the entire system"}
        </button>
        {error && <span className="text-xs text-neg">{error}</span>}
        {success && <span className="text-xs text-pos">{success}</span>}
      </div>
    </Card>
  );
}
