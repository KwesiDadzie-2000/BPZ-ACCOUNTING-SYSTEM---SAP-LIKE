"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { btn, cn } from "./ui";

export function ClearErrors() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);

  async function clear() {
    setBusy(true);
    try {
      await fetch("/api/diagnostics", { method: "POST" });
      setConfirm(false);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  if (!confirm) {
    return (
      <button className={cn(btn.tiny, "hover:border-neg/40 hover:text-neg")} onClick={() => setConfirm(true)}>
        Clear log
      </button>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <button className={cn(btn.danger, "px-2.5 py-1 text-[12px]")} onClick={clear} disabled={busy}>
        {busy ? "Clearing…" : "Confirm"}
      </button>
      <button className={cn(btn.tiny, "px-2.5 py-1 text-[12px]")} onClick={() => setConfirm(false)}>
        Cancel
      </button>
    </div>
  );
}
