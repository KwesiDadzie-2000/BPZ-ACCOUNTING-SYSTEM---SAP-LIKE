"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, cn } from "./ui";
import { num } from "@/lib/format";

type Category = {
  code: string;
  label: string;
  nonProcurement: boolean;
  accounts: { accountNo: string; label: string }[];
  guidance: string;
};

type Partner = { bpNo: string; name: string };

async function post(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

export function ExpenseDesk({
  categories,
  partners,
  ccOptions,
  bankOptions,
}: {
  categories: Category[];
  partners: Partner[];
  ccOptions: { value: string; label: string }[];
  bankOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const statutory = categories.filter((c) => c.nonProcurement);
  const [cat, setCat] = useState("utilities");
  const [account, setAccount] = useState(statutory[0]?.accounts[0]?.accountNo ?? "");
  const [amount, setAmount] = useState("");
  const [desc, setDesc] = useState("");
  const [bp, setBp] = useState("");
  const [cc, setCc] = useState("");
  const [period, setPeriod] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const active = categories.find((c) => c.code === cat);

  function pick(code: string) {
    setCat(code);
    const c = categories.find((x) => x.code === code);
    if (c?.accounts[0]) setAccount(c.accounts[0].accountNo);
    setError(null);
    setMsg(null);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setMsg(null);
    const d = await post({
      action: "post_expense",
      expenseCategory: cat,
      expenseAccount: account,
      amount: Number(amount),
      description: desc,
      bp: bp || undefined,
      cc: cc || undefined,
      period: period || undefined,
    });
    setBusy(false);
    if (d.ok) {
      setMsg(d.message);
      setAmount("");
      setDesc("");
      router.refresh();
    } else setError(d.error);
  }

  return (
    <Card
      title="Expense & Statutory Payments"
      sub="Utilities, taxes, pensions, insurance, regulatory fees, penalties and finance costs — posted straight to the expense account. These never enter the procurement cycle."
    >
      <div className="mb-3 flex flex-wrap gap-1.5">
        {statutory.map((c) => (
          <button
            key={c.code}
            type="button"
            onClick={() => pick(c.code)}
            className={cn(
              "rounded-lg border px-3 py-2 text-[12.5px] font-semibold transition",
              cat === c.code
                ? "border-gold-400 bg-gold-400/15 text-gold-300"
                : "border-ink-600 text-mist-300 hover:border-gold-400/40 hover:text-mist-100"
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {active && (
        <div className="mb-3 rounded-lg border border-ink-700 bg-ink-900/50 px-3 py-2 text-[12.5px] leading-relaxed text-mist-400">
          <span className="font-bold text-gold-300">Why no PO: </span>
          {active.guidance}
        </div>
      )}

      <form onSubmit={submit} className="grid grid-cols-2 gap-3">
        <Field label="Amount (GHS)">
          <input type="number" step="0.01" min={0.01} className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} required />
        </Field>
        <Field label="Fiscal period">
          <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} required />
        </Field>
        <Field label="Expense account" className="col-span-2" hint="Where the cost belongs in the profit and loss account">
          <select className={inputCls} value={account} onChange={(e) => setAccount(e.target.value)}>
            {active?.accounts.map((a) => (
              <option key={a.accountNo} value={a.accountNo}>{a.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Description" className="col-span-2">
          <input className={inputCls} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="e.g. ECG electricity – November, GRA VAT for Q4, SSNIT Tier 2" required />
        </Field>
        <Field label="Paid to (optional)" hint="Select the authority or provider if you track them as a partner">
          <select className={inputCls} value={bp} onChange={(e) => setBp(e.target.value)}>
            <option value="">— none —</option>
            {partners.map((p) => (
              <option key={p.bpNo} value={p.bpNo}>{p.bpNo} · {p.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Cost centre (optional)">
          <select className={inputCls} value={cc} onChange={(e) => setCc(e.target.value)}>
            <option value="">— none —</option>
            {ccOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </Field>

        <div className="col-span-2 rounded-lg border border-gold-400/25 bg-gold-400/5 p-3">
          <span className="text-[12px] font-bold uppercase tracking-wider text-gold-300">What happens next</span>
          <p className="mt-1.5 text-[11.5px] leading-relaxed text-mist-400">
            The bill is charged to the expense account and credited to <strong>Accounts Payable</strong>, so it shows
            in your aging like any other bill. You then pay it from the{" "}
            <strong>Payment Desk</strong> — in full or in part, immediately or when you choose. Nothing is taken from
            the bank at this step.
          </p>
        </div>

        <div className="col-span-2 flex items-center justify-between gap-3 pt-1">
          <span className="font-mono text-[13px] text-mist-300">
            {amount && <>₵{num(Number(amount))} to {active?.accounts.find((a) => a.accountNo === account)?.label.split("·")[0].trim()}</>}
          </span>
          <button className={btn.gold} disabled={busy}>
            {busy ? "Raising bill…" : <><Icon name="doc" size={15} /> Raise bill</>}
          </button>
        </div>

        {msg && <div className="col-span-2 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">{msg}</div>}
        {error && <div className="col-span-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">{error}</div>}
      </form>
    </Card>
  );
}
