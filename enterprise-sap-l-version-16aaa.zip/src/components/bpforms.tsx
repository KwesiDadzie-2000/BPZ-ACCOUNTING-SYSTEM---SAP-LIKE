"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls, cn, StatusBadge } from "./ui";
import { num } from "@/lib/format";

async function postAction(payload: Record<string, unknown>) {
  const res = await fetch("/api/actions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  return res.json();
}

function Feedback({ error, success, busy }: { error: string | null; success: string | null; busy?: boolean }) {
  return (
    <>
      {error && (
        <div className="col-span-2 flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
          <Icon name="x" size={14} className="mt-px shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="col-span-2 flex items-start gap-2 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs text-pos">
          <Icon name="check" size={14} className="mt-px shrink-0" />
          <span>{success}</span>
        </div>
      )}
      {busy && null}
    </>
  );
}

// ----------------------------------------------------------------
// Invoice / quote / credit note / debit note
// ----------------------------------------------------------------
export function InvoiceForm({
  direction,
  bpOptions,
  currencies,
  vatRate = 20,
  expenseOptions,
  ccOptions,
}: {
  direction: "sales" | "purchase";
  bpOptions: { value: string; label: string }[];
  currencies: { value: string; label: string }[];
  vatRate?: number;
  expenseOptions?: { value: string; label: string }[];
  ccOptions?: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [docType, setDocType] = useState<"quote" | "invoice" | "credit" | "debit">("quote");
  const [bp, setBp] = useState("");
  const [currency, setCurrency] = useState("GHS");
  const [amount, setAmount] = useState("");
  const [vat, setVat] = useState(true);
  const [note, setNote] = useState("");
  const [period, setPeriod] = useState("");
  const [expenseAccount, setExpenseAccount] = useState("");
  const [cc, setCc] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showNewBp, setShowNewBp] = useState(false);
  const [newBp, setNewBp] = useState({ code: "", name: "", type: direction === "sales" ? "Customer" : "Vendor", tin: "", phone: "" });
  const [bpList, setBpList] = useState(bpOptions);

  const sub = Number(amount) || 0;
  const v = sub * (vatRate / 100);

  async function createPartner() {
    setBusy(true); setError(null); setSuccess(null);
    const res = await fetch("/api/actions", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create_partner", ...newBp }),
    });
    const data = await res.json();
    setBusy(false);
    if (data.ok) {
      setBpList([...bpList, { value: newBp.code.toUpperCase(), label: `${newBp.code.toUpperCase()} · ${newBp.name}` }]);
      setBp(newBp.code.toUpperCase());
      setSuccess(data.message);
      setShowNewBp(false);
      setNewBp({ code: "", name: "", type: direction === "sales" ? "Customer" : "Vendor", tin: "", phone: "" });
      router.refresh();
    } else setError(data.error);
  }

  async function submit() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const data = await postAction({
      action: "save_invoice", direction, docType, bp, currency,
      subtotal: sub, vat, note, period: period || undefined,
    });
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message);
      setAmount("");
      setNote("");
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title={direction === "sales" ? "Customer Document" : "Supplier Document"} sub={`Quote · Invoice · Credit note · Debit note — VAT @ ${vatRate}% (no cascading)`}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Document type" className="col-span-2">
          <div className="flex gap-1.5">
            {(["quote", "invoice", "credit", "debit"] as const).map((t) => (
              <button key={t} type="button" onClick={() => setDocType(t)} className={cn("flex-1 rounded-md border px-2 py-1.5 text-xs font-semibold capitalize transition", docType === t ? "border-gold-400/60 bg-gold-400/15 text-gold-300" : "border-ink-600 text-mist-500 hover:text-mist-300")}>
                {t === "credit" ? "Credit note" : t === "debit" ? "Debit note" : t}
              </button>
            ))}
          </div>
        </Field>
        <Field label={direction === "sales" ? "Customer" : "Supplier"}>
          <select className={inputCls} value={bp} onChange={(e) => setBp(e.target.value)}>
            <option value="">— select —</option>
            {bpList.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Not in the list?">
          <button type="button" className={cn(inputCls, "text-left text-xs font-semibold text-gold-300 hover:text-gold-400")} onClick={() => setShowNewBp(!showNewBp)}>
            + Add a new {direction === "sales" ? "customer" : "supplier"}
          </button>
        </Field>

        {showNewBp && (
          <div className="col-span-2 grid grid-cols-2 gap-2 rounded-lg border border-gold-400/25 bg-gold-400/5 p-3">
            <Field label="Code" hint="e.g. V010 / C007">
              <input className={inputCls + " font-mono text-xs uppercase"} value={newBp.code} onChange={(e) => setNewBp({ ...newBp, code: e.target.value.toUpperCase() })} />
            </Field>
            <Field label="Name">
              <input className={inputCls} value={newBp.name} onChange={(e) => setNewBp({ ...newBp, name: e.target.value })} />
            </Field>
            <Field label="TIN (optional)">
              <input className={inputCls + " font-mono text-xs"} value={newBp.tin} onChange={(e) => setNewBp({ ...newBp, tin: e.target.value })} />
            </Field>
            <Field label="Phone (optional)">
              <input className={inputCls} value={newBp.phone} onChange={(e) => setNewBp({ ...newBp, phone: e.target.value })} />
            </Field>
            <div className="col-span-2 flex justify-end">
              <button type="button" className={btn.tiny} onClick={createPartner} disabled={busy || !newBp.code || !newBp.name}>
                Save {direction === "sales" ? "customer" : "supplier"}
              </button>
            </div>
          </div>
        )}

        {direction === "purchase" && expenseOptions && (
          <Field label="Expense account" className="col-span-2" hint="Materials go to stock or COGS; services, rent, utilities to their own account — this drives the profit-and-loss analysis">
            <select className={inputCls} value={expenseAccount} onChange={(e) => setExpenseAccount(e.target.value)}>
              <option value="">599000 · General &amp; Administrative (default)</option>
              {expenseOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
        )}

        {ccOptions && (
          <Field label="Cost centre" className="col-span-2" hint="Department or project that owns this cost or earns this revenue">
            <select className={inputCls} value={cc} onChange={(e) => setCc(e.target.value)}>
              <option value="">— none —</option>
              {ccOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </Field>
        )}
        <Field label="Currency">
          <select className={inputCls} value={currency} onChange={(e) => setCurrency(e.target.value)}>
            {currencies.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
        </Field>
        <Field label={`Amount (ex VAT, ${currency})`}>
          <input type="number" min={0} step="0.01" className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" />
        </Field>
        <Field label="Fiscal period">
          <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} />
        </Field>
        <label className="flex items-end gap-2 pb-2 text-xs font-semibold text-mist-400">
          <input type="checkbox" checked={vat} onChange={(e) => setVat(e.target.checked)} className="accent-gold-400" />
          Apply VAT {vatRate}%
        </label>
        <Field label="Note" className="col-span-2">
          <input type="text" className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Order #, delivery terms" />
        </Field>
        <div className="col-span-2 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-ink-900/50 px-3 py-2.5">
          <div className="font-mono text-xs tabular-nums text-mist-400">
            Subtotal {num(sub)} · VAT {num(v)} · <span className="text-sm font-bold text-mist-100">Total {num(docType === "credit" ? -(sub + v) : sub + v)}</span>
          </div>
          <button className={btn.gold} onClick={submit} disabled={busy}>
            {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="doc" size={15} />}
            {busy ? "Saving…" : "Save document"}
          </button>
        </div>
        <Feedback error={error} success={success} />
      </div>
    </Card>
  );
}

// ----------------------------------------------------------------
// Ghana payroll run
// ----------------------------------------------------------------
export function PayrollForm({
  employees,
  ccOptions,
}: {
  employees: { value: string; label: string; basic: number }[];
  ccOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [bpNo, setBpNo] = useState("");
  const [basic, setBasic] = useState("");
  const [allowance, setAllowance] = useState("");
  const [cc, setCc] = useState("");
  const [period, setPeriod] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);

  function pick(e: React.ChangeEvent<HTMLSelectElement>) {
    setBpNo(e.target.value);
    const emp = employees.find((x) => x.value === e.target.value);
    if (emp && !basic) setBasic(String(emp.basic));
  }

  async function submit() {
    setBusy(true);
    setError(null);
    setResult(null);
    const data = await postAction({ action: "run_payroll_gh", bpNo, basic: Number(basic), allowance: Number(allowance) || 0, cc: cc || undefined, period: period || undefined });
    setBusy(false);
    if (data.ok) {
      setResult(
        `${data.message} Gross ${num(data.gross)} · PAYE ${num(data.paye)} · SSNIT ${num(data.ssnit)} · NHIL ${num(data.nhil)} · Housing ${num(data.housing)} · Net ${num(data.net)} (employer +${num(data.employer)})`
      );
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="Run Ghana Payroll" sub="PAYE bands (effective 1 Sep 2026) · SSNIT T1 5.5% + T2 5%/13% capped · NHIL 2.5% · Housing 5% on basic — all editable in Admin">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Employee" className="col-span-2">
          <select className={inputCls} value={bpNo} onChange={pick}>
            <option value="">— select —</option>
            {employees.map((e) => (
              <option key={e.value} value={e.value}>{e.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Basic salary (editable per period)" hint="Last saved value is pre-filled">
          <input type="number" min={0} step="0.01" className={inputCls} value={basic} onChange={(e) => setBasic(e.target.value)} />
        </Field>
        <Field label="Allowance / other pay">
          <input type="number" min={0} step="0.01" className={inputCls} value={allowance} onChange={(e) => setAllowance(e.target.value)} placeholder="0.00" />
        </Field>
        <Field label="Cost center">
          <select className={inputCls} value={cc} onChange={(e) => setCc(e.target.value)}>
            <option value="">— select —</option>
            {ccOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Pay period (month)">
          <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} required />
        </Field>
        <div className="col-span-2 flex justify-end">
          <button className={btn.gold} onClick={submit} disabled={busy}>
            {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="users" size={15} />}
            {busy ? "Computing…" : "Compute & post payroll"}
          </button>
        </div>
        <Feedback error={error} success={result} />
      </div>
    </Card>
  );
}

// ----------------------------------------------------------------
// Bank statement import (CSV parsed in browser)
// ----------------------------------------------------------------
export function BankImportForm({ accounts }: { accounts: { value: string; label: string }[] }) {
  const router = useRouter();
  const [accountId, setAccountId] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!accountId) {
      setError("Pick the bank account first.");
      return;
    }
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      const text = await file.text();
      const lines: { date?: string; description?: string; amount?: number; ref?: string }[] = [];
      const rows = text.split(/\r?\n/).map((r) => r.trim()).filter(Boolean);
      const hasHeader = /date/i.test(rows[0] ?? "");
      for (const row of hasHeader ? rows.slice(1) : rows) {
        const parts = row.split(",").map((p) => p.trim().replace(/^"|"$/g, ""));
        if (parts.length >= 3) {
          lines.push({ date: parts[0], description: parts.slice(1, parts.length - 1).join(","), amount: Number(parts[parts.length - 1].replace(/[^0-9.-]/g, "")), ref: parts[0] });
        }
      }
      const data = await postAction({ action: "import_bank_lines", accountId: Number(accountId), lines });
      if (data.ok) {
        setSuccess(data.message);
        router.refresh();
      } else setError(data.error);
    } catch {
      setError("Could not parse the file. Expected CSV columns: date, description, amount.");
    }
    setBusy(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  return (
    <Card title="Import Bank Statement" sub="CSV: date, description, amount — imported lines land in Reconciliation as unmatched">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Bank account">
          <select className={inputCls} value={accountId} onChange={(e) => setAccountId(e.target.value)}>
            <option value="">— select —</option>
            {accounts.map((a) => (
              <option key={a.value} value={a.value}>{a.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Statement file (.csv)">
          <input ref={fileRef} type="file" accept=".csv,text/csv" onChange={onFile} className="w-full text-xs text-mist-400 file:mr-3 file:rounded-md file:border-0 file:bg-gold-400 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-brand-navy" />
        </Field>
        <Feedback error={error} success={success} busy={busy} />
      </div>
    </Card>
  );
}

// ----------------------------------------------------------------
// Reconciliation row (match / unmatch / edit)
// ----------------------------------------------------------------
export function BankLineRow({
  line,
  journalOptions,
}: {
  line: { id: number; ref: string; txnDate: string; description: string; amount: string; status: string; note: string; journalLineId: number | null };
  journalOptions: { value: string; label: string }[];
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [edit, setEdit] = useState(false);
  const [desc, setDesc] = useState(line.description);
  const [amt, setAmt] = useState(line.amount);

  async function act(payload: Record<string, unknown>) {
    setBusy(true);
    setError(null);
    const data = await postAction(payload);
    setBusy(false);
    if (data.ok) {
      router.refresh();
      setEdit(false);
    } else setError(data.error);
  }

  return (
    <div className="rounded-lg border border-ink-700/70 bg-ink-900/40 p-3">
      {edit ? (
        <div className="grid grid-cols-2 gap-2">
          <input className={inputCls} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Description" />
          <input className={inputCls} value={amt} onChange={(e) => setAmt(e.target.value)} placeholder="Amount" />
          <button className={btn.tiny} onClick={() => act({ action: "edit_bank_line", id: line.id, description: desc, amount: amt })} disabled={busy}>
            Save edit
          </button>
          <button className={btn.tiny} onClick={() => setEdit(false)}>Cancel</button>
        </div>
      ) : (
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-mono text-[12.5px] text-mist-500">{line.txnDate}</span>
          <span className="min-w-0 flex-1 truncate text-[13px] text-mist-300">{line.description || line.ref || "—"}</span>
          <span className={cn("font-mono text-[13px] tabular-nums", Number(line.amount) >= 0 ? "text-pos" : "text-neg")}>{num(Number(line.amount))}</span>
          <StatusBadge status={line.status === "matched" ? "Paid" : "Open"} />
        </div>
      )}
      {!edit && (
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {line.status === "unmatched" ? (
            <select
              className="rounded-md border border-ink-600 bg-ink-950/60 px-2 py-1 text-[12.5px] text-mist-400"
              onChange={(e) => e.target.value && act({ action: "match_bank_line", id: line.id, journalLineId: Number(e.target.value) })}
              defaultValue=""
              disabled={busy}
            >
              <option value="">Match to journal line…</option>
              {journalOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          ) : (
            <button className={btn.tiny} onClick={() => act({ action: "unmatch_bank_line", id: line.id })} disabled={busy}>
              Unmatch
            </button>
          )}
          <button className={btn.tiny} onClick={() => setEdit(true)}>Edit</button>
          {line.journalLineId && <span className="font-mono text-[12px] text-mist-600">→ journal line #{line.journalLineId}</span>}
        </div>
      )}
      {error && <div className="mt-2 text-[12.5px] text-neg">{error}</div>}
    </div>
  );
}

// ----------------------------------------------------------------
// Budget & scenario editor
// ----------------------------------------------------------------
export function BudgetEditor({ accountOptions }: { accountOptions: { value: string; label: string }[] }) {
  const router = useRouter();
  const [year, setYear] = useState(String(new Date().getFullYear()));
  const [scenario, setScenario] = useState("Base");
  const [lines, setLines] = useState<{ account: string; amount: string }[]>([{ account: "", amount: "" }, { account: "", amount: "" }]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function save() {
    setBusy(true);
    setError(null);
    setSuccess(null);
    const data = await postAction({
      action: "save_budget", fiscalYear: Number(year), scenarioName: scenario,
      lines: lines.map((l) => ({ account: l.account, amount: Number(l.amount) || 0 })),
    });
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message);
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="Set Budget / Scenario" sub="Budgets feed the variance report (Budgets & Scenarios page). Scenarios: Base, Upside, Downside — unlimited.">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Fiscal year">
          <input type="number" min={2000} max={2100} className={inputCls + " font-mono text-xs"} value={year} onChange={(e) => setYear(e.target.value)} />
        </Field>
        <Field label="Scenario name">
          <input type="text" className={inputCls} value={scenario} onChange={(e) => setScenario(e.target.value)} placeholder="Base / Upside / Downside" />
        </Field>
        {lines.map((l, idx) => (
          <div key={idx} className="col-span-2 grid grid-cols-[1fr_140px_32px] items-center gap-2">
            <select className={inputCls} value={l.account} onChange={(e) => setLines(lines.map((x, i) => (i === idx ? { ...x, account: e.target.value } : x)))}>
              <option value="">— account —</option>
              {accountOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
            </select>
            <input type="number" className={inputCls} value={l.amount} onChange={(e) => setLines(lines.map((x, i) => (i === idx ? { ...x, amount: e.target.value } : x)))} placeholder="Amount (GHS)" />
            <button className="rounded-md border border-ink-600 p-2 text-mist-500 hover:text-neg disabled:opacity-30" disabled={lines.length <= 2} onClick={() => setLines(lines.filter((_, i) => i !== idx))}>
              <Icon name="x" size={13} />
            </button>
          </div>
        ))}
        <button className="text-xs font-semibold text-mist-500 hover:text-gold-300" onClick={() => setLines([...lines, { account: "", amount: "" }])}>
          + Add budget line
        </button>
        <div className="col-span-2 flex justify-end">
          <button className={btn.gold} onClick={save} disabled={busy}>
            {busy ? <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="scale" size={15} />}
            {busy ? "Saving…" : "Save budget"}
          </button>
        </div>
        <Feedback error={error} success={success} />
      </div>
    </Card>
  );
}
