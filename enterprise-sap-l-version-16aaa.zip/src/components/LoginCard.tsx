"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Icon, btn, inputCls } from "./ui";

export function LoginCard({
  mustChange = false,
  pending2fa = false,
  ticket = "",
}: {
  mustChange?: boolean;
  pending2fa?: boolean;
  ticket?: string;
}) {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [code, setCode] = useState("");
  const [twoFa, setTwoFa] = useState(pending2fa);
  const [twoFaTicket, setTwoFaTicket] = useState(ticket);
  const [recoverMode, setRecoverMode] = useState(false);
  const [recUser, setRecUser] = useState("");
  const [recCode, setRecCode] = useState("");
  const [recPw, setRecPw] = useState("");
  const [recovered, setRecovered] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (data.ok && data.needs2fa) {
        setTwoFa(true);
        setTwoFaTicket(data.ticket as string);
        setError(null);
      } else if (data.ok) {
        if (data.mustChange) {
          setError("First login detected — set a new password to continue.");
        } else {
          router.push("/");
          router.refresh();
        }
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not reach the sign-in service.");
    }
    setBusy(false);
  }

  async function doRecover(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null); setRecovered(null);
    try {
      const res = await fetch("/api/auth/recovery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "recover", username: recUser, recovery: recCode, nextPassword: recPw }),
      });
      const data = await res.json();
      if (data.ok) {
        setRecovered(data.message as string);
        setRecoverMode(false);
      } else setError(data.error as string);
    } catch { setError("Could not verify recovery details."); }
    setBusy(false);
  }

  async function on2fa(e: React.FormEvent) {
    e.preventDefault();
    if (code.length !== 6) { setError("Enter the 6-digit code."); return; }
    setBusy(true); setError(null);
    try {
      const res = await fetch("/api/auth/2fa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticket: twoFaTicket, code }),
      });
      const data = await res.json();
      if (data.ok) { router.push("/"); router.refresh(); }
      else if (String(data.error).includes("expired")) {
        setTwoFa(false); setTwoFaTicket(""); setCode(""); setError(data.error);
      } else setError(data.error);
    } catch { setError("Could not verify the code."); }
    setBusy(false);
  }

  async function onChange(e: React.FormEvent) {
    e.preventDefault();
    if (next.length < 10) {
      setError("New password must be at least 10 characters.");
      return;
    }
    if (next !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ current: password, next }),
      });
      const data = await res.json();
      if (data.ok) {
        // Brand-new clients owe terms acceptance before any data is served;
        // sending them to "/" would only bounce them again.
        router.push("/accept-terms");
        router.refresh();
      } else {
        setError(data.error as string);
      }
    } catch {
      setError("Could not update the password.");
    }
    setBusy(false);
  }

  return (
    <>
      {recoverMode ? (
        <Card title="Regain access" sub="Use the one-time recovery code you saved when you enabled two-factor authentication">
          <form onSubmit={doRecover} className="space-y-3">
            <Field label="Username">
              <input className={inputCls} value={recUser} onChange={(e) => setRecUser(e.target.value)} placeholder="owner" required />
            </Field>
            <Field label="Recovery code">
              <input className={inputCls + " text-center font-mono tracking-[0.25em]"} value={recCode} onChange={(e) => setRecCode(e.target.value.toUpperCase())} placeholder="BPZ-XXXX-XXXX" required />
            </Field>
            <Field label="New password" hint="Minimum 10 characters, upper, lower and a digit">
              <input type="password" className={inputCls} value={recPw} onChange={(e) => setRecPw(e.target.value)} required minLength={10} />
            </Field>
            <button type="submit" className={btn.gold + " w-full"} disabled={busy}>
              {busy ? "Verifying…" : "Restore access"}
            </button>
            <button type="button" className="w-full text-center text-xs text-mist-500 hover:text-mist-300" onClick={() => setRecoverMode(false)}>
              Back to sign in
            </button>
            {recovered && (
              <div className="rounded-lg border border-pos/30 bg-pos/10 px-3 py-2 text-xs leading-relaxed text-pos">{recovered}</div>
            )}
            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
                <Icon name="x" size={14} className="mt-px shrink-0" />
                <span>{error}</span>
              </div>
            )}
          </form>
        </Card>
      ) : twoFa ? (
        <Card title="Two-factor authentication" sub="Enter the 6-digit code from your authenticator app">
          <form onSubmit={on2fa} className="space-y-3">
            <input
              className={inputCls + " text-center font-mono text-2xl tracking-[0.5em]"}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              inputMode="numeric"
              autoFocus
              required
            />
            <button type="submit" className={btn.gold + " w-full"} disabled={busy || code.length !== 6}>
              {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" /> : <Icon name="check" size={15} />}
              {busy ? "Verifying…" : "Verify and continue"}
            </button>
            <button
              type="button"
              className="w-full text-center text-xs text-mist-500 hover:text-mist-300"
              onClick={() => { setTwoFa(false); setCode(""); setTwoFaTicket(""); }}
            >
              Back to password sign-in
            </button>
            <button
              type="button"
              className="w-full text-center text-xs text-gold-400 hover:text-gold-300"
              onClick={() => setRecoverMode(true)}
            >
              Lost your phone? Use a recovery code
            </button>
            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
                <Icon name="x" size={14} className="mt-px shrink-0" />
                <span>{error}</span>
              </div>
            )}
          </form>
        </Card>
      ) : (
      <Card title={mustChange ? "Set a new password" : "Sign in"} sub={mustChange ? "Required on first login of a new account" : "Access the BPZ enterprise platform"}>
        <form onSubmit={mustChange ? onChange : onSubmit} className="space-y-3">
          {!mustChange && (
            <Field label="Username">
              <input
                type="text"
                className={inputCls}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="owner"
                autoFocus
                autoComplete="username"
                required
              />
            </Field>
          )}
          <Field label="Password">
            <input
              type="password"
              className={inputCls}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete={mustChange ? "current-password" : "current-password"}
              required
            />
          </Field>
          {mustChange && (
            <>
              <Field label="New password" hint="Minimum 6 characters">
                <input type="password" className={inputCls} value={next} onChange={(e) => setNext(e.target.value)} required minLength={6} />
              </Field>
              <Field label="Confirm new password">
                <input type="password" className={inputCls} value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
              </Field>
            </>
          )}
          <button type="submit" className={btn.gold + " w-full"} disabled={busy}>
            {busy ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-brand-navy/30 border-t-brand-navy" />
            ) : (
              <Icon name="check" size={15} />
            )}
            {busy ? "Working…" : mustChange ? "Update password & continue" : "Sign in"}
          </button>
          {!mustChange && (
            <button
              type="button"
              className="w-full text-center text-xs text-mist-500 hover:text-gold-300"
              onClick={() => setRecoverMode(true)}
            >
              Locked out or lost your authenticator?
            </button>
          )}
          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-xs text-neg">
              <Icon name="x" size={14} className="mt-px shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </form>
      </Card>
      )
      }
      {mustChange && (
        <button className="mt-3 w-full text-center text-xs text-mist-500 hover:text-mist-300" onClick={() => router.push("/login?reset=0")}>
          Use a different account
        </button>
      )}
    </>
  );
}
