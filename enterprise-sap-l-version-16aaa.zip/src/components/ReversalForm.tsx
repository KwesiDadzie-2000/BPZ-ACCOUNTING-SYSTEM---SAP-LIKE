"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Icon, btn, inputCls, Field } from "./ui";

export function ReversalForm() {
  const router = useRouter();
  const [docNo, setDocNo] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSuccess(null);
    const res = await fetch("/api/actions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reverse_document", docNo, reason }),
    });
    const data = await res.json();
    setBusy(false);
    if (data.ok) {
      setSuccess(data.message);
      setDocNo("");
      setReason("");
      router.refresh();
    } else setError(data.error);
  }

  return (
    <Card title="Reverse a Document" sub="Mirrors every line of a posted document into a balancing reversal — a reason is mandatory and kept in the audit trail.">
      <form onSubmit={submit} className="grid grid-cols-2 gap-3">
        <Field label="Document number">
          <input className={inputCls + " font-mono text-xs"} value={docNo} onChange={(e) => setDocNo(e.target.value)} placeholder="e.g. 5000000004" required />
        </Field>
        <Field label="Reason (mandatory)">
          <input className={inputCls} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Customer disputed invoice line 2" required />
        </Field>
        <div className="col-span-2 flex justify-end">
          <button className={btn.danger} disabled={busy}>
            {busy ? "Reversing…" : "Post reversal"}
          </button>
        </div>
        {error && <div className="col-span-2 text-xs text-neg">{error}</div>}
        {success && <div className="col-span-2 text-xs text-pos">{success}</div>}
      </form>
    </Card>
  );
}
