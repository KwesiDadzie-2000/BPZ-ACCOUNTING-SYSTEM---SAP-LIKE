"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, btn, inputCls, Icon, cn } from "./ui";

type Kind = "opening_balances" | "partners" | "employees" | "assets";

const KINDS: { id: Kind; label: string; columns: string; template: string; note: string }[] = [
  {
    id: "opening_balances",
    label: "Trial balance / opening balances",
    columns: "Account, Description, Debit, Credit, CostCentre (optional), BP (optional)",
    template: `Account,Description,Debit,Credit
101000,Bank - SCB,250000,
110000,Accounts Receivable,84000,
120000,Inventory - Raw Materials,42000,
130000,Vehicles - Fixed Assets,300000,
139000,Accumulated Depreciation,,45000
200000,Accounts Payable,,61000
300000,Share Capital,,570000`,
    note: "Posts one opening journal. If debits and credits differ, a balancing line is created in Equity so you can onboard immediately and clear the difference later — it is flagged in the message.",
  },
  {
    id: "partners",
    label: "Customers & suppliers",
    columns: "Code, Name, Type (Customer/Vendor/Employee), TIN, Phone, Email",
    template: `Code,Name,Type,TIN,Phone,Email
C001,Akosua Retail Ltd,Customer,C0001,0244000001,accounts@akosua.gh
V001,Enterprise Insurance,Vendor,C0002,0244000002,premiums@enterprise.gh
V002,Auto Garage Ltd,Vendor,C0003,0244000003,service@autogarage.gh`,
    note: "Skips codes that already exist, so you can re-upload a corrected file safely.",
  },
  {
    id: "employees",
    label: "Payroll employees",
    columns: "Name, Basic, Allowances, Position, Department, Jurisdiction, TIN, SSNITNo, BankAccount",
    template: `Name,Basic,Allowances,Position,Department,Jurisdiction,TIN,SSNITNo,BankAccount
John Mensah,8000,500,Finance Manager,CC-ADM,GH,C0001,SN001,0123456789
Ama Owusu,6000,300,Sales Lead,CC-SLS,GH,C0002,SN002,0123456790`,
    note: "Jurisdiction defaults to GH (Ghana full statutory scheme). Add employees any time later — salary changes only affect future runs.",
  },
  {
    id: "assets",
    label: "Fixed asset register",
    columns: "Name, Cost, AccumulatedDepreciation, Class, CostCentre, InService",
    template: `Name,Cost,AccumulatedDepreciation,Class,CostCentre,InService
Toyota Hilux,250000,62500,GEN-VEH,CC-OPS,2023-01-15
HP Laserjet Printer,12000,4800,GEN-IT,CC-ADM,2022-06-01
Boardroom Furniture,45000,9000,GEN-FURN,CC-ADM,2021-03-10`,
    note: "Each asset is capitalised with its own journal line so the register ties to the ledger. Use classes GEN-LAND, GEN-BLDG, GEN-PLANT, GEN-VEH, GEN-IT, GEN-FURN, GEN-INTANG, GEN-CIP, or sector classes like MIN-EQ, OIL-WELL, CON-PLANT.",
  },
];

export function MigrationDesk() {
  const router = useRouter();
  const [kind, setKind] = useState<Kind>("opening_balances");
  const [csv, setCsv] = useState("");
  const [period, setPeriod] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<string | null>(null);

  const active = KINDS.find((k) => k.id === kind)!;

  function pick(id: Kind) {
    setKind(id);
    setCsv("");
    setMsg(null);
    setError(null);
    setDetail(null);
  }

  function loadTemplate() {
    setCsv(active.template);
    setError(null);
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setCsv(await f.text());
    if (f.name) setMsg(null);
  }

  async function run() {
    setBusy(true); setError(null); setMsg(null); setDetail(null);
    try {
      const res = await fetch("/api/migrate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, csv, period: period || undefined }),
      });
      const d = await res.json();
      if (d.ok) {
        setMsg(d.message);
        setDetail(
          [d.lines ? `${d.lines} journal lines (Dr ${Number(d.dr).toLocaleString()} / Cr ${Number(d.cr).toLocaleString()})` : "",
           d.created ? `${d.created} records created` : "",
           d.totalCost ? `Total cost ₵${Number(d.totalCost).toLocaleString()}` : "",
           d.skipped?.length ? `Skipped: ${d.skipped.join(", ")}` : "",
           d.errors?.length ? `Warnings: ${d.errors.join("; ")}` : ""].filter(Boolean).join(" · ")
        );
        setCsv("");
        router.refresh();
      } else setError(d.error);
    } catch {
      setError("Could not reach the import service.");
    }
    setBusy(false);
  }

  return (
    <Card
      title="Client Migration"
      sub="Onboard a real client: bring in their opening balances, customers, suppliers, payroll and assets from CSV."
    >
      <div className="mb-3 flex flex-wrap gap-1.5">
        {KINDS.map((k) => (
          <button key={k.id} onClick={() => pick(k.id)}
            className={cn("rounded-lg border px-3 py-2 text-[12.5px] font-semibold transition",
              kind === k.id ? "border-gold-400 bg-gold-400/15 text-gold-300" : "border-ink-600 text-mist-300 hover:border-gold-400/40")}>
            {k.label}
          </button>
        ))}
      </div>

      <div className="mb-3 grid gap-3 md:grid-cols-[1fr_auto]">
        <Field label="Expected columns">
          <div className={inputCls + " font-mono text-[12px] text-mist-400"}>{active.columns}</div>
        </Field>
        {kind === "opening_balances" && (
          <Field label="Opening period">
            <input type="month" className={inputCls + " font-mono text-xs"} value={period} onChange={(e) => setPeriod(e.target.value)} />
          </Field>
        )}
      </div>

      <div className="mb-3 rounded-lg border border-ink-700 bg-ink-900/50 p-3 text-[12.5px] leading-relaxed text-mist-400">
        {active.note}
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <button className={btn.tiny} onClick={loadTemplate}><Icon name="doc" size={13} /> Load template</button>
        <label className={btn.tiny + " cursor-pointer"}>
          <Icon name="download" size={13} /> Upload .csv
          <input type="file" accept=".csv,text/csv" onChange={onFile} className="hidden" />
        </label>
        {csv && <span className="text-[12px] text-mist-500">{csv.split("\n").length - 1} data rows loaded</span>}
      </div>

      <textarea
        className={inputCls + " min-h-[190px] font-mono text-[12px]"}
        placeholder="Paste CSV here, or load a template above…"
        value={csv}
        onChange={(e) => setCsv(e.target.value)}
      />

      <div className="mt-3 flex items-center justify-end gap-3">
        <button className={btn.gold} onClick={run} disabled={busy || !csv.trim()}>
          {busy ? "Importing…" : <><Icon name="check" size={15} /> Import</>}
        </button>
      </div>

      {msg && (
        <div className="mt-3 rounded-lg border border-pos/30 bg-pos/10 px-3 py-2.5 text-[12.5px] text-pos">
          <div className="font-semibold">{msg}</div>
          {detail && <div className="mt-1 text-[11.5px] text-mist-400">{detail}</div>}
        </div>
      )}
      {error && (
        <div className="mt-3 rounded-lg border border-neg/30 bg-neg/10 px-3 py-2 text-[12.5px] text-neg">{error}</div>
      )}
    </Card>
  );
}
